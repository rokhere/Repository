﻿/// <reference path="../Scripts/angular.min.js" />
var retailApp = angular.module('Retail', ['ngRoute', 'ngSanitize']);

retailApp.config(function ($locationProvider) {

    $locationProvider.html5Mode(true);
 
});


