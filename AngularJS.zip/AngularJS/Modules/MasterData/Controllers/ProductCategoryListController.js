﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataProductCategoryListCtrl', function ($scope, $http, $filter, $route, retailConstant, retailSecurityService) {
    $scope.pageName = "Master Data - Product Category List";
    $scope.SearchKeyword = "";
    $scope.ProductCategoryID = "";
    $scope.ProductCategoryListArray = [];


    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };

    $scope.GetCategoryList = function () {

        $http.get(retailConstant.serviceBaseUrl + "/MasterData/GetCategoryList?SearchKeyword=" + $scope.SearchKeyword).then(function (resp) {
            if (resp.data.length > 0) {
                $scope.ProductCategoryListArray = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    }

    $scope.SearchCategory = function () {

        $scope.GetCategoryList();
    }
    $scope.DeleteCategory = function (ProductCategoryID) {
        if (confirm("Are you sure to delete this Product Category?")) {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/DeleteCategory?ProductCategoryID=' + ProductCategoryID,
                //data: JSON.stringify(Category),
                dataType: "json"
            }).then(function (resp) {
                $scope.GetCategoryList();
                alert("Product Category deleted successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }
    };

    $scope.GetCategoryList();
});