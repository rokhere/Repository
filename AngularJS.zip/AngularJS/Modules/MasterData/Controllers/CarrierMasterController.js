﻿var retailMasterDataApp = angular.module('Retail');


retailMasterDataApp.controller('masterDataCarrierMasterCtrl', function ($scope, $q, $filter, $route, $http, $routeParams, $location, retailConstant, retailSecurityService) {

    
    $scope.btnText = "Submit";
    $scope.CarrierModel = { Carrier: '' };
    var requestPromise = [];

    $scope.showMessage = true;
    //local variable declaretion
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };

    $scope.regex = "^(http[s]?:\\/\\/){0,1}(www\\.){0,1}[a-zA-Z0-9\\.\\-]+\\.[a-zA-Z]{2,5}[\\.]{0,1}$";


    //methods//
    $scope.GetStateList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetStates').then(function (resp) {
            //console.log(resp.data.Data.length);
            if (resp.data.Data.length > 0) {
                $scope.StateArray = resp.data.Data;
            }

        }, function () { alert('Error in getting records'); })
    };
    $scope.GetCityList = function (StateID) {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetCitys?stateId=' + StateID).then(function (resp) {
            if (resp.data.Data.length > 0) {
                $scope.CityArray = resp.data.Data;

            }

        }, function () { alert('Error in getting records'); })
    };
    $scope.GetDistrictList = function (StateID) {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetDistricts?StateID=' + StateID).then(function (resp) {
            console.log(resp.data.Data);
            if (resp.data.Data.length > 0) {
                $scope.DistrictArray = resp.data.Data;
            }

        }, function () { alert('Error in getting records'); })
    };
    $scope.selectCity = function () {
        $scope.GetCityList($scope.CarrierModel.StateID);
    }
    $scope.selectDistrict = function () {
        $scope.GetDistrictList($scope.CarrierModel.StateID);
    }

    $scope.CarrierAddEdit = function (val, stock) {
        if (val == true) {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/AddEditCarrier',
                data: JSON.stringify(stock),
                dataType: "json"
            }).then(function (response) {
                //console.log(response);
                //  $scope.CarrierModel = "";

                if ($routeParams.CarrierID == null) {

                    if (response.data == "0") {
                        alert("Please insert Carrier properly");
                    } else {
                        $scope.resetCarrierModel();
                        alert("Carrier added successfully!!!");
                    }

                } else {

                    if (response.data == "0") {
                        alert("Please update Carrier properly");
                    } else {
                        alert("Carrier updated successfully!!!");
                    }
                    $location.path('/CarrierMasterList');
                }

            }, function (response) {
                alert(response.statusText);
            });


        }
        else {
            $scope.showMessage = true;
        }


    }
    $scope.resetCarrierModel = function () {
        $scope.CarrierModel = {};
    };

    //methods//


    //posting account popup.........................................

    $scope.accountArray = {};
    $scope.getPostingAccount = function () {

        var httpPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetPostingAccount').then(function (resp) {

            if (resp.data.length > 0) {
                $scope.accountArray = resp.data;
            }

        }, function () {
            alert('Error in getting records');
        })
        requestPromise.push(httpPromise);
    }

    $scope.openPopup = function (FilterFor, FilterBy) {

        console.log("FilterFor: " + FilterFor + "; FilterBy: " + FilterBy + ";");

        $scope.Row = {};
        $scope.Row.Active = false

        $scope.section = FilterFor;
        $scope.TempAccountArray = $scope.accountArray;

        if (FilterBy == undefined || FilterBy.length > 0) {
            $('#myModal').modal('show');
        } else {
            $('#myModal').modal('hide');
        }
    };

    $scope.selectRow = function (index) {

        if ($scope.section == "1") {
            $scope.CarrierModel.PostingAccountText = $scope.TempAccountArray[index].AcLedger;
            $scope.CarrierModel.AcLedgerID = $scope.TempAccountArray[index].AcLedgerID;
        }

        $('#myModal').modal('hide');
    };
    //posting account.........................................

    //Page load// 
    $scope.getPageLoadData = function () {
        $scope.GetStateList();
        $scope.getPostingAccount();

        $q.all(requestPromise).then(function (data) {
            if ($routeParams.CarrierID != null) {

                // Update PageLoad
                $scope.btnText = "Update";
                $scope.CarrierModel.CarrierID = $routeParams.CarrierID;

                $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSingleCarrier?CarrierID=' + $routeParams.CarrierID).then(function (resp) {
                    if (resp.data.length > 0) {
                        var selectedData = resp.data[0];
                        // $scope.tax.AppliedOn = selectedData.AppliedOn;
                        console.log(selectedData);
                        $scope.CarrierModel.Carrier = selectedData.Carrier;

                        $scope.CarrierModel.PostingAccountText = selectedData.PostingAccountText;
                        $scope.CarrierModel.PostingAccountText = $scope.getAcLedgerValue(selectedData.AcLedgerID);

                        $scope.CarrierModel.Address = selectedData.Address;
                        $scope.CarrierModel.AcLedgerID = selectedData.AcLedgerID;


                        $scope.CarrierModel.StateID = selectedData.StateID;
                        $scope.CarrierModel.StateName = selectedData.Branch;

                        $scope.CarrierModel.CityID = selectedData.CityID;
                        $scope.CarrierModel.City = selectedData.City;

                        $scope.GetCityList(selectedData.StateID);

                        $scope.CarrierModel.DistrictID = selectedData.DistrictID;
                        $scope.CarrierModel.District = selectedData.District;

                        $scope.GetDistrictList(selectedData.StateID);


                        $scope.CarrierModel.Locality = selectedData.Locality;
                        $scope.CarrierModel.PinCode = selectedData.Pincode;
                        $scope.CarrierModel.Phone = selectedData.Phone;
                        $scope.CarrierModel.Mobile = selectedData.Mobile;
                        $scope.CarrierModel.Fax = selectedData.Fax;
                        $scope.CarrierModel.Email = selectedData.Email;
                        $scope.CarrierModel.Website = selectedData.Website;
                        $scope.CarrierModel.ContactPerson = selectedData.ContactPerson;


                    }
                }, function () { alert('Error in getting records'); })

            }
        });

    };
    $scope.getAcLedgerValue = function (AcLedgerID) {
        //console.log($scope.accountArray);
        return $filter('filter')($scope.accountArray, { 'AcLedgerID': AcLedgerID })[0].AcLedger;
    }
    $scope.getPageLoadData();

    //Page load//
})