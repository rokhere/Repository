﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataAccountLedgerListCtrl', function ($scope, $http, $filter, $route, retailConstant, retailSecurityService) {
    $scope.showMessage = false;
    $scope.pageName = "Ledger Account";
    $scope.accountLedgerList = [];

    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };

    $scope.populateAccountLedgerList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetAccountLedgers').then(function (httpResponse) {
            var response = httpResponse.data;

            if (response.Status == 1) {
                $scope.accountLedgerList = response.Data;
            }

        });
    };

    $scope.delete_Onclick = function (acLedger) {

        if (confirm("Are you sure to delete this Account Ledger?")) {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/DeleteAccountLedger?accountLedgerId=' + acLedger.AcLedgerID
            }).then(function (httpResponse) {
                var response = httpResponse.data;
                if (response.Status == 1) {
                    var index = $scope.accountLedgerList.indexOf(acLedger);
                    $scope.accountLedgerList.splice(index, 1);
                }

                alert(response.Message);
            });
        }
        return false;
    };

    $scope.populateAccountLedgerList();
});