﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataOpeningStockEntryCtrl', function ($scope, $http, $filter, $route, $routeParams, retailConstant, retailSecurityService) {

    $scope.OpeningStockModel = {};
    $scope.OpeningStockArray = [];
    $scope.LocationArray = [];
    $scope.ProductArray = [];
    $scope.FilterProductModel = [];
    
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };


    $scope.CalculateGrossAmount = function () {        
        if ($scope.OpeningStockModel.Rate != null && $scope.OpeningStockModel.Qty != null) {            
            $scope.OpeningStockModel.GrossAmount = parseFloat($scope.OpeningStockModel.Rate) * parseFloat($scope.OpeningStockModel.Qty);
        }
    }

    $scope.PopulateLocationList = function () {
        //$http.get(retailConstant.serviceBaseUrl + '/MasterData/PopulateLocationListByProductID?ProductID=' + ProductID).then(function (resp) 
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/PopulateLocationList').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.LocationArray = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    };

    $scope.openPopup = function (FilterBy) {
        //$scope.Accounts = $filter('filter')($scope.Accounts, FilterBy);
        //if (FilterBy.length > 0) {
        $('#myModalProduct').modal('show');
        //}        
    };

    $scope.selectRowForProduct = function (ProductID) {

        

        $scope.FilterProductModel = $filter('filter')($scope.ProductArray, { 'ProductID': ProductID });

        $scope.OpeningStockModel.ProductID = $scope.FilterProductModel[0].ProductID;
        $scope.OpeningStockModel.ProductName = $scope.FilterProductModel[0].ProductName;

        $scope.OpeningStockModel.QtyUnit = $scope.FilterProductModel[0].PurchaseRateUnit;

        //$scope.OpeningStockModel.QtyUnit = $scope.ProductArray[index].SizeStrengthUnit;

        //$scope.PopulateLocationList($scope.ProductArray[index].ProductID);
       
        $('#myModalProduct').modal('hide');
    };

    $scope.PopulateProductList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetProductList').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.ProductArray = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    };



    $scope.SaveOpeningStock = function () {

        if ($scope.button == "Submit") {            
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/AddOpeningStock',
                data: JSON.stringify($scope.OpeningStockModel),
                dataType: "json"
            }).then(function (resp) {
                $scope.AccountGroups = null;
                alert("Opening Stock added successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }
        else if ($scope.button == "Update") {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/UpdateOpeningStock',
                data: JSON.stringify($scope.OpeningStockModel),
                dataType: "json"
            }).then(function (resp) {
                //$scope.AccountGroups = null;
                alert("Opening Stock update successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }


    };

    $scope.GetSingleOpeningStockList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSingleOpeningStockList?OpeningStockEntryID=' + $routeParams.OpeningStockEntryID).then(function (resp) {
            if (resp.data.length > 0) {
                $scope.OpeningStockModel.OpeningStockEntryID = resp.data[0].OpeningStockEntryID;
                $scope.OpeningStockModel.ProductID = resp.data[0].ProductID;
                $scope.OpeningStockModel.LocationID = resp.data[0].LocationID;
                $scope.OpeningStockModel.Qty = resp.data[0].Qty;
                $scope.OpeningStockModel.QtyUnit = resp.data[0].QtyUnit;
                $scope.OpeningStockModel.Rate = resp.data[0].Rate;
                $scope.OpeningStockModel.GrossAmount = resp.data[0].GrossAmount;
                $scope.OpeningStockModel.ManufacturingDate = resp.data[0].ManufacturingDate;
                $scope.OpeningStockModel.ExpiryDate = resp.data[0].ExpiryDate;
                $scope.OpeningStockModel.BatchCode = resp.data[0].BatchCode;
                $scope.OpeningStockModel.BarCode = resp.data[0].BarCode;
                $scope.OpeningStockModel.LotNo = resp.data[0].LotNo;
                $scope.OpeningStockModel.Manufacturer = resp.data[0].Manufacturer;
                $scope.OpeningStockModel.Remarks = resp.data[0].Remarks;
            }
        }, function () { alert('Error in getting records'); })
    }

    $scope.OpeningStockCheckAddEdit = function () {
        $scope.PopulateLocationList();
        $scope.PopulateProductList();
        
        if ($routeParams.OpeningStockEntryID != null) {
            $scope.HeadingText = "Edit";
            $scope.button = "Update";
            $scope.GetSingleOpeningStockList();
        }
        else {
            $scope.HeadingText = "Entry";
            $scope.button = "Submit";
        }
    }

    $scope.OpeningStockCheckAddEdit();

});