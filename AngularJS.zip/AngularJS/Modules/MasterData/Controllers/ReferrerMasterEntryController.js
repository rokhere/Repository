﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataReferrerMasterEntryCtrl', function ($scope, $http, $filter, $q, $route, $routeParams, retailConstant, retailSecurityService) {

    $scope.ReferrerMasterModel = { ReferredFor: '-1', CommissionType: '-1', CalcRate: '-1' };
    $scope.ReferrerMasterArray = [];
    $scope.StateArray = [];
    $scope.CityArray = [];
    $scope.DistrictArray = [];
    $scope.Accounts = {};
    $scope.AccountsArray = [];

    $scope.ReferredForArray =
        [
            { ReferredFor: "-1", ReferredForText: "Please select Referred For" },
            { ReferredFor: "1", ReferredForText: "Vendor" },
            { ReferredFor: "2", ReferredForText: "Customer" },
            { ReferredFor: "3", ReferredForText: "Both" }
        ];

    $scope.CommissionTypeArray =
       [
           { CommissionType: "-1", CommissionTypeText: "Please select Commission Type" },
           { CommissionType: "1", CommissionTypeText: "Cash" },
           { CommissionType: "2", CommissionTypeText: "Bank" },
           { CommissionType: "3", CommissionTypeText: "Others" }
       ];

    $scope.CalculatedOnArray =
       [
           { CalcRate: "-1", CalcRateText: "Please select Calculated On" },
           { CalcRate: "1", CalcRateText: "MRP" },
           { CalcRate: "2", CalcRateText: "Sales Rate" },
           { CalcRate: "3", CalcRateText: "Trade Rate" },
           { CalcRate: "4", CalcRateText: "Purchase Rate" },
           { CalcRate: "5", CalcRateText: "Actual Cost Rate" },
           { CalcRate: "6", CalcRateText: "Billing Rate" }

       ];

    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };
          
    $scope.$watch('ReferrerMasterModel.StateID', function (newValue, oldValue) {
        if (angular.isDefined(newValue)) {
            $scope.LoadStateCity();
        }
    });

    $scope.parseJsonDate = function (model) {
        // date format - /Date(1507573800000)/
        for (var property in model) {
            if (model.hasOwnProperty(property) && property.indexOf('Date') > -1) {
                var jsonDateString = model[property] || '';
                if (jsonDateString.length > 0) {
                    var date = new Date(parseInt(jsonDateString.substr(6)));
                    model[property] = $filter('date')(date, "dd/MM/yyyy");;
                }
            }
        }
    }

    $scope.GetAccount = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetPostingAccount').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.Accounts = resp.data;
                $scope.AccountsArray = resp.data;
            }
        }, function () { alert('Error in getting records'); })
    }

    $scope.openPopup = function (FilterBy) {
        //$scope.Accounts = $filter('filter')($scope.Accounts, FilterBy);
        //if (FilterBy.length > 0) {
        $('#myModalAccount').modal('show');
        //}        
    };

    $scope.selectRowForAccount = function (index) {
        $scope.ReferrerMasterModel.Account = $scope.Accounts[index].AcLedger;
        $scope.ReferrerMasterModel.AcLedgerID = $scope.Accounts[index].AcLedgerID;
        $('#myModalAccount').modal('hide');
    };

    $scope.GetStateList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetStates').then(function (resp) {
            if (resp.data.Data.length > 0) {
                $scope.StateArray = resp.data.Data;
            }

        }, function () { alert('Error in getting records'); })
    };

    $scope.GetCityList = function (httpResponse) {
        if (httpResponse.data.Data.length > 0) {
            $scope.CityArray = httpResponse.data.Data;
        }
    };

    $scope.GetDistrictList = function (httpResponse) {
        if (httpResponse.data.Data.length > 0) {
            $scope.DistrictArray = httpResponse.data.Data;
        }
    };

    $scope.selectCity = function () {
        $scope.GetCityList($scope.ReferrerMasterModel.StateID);
    }

    $scope.selectDistrict = function () {
        $scope.GetDistrictList($scope.ReferrerMasterModel.StateID);
    }

    $scope.LoadStateCity = function () {
        //debugger;

        var StateID = $scope.ReferrerMasterModel.StateID;
        if (angular.isDefined(StateID)) {
            var CityPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetCitys?StateID=' + StateID);
            var DistrictPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetDistricts?StateID=' + StateID);

            //Add to chain
            $scope.combinedPromise = $q.all({ CityArray: CityPromise, DistrictArray: DistrictPromise });
            //CombinedPromise then
            $scope.combinedPromise.then(function (responses) {
                //debugger;

                if (responses.CityArray) {
                    $scope.GetCityList(responses.CityArray);
                }

                if (responses.DistrictArray) {
                    $scope.GetDistrictList(responses.DistrictArray);
                }

            });
        }
    };

    $scope.SaveReferrerMaster = function () {

        if ($scope.button == "Submit") {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/AddReferrerMaster',
                data: JSON.stringify($scope.ReferrerMasterModel),
                dataType: "json"
            }).then(function (resp) {
                $scope.ReferrerMasterModel = null;
                alert("Referrer Master added successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }
        else if ($scope.button == "Update") {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/UpdateReferrerMaster',
                data: JSON.stringify($scope.ReferrerMasterModel),
                dataType: "json"
            }).then(function (resp) {
                //$scope.AccountGroups = null;
                alert("Referrer Master update successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }


    };

    $scope.GetSingleReferrerMasterList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSingleReferrerMasterList?ReferrerID=' + $routeParams.ReferrerID).then(function (resp) {
            if (resp.data.length > 0) {
                console.log(resp.data[0]);
                $scope.parseJsonDate(resp.data[0]);
                $scope.ReferrerMasterModel.ReferrerID = resp.data[0].ReferrerID;
                $scope.ReferrerMasterModel.Referrer = resp.data[0].Referrer;
                $scope.ReferrerMasterModel.Alias = resp.data[0].Alias;
                $scope.ReferrerMasterModel.RegNo = resp.data[0].RegNo;
                $scope.ReferrerMasterModel.Address = resp.data[0].Address;
                $scope.ReferrerMasterModel.Locality = resp.data[0].Locality;
                $scope.ReferrerMasterModel.PinCode = resp.data[0].PinCode;
                $scope.ReferrerMasterModel.CityID = resp.data[0].CityID;
                $scope.ReferrerMasterModel.DistrictID = resp.data[0].DistrictID;
                $scope.ReferrerMasterModel.StateID = resp.data[0].StateID;
                $scope.ReferrerMasterModel.Phone = resp.data[0].Phone;
                $scope.ReferrerMasterModel.Mobile = resp.data[0].Mobile;
                $scope.ReferrerMasterModel.Email = resp.data[0].Email;
                $scope.ReferrerMasterModel.Fax = resp.data[0].Fax;
                $scope.ReferrerMasterModel.Website = resp.data[0].Website;
                $scope.ReferrerMasterModel.ContactPerson = resp.data[0].ContactPerson;
                $scope.ReferrerMasterModel.AnniversaryDate = resp.data[0].AnniversaryDate;
                $scope.ReferrerMasterModel.DateOfBirth = resp.data[0].DateOfBirth;
                $scope.ReferrerMasterModel.BlanketCommission = resp.data[0].BlanketCommission == 1 ? true : false;
                //$scope.ReferrerMasterModel.BlanketCommission = resp.data[0].BlanketCommission;
                $scope.ReferrerMasterModel.CommissionRemarks = resp.data[0].CommissionRemarks;
                $scope.ReferrerMasterModel.CommissionType = resp.data[0].CommissionType;
                $scope.ReferrerMasterModel.CommissionRate = resp.data[0].CommissionRate;
                $scope.ReferrerMasterModel.CalcRate = resp.data[0].CalcRate;
                $scope.ReferrerMasterModel.AcLedgerID = resp.data[0].AcLedgerID;
                $scope.ReferrerMasterModel.ReferredFor = resp.data[0].ReferredFor;
                $scope.ReferrerMasterModel.ReferrerCategory = resp.data[0].ReferrerCategory;
                $scope.ReferrerMasterModel.CashDisc = resp.data[0].CashDisc;
                $scope.ReferrerMasterModel.CashDiscType = resp.data[0].CashDiscType;

            }
        }, function () { alert('Error in getting records'); })
    }

    $scope.ReferrerMasterCheckAddEdit = function () {
        
        $scope.GetStateList();
        $scope.LoadStateCity();
        $scope.GetAccount();
        if ($routeParams.ReferrerID != null) {
            $scope.HeadingText = "Edit";
            $scope.button = "Update";
            $scope.GetSingleReferrerMasterList();
        }
        else {
            $scope.HeadingText = "Entry";
            $scope.button = "Submit";
        }
    }

    $scope.ReferrerMasterCheckAddEdit();

})
.filter('unique', function () {
    return function (collection, keyname) {
        var output = [],
            keys = [];

        angular.forEach(collection, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });

        return output;
    };
});