﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataTaxTypeCtrl', function ($scope, $http, $route, retailConstant, retailSecurityService) {
    $scope.showMessage = false;
    $scope.pageName = "Tax Type";

    $scope.resetTaxTypeModel = function () {
        $scope.taxType = undefined;
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };

    $scope.submit_Onclick = function (formIsValid) {
        
        //TODO: Validation change
        if (formIsValid) {
            console.log('Server Call - SaveTaxType');
            var taxType = { TaxType1: $scope.taxType };

            $http.post(retailConstant.serviceBaseUrl + '/MasterData/SaveTaxType', JSON.stringify(taxType)).then(function (httpResponse) {
                var response = httpResponse.data;
                //TODO: Validation change
                if (response.Status == 1) {
                    $scope.taxType = undefined;
                }

                alert(response.Message);
            });
        } else {
            $scope.showMessage = true;
        }
    };

    //$scope.resetTaxTypeModel();
});