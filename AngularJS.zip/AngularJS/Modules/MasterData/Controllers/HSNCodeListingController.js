﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataHSNCodeListingCtrl', function ($scope, $http, $filter, $route, retailConstant, retailSecurityService) {
    //$scope.pageName = "Master Data - Page2";

    $scope.HsnArray = [];
    $scope.SearchKeyword = "";

    $scope.orderByField = 'HSNCode'; // set the default sort type
    $scope.reverseSort = false;  // set the default sort order
    //$scope.searchHSNCode = '';     // set the default search/filter term

    $scope.searchHSN = function () {

        $scope.getHSNSelectAll();
    }

    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };

    $scope.getHSNSelectAll = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetHSNSelectAll?SearchKeyword=' + $scope.SearchKeyword).then(function (response) {

            if (response.data.length > 0) {
                console.log(response.data);
                $scope.HsnArray = response.data;
            } else {
                $scope.HsnArray = "";
            }            

        }, function (response) { alert('Error in getting records'); })
    };

    $scope.getHSNSelectAll();

    $scope.deleteHsnCode = function (hsn, HSNID) {

        if (confirm("Are you sure to delete this HSN?")) {
            var index = $scope.HsnArray.indexOf(hsn);

            $http.post(retailConstant.serviceBaseUrl + '/MasterData/DeleteHsnCode?HSNID=' + HSNID)
            .then(function (resp) {
                $scope.HsnArray.splice(index, 1);
                alert("HSN Code deleted successfully!!!");
            }, function () { alert('Error in getting records'); })
        }
    };
    //$scope.sort = {
    //    column: 'HSNCode',
    //    descending: false
    //};

    //$scope.selectedCls = function (column) {
    //    return column == scope.sort.column && 'sort-' + scope.sort.descending;
    //};
    //$scope.changeSorting = function (column) {
    //    var sort = scope.sort;
    //    if (sort.column == column) {
    //        sort.descending = !sort.descending;
    //    } else {
    //        sort.column = column;
    //        sort.descending = false;
    //    }
    //};

})
    .filter('unique', function () {
    return function (collection, keyname) {
        var output = [],
            keys = [];

        angular.forEach(collection, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });

        return output;
    };
});