﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataProductCategoryGroupListCtrl', function ($scope, $http, $filter, $route, retailConstant, retailSecurityService) {
    $scope.pg = { ProductCategoryGroup: "", ProductCategoryGroupID: "", ProductCategoryParentGroup: "" };
    $scope.PGCArray = [];
    $scope.SearchKeyword = "";


    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };

    $scope.searchPGC = function () {
        $scope.populatePaggedGrid();
    }
   

    //$scope.fillProductGrid = function () {
    //    var tempSearch = ($scope.SearchKeyword != null ? $scope.SearchKeyword : '');
    //    $http.get("http://localhost:51327/MasterData/FillProductCatGrid?SearchKeyword=" + tempSearch).then(function (response) {
        
    //        if (response.data.length > 0) {                       
    //            $scope.getgrid = response.data;
    //            $("#dvNotFound").css('display', 'none');
    //        } else {
    //            $scope.getgrid = "";
    //            $("#dvNotFound").css('display', 'block');
    //        }
    //    });
    //}; 

    $scope.deleteProductCat = function (ProductCategoryID, index) {
        $http({
            method: 'POST',
            url: retailConstant.serviceBaseUrl + '/MasterData/deleteProductCat?ProductCategoryID=' + ProductCategoryID,
            dataType: "json"
        }).then(function (resp) {
            console.log(resp.data.Data);
            if (resp.data.Data == 0) {
                $scope.empModel = null;
                $scope.getgrid.splice(index, 1);
                alert("Category deleted successfully!");
            } else {
                alert("Category can not be deleted!");
            }
        }, function () {
            alert(data.errors);
        });

    };

    $scope.gocatentrypage = function () {
        $location.path('/ProductCategoryGroup');
    };



    $scope.getPages = function (num) {
        var pages = [];
        for (var i = 1; i <= num; i++) {
            pages.push(i);
        }

        return pages;
    }
    $scope.populatePaggedGrid = function () {
        var tempSearch = ($scope.SearchKeyword != null ? $scope.SearchKeyword : '');
       // pageNo = pageNo || 1;
        //$http.get(retailConstant.serviceBaseUrl + '/Dashboard/GetPagingData?pageNumber=' + pageNo).then(function (httpResponse) {
        //    var response = httpResponse.data;
        //    console.log(response);
        //    if (response.Status == 1) {
        //        $scope.dataPage = response.Data;
        //    }
        //});
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/FillProductCatGrid?SearchKeyword=' + tempSearch).then(function (response) {
            if (response.data.Data.length > 0) {
                $scope.getgrid = response.data.Data;
                $scope.getPageSize = response.data.PageCount;
                $("#dvNotFound").css('display', 'none');
            } else {
                $scope.getgrid = "";
                $("#dvNotFound").css('display', 'block');
            }
        });


    }
   // $scope.fillProductGrid();
    $scope.populatePaggedGrid();
});