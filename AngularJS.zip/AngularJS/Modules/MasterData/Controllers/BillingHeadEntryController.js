﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataBillingHeadEntryCtrl', function ($scope, $http, $filter, $route, $routeParams, retailConstant, retailSecurityService) {

    $scope.BillingHeadModel = {};
    $scope.BillingHeadArray = [];
    $scope.Accounts = {};
    $scope.AccountsArray = [];
    $scope.AddLessList =
        [
            { AddLessValue: "-1", BillingHeadAddLess: "Please select Add / Less" },
            { AddLessValue: "1", BillingHeadAddLess: "Add" },
            { AddLessValue: "2", BillingHeadAddLess: "Less" }
        ];

    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };

    $scope.openPopup = function (FilterBy) {
        //$scope.Accounts = $filter('filter')($scope.Accounts, FilterBy);
        //if (FilterBy.length > 0) {
        $('#myModalAccount').modal('show');
        //}        
    };

    $scope.selectRowForAccount = function (index) {
        $scope.BillingHeadModel.Account = $scope.Accounts[index].AcLedger;
        $scope.BillingHeadModel.AcLedgerID = $scope.Accounts[index].AcLedgerID;
        $('#myModalAccount').modal('hide');
    };

    $scope.GetAccount = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetPostingAccount').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.Accounts = resp.data;
                $scope.AccountsArray = resp.data;
            }
        }, function () { alert('Error in getting records'); })
    }

    $scope.SaveBillingHead = function () {

        if ($scope.button == "Submit") {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/AddBillingHead',
                data: JSON.stringify($scope.BillingHeadModel),
                dataType: "json"
            }).then(function (resp) {
                $scope.AccountGroups = null;
                alert("Billing Head added successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }
        else if ($scope.button == "Update") {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/UpdateBillingHead',
                data: JSON.stringify($scope.BillingHeadModel),
                dataType: "json"
            }).then(function (resp) {
                //$scope.AccountGroups = null;
                alert("Billing Head update successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }


    };

    $scope.GetSingleBillingHeadList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSingleBillingHeadList?BillingHeadID=' + $routeParams.BillingHeadID).then(function (resp) {
            if (resp.data.length > 0) {
                $scope.BillingHeadModel.BillingHeadID = resp.data[0].BillingHeadID;
                $scope.BillingHeadModel.BillingHead = resp.data[0].BillingHead;
                $scope.BillingHeadModel.Account = resp.data[0].AcLedger;
                $scope.BillingHeadModel.BillingHeadAddLess = resp.data[0].BillingHeadAddLess;
            }
        }, function () { alert('Error in getting records'); })
    }

    $scope.BillingHeadCheckAddEdit = function () {
        $scope.GetAccount();       
        if ($routeParams.BillingHeadID != null) {
            $scope.HeadingText = "Edit";
            $scope.button = "Update";
            $scope.GetSingleBillingHeadList();
        }
        else {
            $scope.HeadingText = "Entry";
            $scope.button = "Submit";
        }
    }

    $scope.BillingHeadCheckAddEdit();

})
.filter('unique', function () {
    return function (collection, keyname) {
        var output = [],
            keys = [];

        angular.forEach(collection, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });

        return output;
    };
});