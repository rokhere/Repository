﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataReferrerMasterListCtrl', function ($scope, $http, $filter, $route, retailConstant, retailSecurityService) {
    $scope.pageName = "Referrer Master";
    $scope.ReferrerMasterModel = {};

    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };

    $scope.populateReferrerMaster = function (SearchKeyword) {

        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetReferrerMasterList?SearchKeyword=' + SearchKeyword).then(function (resp) {
            if (resp.data.length > 0) {
                $scope.ReferrerMasterModel = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    }

    $scope.DeleteReferrerMaster = function (ReferrerID) {
        $http({
            method: 'POST',
            url: retailConstant.serviceBaseUrl + '/MasterData/DeleteReferrerMaster?ReferrerID=' + ReferrerID,
            //data: JSON.stringify(Category),
            dataType: "json"
        }).then(function (resp) {
            //$scope.empModel = null;
            $scope.populateReferrerMaster('');
            alert("Referrer Master deleted successfully!!!");
        }, function () {
            alert(data.errors);
        });

    };

    $scope.populateReferrerMaster('');
});