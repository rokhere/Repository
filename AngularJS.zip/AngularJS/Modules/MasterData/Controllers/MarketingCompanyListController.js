﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('marketingCompanyMasterListCtrl', function ($scope, $http, $route, $routeParams, $filter, $q, retailConstant, retailMessageService, retailSecurityService) {
   
    $scope.populateListing = function () {
        //////      
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetMarketingCompanySelectAll').then(function (resp) {
            if (resp) {
                var response = resp.data;                        
                $scope.MarketingCompanyListCollection = resp.data || [];
            }
        });

    }


    $scope.deleteMarketingCompany = function (item, MktCompanyID) {
        var index = $scope.MarketingCompanyListCollection.indexOf(item);
        $http.post(retailConstant.serviceBaseUrl + '/MasterData/MarketingCompanyDelete?MktCompanyID=' + MktCompanyID)
        .then(function (resp) {
            $scope.MarketingCompanyListCollection.splice(index, 1);
            alert("Marketing company deleted successfully!!!");
        }, function () { alert('Error in getting records'); })
    };


    $scope.populateListing();

});