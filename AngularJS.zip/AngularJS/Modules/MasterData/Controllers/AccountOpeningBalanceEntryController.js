﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataAccountOpeningBalanceEntryCtrl', function ($scope, $filter, $http, $route, $routeParams, retailConstant, retailSecurityService) {

    $scope.FilterBy = "";
    $scope.AccountOpeningBalances = { DrCr: '-1' };
    $scope.Location = {};
    $scope.LocationArray = [];
    $scope.Accounts = {};
    $scope.AccountsArray = [];
    $scope.DrCrList =
           [
               { DrCrValue: "-1", DrCr: "Select Dr / Cr" },
               { DrCrValue: "1", DrCr: "Debit" },
               { DrCrValue: "2", DrCr: "Credit" }
           ];

    $scope.FinalFilterAccountModel = [];

    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };


    $scope.GetAccount = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetPostingAccount').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.Accounts = resp.data;
                $scope.AccountsArray = resp.data;
            }
        }, function () { alert('Error in getting records'); })
    }

    $scope.GetLocation = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetLocation').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.Location = resp.data;
                $scope.LocationArray = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    };

    $scope.GetSingleOpeningBalanceList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSingleAcOpeningBalancesList?AcOpeningBalanceID=' + $routeParams.AcOpeningBalanceID).then(function (resp) {
            if (resp.data.length > 0) {
                $scope.AccountOpeningBalances.AcOpeningBalanceID = $routeParams.AcOpeningBalanceID;
                $scope.AccountOpeningBalances.OpeningBalance = resp.data[0].OpeningBalance;
                $scope.AccountOpeningBalances.Direction = resp.data[0].Direction;
                $scope.AccountOpeningBalances.Account = resp.data[0].ACCOUNT;
                $scope.AccountOpeningBalances.StockLocation = resp.data[0].StockLocation;
            }
        }, function () { alert('Error in getting records'); })
    }

    $scope.AccountOpeningBalancesCheckAddEdit = function () {        
        if ($routeParams.AcOpeningBalanceID != null) {
            $scope.HeadingText = "Edit";
            $scope.button = "Update";
            $scope.GetSingleOpeningBalanceList();
            $scope.GetAccount();
            $scope.GetLocation();
        }
        else {
            $scope.HeadingText = "Entry";
            $scope.button = "Submit";
            $scope.GetAccount();
            $scope.GetLocation();   
        }
    }

    //Assign in the Location popup
    $scope.change = function (FilterBy) {
        //$scope.Location = $filter('filter')($scope.Location, FilterBy);
        //if (FilterBy.length > 0) {           
        //}
        $('#myModal').modal('show');
    };

    //Selected Radio Button Value from Location dropdown
    $scope.selectRow = function (index) {

        //alert($scope.Location[index].BranchID);
        $scope.AccountOpeningBalances.StockLocation = $scope.Location[index].StockLocation;
        $scope.AccountOpeningBalances.LocationID = $scope.Location[index].LocationID;
        $scope.AccountOpeningBalances.BranchID = $scope.Location[index].BranchID;
        $('#myModal').modal('hide');
    };
   

    $scope.openPopup = function (FilterBy) {
        //$scope.Accounts = $filter('filter')($scope.Accounts, FilterBy);
        //if (FilterBy.length > 0) {
        $('#myModalAccount').modal('show');
        //}        
    };

    $scope.selectRowForAccount = function (AcLedgerID) {

        $scope.FinalFilterAccountModel = $filter('filter')($scope.Accounts, { 'AcLedgerID': AcLedgerID });
        $scope.AccountOpeningBalances.Account = $scope.FinalFilterAccountModel[0].AcLedger;
        $scope.AccountOpeningBalances.AcLedgerID = $scope.FinalFilterAccountModel[0].AcLedgerID;
        $('#myModalAccount').modal('hide');
    };

    $scope.SaveAccountOpeningBalances = function () {

        if ($scope.button == "Submit") {            
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/AddAccountOpeningBalances',
                data: JSON.stringify($scope.AccountOpeningBalances),
                dataType: "json"
            }).then(function (resp) {
                //$scope.AccountOpeningBalances = null;
                //console.log($scope.AccountOpeningBalances);
                //alert($scope.AccountOpeningBalances);
                alert("Account Opening Balances added successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }
        else if ($scope.button == "Update") {            
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/UpdateAccountOpeningBalances',
                data: JSON.stringify($scope.AccountOpeningBalances),
                dataType: "json"
            }).then(function (resp) {
                alert("Account Opening Balances update successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }


    };

    $scope.AccountOpeningBalancesCheckAddEdit();
})


.filter('unique', function () {
    return function (collection, keyname) {
        var output = [],
            keys = [];

        angular.forEach(collection, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });

        return output;
    };
});