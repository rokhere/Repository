﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataCustomerMasterListCtrl', function ($scope, $http, $filter, $route, retailConstant, retailSecurityService) {
    $scope.pageName = "Customer Master";
    $scope.CustomerMasterModel = {};
    $scope.CustomerMasterArray = [];
    $scope.SearchModel = { SearchKeyword: '', pageNo: 1 };
    $scope.currentPage = 0;
    $scope.pageSize = 2;
    $scope.data = [];
    $scope.q = '';
    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };

    $scope.populateCustomerMaster = function (SearchModel) {

        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetCustomerMasterList?SearchKeyword=' + SearchModel.SearchKeyword + '&pageNo=' + SearchModel.pageNo).then(function (resp) {
            if (resp.data.length > 0) {
                $scope.CustomerMasterModel = resp.data;
                $scope.CustomerMasterArray = resp.data;
                $scope.getPageSize = resp.data[0].pagesize;
                $filter('filter')($scope.data, $scope.q)
            }

        }, function () { alert('Error in getting records'); })
    }

    $scope.DeleteCustomerMaster = function (CustomerMasterID) {
        $http({
            method: 'POST',
            url: retailConstant.serviceBaseUrl + '/MasterData/DeleteCustomerMaster?CustomerMasterID=' + CustomerMasterID,
            //data: JSON.stringify(Category),
            dataType: "json"
        }).then(function (resp) {
            //$scope.empModel = null;
            $scope.populateCustomerMaster('');
            alert("Customer Master deleted successfully!!!");
        }, function () {
            alert(data.errors);
        });

    };

    $scope.getPages = function (num) {
        var pages = [];
        for (var i = 1; i <= num; i++) {
            pages.push(i);
        }

        return pages;
    }

    $scope.populateCustomerMaster($scope.SearchModel);
});