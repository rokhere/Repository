﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataAccountGroupListCtrl', function ($scope, $http, $filter, $route, retailConstant, retailSecurityService) {
    $scope.pageName = "Account Group";

    //$scope.SearchKeyword = "";
    //$scope.NatureOfAccount = "";
    //$scope.AccountType = "";
    $scope.SearchModel = { SearchKeyword: '', NatureOfAccount: '-1', AccountType: '-1' };

    $scope.AccountGroups = [];    
    //$scope.SearchModel = {};

    $scope.NOfAccList =
        [
            { NatureOfAccountID: "-1", NatureOfAccount: "Please select Account Nature" },
            { NatureOfAccountID: "1", NatureOfAccount: "Asset" },
            { NatureOfAccountID: "2", NatureOfAccount: "Liability" },
            { NatureOfAccountID: "3", NatureOfAccount: "Income" },
            { NatureOfAccountID: "4", NatureOfAccount: "Expense" }
        ];    

    $scope.AccTypeList =
       [
           { AccTypeID: "-1", AccountType: "Please select Account Type" },
           { AccTypeID: "1", AccountType: "Cash" },
           { AccTypeID: "2", AccountType: "Bank" },
           { AccTypeID: "3", AccountType: "Others" }
       ];    

    //$scope.populateAccountGroups = function (SearchModel) {
       
    //    $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetAccountGroupList?SearchKeyword=' + SearchModel.SearchKeyword + '&NatureOfAccount=' + SearchModel.NatureOfAccount + '&AccountType=' + SearchModel.AccountType).then(function (httpResponse) {
    //    //$http.get(retailConstant.serviceBaseUrl + '/MasterData/GetAccountGroupList?objSearchModel='+SearchModel).then(function (httpResponse) {
    //        var response = httpResponse.data;
    //        if (response.Status == 1) {
    //            $scope.AccountGroups = response.Data;
    //        }
    //    });
    //};

    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };

    $scope.populateAccountGroups = function (SearchModel) {

        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetAccountGroupList?SearchKeyword=' + SearchModel.SearchKeyword + '&NatureOfAccount=' + SearchModel.NatureOfAccount + '&AccountType=' + SearchModel.AccountType).then(function (resp) {
            if (resp.data.length > 0) {
                $scope.AccountGroups = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    }

    $scope.DeleteAccountGroup = function (AcGroupID) {

        if (confirm("Are you sure to delete this Account Group?")) {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/DeleteAccountGroups?AcGroupID=' + AcGroupID,
                //data: JSON.stringify(Category),
                dataType: "json"
            }).then(function (resp) {
                $scope.empModel = null;
                alert("Account Group deleted successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }
    };

    $scope.populateAccountGroups($scope.SearchModel);
});