﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataStockLocationCtrl', function ($scope, $q, $filter, $http, $route, $routeParams, $location, retailConstant, retailSecurityService) {
    $scope.pageName = "Master Data - Product Category";
    $scope.btnText = "Submit";
    $scope.section = "";
    $scope.BranchArray = [];
    $scope.PostingAccountArray = [];
    $scope.StateArray = [];
    $scope.CityArray = [];
    $scope.DistrictArray = [];
    var requestPromise = [];
    $scope.StockLocationModel = {};
    //$scope.StockLocationModel = {
    //    StockLocation: '', Alias: '', Branch: '', PostingAccountText: '', Address: '', State: '', City: '', District: '', Locality: ''
    //    , PinCode: '', Mobile: '', Fax: '', Email: '', Website: '', ContactPerson: '' };

    //$scope.resetTaxRateModel = function () {
    //    $scope.taxRateDetailModel = {
    //        StockLocation: '', Alias: '', Branch: '', PostingAccount: '', Address: '', State: '', City: '', District: '', Locality: ''
    //    , PinCode: '', Mobile: '', Fax: '', Email: '', Website: '', ContactPerson: ''
    //    };
    //};

    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };

    $scope.SetAllCheckBoxDefaultStatus = function () {
        $scope.StockLocationModel.IsAllProduct = true;
        $scope.StockLocationModel.IsAllCustomer = true;
        $scope.StockLocationModel.IsAllVendor = true;
        $scope.StockLocationModel.IsAllAccount = true;
        $scope.StockLocationModel.IsBillingLocation = true;
    };


    $scope.GetBranchList = function () {
        //$http.get("http://localhost:51327/MasterData/GetBranchList").then(function (resp) {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetBranchList').then(function (resp) {
            console.log(resp.data.Data.length);
            if (resp.data.Data.length > 0) {
                $scope.BranchArray = resp.data.Data;
            }

        }, function () { alert('Error in getting records'); })
    };

    $scope.GetPostingAccountList = function () {
        $http.get(retailConstant.serviceBaseUrl +'/MasterData/GetPostingAccountList').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.PostingAccountArray = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    };
    $scope.GetStateList = function () {
        $http.get(retailConstant.serviceBaseUrl +'/MasterData/GetStates').then(function (resp) {         
            //console.log(resp.data.Data.length);
            if (resp.data.Data.length > 0) {               
                $scope.StateArray = resp.data.Data;               
            }

        }, function () { alert('Error in getting records'); })
    };
    $scope.GetCityList = function (StateID) {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetCitys?stateId=' + StateID).then(function (resp) {
            if (resp.data.Data.length > 0) {              
                $scope.CityArray = resp.data.Data;
               
            }

        }, function () { alert('Error in getting records'); })
    };
    $scope.GetDistrictList = function (StateID) {
        $http.get(retailConstant.serviceBaseUrl +'/MasterData/GetDistricts?StateID=' + StateID).then(function (resp) {
            console.log(resp.data.Data);
            if (resp.data.Data.length > 0) {
                $scope.DistrictArray = resp.data.Data;
            }

        }, function () { alert('Error in getting records'); })
    };
    $scope.selectCity = function () {
        $scope.GetCityList($scope.StockLocationModel.StateID);
    }
    $scope.selectDistrict = function () {
        $scope.GetDistrictList($scope.StockLocationModel.StateID);
    }


    //posting account popup.........................................

    $scope.accountArray = {};
    $scope.getPostingAccount = function () {

        var httpPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetPostingAccount').then(function (resp) {      

            if (resp.data.length > 0) {
                $scope.accountArray = resp.data;              
            }

        }, function () {         
            alert('Error in getting records');
        })     
        requestPromise.push(httpPromise);
    }

    $scope.openPopup = function (FilterFor, FilterBy) {

        console.log("FilterFor: " + FilterFor + "; FilterBy: " + FilterBy + ";");

        $scope.Row = {};
        $scope.Row.Active = false

        $scope.section = FilterFor;
        $scope.TempAccountArray = $scope.accountArray;      

        if (FilterBy == undefined || FilterBy.length > 0) {
            $('#myModal').modal('show');
        } else {
            $('#myModal').modal('hide');
        }
    };

    $scope.selectRow = function (index) {     

        if ($scope.section == "1") {
            $scope.StockLocationModel.PostingAccountText = $scope.TempAccountArray[index].AcLedger;
            $scope.StockLocationModel.AcLedgerID = $scope.TempAccountArray[index].AcLedgerID;
        }          
       
        $('#myModal').modal('hide');
    };
    //posting account.........................................

    //start insert stock location
    $scope.StockLocationAddEdit = function (stock) {     

        $http({
            method: 'POST',
            url: retailConstant.serviceBaseUrl + '/MasterData/AddEditStockLocation',
            data: JSON.stringify(stock),
            dataType: "json"
        }).then(function (httpResponse) {
            var response = httpResponse.data;
            alert(response.Message);
            $scope.resetStockLocation();
            if (response.Status == 1) {
                if ($routeParams.LocationID != null) {
                    $location.path('/StockLocationList');
                }
            }

        }, function (response) {
            alert(response.statusText);
        });      

    }
    $scope.resetStockLocation = function () {
        $scope.StockLocationModel = {};
    };
    //end insert stock location

      //Page load 
    $scope.getPageLoadData = function () {
        $scope.GetStateList();
        $scope.GetBranchList();
        $scope.getPostingAccount();

        $q.all(requestPromise).then(function (data) {
            if ($routeParams.LocationID != null) {

                // Update PageLoad
                $scope.btnText = "Update";
                $scope.StockLocationModel.LocationID = $routeParams.LocationID;

                $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSingleStockLocation?LocationID=' + $routeParams.LocationID).then(function (resp) {
                    if (resp.data.length > 0) {
                        var selectedData = resp.data[0];
                        // $scope.tax.AppliedOn = selectedData.AppliedOn;
                        console.log(selectedData);
                        $scope.StockLocationModel.StockLocation = selectedData.StockLocation;
                        $scope.StockLocationModel.Alias = selectedData.Alias;
                        // $scope.BindDisplayText(selectedData.IsWithinState, selectedData.BranchID, selectedData.TaxRateDetailID);

                        $scope.StockLocationModel.IsAllProduct = selectedData.IsAllProduct;
                        $scope.StockLocationModel.IsAllCustomer = selectedData.IsAllCustomer;
                        $scope.StockLocationModel.IsAllVendor = selectedData.IsAllVendor;
                        $scope.StockLocationModel.IsAllAccount = selectedData.IsAllAccount;
                        $scope.StockLocationModel.IsBillingLocation = selectedData.IsBillingLocation;



                        
                        $scope.StockLocationModel.BranchID = selectedData.BranchID;
                        $scope.StockLocationModel.Branch = selectedData.Branch;  
                        $scope.StockLocationModel.PostingAccountText = selectedData.PostingAccountText;                     
                        $scope.StockLocationModel.PostingAccountText = $scope.getAcLedgerValue(selectedData.AcLedgerID);
                        $scope.StockLocationModel.Address = selectedData.Address;
                        $scope.StockLocationModel.AcLedgerID = selectedData.AcLedgerID;   


                        $scope.StockLocationModel.StateID = selectedData.StateID;
                        $scope.StockLocationModel.StateName = selectedData.Branch;

                        $scope.StockLocationModel.CityID = selectedData.CityID;
                        $scope.StockLocationModel.City = selectedData.City;
                        

                        $scope.GetCityList(selectedData.StateID);
                       



                        $scope.StockLocationModel.DistrictID = selectedData.DistrictID;
                        $scope.StockLocationModel.District = selectedData.District;

                        $scope.GetDistrictList(selectedData.StateID);


                        $scope.StockLocationModel.Locality = selectedData.Locality;
                        $scope.StockLocationModel.PinCode = selectedData.PinCode;
                        $scope.StockLocationModel.Phone = selectedData.Phone;
                        $scope.StockLocationModel.Mobile = selectedData.Mobile;
                        $scope.StockLocationModel.Fax = selectedData.Fax;
                        $scope.StockLocationModel.Email = selectedData.Email;
                        $scope.StockLocationModel.Website = selectedData.Website;
                        $scope.StockLocationModel.ContactPerson = selectedData.ContactPerson;


                    }
                }, function () { alert('Error in getting records'); })

            }
        });

    };
    $scope.getAcLedgerValue = function (AcLedgerID) {
        //console.log($scope.accountArray);
        return $filter('filter')($scope.accountArray, { 'AcLedgerID': AcLedgerID })[0].AcLedger;
    }

    $scope.SetAllCheckBoxDefaultStatus();
    $scope.getPageLoadData();


    //Page load
})