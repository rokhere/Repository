﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataAccountLedgerCtrl', function ($scope, $http, $route, $routeParams, $filter, $q, retailConstant, retailMessageService, retailSecurityService) {
    //Property
    $scope.showMessage = false;
    $scope.pageName = "Ledger Account";
    $scope.states = [];
    $scope.districts = [];
    $scope.citys = [];
    $scope.accountGroups = [];
    $scope.accLedgerModel = {};
    $scope.selectedAccountGroup = undefined;
    $scope.combinedPromise = undefined;
    $scope.$watch('accLedgerModel.AcGroupID', function (newValue, oldValue) {
        var accGroup = $filter('filter')($scope.accountGroups, { AcGroupID: newValue });
        if (accGroup.length > 0) {
            $scope.selectedAccountGroup = accGroup[0];
        }
    });

    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };

    //Methods
    $scope.populateStates = function (httpResponse) {
        $scope.districts = [];
        $scope.citys = [];

        var response = httpResponse.data;
        if (response.Status == 1) {
            $scope.states = response.Data;
        }
    };
    $scope.populateAccountGroups = function (httpResponse) {
        var response = httpResponse.data;

        if (response.Status == 1) {
            $scope.accountGroups = response.Data;
        }
    };
    $scope.parseJsonDate = function (model) {
        // date format - /Date(1507573800000)/
        for (var property in model) {
            if (model.hasOwnProperty(property) && property.indexOf('Date') > -1) {
                var jsonDateString = model[property] || '';
                if (jsonDateString.length > 0) {
                    var date = new Date(parseInt(jsonDateString.substr(6)));
                    model[property] = $filter('date')(date, "dd/MM/yyyy");;
                }
            }
        }
    }
    $scope.populateAccLedgerModel = function (httpResponse) {
        var response = httpResponse.data;

        if (response.Status == 1 && response.Data.length > 0) {
            var model = response.Data[0];

            //Format JSon Date
            $scope.parseJsonDate(model);

            model.AcLedger1 = model.AcLedger;

            $scope.accLedgerModel = model;

            $scope.state_OnChange(model.StateID);

            console.log($scope.accLedgerModel);

            //delete not required attrs
            delete $scope.accLedgerModel.CreateDate;
            delete $scope.accLedgerModel.UpdateDate;
            delete $scope.accLedgerModel.AcLedger;
        }

    };
    $scope.onLoad = function () {
        //Ref. https://stackoverflow.com/questions/28319775/make-multiple-http-calls-synchronously-in-angularjs

        //States
        var statePromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetStates');

        //AccountGroups
        var accountGroupPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetAccountGroups');

        //AccLedgerModel
        var accountLedgerId = $routeParams.accountLedgerId;
        if (angular.isDefined(accountLedgerId)) {
            var accountLedgerPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetAccountLedger?accountLedgerId=' + accountLedgerId);

            //Add to chain
            $scope.combinedPromise = $q.all({
                state: statePromise,
                accountGroup: accountGroupPromise,
                accountLedger: accountLedgerPromise
            });
        } else {
            //Add to chain
            $scope.combinedPromise = $q.all({
                state: statePromise,
                accountGroup: accountGroupPromise
            });
        }


        //CombinedPromise then
        $scope.combinedPromise.then(function (responses) {
            console.log(responses);

           

            if (responses.accountLedger) {
                $scope.populateAccLedgerModel(responses.accountLedger);
            }

            if (responses.state) {
                $scope.populateStates(responses.state);
            }

            if (responses.accountGroup) {
                $scope.populateAccountGroups(responses.accountGroup);
            }

        });
    };

    //Events
    $scope.accountGroup_OnChange = function (item) {
        $scope.accLedgerModel.AcGroupID = item.AcGroupID;
        $scope.accLedgerModel.AcNature = item.AcNature;
        $scope.accLedgerModel.CashBankType = item.CashBankType;
    };
    $scope.state_OnChange = function (stateId) {

        $scope.districts = [];
        $scope.citys = [];
        stateId = stateId || 0;

        if (stateId > 0) {
            //Pupulate Districts
            $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetDistricts/?stateId=' + stateId).then(function (httpResponse) {
                var response = httpResponse.data;

                if (response.Status == 1) {
                    $scope.districts = response.Data;
                }

            });

            //Populate Citys
            $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetCitys/?stateId=' + stateId).then(function (httpResponse) {
                var response = httpResponse.data;

                if (response.Status == 1) {
                    $scope.citys = response.Data;
                }

            });
        }
    };
    $scope.cashBankType_OnChange = function () {
        $scope.accLedgerModel.BankAcNo = undefined;
        $scope.accLedgerModel.BankAcName = undefined;
        $scope.accLedgerModel.BankBranch = undefined;
        $scope.accLedgerModel.BankIFSC = undefined;
    };
    $scope.submit_Onclick = function (formIsValid) {

        //TODO: Validation change
        if (formIsValid) {
            console.log($scope.accLedgerModel);

            $http.post(retailConstant.serviceBaseUrl + '/MasterData/SaveAccountLedger', JSON.stringify($scope.accLedgerModel)).then(function (httpResponse) {
                var response = httpResponse.data;

                //TODO: Validation change
                if (response.Status == 1) {
                    $scope.accLedgerModel = {};
                    $scope.selectedAccountGroup = null;
                    //retailMessageService.showSuccessMessage(response.Message);
                    alert("Ledger Account added successfully!!!");

                } else {
                    //retailMessageService.showErrorMessage(response.Message);
                    alert("Account Ledger Not Saved!!!");
                }

                //alert(response.Message);
            });
        } else {
            $scope.showMessage = true;
        }
    };

    //OnLoad
    $scope.onLoad();
});