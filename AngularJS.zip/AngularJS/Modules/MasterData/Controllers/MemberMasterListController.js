﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataMemberMasterListCtrl', function ($scope, $http, $filter, $route, retailConstant, retailSecurityService) {
    $scope.pageName = "Member Master";
    $scope.MemberMasterModel = {};

    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };

    $scope.populateMemberMaster = function (SearchKeyword) {

        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetMemberMasterList?SearchKeyword=' + SearchKeyword).then(function (resp) {
            if (resp.data.length > 0) {
                $scope.MemberMasterModel = resp.data;                
            }

        }, function () { alert('Error in getting records'); })
    }

    $scope.SearchMember = function () {
        $scope.populateMemberMaster(SearchKeyword);
    }

    $scope.DeleteMemberMaster = function (MemberId) {        
        $http({
            method: 'POST',
            url: retailConstant.serviceBaseUrl + '/MasterData/DeleteMemberMaster?MemberId=' + MemberId,
            //data: JSON.stringify(Category),
            dataType: "json"
        }).then(function (resp) {
            //$scope.empModel = null;
            $scope.populateMemberMaster('');
            alert("Member Master deleted successfully!!!");
        }, function () {
            alert(data.errors);
        });

    };

    $scope.populateMemberMaster('');
});