﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('marketingCompanyGroupListCtrl', function ($scope, $http, $route, $routeParams, $filter, $q, retailConstant, retailMessageService, retailSecurityService) {
   
    $scope.populateListing = function () {
        //////      
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetMarketingCompanyGroupSelectAll').then(function (resp) {
            if (resp) {
                var response = resp.data;
                $scope.MarketingCompanyListCollection = resp.data || [];
            }
        });

    }


    $scope.deleteMarketingCompany = function (item, MktGroupID) {
        var index = $scope.MarketingCompanyListCollection.indexOf(item);
        $http.post(retailConstant.serviceBaseUrl + '/MasterData/MarketingCompanyGroupDelete?MktGroupID=' + MktGroupID)
        .then(function (resp) {
            $scope.MarketingCompanyListCollection.splice(index, 1);
            alert("Marketing group deleted successfully!!!");
        }, function () { alert('Error in getting records'); })
    };


    $scope.populateListing();

});