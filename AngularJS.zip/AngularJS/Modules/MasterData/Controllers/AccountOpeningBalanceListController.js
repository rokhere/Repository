﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataAccountOpeningBalanceListCtrl', function ($scope, $http, $filter, $route, retailConstant, retailSecurityService) {
    $scope.pageName = "Account Opening Balance List";

    $scope.AccountOpeningBalances = [];
    $scope.SearchModel = { SearchKeyword: ''};

    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };

    $scope.populateAccountOpeningBalances = function (SearchModel) {

        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetAccountOpeningBalancesList?SearchKeyword=' + SearchModel.SearchKeyword).then(function (resp) {
            if (resp.data.length > 0) {
                $scope.AccountOpeningBalances = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    }


    $scope.DeleteAccountOpeningBalance = function (AcOpeningBalanceID) {
        if (confirm("Are you sure to delete this Account Opening Balance?")) {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/DeleteAccountOpeningBalance?AcOpeningBalanceID=' + AcOpeningBalanceID,
                //data: JSON.stringify(Category),
                dataType: "json"
            }).then(function (resp) {
                //$scope.empModel = null;
                $scope.populateAccountOpeningBalances($scope.SearchModel);
                alert("Account Opening Balance deleted successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }
        return false;

    };

    $scope.populateAccountOpeningBalances($scope.SearchModel);
});