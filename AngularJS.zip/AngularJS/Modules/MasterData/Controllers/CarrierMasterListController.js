﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataCarrierMasterListCtrl', function ($scope, $filter, $http, $route, $routeParams, retailConstant, retailSecurityService) {

   

    $scope.CarrierModelList = {};
    $scope.SearchKeyword = ""; 
    $scope.reverseSort = false;  // set 
   
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };

    $scope.CarrierListGrid = function () {
        var tempSearch = ($scope.SearchKeyword != null ? $scope.SearchKeyword : '');
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/CarrierSelectAll?SearchKeyword=' + tempSearch).then(function (response) {

            if (response.data.length > 0) {              
                $scope.CarrierModelList = response.data;
                $("#dvNotFound").css('display', 'none');
            } else {
                $scope.CarrierModelList = "";
                $("#dvNotFound").css('display', 'block');
            }

        }, function (response) { alert('Error in getting records'); })
    };


    $scope.deleteCarrier = function (itemCarrier, CarrierID) {
        //console.log(tax + "/" + TAXID);
        var index = $scope.CarrierModelList.indexOf(itemCarrier);

        $http.post(retailConstant.serviceBaseUrl + '/MasterData/DeleteCarrier?CID=' + CarrierID)
        .then(function (resp) {
            $scope.CarrierModelList.splice(index, 1);
            alert("Carrier deleted successfully!!!");
        }, function () { alert('Error in getting records'); })
    };

    $scope.CarrierListGrid();
    $scope.searchCarrier = function () {
        $scope.CarrierListGrid();
    }


})