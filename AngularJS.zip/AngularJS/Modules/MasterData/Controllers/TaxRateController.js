﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataTaxRateCtrl', function ($scope, $http, $route, $filter, $routeParams, retailConstant, retailSecurityService) {
    $scope.pageName = "Tax Rate";
    $scope.taxTypes = [];
    $scope.taxRateModel = { TaxTypeID: '', TaxRateDesc: '', Value: '' };

    $scope.resetTaxRateModel = function () {
        $scope.taxRateModel = { TaxTypeID: '', TaxRateDesc: '', Value: '' };
    };

    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };

    $scope.populateTaxTypes = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetTaxTypes').then(function (httpResponse) {
                var response = httpResponse.data;

                if (response.Status == 1) {
                    $scope.taxTypes = response.Data;
                }
            });
    };
   
    $scope.populateTaxRateModel = function () {
        var taxRateId = $routeParams.taxRateId;

        if (angular.isDefined(taxRateId)) {
            $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetTaxRate?taxRateId=' + taxRateId).then(function (httpResponse) {
                var response = httpResponse.data;

                if (response.Status == 1) {
                    $scope.taxRateModel = response.Data;

                    //delete not required attrs
                    delete $scope.taxRateModel.CreateDate;
                    delete $scope.taxRateModel.UpdateDate;
                }
            });
        }

    };

    $scope.submit_Onclick = function (formIsValid) {
        //TODO: Validation change
        if (formIsValid) {
            console.log('Server Call - SaveTaxRate');

            $http.post(retailConstant.serviceBaseUrl + '/MasterData/SaveTaxRate', JSON.stringify($scope.taxRateModel)).then(function (httpResponse) {
                var response = httpResponse.data;
                //TODO: Validation change
                if (response.Status == 1) {
                    $scope.resetTaxRateModel();
                }

                alert(response.Message);
            });
        }
    };

    $scope.resetTaxRateModel();
    $scope.populateTaxTypes();
    $scope.populateTaxRateModel();
});