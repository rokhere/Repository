﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataMemberMasterEntryCtrl', function ($scope, $http, $filter, $q, $route, $routeParams, retailConstant, retailSecurityService) {

    $scope.MemberMasterModel = {};
    $scope.BranchMasterArray = {};
    $scope.RoleMasterArray = {};
    $scope.MemberMasterArray = [];
    $scope.StateArray = [];
    $scope.CityArray = [];
    $scope.DistrictArray = [];
   

    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };

    $scope.parseJsonDate = function (model) {                               //Paas Complete model for all date field
        // date format - /Date(1507573800000)/
        var pageDateFields = ['DOB', 'DOW', 'ValidTill', 'ValidTill2', , 'ValidTill3', 'ValidTill4', 'ValidTill5']                 // Add those fied which is not add as Date
        for (var property in model) {
            if (model.hasOwnProperty(property) && (property.indexOf('Date') > -1 || pageDateFields.indexOf(property) > -1)) {
                var jsonDateString = model[property] || '';
                if (jsonDateString.length > 0) {
                    var date = new Date(parseInt(jsonDateString.substr(6)));
                    model[property] = $filter('date')(date, "dd/MM/yyyy");;
                }
            }
        }
    }
   
    $scope.GetBranchMasterList = function () {

        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetBranchMasterList').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.BranchMasterArray = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    };

    $scope.GetRoleMasterList = function () {

        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetRoleMasterList').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.RoleMasterArray = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    };

    $scope.$watch('MemberMasterModel.StateID', function (newValue, oldValue) {
        if (angular.isDefined(newValue)) {
            $scope.LoadStateCity();
        }
    });

    $scope.GetStateList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetStates').then(function (resp) {
            if (resp.data.Data.length > 0) {
                $scope.StateArray = resp.data.Data;
            }

        }, function () { alert('Error in getting records'); })
    };

    $scope.GetCityList = function (httpResponse) {
        if (httpResponse.data.Data.length > 0) {
            $scope.CityArray = httpResponse.data.Data;
        }
    };

    $scope.GetDistrictList = function (httpResponse) {
        if (httpResponse.data.Data.length > 0) {
            $scope.DistrictArray = httpResponse.data.Data;
        }
    };

    $scope.selectCity = function () {
        $scope.GetCityList($scope.MemberMasterModel.StateID);
    }

    $scope.selectDistrict = function () {
        $scope.GetDistrictList($scope.MemberMasterModel.StateID);
    }

    $scope.LoadStateCity = function () {
        //debugger;

        var StateID = $scope.MemberMasterModel.StateID;
        if (angular.isDefined(StateID)) {
            var CityPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetCitys?StateID=' + StateID);
            var DistrictPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetDistricts?StateID=' + StateID);

            //Add to chain
            $scope.combinedPromise = $q.all({ CityArray: CityPromise, DistrictArray: DistrictPromise });
            //CombinedPromise then
            $scope.combinedPromise.then(function (responses) {
                //debugger;

                if (responses.CityArray) {
                    $scope.GetCityList(responses.CityArray);
                }

                if (responses.DistrictArray) {
                    $scope.GetDistrictList(responses.DistrictArray);
                }

            });
        }
    };

    $scope.SaveMemberMaster = function () {

        if ($scope.button == "Submit") {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/AddMemberMaster',
                data: JSON.stringify($scope.MemberMasterModel),
                dataType: "json"
            }).then(function (resp) {
                $scope.MemberMasterModel = null;
                alert("Member Master added successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }
        else if ($scope.button == "Update") {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/UpdateMemberMaster',
                data: JSON.stringify($scope.MemberMasterModel),
                dataType: "json"
            }).then(function (resp) {
                //$scope.AccountGroups = null;
                alert("Member Master update successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }


    };

    $scope.GetSingleMemberMasterList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSingleMemberMasterList?MemberId=' + $routeParams.MemberId).then(function (resp) {
            if (resp.data.length > 0) {
                $scope.parseJsonDate(resp.data[0]);
                $scope.MemberMasterModel.MemberId = $routeParams.MemberId;
                $scope.MemberMasterModel.LoginId = resp.data[0].LoginId;
                $scope.MemberMasterModel.BranchID = resp.data[0].BranchID;
                $scope.MemberMasterModel.RoleID = resp.data[0].RoleID;
                $scope.MemberMasterModel.FirstName = resp.data[0].FirstName;
                $scope.MemberMasterModel.LastName = resp.data[0].LastName;
                //$scope.MemberMasterModel.IsSuperAdmin = resp.data[0].IsSuperAdmin;
                $scope.MemberMasterModel.IsSuperAdmin = resp.data[0].IsSuperAdmin == 1 ? true : false;                
                $scope.MemberMasterModel.Alias = resp.data[0].Alias;
                $scope.MemberMasterModel.Address = resp.data[0].Address;
                $scope.MemberMasterModel.StateID = resp.data[0].StateID;
                $scope.MemberMasterModel.DistrictID = resp.data[0].DistrictID;
                $scope.MemberMasterModel.CityID = resp.data[0].CityID;
                $scope.MemberMasterModel.Locality = resp.data[0].Locality;
                $scope.MemberMasterModel.Pincode = resp.data[0].Pincode;
                $scope.MemberMasterModel.Phone = resp.data[0].Phone;
                $scope.MemberMasterModel.Mobile = resp.data[0].Mobile;
                $scope.MemberMasterModel.DOB = resp.data[0].DOB;
                //$scope.MemberMasterModel.IsBlock = resp.data[0].IsBlock;
                $scope.MemberMasterModel.IsBlock = resp.data[0].IsBlock == 1 ? true : false;                
                $scope.MemberMasterModel.BlockingDate = resp.data[0].BlockingDate;
            }
        }, function () { alert('Error in getting records'); })
    }

    $scope.MemberMasterCheckAddEdit = function () {
        
        $scope.GetBranchMasterList();
        $scope.GetRoleMasterList();
        $scope.GetStateList();
        $scope.LoadStateCity();
        if ($routeParams.MemberId != null) {
            $scope.HeadingText = "Edit";
            $scope.button = "Update";
            $scope.GetSingleMemberMasterList();
        }
        else {
            $scope.HeadingText = "Entry";
            $scope.button = "Submit";
        }
    }

    $scope.MemberMasterCheckAddEdit();

})
.filter('unique', function () {
    return function (collection, keyname) {
        var output = [],
            keys = [];

        angular.forEach(collection, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });

        return output;
    };
});