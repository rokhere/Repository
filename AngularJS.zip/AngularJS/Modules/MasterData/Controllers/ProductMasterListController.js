﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataProductMasterListCtrl', function ($scope, $http, $route, retailConstant, retailSecurityService) {

    $scope.pageName = "Product Master";
    $scope.productMasters = [];
    $scope.keyword = '';
    $scope.productMaster = undefined;
    $scope.productMasterImages = [];

    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };


    $scope.populateProductMasters = function (keyword) {

        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetProductMasters?keyword=' + keyword).then(function (httpResponse) {
            var response = httpResponse.data;

            if (response.Status == 1) {
                $scope.productMasters = response.Data;
            } else {
                alert(response.Message);
            }

        });
    };

    $scope.resetProductMasterImages = function () {
        var images = [];
        var productMasterImages = $scope.productMasterImages;
        for (var i = 0; i < productMasterImages.length; i++) {
            if (productMasterImages[i].length > 0) {
                images.push(productMasterImages[i]);
            }
        }

        if (images.length == 0) {
            images = [''];
        }

        $scope.productMasterImages = images;
    };

    $scope.getProductImagePath = function (imgName) {
        return retailConstant.serviceBaseUrl + '/UploadedFiles/ProductImages/' + imgName;
    };

    $scope.productMasterImagesAdd = function (imgName) {
        if (imgName.length > 0) {
            var parts = imgName.split('#');
            $scope.productMasterImages.push({ id: parts[0], name: parts[1] });
        }
    }

    $scope.file_Onchange = function (sender) {
        if (sender.files.length > 0) {
            var file = sender.files[0];

            var fd = new FormData();
            fd.append('file', file);

            $http.post(retailConstant.serviceBaseUrl + '/MasterData/ProductAddImage?id=' + $scope.productMaster.ProductID, fd, {
                transformRequest: angular.identity,
                headers: { 'Content-Type': undefined }
            }).then(function (httpResponse) {
                var response = httpResponse.data;

                if (response.Status == 1) {
                    $scope.productMasterImagesAdd(response.Data);
                }

                alert(response.Message);
            }).finally(function () {
                $(sender).val('');
            });;
        }
    };

    $scope.delete_Onclick = function (pm) {

        if (confirm("Are you sure to delete this Product?")) {
            $http({
                method: 'DELETE',
                url: retailConstant.serviceBaseUrl + '/MasterData/DeleteProductMaster?id=' + pm.ProductID
            }).then(function (httpResponse) {
                var response = httpResponse.data;
                if (response.Status == 1) {
                    var index = $scope.productMasters.indexOf(pm);
                    $scope.productMasters.splice(index, 1);
                }

                alert(response.Message);
            });
        }
    };

    $scope.deleteImg_Onclick = function (index, imgName, imgId) {

        $http({
            method: 'DELETE',
            url: retailConstant.serviceBaseUrl + '/MasterData/ProductDeleteImage?id=' + imgId + '&filename=' + imgName
        }).then(function (httpResponse) {
            var response = httpResponse.data;
            if (response.Status == 1) {
                $scope.productMasterImages.splice(index, 1);
                $scope.productMaster.ProductImages = $scope.productMasterImages;
            }

            alert(response.Message);
        });
    };

    $scope.addImage_Onclick = function (pm) {
        if (pm.ProductImages == null) {
            pm.ProductImages = '';
        }

        $scope.productMaster = pm;

        $scope.productMasterImages = [];
        var prodImages = pm.ProductImages.split(',');

        if (prodImages.length > 0) {
            for (var i = 0; i < prodImages.length; i++) {
                $scope.productMasterImagesAdd(prodImages[i]);
            }
        }

        $('#dvProductImageModal').modal('show');
    };

    $scope.populateProductMasters('');
});