﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataHSNCodeCtrl', function ($scope, $filter, $http, $route, $routeParams, $location, retailConstant, retailSecurityService) {
    // $scope.pageName = "Master Data - HSNCode";    
    $scope.btnText = "Submit";
    $scope.mode = "Entry";
    $scope.PurchasedTaxArray = [];
    $scope.SalesTaxArray = [];
    $scope.TempTaxArray = [];
    $scope.section = "";
    //$scope.HSN.PurchaseTaxID = "";
    //$scope.HSN.SalesTaxID = "";
    $scope.HSNID = "";
    $scope.HSN = {};

    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };

    $scope.getPageLoadData = function () {             

            // Normal PageLoad

        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetHSNPageLoadData').then(function (resp) {

                if (resp.data.PurchasedTaxList.length > 0) {
                    //console.log(resp.data.PurchasedTaxList);
                    $scope.PurchasedTaxArray = resp.data.PurchasedTaxList;
                } else {

                }

                if (resp.data.SaleTaxList.length > 0) {
                    //console.log(resp.data.SaleTaxList);
                    $scope.SalesTaxArray = resp.data.SaleTaxList;
                } else {

                }

            }, function () { alert('Error in getting records'); })


            if ($routeParams.HSNID != null) {

                // Update PageLoad
                $scope.mode = "Edit";
                $scope.btnText = "Update";
                $scope.HSN.HSNID = $routeParams.HSNID;

                $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSingleHsnCode?HsnCode=' + $routeParams.HSNID).then(function (resp) {
                    if (resp.data.length > 0) {
                        $scope.SingleSingleHsnCodeArray = resp.data;
                        console.log(resp.data);
                        $scope.HSN.Code = $scope.SingleSingleHsnCodeArray[0].HSNCode;
                        $scope.HSN.Description = $scope.SingleSingleHsnCodeArray[0].Description;
                        $scope.HSN.SalesTaxID = $scope.SingleSingleHsnCodeArray[0].STaxID;
                        $scope.HSN.PurchaseTaxID = $scope.SingleSingleHsnCodeArray[0].PTaxID;
                        $scope.HSN.PurchaseTaxCode = $scope.SingleSingleHsnCodeArray[0].PTaxCode;
                        $scope.HSN.SalesTaxCode = $scope.SingleSingleHsnCodeArray[0].STaxCode;
                    }
                }, function () { alert('Error in getting records'); })

            }
    };

    $scope.getPageLoadData();

    //Assign in the Purchase popup
    $scope.change = function (FilterFor, FilterBy) {

        $scope.popupData = [];
        $scope.popupData = "";
        $scope.TempPurchasedTaxArray = "";

        $scope.section = FilterFor;

        //$scope.TempAccountArray = $scope.accountArray;

        if ($scope.section == "P") {
            $scope.popupData = $scope.PurchasedTaxArray;
        }
        else if ($scope.section == "S") {
            $scope.popupData = $scope.SalesTaxArray;
        }

        $scope.TempTaxArray = $filter('filter')($scope.popupData, FilterBy);

        //if (FilterBy.length > 0) {
        //    $('#myModal').modal('show');
        //} else {
        //    $('#myModal').modal('hide');
        //}

        if (FilterBy == undefined || FilterBy.length > 0) {
            $('#myModal').modal('show');
        } else {
            $('#myModal').modal('hide');
        }
    };

    //Selected Radio Button Value from purchase dropdown
    $scope.selectRow = function (index) {
        if ($scope.section == "P") {
            $scope.HSN.PurchaseTaxCode = $scope.TempTaxArray[index].TaxCode;
            $scope.HSN.PurchaseTaxID = $scope.TempTaxArray[index].TaxID;
        } else {
            $scope.HSN.SalesTaxCode = $scope.TempTaxArray[index].TaxCode;
            $scope.HSN.SalesTaxID = $scope.TempTaxArray[index].TaxID;
        }

        $('#myModal').modal('hide');
    };

    $scope.HSNAddEdit = function (HSN) {

        if ($routeParams.HSNID == null) {

            //ADD

            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/AddHSNCode',
                data: JSON.stringify(HSN),
                dataType: "json"
            }).then(function (response) {
                //console.log(response);
                //$scope.HSN = "";
                $scope.clear_field();
                if (response.data == "0") {
                    alert("Please insert HSN code properly");
                } else {
                    alert("HSN code added successfully!!!");
                }
            }, function (response) {
                alert(response.statusText);
            });

        } else {

            ///EDIT

            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/UpdateSingleHsnCode',
                data: JSON.stringify(HSN),
                dataType: "json"
            }).then(function (resp) {

                //if (response.data == "0") {
                //    alert("Please update HSN code properly");
                //} else {
                //    alert("HsnCode updated successfully!!!");
                //}
                alert("HsnCode updated successfully!!!");
                $location.path('/HSNCodeListing');
            }, function () {
                alert(data.errors);
            });

        }

    };

    $scope.clear_field = function () {
        $scope.HSN.Code = "";
        $scope.HSN.Description = "";
        $scope.HSN.SalesTaxID = "";
        $scope.HSN.PurchaseTaxID = "";
        $scope.HSN.PurchaseTaxCode = "";
        $scope.HSN.SalesTaxCode = "";
    };

   
}).filter('unique', function () {
    return function (collection, keyname) {
        var output = [],
            keys = [];

        angular.forEach(collection, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });

        return output;
    };
});