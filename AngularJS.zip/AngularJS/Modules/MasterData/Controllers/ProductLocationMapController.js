﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataProductLocationMapCtrl', function ($scope, $http, $filter, $route, $routeParams, retailConstant, retailSecurityService) {

    $scope.ProductLocationMapModel = {};
    $scope.ProductLocationMapArray = [];

    $scope.LocationModel = {};
    $scope.LocationArray = [];

    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };

    $scope.PopulateLocationList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/PopulateLocationList').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.LocationArray = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    };

    $scope.SaveProductLocationMap = function () {
        //console.log($scope.ProductLocationMapModel);
        //    $http({
        //        method: 'POST',
        //        url: retailConstant.serviceBaseUrl + '/MasterData/AddUpdateProductLocationMap',
        //        data: JSON.stringify($scope.ProductLocationMapModel),
        //        dataType: "json"
        //    }).then(function (resp) {
        //        //$scope.AccountGroups = null;
        //        alert("Product Location Mapped successfully!!!");
        //    }, function () {
        //        alert(data.errors);
        //    });


        var ProductLocationMap = {
            ProductLocationMapID: $scope.ProductCategory,
            ProductID: $routeParams.ProductID,
            LocationID: $scope.ProductLocationMapModel.LocationID,
            ShelfNo: $scope.ProductLocationMapModel.ShelfNo,
            LocMaxStock: $scope.ProductLocationMapModel.LocMaxStock,
            LocMinStock: $scope.ProductLocationMapModel.LocMinStock,
            ReorderLevel: $scope.ProductLocationMapModel.ReorderLevel
        };
        $http({
            method: 'POST',
            url: retailConstant.serviceBaseUrl + '/MasterData/AddUpdateProductLocationMap',
            data: JSON.stringify(ProductLocationMap),
            dataType: "json"
        }).then(function (resp) {
            $scope.empModel = null;
            alert("Product Location Mapped successfully!!!");
        }, function () {
            alert(data.errors);
        });
    };

    $scope.populateProductLocationMap = function (ProductID, LocationID) {        
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetProductLocationMapList?ProductID=' + ProductID + '&LocationID=' + LocationID).then(function (resp) {
            if (resp.data.length > 0) {
                //console.log(resp.data);
                $scope.ProductLocationMapModel = resp.data;

                if (LocationID>0) {
                    $scope.ProductLocationMapModel.LocationID = LocationID;
                    $scope.ProductLocationMapModel.ShelfNo = resp.data[0].ShelfNo;
                    $scope.ProductLocationMapModel.LocMaxStock = resp.data[0].LocMaxStock;
                    $scope.ProductLocationMapModel.LocMinStock = resp.data[0].LocMinStock;
                    $scope.ProductLocationMapModel.ReorderLevel = resp.data[0].ReorderLevel;
                    $scope.ProductLocationMapModel.Unit = resp.data[0].Unit;
                }                
            }
            //else {
            //    $scope.ProductLocationMapModel = null;
            //}

        }, function () { alert('Error in getting records'); })
    }

    $scope.DeleteProductLocationMap = function (ProductLocationMapID) {
        $http({
            method: 'POST',
            url: retailConstant.serviceBaseUrl + '/MasterData/DeleteProductLocationMap?ProductLocationMapID=' + ProductLocationMapID,
            //data: JSON.stringify(Category),
            dataType: "json"
        }).then(function (resp) {
            //$scope.empModel = null;
            $scope.populateProductLocationMap('');
            alert("Billing Head deleted successfully!!!");
        }, function () {
            alert(data.errors);
        });

    };

    $scope.Location_OnChange = function (LocationID) {
        
        $scope.populateProductLocationMap($routeParams.ProductID, LocationID);
    };

    $scope.ProductLocationMapCheckAddEdit = function () {
        
        $scope.PopulateLocationList();
        $scope.ProductName = $routeParams.Product;

        if ($routeParams.ProductID != null && $routeParams.Product != null) {
            
            $scope.populateProductLocationMap($routeParams.ProductID,0);
            ProductID = $routeParams.ProductID;
            $scope.HeadingText = "Map";            
            $scope.button = "Save";
        }
        else {
            $scope.HeadingText = "Edit";            
            $scope.button = "Update";
        }
    }

    $scope.ProductLocationMapCheckAddEdit();

})
.filter('unique', function () {
    return function (collection, keyname) {
        var output = [],
            keys = [];

        angular.forEach(collection, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });

        return output;
    };
});