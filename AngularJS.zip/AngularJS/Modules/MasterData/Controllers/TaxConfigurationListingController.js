﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataTaxConfigurationListingCtrl', function ($scope, $filter, $http, $route, retailConstant, retailSecurityService) {
    $scope.TaxArray = [];
    $scope.SearchKeyword = "";

    $scope.orderByField = 'TaxCode'; // set the default sort type
    $scope.reverseSort = false;  // set the default sort order
    //$scope.searchHSNCode = '';     // set the default search/filter term


    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };

    $scope.searchTax = function () {

        $scope.getTAXSelectAll();
    }

    $scope.getTAXSelectAll = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetTaxConfigSelectAll?SearchKeyword=' + $scope.SearchKeyword).then(function (response) {

            if (response.data.length > 0) {
                console.log(response.data);
                $scope.TaxArray = response.data;
            } else {
                $scope.TaxArray = "";
            }

        }, function (response) { alert('Error in getting records'); })
    };

    $scope.getTAXSelectAll();

    $scope.deleteTaxCode = function (tax, TAXID) {
        //console.log(tax + "/" + TAXID);
        var index = $scope.TaxArray.indexOf(tax);  

        $http.post(retailConstant.serviceBaseUrl + '/MasterData/DeleteTaxConfig?TaxID=' + TAXID)
        .then(function (resp) {
            $scope.TaxArray.splice(index, 1);
            alert("Tax deleted successfully!!!");
        }, function () { alert('Error in getting records'); })
    };
   
}).filter('unique', function () {
    return function (collection, keyname) {
        var output = [],
            keys = [];

        angular.forEach(collection, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });

        return output;
    };
});