﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataStockLocationTransferListCtrl', function ($scope, $http, $filter, $route, retailConstant, retailSecurityService) {
    $scope.pageName = "Stock Location Transfer";
    $scope.StockLocationTransferModel = {};
    $scope.SearchModel = { SearchKeyword: '', FilterBy: '1' };

    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };

    $scope.populateStockLocationTransfer = function (SearchModel) {        
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetStockLocationTransferList?SearchKeyword=' + SearchModel.SearchKeyword + '&Filterby=' + SearchModel.FilterBy).then(function (resp) {
            if (resp.data.length > 0) {

                $scope.parseJsonDate(resp.data[0]);
                $scope.StockLocationTransferModel = resp.data;

            }

        }, function () { alert('Error in getting records'); })
    }


    $scope.parseJsonDate = function (model) {
        // date format - /Date(1507573800000)/
        for (var property in model) {
            if (model.hasOwnProperty(property) && property.indexOf('Date') > -1) {
                var jsonDateString = model[property] || '';
                if (jsonDateString.length > 0) {
                    var date = new Date(parseInt(jsonDateString.substr(6)));
                    model[property] = $filter('date')(date, "dd/MM/yyyy");;
                }
            }
        }
    };


    $scope.FilterBy =
        [
            { FilterByID: "1", FilterBy: "Issue" },
            { FilterByID: "2", FilterBy: "Receipt" }
        ];

    $scope.DeleteStockLocationTransfer = function (StockTransferID) {

        if (confirm("Are you sure to delete this Stock Location Transfer?")) {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/DeleteStockLocationTransfer?StockTransferID=' + StockTransferID,
                //data: JSON.stringify(Category),
                dataType: "json"
            }).then(function (resp) {
                //$scope.empModel = null;
                $scope.populateStockLocationTransfer('');
                alert("Stock Location Transfer deleted successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }
        return false;        
    };

    $scope.populateStockLocationTransfer($scope.SearchModel);
});