﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataOpeningStockListCtrl', function ($scope, $http, $filter, $route, retailConstant, retailSecurityService) {
    $scope.pageName = "Opening Stock";
    $scope.OpeningStockModel = {};

    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };

    $scope.parseJsonDate = function (model) {
        // date format - /Date(1507573800000)/
        var pageDateFields = ['ExpiryDate', 'ManufacturingDate']                 // Add those fied which is not add as Date
        for (var property in model) {
            if (model.hasOwnProperty(property) && (property.indexOf('Date') > -1 || pageDateFields.indexOf(property) > -1)) {
                var jsonDateString = model[property] || '';
                if (jsonDateString.length > 0) {
                    var date = new Date(parseInt(jsonDateString.substr(6)));
                    model[property] = $filter('date')(date, "dd/MM/yyyy");;
                }
            }
        }
    };

    $scope.populateOpeningStock = function (SearchKeyword) {

        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetOpeningStockList?SearchKeyword=' + SearchKeyword).then(function (resp) {
            if (resp.data.length > 0) {

                var len = resp.data.length;
                for (i = 0 ; i <= len ; i++) {
                    $scope.parseJsonDate(resp.data[i]);
                }
                //$scope.parseJsonDate(resp.data[0]);
                //console.log(resp.data);
                $scope.OpeningStockModel = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    }

    $scope.DeleteOpeningStock = function (OpeningStockEntryID) {
        $http({
            method: 'POST',
            url: retailConstant.serviceBaseUrl + '/MasterData/DeleteOpeningStock?OpeningStockEntryID=' + OpeningStockEntryID,
            //data: JSON.stringify(Category),
            dataType: "json"
        }).then(function (resp) {
            //$scope.empModel = null;
            $scope.populateOpeningStock('');
            alert("Opening Stock deleted successfully!!!");
        }, function () {
            alert(data.errors);
        });

    };

    $scope.populateOpeningStock('');
});