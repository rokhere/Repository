﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataTaxRateDetailListCtrl', function ($scope, $http, $filter, $route, retailConstant, retailSecurityService) {
    $scope.pageName = "Tax Rate Details";

    $scope.taxRateDetails = [];

    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };

    $scope.populateRateDetails = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetTaxRateDetailList').then(function (httpResponse) {
            var response = httpResponse.data;

            if (response.Status == 1) {
                $scope.taxRateDetails = response.Data;
            }

        });
    };

    $scope.delete_Onclick = function (taxRateDetail) {

        if (confirm("Are you sure to delete this Rate Detail?")) {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/DeleteTaxRateDetail?taxRateDetailId=' + taxRateDetail.TaxRateDetailID
            }).then(function (httpResponse) {
                var response = httpResponse.data;
                if (response.Status == 1) {
                    var index = $scope.taxRateDetails.indexOf(taxRateDetail);
                    $scope.taxRateDetails.splice(index, 1);
                }

                alert(response.Message);
            });
        }
        return false;
    };

    $scope.populateRateDetails();

});