﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataProductCategoryGroupCtrl', function ($scope, $filter, $http, $routeParams, $location, retailConstant) {
    $scope.btnText = "Submit";
    $scope.pageName = "Master Data - Product Category Group";
    $scope.pg = {};
    $scope.PCGID = "";
    $scope.PCGReset = {};
    $scope.showMessage = false;

    $scope.insertProductCat = function (val,obj) {
        if (val == true) {

            if ($routeParams.PCGID == null) {

                $http({
                    method: "post",
                    url: retailConstant.serviceBaseUrl + '/MasterData/InsertProductCategory',
                    data: JSON.stringify(obj),
                    dataType: "json"
                })
                .then(function (response) {
                    $scope.clear_field();
                    if (response.data == "0") {
                        alert("Please enter Product category group.");
                    } else {
                        alert("Product category group added successfully!!!");
                    }
                }, function () { alert('Error in getting records'); })
            } else {
                ///EDIT
                $http({
                    method: 'POST',
                    url: retailConstant.serviceBaseUrl + '/MasterData/UpdateProductCatGroup',
                    data: JSON.stringify(obj),
                    dataType: "json"
                }).then(function (response) {

                    if (response.data == "0") {
                        alert("Please enter Product category group");
                    } else {
                        alert("Product category group updated successfully!!!");
                    }

                    $location.path('/ProductCategoryGroupList');
                }, function () {
                    alert(data.errors);
                });
            }
        }
        else {
            $scope.showMessage = true;
        }
        
    }

    $scope.clear_field = function () {
        $scope.pg.ProductCategoryGroup = "";
        $scope.pg.ProductCategoryGroupID = "";
        $scope.pg.ParentID = "";
        $scope.pg.ProductCategoryParentGroup = "";
        
        
    };
   
    $scope.fillproductdropdown = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/FillProductDropdown').then(function (response) {
            $scope.getdropdown = response.data;
        },
        function ()
        {
            alert('Error in getting records');
        });
        if ($routeParams.PCGID != null) {       

            // Update PageLoad
           // $scope.mode = "Edit";
            $scope.btnText = "Update";
            //$scope.HSN.HSNID = $routeParams.PCGID;

            $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetProductCatGroupSelectOne?PCGID=' + $routeParams.PCGID).then(function (resp) {
                if (resp.data.length > 0) {

                    $scope.PCGReset = resp.data;                  
                    console.log(resp.data);
                    $scope.pg.ProductCategoryGroupID = $scope.PCGReset[0].ProductCategoryGroupID;
                    $scope.pg.ProductCategoryGroup = $scope.PCGReset[0].ProductCategoryGroup;
                    $scope.pg.ProductCategoryParentGroup = $scope.PCGReset[0].ProductCategoryParentGroup;
                    $scope.pg.ParentID = $scope.PCGReset[0].ParentID;
                   
                   
                }
            }, function () { alert('Error in getting records'); })



        }
    };
    $scope.fillProductGrid = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/FillProductDropdown').then(function (response) {
            $scope.getdropdown = response.data;
        });
    };

    $scope.fillproductdropdown();
});