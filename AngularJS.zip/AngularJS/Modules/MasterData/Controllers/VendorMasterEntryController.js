﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataVendorMasterEntryCtrl', function ($scope, $http, $filter, $q, $route, $routeParams, retailConstant, retailSecurityService) {
    $scope.VendorMdl = {};
    $scope.VendorArray = [];
    $scope.StateArray = [];
    $scope.CityArray = [];
    $scope.DistrictArray = [];
    $scope.Accounts = {};
    $scope.AccountsArray = [];
    $scope.hideDate = true;
    $scope.showMessage = false;
    $scope.combinedPromise = undefined;

    $scope.SetDefaultStatus = function () {
        $scope.VendorMdl.ContinueStatus = 1;
    };

    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };

    $scope.parseJsonDate = function (model) {                               //Paas Complete model for all date field
        // date format - /Date(1507573800000)/
        var pageDateFields = ['DOB', 'DOW', 'ValidTill', 'ValidTill2', , 'ValidTill3', 'ValidTill4', 'ValidTill5']                 // Add those fied which is not add as Date
        for (var property in model) {
            if (model.hasOwnProperty(property) && (property.indexOf('Date') > -1 || pageDateFields.indexOf(property) > -1)) {
                var jsonDateString = model[property] || '';
                if (jsonDateString.length > 0) {
                    var date = new Date(parseInt(jsonDateString.substr(6)));
                    model[property] = $filter('date')(date, "dd/MM/yyyy");;
                }
            }
        }
    }

    //$scope.GetCityList = function (StateID) {
    //    $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetCitys?stateId=' + StateID).then(function (resp) {
    //        if (resp.data.Data.length > 0) {
    //            $scope.CityArray = resp.data.Data;

    //        }

    //    }, function () { alert('Error in getting records'); })
    //};    

    //$scope.GetDistrictList = function (StateID) {
    //    $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetDistricts?StateID=' + StateID).then(function (resp) {
    //        //console.log(resp.data.Data);
    //        if (resp.data.Data.length > 0) {
    //            $scope.DistrictArray = resp.data.Data;
    //        }

    //    }, function () { alert('Error in getting records'); })
    //};  

    $scope.$watch('VendorMdl.StateID', function (newValue, oldValue) {
        if (angular.isDefined(newValue)) {
            $scope.LoadStateCity();
        }
    });

    $scope.GetStateList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetStates').then(function (resp) {            
            if (resp.data.Data.length > 0) {
                $scope.StateArray = resp.data.Data;
            }

        }, function () { alert('Error in getting records'); })
    };

    $scope.GetCityList = function (httpResponse) {
        if (httpResponse.data.Data.length > 0) {
            $scope.CityArray = httpResponse.data.Data;
        }
    };

    $scope.GetDistrictList = function (httpResponse) {
        if (httpResponse.data.Data.length > 0) {
            $scope.DistrictArray = httpResponse.data.Data;
        }
    };
     
    $scope.selectCity = function () {
        $scope.GetCityList($scope.VendorMdl.StateID);
    }

    $scope.selectDistrict = function () {
        $scope.GetDistrictList($scope.VendorMdl.StateID);
    }

    $scope.LoadStateCity = function () {
        //debugger;
        
        var StateID = $scope.VendorMdl.StateID;
        if (angular.isDefined(StateID)) {
            var CityPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetCitys?StateID=' + StateID);
            var DistrictPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetDistricts?StateID=' + StateID);

            //Add to chain
            $scope.combinedPromise = $q.all({ CityArray: CityPromise, DistrictArray: DistrictPromise });     
            //CombinedPromise then
            $scope.combinedPromise.then(function (responses) {
            //debugger;

            if (responses.CityArray) {
                $scope.GetCityList(responses.CityArray);
            }

            if (responses.DistrictArray) {
                $scope.GetDistrictList(responses.DistrictArray);
            }

        });
        }
    };

    $scope.GetAccount = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetPostingAccount').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.Accounts = resp.data;
                $scope.AccountsArray = resp.data;
            }
        }, function () { alert('Error in getting records'); })
    }

    $scope.openPopup = function (FilterBy) {
        //$scope.Accounts = $filter('filter')($scope.Accounts, FilterBy);
        //if (FilterBy.length > 0) {
        $('#myModalAccount').modal('show');
        //}        
    };

    $scope.selectRowForAccount = function (index) {
        $scope.VendorMdl.Account = $scope.Accounts[index].AcLedger;
        $scope.VendorMdl.AcLedgerID = $scope.Accounts[index].AcLedgerID;
        $('#myModalAccount').modal('hide');
    };

    $scope.showDate = function (type) {
        //console.log(type);
        $scope.VendorMdl.DiscontinueDate = "";
        if (type == 1) {
            $scope.hideDate = true;
        } else {
            $scope.hideDate = false;
        }
    }

    $scope.GetSingleVendorList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSingleVendorList?VendorID=' + $routeParams.VendorID).then(function (resp) {
            if (resp.data.length > 0) {
                $scope.parseJsonDate(resp.data[0]);

                $scope.VendorMdl.VendorID = $routeParams.VendorID;
                $scope.VendorMdl.Vendor = resp.data[0].Vendor;
                $scope.VendorMdl.Alias = resp.data[0].Alias;
                $scope.VendorMdl.Address = resp.data[0].Address;

                $scope.VendorMdl.StateID = resp.data[0].StateID;
                //$scope.VendorMdl.CityID = $scope.GetCityList(resp.data[0].StateID);;
                //$scope.VendorMdl.DistrictID = $scope.GetDistrictList(resp.data[0].DistrictID);

                $scope.VendorMdl.CityID = resp.data[0].CityID;
                $scope.VendorMdl.DistrictID = resp.data[0].DistrictID;

                $scope.VendorMdl.AcLedgerID = resp.data[0].AcLedgerID;
                $scope.VendorMdl.Account = resp.data[0].AcLedger;

                //if (resp.data[0].ContinueStatus == 1) {
                //    alert(resp.data[0].ContinueStatus);                   
                //    $scope.VendorMdl.ContinueStatus = true;
                //} else {
                //    $scope.VendorMdl.ContinueStatus = false;
                //}
                $scope.VendorMdl.ContinueStatus = resp.data[0].ContinueStatus;

                $scope.VendorMdl.Locality = resp.data[0].Locality;
                $scope.VendorMdl.Pincode = resp.data[0].Pincode;
                $scope.VendorMdl.Mobile = resp.data[0].Mobile;
                $scope.VendorMdl.Phone = resp.data[0].Phone;
                $scope.VendorMdl.Fax = resp.data[0].Fax;
                $scope.VendorMdl.Email = resp.data[0].Email;
                $scope.VendorMdl.CreditDays = resp.data[0].CreditDays;
                $scope.VendorMdl.ContactPerson = resp.data[0].ContactPerson;
                $scope.VendorMdl.Website = resp.data[0].Website;
                $scope.VendorMdl.DOB = resp.data[0].DOB;
                $scope.VendorMdl.DOW = resp.data[0].DOW;
                $scope.VendorMdl.GSTNo = resp.data[0].GSTNo;
                $scope.VendorMdl.GSTDate = resp.data[0].GSTDate;
                $scope.VendorMdl.LicenseDescription1 = resp.data[0].LicenseDescription1;
                $scope.VendorMdl.LicenseNo1 = resp.data[0].LicenseNo1;
                $scope.VendorMdl.IssueDate1 = resp.data[0].IssueDate1;
                $scope.VendorMdl.ValidTill = resp.data[0].ValidTill;
                $scope.VendorMdl.LicenseDescription2 = resp.data[0].LicenseDescription2;
                $scope.VendorMdl.LicenseNo2 = resp.data[0].LicenseNo2;
                $scope.VendorMdl.IssueDate2 = resp.data[0].IssueDate2;
                $scope.VendorMdl.ValidTill2 = resp.data[0].ValidTill2;
                $scope.VendorMdl.LicenseDescription3 = resp.data[0].LicenseDescription3;
                $scope.VendorMdl.LicenseNo3 = resp.data[0].LicenseNo3;
                $scope.VendorMdl.IssueDate3 = resp.data[0].IssueDate3;
                $scope.VendorMdl.ValidTill3 = resp.data[0].ValidTill3;
                $scope.VendorMdl.LicenseDescription4 = resp.data[0].LicenseDescription4;
                $scope.VendorMdl.LicenseNo4 = resp.data[0].LicenseNo4;
                $scope.VendorMdl.IssueDate4 = resp.data[0].IssueDate4;
                $scope.VendorMdl.ValidTill4 = resp.data[0].ValidTill4;
                $scope.VendorMdl.LicenseDescription5 = resp.data[0].LicenseDescription5;
                $scope.VendorMdl.LicenseNo5 = resp.data[0].LicenseNo5;
                $scope.VendorMdl.IssueDate5 = resp.data[0].IssueDate5;
                $scope.VendorMdl.ValidTill5 = resp.data[0].ValidTill5;
            }
        }, function () { alert('Error in getting records'); })
    }

    $scope.VendorMasterCheckAddEdit = function () {        
        if ($routeParams.VendorID != null) {
            $scope.HeadingText = "Edit";
            $scope.button = "Update";
            $scope.GetSingleVendorList();
            $scope.GetStateList();
            $scope.LoadStateCity();
            $scope.GetAccount();            
        }
        else {
            $scope.HeadingText = "Entry";
            $scope.button = "Submit";
            $scope.GetStateList();
            $scope.LoadStateCity();
            $scope.GetAccount();
            //$scope.GetDistrictList();
            $scope.SetDefaultStatus();
        }
    }

    $scope.SaveVendorMaster = function (formIsValid) {
        //console.log('SaveVendorMaster');
        if (formIsValid) {            
            if ($scope.button == "Submit") {
                console.log($scope.VendorMdl);
                $http({
                    method: 'POST',
                    url: retailConstant.serviceBaseUrl + '/MasterData/AddVendorMaster',
                    data: JSON.stringify($scope.VendorMdl),
                    dataType: "json"
                }).then(function (resp) {
                    alert("Vendor added successfully!!!");
                }, function () {
                    alert(data.errors);
                });
            }
            else if ($scope.button == "Update") {
                $http({
                    method: 'POST',
                    url: retailConstant.serviceBaseUrl + '/MasterData/UpdateVendorMaster',
                    data: JSON.stringify($scope.VendorMdl),
                    dataType: "json"
                }).then(function (resp) {
                    alert("Vendor update successfully!!!");
                    $scope.GetSingleVendorList();
                }, function () {
                    alert(data.errors);
                });
            }
        }
        else {
            $scope.showMessage = true;
        }


    };

    $scope.VendorMasterCheckAddEdit();
});