﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataStockLocationListCtrl', function ($scope, $filter, $http, $route, $routeParams, retailConstant, retailSecurityService) {

    $scope.StockLocationList = [];
    $scope.SearchKeyword = ""; 
    $scope.reverseSort = false;  // set 
   
    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };

    $scope.StockLocationListGrd = function () {
        var tempSearch = ($scope.SearchKeyword != null ? $scope.SearchKeyword : '');
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/StockLocationSelectAll?SearchKeyword=' + tempSearch).then(function (response) {

            if (response.data.length > 0) {
                console.log(response.data);
                $scope.StockLocationList = response.data;
            } else {
                $scope.StockLocationList = "";
            }

        }, function (response) { alert('Error in getting records'); })
    };


    $scope.deleteStockLocation = function (stocklocation, LocationID) {

        if (confirm("Are you sure to delete this Stock Location?")) {
            //console.log(tax + "/" + TAXID);
            var index = $scope.StockLocationList.indexOf(stocklocation);

            $http.post(retailConstant.serviceBaseUrl + '/MasterData/DeleteStockLocation?SLID=' + LocationID)
            .then(function (resp) {
                $scope.StockLocationList.splice(index, 1);
                alert("Stock Location deleted successfully!!!");
            }, function () { alert('Error in getting records'); })

        }
    };

    $scope.StockLocationListGrd();
    $scope.searchStockLocation = function () {      
        $scope.StockLocationListGrd();
    }
})