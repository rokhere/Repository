﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataProductMasterCtrl', function ($scope, $q, $sce, $filter, $location, $http, $route, $routeParams, retailConstant, retailSecurityService) {

    $scope.pro = {};


    $scope.productAttributeCatList = {};
    $scope.productAttributeCat = {};
    $scope.productAttribute = {};
    $scope.productAttributeCatSend = {};


    $scope.hideDate = true;
    $scope.btnText = "Submit";
    //if($scope.ProductName!=undefined)
    //$scope.btnPopup = "Set Product Attributes";
    
    $scope.disabledMarketingCompany = true;
    $scope.disabledSPRateUnit = true;

    $scope.CategoryTaxDetails = "";
    $scope.showCategoryTaxDetails = false;

    $scope.objMarketingGroup = {};
    $scope.objMarketingCompany = {};
    $scope.objProductCategory = {};
    $scope.objProductHSN = {};
    $scope.objProductUnitMaster = {};
    $scope.objProductScheduleMaster = {};

    var requestPromise = [];

   
    $scope.bindMarketingCompany = function (MarketingGroupID) {
        //console.log(MarketingGroupID);

        var httpPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetMarketingCompany?MarketingGroupID=' + MarketingGroupID).then(function (resp) {

            console.log(resp);

            if (resp.data.length > 0) {
                //console.log(resp.data);
                $scope.objMarketingCompany = resp.data;
                $scope.disabledMarketingCompany = false;
            } else {
                $scope.objMarketingCompany = "";
                $scope.disabledMarketingCompany = true;
            }

        }, function () { alert('Error in getting records in bindMarketingCompany'); })

        requestPromise.push(httpPromise);
    };

    $scope.parseJsonDate = function (model) {
        // date format - /Date(1507573800000)/
        for (var property in model) {
            if (model.hasOwnProperty(property) && property.indexOf('Date') > -1) {
                var jsonDateString = model[property] || '';
                if (jsonDateString.length > 0) {
                    var date = new Date(parseInt(jsonDateString.substr(6)));
                    model[property] = $filter('date')(date, "dd/MM/yyyy");;
                }
            }
        }
    };

    $scope.getPageLoadData = function () {

        // Normal PageLoad

        var httpPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetProductMasterPageLoad').then(function (resp) {

           // console.log(resp);

            var response = resp.data;

            if (resp.data.MarketingGroupList.length > 0) {
                //console.log(resp.data.MarketingGroupList);
                $scope.objMarketingGroup = resp.data.MarketingGroupList;
            } else {
                $scope.objMarketingGroup = "";
            }
            
            if (resp.data.ProductCategoryList.length > 0) {
                //console.log(resp.data.ProductCategoryList);
                $scope.objProductCategory = resp.data.ProductCategoryList;
            } else {
                $scope.objProductCategory = "";
            }

            
            if (resp.data.ProductHSNList.length > 0) {
                //console.log(resp.data.ProductHSNList);
                $scope.objProductHSN = resp.data.ProductHSNList;
            } else {
                $scope.objProductHSN = "";
            }
            
            if (resp.data.ProductUnitMasterList.length > 0) {
                //console.log(resp.data.ProductUnitMasterList);
                $scope.objProductUnitMaster = resp.data.ProductUnitMasterList;
            } else {
                $scope.objProductUnitMaster = "";
            }

            if (resp.data.ProductScheduleMasterList.length > 0) {
                //console.log(resp.data.ProductScheduleMasterList);
                $scope.objProductScheduleMaster = resp.data.ProductScheduleMasterList;
            } else {
                $scope.objProductScheduleMaster = "";
            }

        }, function () { alert('Error in getting records in getPageLoadData'); })

        requestPromise.push(httpPromise);

        if ($routeParams.ProductID != null) {

            // Update PageLoad
            $scope.mode = "Edit";
            $scope.btnText = "Update";
            $scope.pro.ProductID = $routeParams.ProductID;

            $http.get(retailConstant.serviceBaseUrl + '/MasterData/ProductMasterSelectOne?ProductID=' + $routeParams.ProductID).then(function (resp) {
                //console.log(resp);
                if (resp.data.length > 0) {
                    //$scope.SingleSingleProductArray = resp.data; //resp.data[0].Alias
                    console.log(resp.data[0]);
                    var selectedData = resp.data[0];

                    if (selectedData.MarketingGroupID != 0) {
                        $scope.pro.MarketingGroupID = "";
                        $scope.disabledMarketingCompany = false;
                        $scope.bindMarketingCompany(selectedData.MarketingGroupID);
                    } else {
                        $scope.disabledMarketingCompany = true;
                    }

                    $q.all(requestPromise).then(function (data) {

                    $scope.pro.ProductName = selectedData.ProductName;
                    $scope.pro.Alias = selectedData.Alias;
                    $scope.pro.Description = selectedData.Description;
                    $scope.pro.MarketingGroupID = selectedData.MarketingGroupID;

                    $scope.pro.MarketingCompanyID = selectedData.MarketingCompanyID;

                    $scope.pro.ProductCategoryID = selectedData.ProductCategoryID;
                    $scope.pro.HSNID = selectedData.HSNID;
                    $scope.pro.SizeStrength = selectedData.SizeStrength;
                    $scope.pro.SizeStrengthUnitID = selectedData.SizeStrengthUnitID;
                    $scope.pro.Brand = selectedData.Brand;
                    $scope.pro.PrintName = selectedData.PrintName;
                    $scope.pro.ScheduleID = selectedData.ScheduleID;
                    $scope.pro.Colour = selectedData.Colour;
                    $scope.pro.CaseLot = selectedData.CaseLot;
                        //$scope.pro.MinStock = parseInt(selectedData.MinStock.toFixed(2));
                    $scope.pro.MinStock = selectedData.MinStock;
                    $scope.pro.MaxStock = selectedData.MaxStock;
                    $scope.pro.BillingUnit1 = selectedData.BillingUnit1;
                    $scope.pro.PerUnit1Content = selectedData.PerUnit1Content;
                    $scope.pro.BillingUnit2 = selectedData.BillingUnit2;
                    $scope.pro.PerUnit2Content = selectedData.PerUnit2Content;
                    $scope.pro.BillingUnit3 = selectedData.BillingUnit3;
                        $scope.pro.AllowSellLoose = selectedData.AllowSellLoose == 1 ? true : false;
                    $scope.pro.MRP = selectedData.MRP;
                    $scope.pro.PurchaseRate = selectedData.PurchaseRate;
                    $scope.pro.SalesRate = selectedData.SalesRate;
                    $scope.pro.DistributionRate = selectedData.DistributionRate;
                    $scope.pro.TradeRate = selectedData.TradeRate;
                    $scope.pro.Length = selectedData.Length;
                    $scope.pro.LengthUnit = selectedData.LengthUnit;
                    $scope.pro.Width = selectedData.Width;
                    $scope.pro.WidthUnit = selectedData.WidthUnit;
                    $scope.pro.Height = selectedData.Height;
                    $scope.pro.HeightUnit = selectedData.HeightUnit;
                    $scope.pro.Weight = selectedData.Weight;
                    $scope.pro.WeightUnit = selectedData.WeightUnit;

                        if (selectedData.BillingUnit1 != 0 || selectedData.BillingUnit1 != 0 || selectedData.BillingUnit1 != 0) {
                            $scope.disabledSPRateUnit = false;
                        } else {
                            $scope.disabledSPRateUnit = true;
                        }

                    $scope.pro.PurchaseRateUnit = selectedData.PurchaseRateUnit;
                    $scope.pro.SalesRateUnit = selectedData.SalesRateUnit;

                        $scope.pro.ApplyOnLotBatch = selectedData.ApplyOnLotBatch == 1 ? true : false;
                        $scope.pro.ApplyOnLotBarCode = selectedData.ApplyOnLotBarCode == 1 ? true : false;
                        $scope.pro.ApplyOnLotMfgDate = selectedData.ApplyOnLotMfgDate == 1 ? true : false;
                        $scope.pro.ApplyOnLotExpiryDate = selectedData.ApplyOnLotExpiryDate == 1 ? true : false;
                        $scope.pro.ApplyOnLotUniqueID = selectedData.ApplyOnLotUniqueID == 1 ? true : false;
                        $scope.pro.ApplyOnLotKeepStock = selectedData.ApplyOnLotKeepStock == 1 ? true : false;

                    $scope.pro.ContinueStatus = selectedData.ContinueStatus;

                        if (selectedData.ContinueStatus == 2) {
                            $scope.hideDate = false;
                        } else {
                            $scope.hideDate = true;
                        }

                        //$scope.pro.DiscontinueDate = selectedData.DiscontinueDate;
                        //$scope.pro.DiscontinueDate = $filter('date')(selectedData.DiscontinueDate, "dd-MM-yyyy");
                        //debugger;
                        $scope.parseJsonDate(selectedData);
                    $scope.pro.DiscontinueDate = selectedData.DiscontinueDate;
                        console.log($scope.pro.DiscontinueDate);

                        $scope.pro.PrintBarCode = selectedData.PrintBarCode == 1 ? true : false;
                        $scope.pro.SKUProductName = selectedData.SKUProductName == 1 ? true : false;
                        $scope.pro.SKUSizeStrength = selectedData.SKUSizeStrength == 1 ? true : false;
                        $scope.pro.SKUUnit = selectedData.SKUUnit == 1 ? true : false;
                        $scope.pro.SKUMarketingCompany = selectedData.SKUMarketingCompany == 1 ? true : false;
                        $scope.pro.SKUSaleRateUnit = selectedData.SKUSaleRate == 1 ? true : false;
                        $scope.pro.SKUBrand = selectedData.SKUBrand == 1 ? true : false;
                        $scope.pro.SKULotID = selectedData.SKULotID == 1 ? true : false;
                        $scope.pro.SKUBatch = selectedData.SKUBatch == 1 ? true : false;
                        $scope.pro.SKUColor = selectedData.SKUColor == 1 ? true : false;
                        $scope.pro.SKUMRP = selectedData.SKUMRP == 1 ? true : false;
                        $scope.pro.SKUExpiryDate = selectedData.SKUExpiryDate == 1 ? true : false;
                        $scope.pro.SKUMFGDate = selectedData.SKUMFGDate == 1 ? true : false;
                        $scope.pro.SKUManufacturer = selectedData.SKUManufacturer == 1 ? true : false;
                        $scope.pro.SKUSaleRate = selectedData.SKUSaleRate == 1 ? true : false;
                        $scope.pro.SKUMRP = selectedData.SKUMRP == 1 ? true : false;
                        $scope.pro.SKUMRP = selectedData.SKUMRP == 1 ? true : false;
                    });

                }
            }, function () { alert('Error in getting records in ProductMasterSelectOne'); })

        }
    }

    $scope.showDate = function (type) {
        //console.log(type);
        $scope.pro.DiscontinueDate = "";
        if (type == 1) {
            $scope.hideDate = true;            
        } else {
            $scope.hideDate = false;
        }
    }

    $scope.getPageLoadData();


    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };

    $scope.ProductAddEdit = function (pro) {
        var action = $routeParams.ProductID == null ? 'AddProduct' : 'EditProduct';

        $http({
            method: 'POST',
            url: retailConstant.serviceBaseUrl + '/MasterData/' + action,
            data: JSON.stringify(pro),
            dataType: "json"
        }).then(function (httpResponse) {
            
            var response = httpResponse.data;

            alert(response.Message);

            if (response.Status == 1) {
                $scope.pro = {};

                if ($routeParams.ProductID != null) {
                    $location.path('/ProductMasterList');
                }
            }

        }, function (response) {
            alert(response.statusText);
        });
    }

    $scope.print_onClick = function () {
        alert('Product Master Print Click!');
    };

    $scope.draft_onClick = function () {
        alert('Product Master Draft Click!');
    };

    $scope.cancel_onClick = function (formIsChanged) {
        var confirmation = true;
        if (formIsChanged) {
            confirmation = confirm("Do yoy want to cancel?");
        }

        if (confirmation) {
            if (angular.isDefined($routeParams.ProductID)) {
                $location.url('ProductMasterList');
            }
            else {
                $route.reload();
            }
        }
        console.log('Product Master Cancel Click!');
    };

    $scope.enabledSPRateUnit = function (pro) {
        //console.log(pro);
        if (pro.BillingUnit1 != undefined || pro.BillingUnit2 != undefined || pro.BillingUnit3 != undefined) {
            if (pro.BillingUnit1 != "" || pro.BillingUnit2 != "" || pro.BillingUnit3 != "") {
                $scope.disabledSPRateUnit = false;
            } else {
                $scope.disabledSPRateUnit = true;
            }
        } else {
            $scope.disabledSPRateUnit = true;
        }
    }

   
    $scope.displayText = "";
    $scope.PopulateCategoryTaxDetails = function (ProductCategoryID) {
        console.log(ProductCategoryID);
        if (ProductCategoryID != "") {
            $http.get(retailConstant.serviceBaseUrl + '/MasterData/PopulateCategoryTaxDetails?ProductCategoryID=' + ProductCategoryID).then(function (httpResponse) {

                //console.log(resp);

                //$scope.displayText = "Called";
                //$scope.showCategoryTaxDetails = true;
                var response = httpResponse.data;

                if (response.Status == 1 && response.Data.length > 0) {
                    $scope.displayText = response.Data[0];
                $scope.showCategoryTaxDetails = true;
                }

            }, function () { alert('Error in getting records in PopulateCategoryTaxDetails'); })
        } else {
            $scope.displayText = "";
            $scope.showCategoryTaxDetails = false;
        }
    }

    $scope.displayTextHtml = function () {
        return $sce.trustAsHtml($scope.displayText);
    };

    /////////////////  Product Attribute  : rakesh ///////////////

    $scope.openPopup = function () {            
        $('#successmsg').modal('show');
        $scope.FillProductAttributeCategory();
        $scope.FillProductAttributeCategoryGrid();
        //$scope.Row = {};
        //$scope.Row.Active = false

        //$scope.section = FilterFor;
        //$scope.TempAccountArray = $scope.accountArray;

        //if (FilterBy == undefined || FilterBy.length > 0) {
        //    $('#myModal').modal('show');
        //} else {
        //    $('#myModal').modal('hide');
        //}

    };

    $scope.FillProductAttributeCategory = function () { 
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetProductAttributeCategory').then(function (resp) {
           
            if (resp.data.length > 0) {
               // console.log(resp.data);
                $scope.productAttributeCat = resp.data;
                
            } else {
                $scope.productAttributeCat = "";              
            }

        }, function () { alert('Error in getting records in bindMarketingCompany'); })

    }
    $scope.FillProductCategory = function (sss) {
        var AttributeCategoryID = $scope.productAttributeCat[0].AttributeCategoryID;
        var AttributeCategory = $scope.productAttributeCat[0].AttributeCategory;       
     
        //console.log($scope.pacitem.AttributeCategoryID);

        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetProductAttribute?AttributeCategoryID=' + 1).then(function (resp) {
           // console.log(resp.data);
            if (resp.data.length > 0) {            
                $scope.productAttribute = resp.data;
             
            } else {
                $scope.productAttribute = "";
            
            }

        }, function () { alert('Error in getting records in bindMarketingCompany'); })

    }

    $scope.FillProductAttributeCategoryGrid = function () {
        $scope.productID = 1;
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetProductAttributesCatList?productID=' + $scope.productID).then(function (resp) {
           // console.log(resp.data);
            if (resp.data.length > 0) {
                $scope.productAttributeCatList = resp.data;
            } else {
                $scope.productAttributeCatList = "";

            }

        }, function () { alert('Error in getting records in bindMarketingCompany'); })

    }

    $scope.addProductCatAtttibute = function (pac) {      
        var attrCatParam = pac.ProductAttributeCategoryID.split('|');
        var attrCatId = attrCatParam[0];
        var attrCatText = attrCatParam[1];

        var attrParam = pac.ProductAttributeID.split('|');
        var attrId = attrParam[0];
        var attrText = attrParam[1];    


        var productAttributeModel = 
        {
            "ProductID":1,
            "ProductAttributeID": attrId,
            "ProductAttributeCategoryID": attrCatId,
            "ProductAttribute": attrText,
            "ProductAttributeCategory": attrCatText        
           
        };     
       // console.log(productAttributeModel);
        $http({
            method: 'POST',
            url: retailConstant.serviceBaseUrl + '/MasterData/AddProductAttributesMap',
            data: JSON.stringify(productAttributeModel),
            dataType: "json"
        }).then(function (response) {
            //console.log(response);        
            if (response.data == "0") {                      
                
            } else {            
                $scope.productAttributeCatList.push({ ProductAttributeMapID: 1, ProductAttributeID: attrId, ProductAttributeCategoryID: attrCatId, ProductAttribute: attrText, ProductAttributeCategory: attrCatText });
               // console.log($scope.productAttributeCatList);
                alert("Attribute added successfully");
            }

        }, function (response) {
            alert(response.statusText);
        });
    }

    $scope.deleteProductAttributeCategory = function (ProductAttributeMap, ProductAttributeMapID) {
        var index = $scope.productAttributeCatList.indexOf(ProductAttributeMap);
        $http({
            method: 'POST',
            url: 'http://localhost:51327/MasterData/DeleteProductAttributesMap?ProductAttributeMapID=' + ProductAttributeMapID,
            dataType: "json"
        }).then(function (resp) {         
            $scope.productAttributeCatList.splice(index, 1);
            alert("Product Attributes deleted successfully!!!");
        }, function () {
            alert(data.errors);
        });

    };
    
    $scope.HasProductAttribute = function () {
        if ($routeParams.ProductID != null) {
            $scope.btnPopup = "Set Product Attributes";
            return true;
        }
        else {
            return false;
        }
    };

    /////////////////  Product Attribute  : rakesh ///////////////

}).filter('unique', function () {
    return function (collection, keyname) {
        var output = [],
            keys = [];

        angular.forEach(collection, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });

        return output;
    };
}).directive('decimalPlaces',function(){
    return {
        link:function(scope,ele,attrs){
            ele.bind('keypress',function(e){
                var newVal=$(this).val()+(e.charCode!==0?String.fromCharCode(e.charCode):'');
                if($(this).val().search(/(.*)\.[0-9][0-9]/)===0 && newVal.length>$(this).val().length){
                    e.preventDefault();
                }
            });
        }
    };
}).directive('decimalPlaces3', function () {
    return {
        link: function (scope, ele, attrs) {
            ele.bind('keypress', function (e) {
                var newVal = $(this).val() + (e.charCode !== 0 ? String.fromCharCode(e.charCode) : '');
                if ($(this).val().search(/(.*)\.[0-9][0-9][0-9]/) === 0 && newVal.length > $(this).val().length) {
                    e.preventDefault();
                }
            });
        }
    };
});