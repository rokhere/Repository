﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataStockLocationTransferEntryCtrl', function ($scope, $http, $filter, $route, $routeParams, retailConstant, retailSecurityService) {

    $scope.StockLocationTransferMasterModel = {};
    $scope.StockLocationTransferDetailModel = {};
    $scope.StockLocationTransferArray = [];
    $scope.EntryNoModel = {};
    $scope.FilterEntryNoModel = {};
    $scope.LocationModel = {};
    $scope.LocationArray = [];
    $scope.ProductArray = [];
    $scope.LotNoModel = {};
    $scope.LotNoArray = {};


    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };

    $scope.parseJsonDate = function (model) {
        // date format - /Date(1507573800000)/
        var pageDateFields = ['ExpiryDate', 'ManufacturingDate']                 // Add those fied which is not add as Date
        for (var property in model) {
            if (model.hasOwnProperty(property) && (property.indexOf('Date') > -1 || pageDateFields.indexOf(property) > -1)) {
                var jsonDateString = model[property] || '';
                if (jsonDateString.length > 0) {
                    var date = new Date(parseInt(jsonDateString.substr(6)));
                    model[property] = $filter('date')(date, "dd/MM/yyyy");;
                }
            }
        }
    };

    $scope.GetEntryNo = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetEntryNoList').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.EntryNoModel = resp.data;
            }
        }, function () { alert('Error in getting records'); })
    }

    $scope.PopulateLocationList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/PopulateLocationList').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.LocationArray = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    };

    $scope.OnChangeByEntryNo = function (EntryNoModel) {
        //var selectedText = EntN.options[EntN.selectedIndex].innerHTML;
        var selectedValue = EntN.value;

        $scope.FilterEntryNoModel = $filter('filter')(EntryNoModel, { 'SeriesID': selectedValue });

        //console.log(EntryNoModel);
        //alert(selectedValue);
        //alert(selectedText);
        //StockLocationTransferMasterModel.IssueLocationID = $scope.FilterEntryNoModel[0].IssueLocationID
        $scope.StockLocationTransferMasterModel.EntryNo = $scope.FilterEntryNoModel[0].EntryNo;
        $scope.StockLocationTransferMasterModel.IssueLocation = $scope.FilterEntryNoModel[0].IssueLocation;

        $scope.PopulateProductList($scope.FilterEntryNoModel[0].IssueLocationID)
    }


    //$scope.OnChangeByProduct = function (LocationID) {
    //    $scope.PopulateProductList(LocationID)
    //}

    $scope.PopulateProductList = function (LocationID) {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetTransactionProductList?LocationID=' + LocationID).then(function (resp) {
            if (resp.data.length > 0) {
                $scope.ProductArray = resp.data;                
            }

        }, function () { alert('Error in getting records'); })
    };

    $scope.openPopup = function (FilterBy) {
        //$scope.Accounts = $filter('filter')($scope.Accounts, FilterBy);
        //if (FilterBy.length > 0) {
        $('#myModalProduct').modal('show');
        //}        
    };

    $scope.selectRowForProduct = function (index) {
        $scope.StockLocationTransferDetailModel.ProductID = $scope.ProductArray[index].ProductID;
        $scope.StockLocationTransferDetailModel.ProductName = $scope.ProductArray[index].ProductName;
        $scope.PopulateLotNoListByLocationIDAndProductID();
        $('#myModalProduct').modal('hide');
    };

    $scope.openLotPopup = function () {
        //$scope.Accounts = $filter('filter')($scope.Accounts, FilterBy);
        //if (FilterBy.length > 0) {
        $('#myModalLot').modal('show');
        //}        
    };

    $scope.selectRowForLotNo = function (index) {       
        //$scope.StockLocationTransferDetailModel.ProductID = $scope.ProductArray[index].ProductID;
        $scope.StockLocationTransferDetailModel.LotNo = $scope.LotNoArray[index].LotNo;        
        $scope.StockLocationTransferDetailModel.BatchCode = $scope.LotNoArray[index].BatchCode;
        $scope.StockLocationTransferDetailModel.BarCode = $scope.LotNoArray[index].BarCode;
        $scope.StockLocationTransferDetailModel.Manufacturer = $scope.LotNoArray[index].Manufacturer;
        $scope.StockLocationTransferDetailModel.ManufacturingDate = $scope.LotNoArray[index].ManufacturingDate;
        $scope.StockLocationTransferDetailModel.ExpiryDate = $scope.LotNoArray[index].ExpiryDate;

        $('#myModalLot').modal('hide');
    };


    $scope.PopulateLotNoListByLocationIDAndProductID = function () {

        //if ($scope.StockLocationTransferMasterModel.LocationID != null && $scope.StockLocationTransferMasterModel.ProductID != null) {
            $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetLotNoByLocationIDAndProductID?LocationID=' + $scope.StockLocationTransferMasterModel.LocationID + '&ProductID=' + $scope.StockLocationTransferDetailModel.ProductID).then(function (resp) {
                if (resp.data.length > 0) {

                    var len = resp.data.length;
                    for (i = 0 ; i <= len ; i++) {
                        $scope.parseJsonDate(resp.data[i]);
                    }

                    $scope.LotNoArray = resp.data;
                }

            }, function () { alert('Error in getting records'); })
        //}
    };

    $scope.SaveStockLocationTransfer = function () {

        var StockLocationTransferModel = angular.copy($scope.StockLocationTransferMasterModel);
        postPurchaseModel.StockLocationTransferDetailModel = $scope.StockLocationTransferDetailModel;

        if ($scope.button == "Add Product") {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/AddStockLocationTransfer',
                data: JSON.stringify($scope.StockLocationTransferModel),
                dataType: "json"
            }).then(function (resp) {
                $scope.AccountGroups = null;
                alert("Billing Head added successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }
        else if ($scope.button == "Update") {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/UpdateBillingHead',
                data: JSON.stringify($scope.BillingHeadModel),
                dataType: "json"
            }).then(function (resp) {
                //$scope.AccountGroups = null;
                alert("Billing Head update successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }


    };

    $scope.GetSingleBillingHeadGetSingleStockLocationTransferListList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSingleStockLocationTransferList?StockTransferID=' + $routeParams.StockTransferID).then(function (resp) {
            if (resp.data.length > 0) {
                //$scope.StockLocationTransferModel.BillingHeadID = resp.data[0].BillingHeadID;
                //$scope.StockLocationTransferModel.BillingHead = resp.data[0].BillingHead;
                //$scope.StockLocationTransferModel.Account = resp.data[0].AcLedger;
                //$scope.StockLocationTransferModel.BillingHeadAddLess = resp.data[0].BillingHeadAddLess;
            }
        }, function () { alert('Error in getting records'); })
    }

    $scope.StockLocationTransferCheckAddEdit = function () {
        $scope.GetEntryNo();
        $scope.PopulateLocationList();
        //$scope.PopulateProductList();
        if ($routeParams.StockTransferID != null) {
            $scope.HeadingText = "Edit";
            $scope.button = "Update";
            $scope.GetSingleStockLocationTransferList();
        }
        else {
            $scope.HeadingText = "Entry";
            $scope.button = "Add Product";
        }
    }

    $scope.StockLocationTransferCheckAddEdit();

});