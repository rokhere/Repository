﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataAccountGroupEntryCtrl', function ($scope, $http, $filter, $q, $route, $routeParams, retailConstant, retailSecurityService) {
    //$scope.pageName = "Account Group";
    //$scope.AccountGroups = [];
    //$scope.AccountGroups = { AccountGroup: '', Alias: '', ParentGroupName: '-1', NatureOfAccount: '-1', AccountType: '-1', TradingAccount: '1' };    
    //$scope.AccountGroupsLoad = { NatureOfAccount: '-1', NatureOfAccount: '-1', AccountType: '-1', TradingAccount: '1', };

    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };

    $scope.AccountGroups = { AcNature: '-1', CashBankType: '-1' };   
    $scope.ParentAccountGroupArray = [];
    $scope.NOfAccList =
        [
            { AcNature: "-1", NatureOfAccount: "Please select Account Nature" },
            { AcNature: "1", NatureOfAccount: "Asset" },
            { AcNature: "2", NatureOfAccount: "Liability" },
            { AcNature: "3", NatureOfAccount: "Income" },
            { AcNature: "4", NatureOfAccount: "Expense" }
        ];

    $scope.AccTypeList =
       [
           { CashBankType: "-1", AccountType: "Please select Account Type" },
           { CashBankType: "1", AccountType: "Cash" },
           { CashBankType: "2", AccountType: "Bank" },
           { CashBankType: "3", AccountType: "Others" }
       ];
 
    $scope.PopulateParentAccountGroupList = function () {

        $http.get(retailConstant.serviceBaseUrl + '/MasterData/PopulateParentAccountGroupList').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.ParentAccountGroupArray = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    };

    $scope.SaveAccountGroup = function () {

        if ($scope.button == "Submit") {            
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/AddAccountGroup',
                data: JSON.stringify($scope.AccountGroups),
                dataType: "json"
            }).then(function (resp) {
                $scope.AccountGroups = null;
                alert("Account Group added successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }
        else if ($scope.button == "Update") {            
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/UpdateAccountGroup',
                data: JSON.stringify($scope.AccountGroups),
                dataType: "json"
            }).then(function (resp) {
                //$scope.AccountGroups = null;
                alert("Account Group update successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }


    };

    $scope.GetSingleAcGroupList = function () {        
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSingleAcGroupList?AcGroupID=' + $routeParams.AcGroupID).then(function (resp) {
            if (resp.data.length > 0) {
                //$scope.AccountGroups = resp.data[0];                
                //$scope.AccountGroups.AcGroup = $scope.AccountGroups[0].AcGroup;
                //$scope.AccountGroups.Alias = $scope.AccountGroups[0].Alias;
                //$scope.AccountGroups.AcGroupID = $scope.AccountGroups[0].AcGroupID;
                //$scope.AccountGroups.AcNature = $scope.AccountGroups[0].AcNature;
                //$scope.AccountGroups.CashBankType = $scope.AccountGroups[0].CashBankType;

                //if ($scope.AccountGroups[0].IsTradingAc==1) {
                //    //$scope.Items[0].Selected = true;
                //    $scope.AccountGroups.IsTradingAc = true;
                //} else {
                //    $scope.AccountGroups.IsTradingAc = false;
                //}
                //$scope.AccountGroups = null;

                $scope.AccountGroups.AcGroupID = resp.data[0].AcGroupID;
                $scope.AccountGroups.AcGroup = resp.data[0].AcGroup;
                $scope.AccountGroups.Alias = resp.data[0].Alias;
                $scope.AccountGroups.ParentGroup = resp.data[0].ParentGroup; //resp.data[0].ContinueStatus == 1 ? true : false;
                $scope.AccountGroups.ParentGroupName = resp.data[0].ParentGroupName;
                $scope.AccountGroups.AcNature = resp.data[0].AcNature;
                $scope.AccountGroups.CashBankType = resp.data[0].CashBankType;

                if (resp.data[0].IsTradingAc == 1) {
                    $scope.AccountGroups.IsTradingAc = true;
                } else {
                    $scope.AccountGroups.IsTradingAc = false;
                }                
            }
        }, function () { alert('Error in getting records'); })
    }

    $scope.AcGroupCheckAddEdit = function () {        
        $scope.PopulateParentAccountGroupList();

        if ($routeParams.AcGroupID != null) {
            $scope.HeadingText = "Edit";
            $scope.button = "Update";
            $scope.GetSingleAcGroupList();
        }
        else {
            $scope.HeadingText = "Entry";
            $scope.button = "Submit";
        }
    }

    $scope.AcGroupCheckAddEdit();
    
});