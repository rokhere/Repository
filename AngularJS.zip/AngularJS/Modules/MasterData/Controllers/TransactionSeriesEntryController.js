﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataTransactionSeriesEntryCtrl', function ($scope, $http, $filter, $route, $routeParams, retailConstant, retailSecurityService) {

    $scope.TransactionSeriesModel = { TransactionType: '-1', BillingRateValue: '-1' };
    $scope.TransactionSeriesArray = [];
    $scope.LocationArray = [];
    $scope.BillingRateArray = [];
   

    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };          


    $scope.SetPostInAccountDefaultStatus = function () {
        $scope.TransactionSeriesModel.IsAcImpact = true;
    };

    $scope.TransactionTypeArray =
        [
            { TransactionType: "-1", TransactionTypeText: "Please select Transaction Type" },
            { TransactionType: "1", TransactionTypeText: "Purchase Order" },
            { TransactionType: "2", TransactionTypeText: "Purchase Challan" },
            { TransactionType: "3", TransactionTypeText: "Purchase Invoice" },
            { TransactionType: "4", TransactionTypeText: "Purchase Return" },
            { TransactionType: "5", TransactionTypeText: "Sales Order" },
            { TransactionType: "6", TransactionTypeText: "Sales Challan" },
            { TransactionType: "7", TransactionTypeText: "Sales Invoice" },
            { TransactionType: "8", TransactionTypeText: "Sales Return" }
        ];


    $scope.BillingRateArray =
       [
           { BillingRateValue: "-1", BillingRateText: "Please select Billing Rate" },
           { BillingRateValue: "1", BillingRateText: "MRP" },
           { BillingRateValue: "2", BillingRateText: " Sales Rate" },
           { BillingRateValue: "3", BillingRateText: "Trade Rate" },
           { BillingRateValue: "4", BillingRateText: "Purchase Rate" },
           { BillingRateValue: "5", BillingRateText: "Distribution Rate" },
           { BillingRateValue: "6", BillingRateText: "Actual Cost Rate" }
       ];

    $scope.SaveTransactionSeries = function () {

        if ($scope.button == "Submit") {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/AddTransactionSeries',
                data: JSON.stringify($scope.TransactionSeriesModel),
                dataType: "json"
            }).then(function (resp) {
                $scope.TransactionSeriesModel = null;
                alert("Transaction Series added successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }
        else if ($scope.button == "Update") {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/UpdateTransactionSeries',
                data: JSON.stringify($scope.TransactionSeriesModel),
                dataType: "json"
            }).then(function (resp) {
                //$scope.AccountGroups = null;
                alert("Transaction Series update successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }


    };

    $scope.PopulateLocationList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/PopulateLocationList').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.LocationArray = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    };

    $scope.GetSingleTransactionSeriesList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSingleTransactionSeriesList?SeriesID=' + $routeParams.SeriesID).then(function (resp) {
            if (resp.data.length > 0) {                
                $scope.TransactionSeriesModel.SeriesID = resp.data[0].SeriesID;
                $scope.TransactionSeriesModel.Series = resp.data[0].Series;
                $scope.TransactionSeriesModel.StartingNo = resp.data[0].StartingNo;
                $scope.TransactionSeriesModel.LocationID = resp.data[0].LocationID;
                $scope.TransactionSeriesModel.Description = resp.data[0].Description;
                $scope.TransactionSeriesModel.BillingRateValue = resp.data[0].BillingRate;
                $scope.TransactionSeriesModel.TransactionType = resp.data[0].TransactionType;
                $scope.TransactionSeriesModel.IsAcImpact = resp.data[0].IsAcImpact == 1 ? true : false;


                //$scope.VendorMdl.IsAcImpact = resp.data[0].IsAcImpact == 1 ? true : false;
                //$scope.TransactionSeriesModel.IsAcImpact = resp.data[0].IsAcImpact;
            }
        }, function () { alert('Error in getting records'); })
    }

    $scope.TransactionSeriesCheckAddEdit = function () {
        
        $scope.PopulateLocationList();
        if ($routeParams.SeriesID != null) {
            $scope.HeadingText = "Edit";
            $scope.button = "Update";
            $scope.GetSingleTransactionSeriesList();
        }
        else {
            $scope.HeadingText = "Entry";
            $scope.button = "Submit";            
        }
    }

    $scope.SetPostInAccountDefaultStatus();
    $scope.TransactionSeriesCheckAddEdit();

});