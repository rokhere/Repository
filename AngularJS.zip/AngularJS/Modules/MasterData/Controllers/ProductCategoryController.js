﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataProductCategoryCtrl', function ($scope, $http, $filter, $q, $route, $routeParams, retailConstant, retailSecurityService) {
    
    $scope.ProductCategoryModel = {};
    $scope.pageName = "Master Data - Product Category";
    $scope.section = "";
    $scope.PurchasedTax = {};
    $scope.SaleTax = {};
    $scope.HSNCodeArray = [];
    $scope.ProductCategoryGroupArray = [];
    $scope.PurchasedTaxArray = [];
    $scope.SalesTaxArray = [];    
    $scope.TempTaxArray = [];
    $scope.SingleProductCategoryListArray = [];
    $scope.ProductCategoryGroup = '';
    $scope.showMessage = false;


    $scope.PurchasedTaxInnerState = {};
    $scope.SaleTaxInnerState = {};

    $scope.PurchasedTaxInnerStateArray = [];
    $scope.SalesTaxInnerStateArray = [];

    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };
    //$scope.purchasedata = false;
    //$scope.TempSaleTaxArray = [];
    //$scope.saledata = false;

    //$scope.GetHSNCodeList = function () {
    //    debugger;
    //    $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetHSNCodeList').then(function (resp) {
    //        if (resp.data.length > 0) {
    //            $scope.HSNCodeArray = resp.data;
    //        }

    //    }, function () { alert('Error in getting records'); })
    //};

    //$scope.GetProductCategoryGroupList = function () {
    //    debugger;
    //    $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetProductCategoryGroupList').then(function (resp) {
    //        if (resp.data.length > 0) {
    //            $scope.ProductCategoryGroupArray = resp.data;
    //        }            
    //    }, function () { alert('Error in getting records'); })
    //};

    $scope.GetHSNCodeList = function (httpResponse) {
        //console.log(httpResponse.data);
        debugger;
        var response = httpResponse.data;        
        if (response.length >0) {
            $scope.HSNCodeArray = response;
        }

        //if (httpResponse.data.Data.length > 0) {
        //    $scope.HSNCodeArray = httpResponse.data.Data;
        //}
    };

    $scope.GetProductCategoryGroupList = function (httpResponse) {
        //console.log(httpResponse.data);
        debugger;
        var response = httpResponse.data;
        if (response.length > 0) {
            $scope.ProductCategoryGroupArray = response;
        } 

        //if (httpResponse.data.Data.length > 0) {
        //    $scope.ProductCategoryGroupArray = httpResponse.data.Data;
        //}
    };

    $scope.CallMultiplePromise = function () {

        debugger;
        //Ref. https://stackoverflow.com/questions/29168316/angular-q-returning-promise-multiple-http-calls
        //return $q.all([$scope.GetProductCategoryGroupList(), $scope.GetHSNCodeList(), $scope.GetSingleCategoryList()]).then(function (results) {
        //    // OPTIONAL  aggregate results before resolving
        //    return results;
        //});

        //Product Category Group List
        var ProductCategoryGroupPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetProductCategoryGroupList');

        //HSN Code List
        var HSNCodePromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetHSNCodeList');

        


        if (angular.isDefined($routeParams.ProductCategoryID)) {

            //Single Category List
            var SingleCategoryPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSingleCategoryList?CategoryID=' + $routeParams.ProductCategoryID);

            //Add to chain
            $scope.combinedPromise = $q.all({
                SingleCategoryList: SingleCategoryPromise,
                ProductCategoryGroupList: ProductCategoryGroupPromise,
                HSNCodeList: HSNCodePromise
            });
        } else {
            //Add to chain
            $scope.combinedPromise = $q.all({
                ProductCategoryGroupList: ProductCategoryGroupPromise,
                HSNCodeList: HSNCodePromise
            });
        }

        
        
        //CombinedPromise then
        $scope.combinedPromise.then(function (responses) {
            //console.log(responses);

            if (responses.SingleCategoryList) {
                $scope.GetSingleCategoryList(responses.SingleCategoryList);
            }

            if (responses.ProductCategoryGroupList) {

                $scope.GetProductCategoryGroupList(responses.ProductCategoryGroupList);
            }

            if (responses.HSNCodeList) {
                $scope.GetHSNCodeList(responses.HSNCodeList);
            }

           

        });


    };

    $scope.GetPurchasedTaxList = function () {        
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetPurchasedTaxList').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.PurchasedTaxArray = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    };

    $scope.GetSalesTaxList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSalesTaxList').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.SalesTaxArray = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    };

    $scope.GetPurchasedTaxInnerStateList = function () {        
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetPurchasedTaxInnerStateList').then(function (resp) {            
            if (resp.data.length > 0) {                
                $scope.PurchasedTaxInnerStateArray = resp.data;
                $scope.PurchasedTaxInnerState = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    };

    $scope.GetSalesTaxInnerStateList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSalesTaxInnerStateList').then(function (resp) {
            if (resp.data.length > 0) {                
                $scope.SalesTaxInnerStateArray = resp.data;
                $scope.SaleTaxInnerState = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    };

    //Assign in the Purchase popup
    $scope.change = function (FilterFor,FilterBy) {
               
        $scope.popupData = [];
        $scope.popupData = "";
        $scope.TempPurchasedTaxArray = "";
        $scope.search = "";
        


        $scope.section = FilterFor;

        if ($scope.section == "P") {
            $scope.popupData = $scope.PurchasedTaxArray;
        }
        else if ($scope.section == "S") {
            $scope.popupData = $scope.SalesTaxArray;
        }
        else if ($scope.section == "PIS") {
            $scope.popupData = $scope.PurchasedTaxInnerStateArray;
        }
        else if ($scope.section == "SIS") {
            $scope.popupData = $scope.SalesTaxInnerStateArray;
        }

        $scope.TempTaxArray = $scope.popupData;

        //$scope.TempTaxArray = $filter('filter')($scope.popupData, FilterBy);
        //if (FilterBy.length > 0) {           
        //} 

        $('#myModal').modal('show');
    };

    //Selected Radio Button Value from purchase dropdown
    $scope.selectRow = function (index) {
        if ($scope.section == "P") {
            $scope.ProductCategoryModel.PurchasedTaxTaxCode = $scope.TempTaxArray[index].TaxCode;
            $scope.ProductCategoryModel.PurchasedTaxTaxID = $scope.TempTaxArray[index].TaxID;
        } else if ($scope.section == "S") {
            $scope.ProductCategoryModel.SaleTaxTaxCode = $scope.TempTaxArray[index].TaxCode;
            $scope.ProductCategoryModel.SaleTaxTaxID = $scope.TempTaxArray[index].TaxID;
        } else if ($scope.section == "PIS") {
            $scope.ProductCategoryModel.PurchasedTaxInnerStateTaxCode = $scope.TempTaxArray[index].TaxCode;
            $scope.ProductCategoryModel.PurchasedTaxInnerStateTaxID = $scope.TempTaxArray[index].TaxID;
        } else if ($scope.section == "SIS") {
            $scope.ProductCategoryModel.SaleTaxInnerStateTaxCode = $scope.TempTaxArray[index].TaxCode;
            $scope.ProductCategoryModel.SaleTaxInnerStateTaxID = $scope.TempTaxArray[index].TaxID;
        }

        $('#myModal').modal('hide');        
    };

    $scope.SaveCategory = function (formIsValid) {

        if (formIsValid) {

            if ($scope.button == "Submit") {
                var Category = {
                    ProductCategory: $scope.ProductCategoryModel.ProductCategory, Alias: $scope.ProductCategoryModel.Alias,
                    ProductCategoryGroupID: $scope.ProductCategoryModel.ProductCategoryGroupID, HSNID: $scope.ProductCategoryModel.HSNID,
                    DiscLimitPercentage: $scope.ProductCategoryModel.DiscLimitPercentage, PTaxID: $scope.ProductCategoryModel.PurchasedTaxTaxID,
                    STaxID: $scope.ProductCategoryModel.SaleTaxTaxID, outsideStatePTaxID: $scope.ProductCategoryModel.PurchasedTaxInnerStateTaxID,
                    outsideStateSTaxID: $scope.ProductCategoryModel.SaleTaxInnerStateTaxID
                };
                $http({
                    method: 'POST',
                    url: retailConstant.serviceBaseUrl + '/MasterData/AddCategory',
                    data: JSON.stringify(Category),
                    dataType: "json"
                }).then(function (resp) {
                    $scope.empModel = null;
                    alert("Category added successfully!!!");
                }, function () {
                    alert(data.errors);
                });
            }
            else if ($scope.button == "Update") {

                var Category = {
                    productCategoryID: $routeParams.ProductCategoryID, ProductCategory: $scope.ProductCategoryModel.ProductCategory, Alias: $scope.ProductCategoryModel.Alias,
                    ProductCategoryGroupID: $scope.ProductCategoryModel.ProductCategoryGroupID, HSNID: $scope.ProductCategoryModel.HSNID,
                    DiscLimitPercentage: $scope.ProductCategoryModel.DiscLimitPercentage, PTaxID: $scope.ProductCategoryModel.PurchasedTaxTaxID,
                    STaxID: $scope.ProductCategoryModel.SaleTaxTaxID, outsideStatePTaxID: $scope.ProductCategoryModel.PurchasedTaxInnerStateTaxID,
                    outsideStateSTaxID: $scope.ProductCategoryModel.SaleTaxInnerStateTaxID
                };
                //console.log(Category);
                $http({
                    method: 'POST',
                    url: retailConstant.serviceBaseUrl + '/MasterData/UpdateCategory',
                    data: JSON.stringify(Category),
                    dataType: "json"
                }).then(function (resp) {
                    $scope.empModel = null;
                    alert("Category update successfully!!!");
                }, function () {
                    alert(data.errors);
                });
            }

        }
        else {
            $scope.showMessage = true;
        }

    };


    $scope.GetSingleCategoryList = function (httpResponse) {
        debugger;
        var response = httpResponse.data;

            if (response.length > 0) {

                $scope.SingleProductCategoryListArray = response;

                $scope.ProductCategoryModel.ProductCategory = $scope.SingleProductCategoryListArray[0].ProductCategory;
                $scope.ProductCategoryModel.DiscLimitPercentage = $scope.SingleProductCategoryListArray[0].DiscLimitPercentage;
                $scope.ProductCategoryModel.Alias = $scope.SingleProductCategoryListArray[0].Alias;

                $scope.ProductCategoryModel.ProductCategoryGroupID = $scope.SingleProductCategoryListArray[0].ProductCategoryGroupID;
                $scope.ProductCategoryModel.ProductCategoryGroup = $scope.SingleProductCategoryListArray[0].ProductCategoryGroup;
                

                $scope.ProductCategoryModel.HSNID = $scope.SingleProductCategoryListArray[0].HSNID;


                $scope.ProductCategoryModel.PurchasedTaxTaxCode = $scope.SingleProductCategoryListArray[0].PTaxCode;
                $scope.ProductCategoryModel.PurchasedTaxTaxID = $scope.SingleProductCategoryListArray[0].PTaxID;

                $scope.ProductCategoryModel.SaleTaxTaxCode = $scope.SingleProductCategoryListArray[0].STaxCode;
                $scope.ProductCategoryModel.SaleTaxTaxID = $scope.SingleProductCategoryListArray[0].STaxID;

                $scope.ProductCategoryModel.PurchasedTaxInnerStateTaxCode = $scope.SingleProductCategoryListArray[0].OutsideStatePTaxCode;
                $scope.ProductCategoryModel.PurchasedTaxInnerStateTaxID = $scope.SingleProductCategoryListArray[0].OutsideStatePTaxID;

                $scope.ProductCategoryModel.SaleTaxInnerStateTaxCode = $scope.SingleProductCategoryListArray[0].OutsideStateSTaxCode;
                $scope.ProductCategoryModel.SaleTaxInnerStateTaxID = $scope.SingleProductCategoryListArray[0].OutsideStateSTaxID;

            }
    }


    //$scope.GetSingleCategoryList = function () {

    //    debugger;
    //    $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSingleCategoryList?CategoryID=' + $routeParams.ProductCategoryID).then(function (resp) {
    //        if (resp.data.length > 0) {

    //            $scope.SingleProductCategoryListArray = resp.data;

    //            $scope.ProductCategoryModel.ProductCategory = $scope.SingleProductCategoryListArray[0].ProductCategory;
    //            $scope.ProductCategoryModel.DiscLimitPercentage = $scope.SingleProductCategoryListArray[0].DiscLimitPercentage;
    //            $scope.ProductCategoryModel.Alias = $scope.SingleProductCategoryListArray[0].Alias;

    //            $scope.ProductCategoryModel.ProductCategoryGroupID = $scope.SingleProductCategoryListArray[0].ProductCategoryGroupID;

    //            $scope.ProductCategoryModel.HSNID = $scope.SingleProductCategoryListArray[0].HSNID;

                
    //            $scope.ProductCategoryModel.PurchasedTaxTaxCode = $scope.SingleProductCategoryListArray[0].PTaxCode;
    //            $scope.ProductCategoryModel.PurchasedTaxTaxID = $scope.SingleProductCategoryListArray[0].PTaxID;

    //            $scope.ProductCategoryModel.SaleTaxTaxCode = $scope.SingleProductCategoryListArray[0].STaxCode;
    //            $scope.ProductCategoryModel.SaleTaxTaxID = $scope.SingleProductCategoryListArray[0].STaxID;

    //            $scope.ProductCategoryModel.PurchasedTaxInnerStateTaxCode = $scope.SingleProductCategoryListArray[0].OutsideStatePTaxCode;
    //            $scope.ProductCategoryModel.PurchasedTaxInnerStateTaxID = $scope.SingleProductCategoryListArray[0].OutsideStatePTaxID;
                
    //            $scope.ProductCategoryModel.SaleTaxInnerStateTaxCode = $scope.SingleProductCategoryListArray[0].OutsideStateSTaxCode;
    //            $scope.ProductCategoryModel.SaleTaxInnerStateTaxID = $scope.SingleProductCategoryListArray[0].OutsideStateSTaxID;
                
    //        }

    //        //$scope.GetProductCategoryGroupList();
    //        //$scope.GetHSNCodeList();
    //    }, function () { alert('Error in getting records'); })
    //}

    $scope.CheckAddEdit = function () {
        //var ProductCategoryID = getUrlParameter('ProductCategoryID');
        //alert($routeParams.ProductCategoryID);
                   
        //$scope.GetProductCategoryGroupList();
        //$scope.CallMultiplePromise();
        
        
        $scope.GetPurchasedTaxList();
        $scope.GetSalesTaxList();

        $scope.GetPurchasedTaxInnerStateList();
        $scope.GetSalesTaxInnerStateList();

        if ($routeParams.ProductCategoryID != null) {
           
            
            $scope.HeadingText = "Edit";
            $scope.button = "Update";
            //$scope.GetSingleCategoryList();
            $scope.CallMultiplePromise();
            
        }
        else {
            //$scope.GetProductCategoryGroupList();
            //$scope.GetHSNCodeList();
            $scope.CallMultiplePromise();
            $scope.HeadingText = "Entry";
            $scope.button = "Submit";
        }
    }

    $scope.CheckAddEdit();    
})

  .filter('unique', function () {
      return function (collection, keyname) {
          var output = [],
              keys = [];

          angular.forEach(collection, function (item) {
              var key = item[keyname];
              if (keys.indexOf(key) === -1) {
                  keys.push(key);
                  output.push(item);
              }
          });

          return output;
      };
  });