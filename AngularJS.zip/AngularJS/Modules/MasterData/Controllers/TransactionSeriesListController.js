﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataTransactionSeriesListCtrl', function ($scope, $http, $filter, $route, retailConstant, retailSecurityService) {
    $scope.pageName = "Transaction Series";
    $scope.TransactionSeriesModel = {};
    $scope.SearchModel = { SearchKeyword: ''};
    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };

    $scope.populateTransactionSeries = function (SearchKeyword) {

        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetTransactionSeriesList?SearchKeyword=' + SearchKeyword).then(function (resp) {
            if (resp.data.length > 0) {
                $scope.TransactionSeriesModel = resp.data;
            }

        }, function () { alert('Error in getting records'); })
    }

    $scope.DeleteTransactionSeries = function (SeriesID) {

        if (confirm("Are you sure to delete this Transaction Series?")) {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/DeleteTransactionSeries?SeriesID=' + SeriesID,
                //data: JSON.stringify(Category),
                dataType: "json"
            }).then(function (resp) {
                //$scope.empModel = null;
                $scope.populateTransactionSeries('');
                alert("Transaction Series deleted successfully!!!");
            }, function () {
                alert(data.errors);
            });
        }

    };

    $scope.populateTransactionSeries('');
});