﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataTaxRateDetailCtrl', function ($scope, $http, $filter, $q, $route, $routeParams, retailConstant, retailSecurityService) {

    $scope.pageName = "Tax Rate Details";
    $scope.taxTypes = [];
    $scope.taxRates = [];
    $scope.taxRateDetailModel = { TaxTypeID: '', TaxRateID: '', IsWithinState: '', TaxRateBreakup: '', TaxRateValue: '' };


    //$scope.$watch('taxRateDetailModel.TaxTypeID', function (newValue, oldValue) {
    //    if (angular.isDefined(newValue) && newValue !='') {
    //        $scope.LoadTaxddl();
    //    }
    //});

    //$scope.populateTaxTypes = function () {

    //    $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetTaxTypes').then(function (httpResponse) {
    //        var response = httpResponse.data;

    //        if (response.Status == 1) {
    //            $scope.taxTypes = response.Data;
    //        }
    //    });
    //};

    //$scope.populateTaxRates = function (httpResponse) {

    //    if (httpResponse.data.length > 0) {
    //        $scope.taxRates = httpResponse.data.Data;
    //    }
    //};


    //$scope.LoadTaxddl = function () {
    //    //debugger;
    //    var TaxTypeID = $scope.taxRateDetailModel.TaxTypeID;
    //    if (angular.isDefined(TaxTypeID)) {
    //        var TaxRatesPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetTaxRates?TaxTypeID=' + TaxTypeID);
    //        //Add to chain
    //        $scope.combinedPromise = $q.all({ taxRates: TaxRatesPromise });
    //        //CombinedPromise then
    //        $scope.combinedPromise.then(function (responses) {
    //            debugger;
    //            if (responses.taxRates) {
    //                $scope.populateTaxRates(responses.taxRates);
    //            }
    //        });
    //    }
    //};

    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };

    $scope.resetTaxRateModel = function () {
        $scope.taxRateDetailModel = { TaxTypeID: '', TaxRateID: '', IsWithinState: '', TaxRateBreakup: '', TaxRateValue: '' };
    };

    $scope.populateTaxTypes = function () {
      
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetTaxTypes').then(function (httpResponse) {
            var response = httpResponse.data;

            if (response.Status == 1) {
                $scope.taxTypes = response.Data;
            }
        });
    };

    $scope.populateTaxRates = function (TaxTypeID) {
    
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetTaxRates?TaxTypeID=' + TaxTypeID).then(function (httpResponse) {
            var response = httpResponse.data;
            debugger;
            if (response.Status == 1) {
                $scope.taxRates = response.Data;
            }

        });
    };

    $scope.openPopup = function (FilterBy) {
        //$scope.Accounts = $filter('filter')($scope.Accounts, FilterBy);
        //if (FilterBy.length > 0) {
        $('#myModaltaxRates').modal('show');
        //}        
    };

    $scope.selectRowFortaxRates = function (index) {
        $scope.taxRateDetailModel.TaxRateID = $scope.taxRates[index].TaxRateID;
        $scope.taxRateDetailModel.TaxRateDesc = $scope.taxRates[index].TaxRateDesc;
        $('#myModaltaxRates').modal('hide');
    };

    $scope.populateTaxRateModel = function () {
        var taxRateDetailId = $routeParams.taxRateDetailId;
        
        if (angular.isDefined(taxRateDetailId)) {            
            $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSingleTaxRateDetail?taxRateDetailId=' + taxRateDetailId).then(function (resp) {
                if (resp.data.length > 0) {
                    debugger;
                    
                    $scope.taxRateDetailModel = resp.data;                    
                    $scope.taxRateDetailModel.TaxTypeID = resp.data[0].TaxTypeID;
                    
                    $scope.populateTaxRates(resp.data[0].TaxTypeID);

                    $scope.taxRateDetailModel.TaxRateID = resp.data[0].TaxRateID;

                    $scope.taxRateDetailModel.TaxRateDesc = resp.data[0].TaxRateDesc;
                    $scope.taxRateDetailModel.IsWithinState = resp.data[0].IsWithinState == 0 ? 2 : resp.data[0].IsWithinState;

                    $scope.taxRateDetailModel.TaxRateBreakup = resp.data[0].TaxRateBreakup;
                    $scope.taxRateDetailModel.TaxRateValue = resp.data[0].TaxRateValue;
                   

                    //$scope.LoadTaxddl();
                }
            }, function () { alert('Error in getting records'); })            
        }
    };

    $scope.add_Onclick = function (formIsValid) {
        //TODO: Validation change
        if (formIsValid) {
            console.log('Server Call - SaveTaxRateDetail');
            console.log($scope.taxRateDetailModel);
            var taxRateDetailModel = { TaxRateDetailID: $routeParams.taxRateDetailId, TaxTypeID: $scope.taxRateDetailModel.TaxTypeID, TaxRateID: $scope.taxRateDetailModel.TaxRateID, IsWithinState: $scope.taxRateDetailModel.IsWithinState, TaxRateBreakup: $scope.taxRateDetailModel.TaxRateBreakup, TaxRateValue: $scope.taxRateDetailModel.TaxRateValue };
            debugger;
            $http.post(retailConstant.serviceBaseUrl + '/MasterData/SaveTaxRateDetail', JSON.stringify(taxRateDetailModel)).then(function (httpResponse) {
                var response = httpResponse.data;
                //TODO: Validation change
                if (response.Status == 1) {
                    $scope.resetTaxRateModel();
                }

                alert(response.Message);
            });
        }
    };

    $scope.populateTaxTypes();
    //$scope.populateTaxRates();
    $scope.populateTaxRateModel();
});