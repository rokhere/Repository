﻿var retailMasterDataApp = angular.module('Retail');
retailMasterDataApp.controller('masterDataTaxConfigurationCtrl', function ($scope, $q, $sce, $filter, $route, $http, $routeParams, $location, retailConstant, retailSecurityService) {
    $scope.btnText = "Submit";
    $scope.tax = {};
    $scope.FinalFilterAccountModel = [];
    //$scope.tax.TaxID = 0;
    var requestPromise = [];
    $scope.taxRates = [];
    $scope.taxTypes = [];  
    $scope.showMessage = false;


    $scope.SetDefaultTransactionType = function () {        
        $scope.tax.AppliedOn = 1;
        $scope.PostingAccountText = "Sales";
    };

    $scope.showTransactionType = function (type) {        
        if (type == 1) {
            $scope.tax.AppliedOn = 1;
            $scope.PostingAccountText = "Sales";
        } else {
            $scope.tax.AppliedOn = 0;
            $scope.PostingAccountText = "Purchase";
        }
    }

    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForCreate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Create);
    };

    $scope.populateTaxTypes = function () {
        var httpPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetTaxTypes').then(function (httpResponse) {
            var response = httpResponse.data;

            if (response.Status == 1) {
                $scope.taxTypes = response.Data;
            }
        });
        //requestPromise.push(httpPromise);
    };

    $scope.openTaxRatePopup = function (FilterBy) {
        //$scope.Accounts = $filter('filter')($scope.Accounts, FilterBy);
        //if (FilterBy.length > 0) {
        $('#myModaltaxRates').modal('show');
        //}        
    };

    $scope.selectRowFortaxRates = function (index) {
        $scope.tax.TaxRateDetailID = $scope.taxRates[index].TaxRateID;
        $scope.tax.TaxRateDesc = $scope.taxRates[index].TaxRateDesc;
        $('#myModaltaxRates').modal('hide');
    };

    //$scope.populateTaxTypes();

    
    //$scope.populateTaxRates = function () {

    //    var httpPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetTaxRates').then(function (httpResponse) {
    //        var response = httpResponse.data;
    //        //console.log(response.Data); 
    //        if (response.Status == 1) {
    //            $scope.taxRates = response.Data;
    //        }

    //    });
    //    requestPromise.push(httpPromise);
    //};
    //$scope.populateTaxRates();

    $scope.populateTaxRates = function (TaxTypeID) {

        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetTaxRates?TaxTypeID=' + TaxTypeID).then(function (httpResponse) {
            var response = httpResponse.data;

            if (response.Status == 1) {
                $scope.taxRates = response.Data;
            }

        });
    };

    $scope.displayText = "<strong>CGST</strong> = 6% &nbsp; | &nbsp;<strong>SGST</strong> = 6%";
    $scope.BindDisplayText = function (IsWithinState, TaxTypeID, TaxRateDetailID) {

        //console.log("IsWithinState: " + IsWithinState + "; TaxTypeID: " + TaxTypeID + "; TaxRateID: " + TaxRateDetailID + ";");

        if (IsWithinState != undefined && TaxTypeID != undefined && TaxRateDetailID != undefined) {
            $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetTaxRateDetailsText?IsWithinState=' + IsWithinState + '&TaxTypeID=' + TaxTypeID + '&TaxRateID=' + TaxRateDetailID).then(function (resp) {

                if (resp.data.Data.length > 0) {

                    $scope.displayText = "";
                    //console.log(resp.data);
                    //console.log("TaxRateBreakup: " + resp.data.Data[0].TaxRateBreakup);
                    //console.log("TaxRateValue: " + resp.data.Data[0].TaxRateValue);
                    angular.forEach(resp.data.Data, function (value, index) {
                        $scope.displayText += value.TaxRateBreakup + (resp.data.Data.length > 1 ? " | " : "");
                    })

                }

            }, function () { alert('Error in getting records'); })
        }
    };

    $scope.displayTextHtml = function () {
        return $sce.trustAsHtml($scope.displayText);
    };

    //$scope.accountArray = [
    //    { ID: '1', SGSTValue: 'SGST Tax Rate 1', CGSTValue: 'CGST Tax Rate 1' },
    //     { ID: '2', SGSTValue: 'SGST Tax Rate 2', CGSTValue: 'CGST Tax Rate 2' },
    //      { ID: '3', SGSTValue: 'SGST Tax Rate 3', CGSTValue: 'CGST Tax Rate 3' },
    //];
    $scope.accountArray = {};
    $scope.getPostingAccount = function () {

        //var deferred = $q.defer();

        var httpPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetPostingAccount').then(function (resp) {

            //deferred.resolve(resp);

            if (resp.data.length > 0) {
                $scope.accountArray = resp.data;
                //console.log(resp.data);
            }

        }, function () {
            //deferred.reject({ message: "Really bad" }); 
            alert('Error in getting records');
        })

        //return deferred.promise;
        requestPromise.push(httpPromise);
    }
    //$scope.getPostingAccount();


    //$scope.showSGSTValue = false;
    //$scope.showCGSTValue = false;

    $scope.openPopup = function (FilterFor, FilterBy) {

        console.log("FilterFor: " + FilterFor + "; FilterBy: " + FilterBy + ";");

        $scope.Row = {};
        $scope.Row.Active = false

        $scope.section = FilterFor;
        $scope.TempAccountArray = $scope.accountArray;

        //if (FilterFor == "1") {
        //    $scope.showSGSTValue = true;
        //    $scope.showCGSTValue = false;
        //    $scope.TempAccountArray = $filter('filter')($scope.accountArray, { SGSTValue: FilterBy });
        //}
        //else {
        //    $scope.showSGSTValue = false;
        //    $scope.showCGSTValue = true;
        //    $scope.TempAccountArray = $filter('filter')($scope.accountArray, { CGSTValue: FilterBy });
        //}        

        if (FilterBy == undefined || FilterBy.length > 0) {
            $('#myModal').modal('show');
        } else {
            $('#myModal').modal('hide');
        }
    };

    $scope.selectRow = function (AcLedgerID) {
        //if ($scope.section == "1") {
        //    $scope.tax.SGSTPostingAccount = $scope.TempAccountArray[index].SGSTValue;
        //    //$scope.ID = $scope.TempAccountArray[index].ID;
        //} else {
        //    $scope.tax.CGSTPostingAccount = $scope.TempAccountArray[index].CGSTValue;
        //    //$scope.ID = $scope.TempAccountArray[index].ID;
        //}
               
        $scope.FinalFilterAccountModel = $filter('filter')($scope.TempAccountArray, { 'AcLedgerID': AcLedgerID });
       
        if ($scope.section == "1") {
            $scope.tax.SGSTAcHeadText = $scope.FinalFilterAccountModel[0].AcLedger;
            $scope.tax.SGSTAcHead = $scope.FinalFilterAccountModel[0].AcLedgerID;
        }
        else if ($scope.section == "2") {
            $scope.tax.CGSTAcHeadText = $scope.FinalFilterAccountModel[0].AcLedger;
            $scope.tax.CGSTAcHead = $scope.FinalFilterAccountModel[0].AcLedgerID;
        }
        else if ($scope.section == "3") {
            $scope.tax.IGSTAcHeadText = $scope.FinalFilterAccountModel[0].AcLedger;
            $scope.tax.IGSTAcHead = $scope.FinalFilterAccountModel[0].AcLedgerID;
        }
        else if ($scope.section == "4") {
            $scope.tax.PSAcHeadText = $scope.FinalFilterAccountModel[0].AcLedger;
            $scope.tax.PSAcHead = $scope.FinalFilterAccountModel[0].AcLedgerID;
        }
        else if ($scope.section == "5") {
            $scope.tax.PSReturnAcHeadText = $scope.FinalFilterAccountModel[0].AcLedger;
            $scope.tax.PSReturnAcHead = $scope.FinalFilterAccountModel[0].AcLedgerID;
        }
        else if ($scope.section == "6") {
            $scope.tax.PSClaimAcHeadText = $scope.FinalFilterAccountModel[0].AcLedger;
            $scope.tax.PSClaimAcHead = $scope.FinalFilterAccountModel[0].AcLedgerID;
        }
        else if ($scope.section == "7") {
            $scope.tax.GSTCESSAcHeadText = $scope.FinalFilterAccountModel[0].AcLedger;
            $scope.tax.GSTCESSAcHead = $scope.FinalFilterAccountModel[0].AcLedgerID;
        }


        $('#myModal').modal('hide');
    };


    $scope.getPageLoadData = function () {

        // Normal PageLoad        
        $scope.populateTaxTypes();
        //$scope.populateTaxRates();
        $scope.getPostingAccount();
        //console.log(requestPromise);
        $q.all(requestPromise).then(function (data) {
            if ($routeParams.TaxID != null) {

                // Update PageLoad
                $scope.btnText = "Update";
                $scope.tax.TaxID = $routeParams.TaxID;

                $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetSingleTaxConfig?TaxID=' + $routeParams.TaxID).then(function (resp) {
                    if (resp.data.length > 0) {
                        //console.log(resp.data);
                        var selectedData = resp.data[0];
                        // $scope.tax.AppliedOn = selectedData.AppliedOn;
                        //console.log(selectedData.AppliedOn);

                        $scope.tax.TaxCode = selectedData.TaxCode;
                        $scope.tax.Description = selectedData.Description;
                        $scope.tax.AppliedOn = selectedData.AppliedOn;
                        
                        $scope.populateTaxRates(selectedData.TaxTypeID);

                        //$scope.BindDisplayText(selectedData.IsWithinState, selectedData.TaxTypeID, selectedData.TaxRateDetailID);

                        $scope.tax.IsWithinState = selectedData.IsWithinState;
                        $scope.tax.TaxTypeID = selectedData.TaxTypeID;
                        $scope.tax.TaxRateDetailID = selectedData.TaxRateDetailID;
                        $scope.tax.TaxRateDesc = selectedData.TaxRateDesc;

                        if (selectedData.AppliedOn == 1) {
                            $scope.PostingAccountText = "Sales";
                        } else {
                            $scope.PostingAccountText = "Purchase";
                        }

                        
                        //$scope.tax.TaxRateDetailID = $scope.populateTaxRates(resp.data[0].TaxTypeID);

                        if (selectedData.SGSTAcHead != null) {
                            $scope.tax.SGSTAcHeadText = $scope.getAcLedgerValue(selectedData.SGSTAcHead);
                            $scope.tax.SGSTAcHead = selectedData.SGSTAcHead;
                        }
                        if (selectedData.CGSTAcHead != null) {                           
                            $scope.tax.CGSTAcHeadText = $scope.getAcLedgerValue(selectedData.CGSTAcHead);
                            $scope.tax.CGSTAcHead = selectedData.CGSTAcHead;
                        }

                        
                        if (selectedData.IGSTAcHead != null) {
                            $scope.tax.IGSTAcHeadText = $scope.getAcLedgerValue(selectedData.IGSTAcHead);
                            $scope.tax.IGSTAcHead = selectedData.IGSTAcHead;
                        }

                        if (selectedData.PSAcHead != null) {
                            $scope.tax.PSAcHeadText = $scope.getAcLedgerValue(selectedData.PSAcHead);
                            $scope.tax.PSAcHead = selectedData.PSAcHead;
                        }

                        if (selectedData.PSReturnAcHead != null) {
                            $scope.tax.PSReturnAcHeadText = $scope.getAcLedgerValue(selectedData.PSReturnAcHead);
                            $scope.tax.PSReturnAcHead = selectedData.PSReturnAcHead;
                        }

                        if (selectedData.PSClaimAcHead != null) {
                            $scope.tax.PSClaimAcHeadText = $scope.getAcLedgerValue(selectedData.PSClaimAcHead);
                            $scope.tax.PSClaimAcHead = selectedData.PSClaimAcHead;
                        }
                        $scope.tax.CessType = selectedData.CessType;
                        $scope.tax.CessDescription = selectedData.CessDescription;
                        $scope.tax.CessInPercentage = selectedData.CessInPercentage;
                        $scope.tax.CessRatePerUnit = selectedData.CessRatePerUnit;

                        $scope.tax.GSTCESSAcHeadText = $scope.getAcLedgerValue(selectedData.GSTCESSAcHead);
                        $scope.tax.GSTCESSAcHead = selectedData.GSTCESSAcHead;
                    }
                }, function () { alert('Error in getting records'); })

            }
            else
            {                
                $scope.SetDefaultTransactionType();
            }
        });
    };
    $scope.getAcLedgerValue = function (AcLedgerID) {
        //console.log($scope.accountArray);

        if (AcLedgerID != null) {
            return $filter('filter')($scope.accountArray, { 'AcLedgerID': AcLedgerID })[0].AcLedger;
        }
    }

    $scope.TaxConfigAddEdit = function (formIsValid) {

        if (formIsValid) {
            
                $http({
                    method: 'POST',
                    url: retailConstant.serviceBaseUrl + '/MasterData/AddEditTaxConfig',
                    data: JSON.stringify($scope.tax),
                    dataType: "json"
                }).then(function (resp) {
                    if ($routeParams.TaxID == null) {
                        alert("Tax Config added successfully!!!");
                    }
                    else
                    {
                        alert("Tax Config updated successfully!!!");
                    }
                }, function () {
                    alert(data.errors);
                });
            }
        
        else {
            $scope.showMessage = true;
        }

    }

    $scope.getPageLoadData();

 

}).filter('unique', function () {
    return function (collection, keyname) {
        var output = [],
            keys = [];

        angular.forEach(collection, function (item) {
            var key = item[keyname];
            if (keys.indexOf(key) === -1) {
                keys.push(key);
                output.push(item);
            }
        });

        return output;
    };
});