﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('marketingCompanyGroupMasterCtrl', function ($scope, $http, $route,$location, $routeParams, $filter, $q, retailConstant, retailMessageService, retailSecurityService) {
   
    $scope.MarketingGrp = {};
    $scope.btnText = "Submit";

    var requestPromise = [];
    var MktCompanyGroupIDForEdit = '';
    if ($routeParams.MktGroupID == undefined) {
        MktCompanyGroupIDForEdit = 0;
    } else {
        MktCompanyGroupIDForEdit = $routeParams.MktGroupID;
    }


    $scope.populateMarketingGroup = function (resp) {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/MarketingGroupSelectDropdown').then(function (resp) {
            if (resp.data.length > 0) {
                $scope.mrkGrpCollection = resp.data;

            }
        });
    };

    //methods//
    $scope.GetStateList = function () {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetStates').then(function (resp) {
            //console.log(resp.data.Data.length);
            if (resp.data.Data.length > 0) {
                $scope.StateArray = resp.data.Data;
            }

        }, function () { alert('Error in getting records'); })
    };
    $scope.GetCityList = function (StateID) {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetCitys?stateId=' + StateID).then(function (resp) {
            if (resp.data.Data.length > 0) {
                $scope.CityArray = resp.data.Data;

            }

        }, function () { alert('Error in getting records'); })
    };
    $scope.GetDistrictList = function (StateID) {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetDistricts?StateID=' + StateID).then(function (resp) {
            console.log(resp.data.Data);
            if (resp.data.Data.length > 0) {
                $scope.DistrictArray = resp.data.Data;
            }

        }, function () { alert('Error in getting records'); })
    };
    $scope.selectCity = function (varState) {
        $scope.MarketingGrp.StateID = varState;
        $scope.PopulateCityAndDistrict(varState);
    }
    $scope.selectDistrict = function () {
        //  $scope.GetDistrictList($scope.MarketingGrp.StateID);
    }
    //call page load//
    $scope.GetCityList = function (httpResponse) {
        if (httpResponse.data.Data.length > 0) {
            $scope.CityArray = httpResponse.data.Data;
        }
    };
    $scope.GetDistrictList = function (httpResponse) {
        if (httpResponse.data.Data.length > 0) {
            $scope.DistrictArray = httpResponse.data.Data;
        }
    };
    $scope.onLoad = function () {

        if (MktCompanyGroupIDForEdit != null && MktCompanyGroupIDForEdit != 0) {
            $scope.populateMarketingGroup();
            $scope.populateMarketingCompanySelectOne(MktCompanyGroupIDForEdit);
            $scope.GetStateList();
            var StateID = $scope.MarketingGrp.StateID;         
            $scope.MarketingGrp.IsEdit = 1;
        } else {
            $scope.populateMarketingGroup();
            $scope.GetStateList();
            $scope.MarketingGrp.IsEdit = 0;
        }


    }

    $scope.PopulateCityAndDistrict = function (StateID) {

        if (angular.isDefined(StateID)) {
            var CityPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetCitys?StateID=' + StateID);
            var DistrictPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetDistricts?StateID=' + StateID);

            //Add to chain
            $scope.combinedPromise = $q.all({ CityArray: CityPromise, DistrictArray: DistrictPromise });
            //CombinedPromise then
            $scope.combinedPromise.then(function (responses) {
                //debugger;
                if (responses.CityArray) {
                    $scope.GetCityList(responses.CityArray);
                }
                if (responses.DistrictArray) {
                    $scope.GetDistrictList(responses.DistrictArray);
                }
            });

        }
    }

    $scope.populateMarketingCompanySelectOne = function (MktGroupID) {
        $http.get(retailConstant.serviceBaseUrl + '/MasterData/MarketingCompanyGroupSelectOne?MktGroupID=' + MktGroupID).then(function (resp) {
            if (resp) {
                var response = resp.data;
                console.log(resp.data);               
                $scope.MarketingGrp.MktGroupID = response[0].MktGroupID;
                $scope.MarketingGrp.Alias = response[0].Alias;
                $scope.MarketingGrp.Address = response[0].Address;
                $scope.MarketingGrp.StateID = response[0].StateID;
                $scope.MarketingGrp.CityID = response[0].CityID;
                $scope.MarketingGrp.DistrictID = response[0].DistrictID;
                $scope.MarketingGrp.Locality = response[0].Locality;
                $scope.MarketingGrp.PinCode = response[0].Pincode;
                $scope.MarketingGrp.Phone = response[0].Phone;
                $scope.MarketingGrp.Mobile = response[0].Mobile;
                $scope.MarketingGrp.GroupName = response[0].GroupName;
                $scope.MarketingGrp.Fax = response[0].Fax;
                $scope.MarketingGrp.Email = response[0].Email;
                $scope.MarketingGrp.Website = response[0].Website;
                $scope.MarketingGrp.ContactPerson = response[0].ContactPerson;
                $scope.PopulateCityAndDistrict(response[0].StateID);

            }
        });

    }
    $scope.marketingCompanyAdd = function (MarketingGrp) {
        $http({
            method: 'POST',
            url: retailConstant.serviceBaseUrl + '/MasterData/AddMarketingGroup',
            data: JSON.stringify(MarketingGrp),
            dataType: "json"
        }).then(function (response) {
            alert(response.data.Message);
            if (response.data.Status == 1) {
                $location.path('/MarketingCompanyGroupList');
            }

        }, function (response) {
            alert(response.statusText);
        });
    }

    $scope.marketingCompanyClear = function () {

        $scope.MarketingGrp.GroupName = '';
        $scope.MarketingGrp.Alias = '';
        $scope.MarketingGrp.Address = '';
        $scope.MarketingGrp.Locality = '';
        $scope.MarketingGrp.PinCode = '';
        $scope.MarketingGrp.Phone = '';
        $scope.MarketingGrp.Mobile = '';
        $scope.MarketingGrp.Fax = '';
        $scope.MarketingGrp.Email = '';
        $scope.MarketingGrp.Website = '';
        $scope.MarketingGrp.ContactPerson = '';
        $scope.MarketingGrp.StateID = '';
        $scope.MarketingGrp.CityID = '';
        $scope.MarketingGrp.DistrictID = '';
    }

    $scope.mrktGroup_OnChange = function (mrkGrpCollection) {
        var selectedValue = EntN.value;
        $scope.FilterEntryNoModel = $filter('filter')(mrkGrpCollection, { 'MktGroupID': selectedValue });
        $scope.MarketingGrp.MktGroupID = $scope.FilterEntryNoModel[0].MktGroupID;


    }

    $scope.onLoad();
});