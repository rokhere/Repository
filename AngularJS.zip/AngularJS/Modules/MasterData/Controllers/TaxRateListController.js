﻿var retailMasterDataApp = angular.module('Retail');

retailMasterDataApp.controller('masterDataTaxRateListCtrl', function ($scope, $http, $filter, $route, retailConstant, retailSecurityService) {
    $scope.pageName = "Tax Rate";
    $scope.taxRates = [];

    //Authorization
    $scope.IsAuthorizedForUpdate = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Update);
    };

    $scope.IsAuthorizedForDelete = function () {
        return retailSecurityService.isUserPageActionAuthorized($route.current.$$route.originalPath, retailConstant.userPageAction.Delete);
    };


    $scope.populateTaxRates = function () {

        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetTaxRatesList').then(function (httpResponse) {
            var response = httpResponse.data;

            if (response.Status == 1) {
                $scope.taxRates = response.Data;
            }

        });
    };

    $scope.delete_Onclick = function (taxRate) {

        if (confirm("Are you sure to delete this Tax Rate?")) {
            $http({
                method: 'POST',
                url: retailConstant.serviceBaseUrl + '/MasterData/DeleteTaxRate?taxRateId=' + taxRate.TaxRateID
            }).then(function (httpResponse) {
                var response = httpResponse.data;
                if (response.Status == 1) {
                    var index = $scope.taxRates.indexOf(taxRate);
                    $scope.taxRates.splice(index, 1);
                }

                alert(response.Message);
            });
        }
    };

    $scope.populateTaxRates();
});