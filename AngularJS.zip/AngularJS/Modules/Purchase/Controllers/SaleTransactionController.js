﻿var retailSalesApp = angular.module('Retail');


retailPurchaseApp.controller('saleTransactionCtrl', function ($scope, $q, $filter, $http, $routeParams, $location, retailConstant) {

    $scope.Sales = { SalesID: 0};//SalesMaster
    $scope.SalesDetails = { SalesDetailID: 0 };//SalesDetail
    $scope.SalesDetailsCollection = {};
    $scope.VendorArray = [];
    $scope.ReferrerArray = [];
    $scope.ProductArray = [];  
    $scope.Sales.OrderNosection = $routeParams.Type;

    $scope.Sales.ShippingAndAdjustment = 1;

    var requestPromise = [];

    $scope.challanButton = false;
    $scope.invoiceButton = false;

    var SalesIDForEdit = '';  
    if ($routeParams.SalesID == undefined) {
        SalesIDForEdit = 0;
    } else {
        SalesIDForEdit = $routeParams.SalesID;
    } 
   
    $scope.Sales.CheckStatus = 1;
  


    $scope.SalesDetails.TransactionType = $routeParams.Type;
    $scope.BillingHeadDetail = {}      
    $scope.checkList =
       [
           { CheckStatus: "-1", StatusName: "Select Check Status" },
           { CheckStatus: "1", StatusName: "Draft" },
           { CheckStatus: "2", StatusName: "Checked" }
        
       ]; 
   
    $scope.FreightTypeCollection =
     [
         { FreightType: "-1", FreightTypeName: "Select Freight Type" },
         { FreightType: "1", FreightTypeName: "FOB to Pay" },
         { FreightType: "2", FreightTypeName: "FOB Paid (Add)" },
         { FreightType: "3", FreightTypeName: "FOR to Pay (Less)" },
         { FreightType: "4", FreightTypeName: "FOR Paid" }
     ];
    $scope.CashDiscTypeCollection =
      [
          { CashDiscType: "-1", CashDiscTypeName: "Select" },
          { CashDiscType: "1", CashDiscTypeName: "Flat Rate" },
          { CashDiscType: "2", CashDiscTypeName: "% on Taxable Amount" },
         { CashDiscType: "3", CashDiscTypeName: "% on Net Amount (before Cash Discount)" }

      ];    


    $scope.moveToInvoice = "Move To Invoice";
    $scope.moveToChallan = "Move To Challan";

    $scope.parseJsonDate = function (model) {
        // date format - /Date(1507573800000)/
        for (var property in model) {
            if (model.hasOwnProperty(property) && property.indexOf('Date') > -1) {
                var jsonDateString = model[property] || '';
                if (jsonDateString.length > 0) {
                    var date = new Date(parseInt(jsonDateString.substr(6)));
                    model[property] = $filter('date')(date, "dd/MM/yyyy");;
                }
            }
        }
    }
 
    //#region - Sales Common Popup
    $scope.SalesCommonPopupSelectedItem = undefined;
    $scope.SalesCommonPopupCombinedPromise = undefined;
    $scope.popupFor = undefined;
    $scope.SalesCommonPopupSearch = '';
    $scope.showSalesCommonPopup = function (popupFor) {
        
        $scope.SalesCommonPopupCombinedPromise = undefined;
        $scope.popupFor = popupFor;

        //Prepare Promise
        var popupDataPromise = undefined;
        if ($scope.popupFor == 'Customer') {
            var locationId = $scope.Sales.LocationID || 0;
            if (locationId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Sales/GetCustomer?LocationID=' + locationId);
                $scope.SalesCommonPopupCombinedPromise = $q.all({ Customer: popupDataPromise });
            }
        } else if ($scope.popupFor == 'Referrer') {
            var CustomerID = $scope.Sales.CustomerID || 0;
            if (CustomerID > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Sales/GetReferrer?CustomerID=' + CustomerID);
                $scope.SalesCommonPopupCombinedPromise = $q.all({ Referrer: popupDataPromise });
            }
        } else if ($scope.popupFor == 'PriceDesc') {
            var CustomerID = $scope.Sales.CustomerID || 0;
            if (CustomerID > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Sales/GetReferrer?CustomerID=' + CustomerID);
                $scope.SalesCommonPopupCombinedPromise = $q.all({ Referrer: popupDataPromise });
            }
        } else if ($scope.popupFor == 'Product') {
            var CustomerID = $scope.Sales.CustomerID || 0;
            var locationId = $scope.Sales.LocationID || 0;
            if (CustomerID > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Sales/Getproduct?LocationID=' + locationId);
                $scope.SalesCommonPopupCombinedPromise = $q.all({ Product: popupDataPromise });
            }
        } else if ($scope.popupFor == 'Billing') {
            var CustomerID = $scope.Sales.CustomerID || 0;
            if (CustomerID > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Sales/BillingHead');
                $scope.SalesCommonPopupCombinedPromise = $q.all({ BillingHead: popupDataPromise });
            } 
        } else if ($scope.popupFor == 'TaxCode') {
            var CustomerID = $scope.Sales.CustomerID || 0;
            if (CustomerID > 0) {
                var tempTransactionPlace = $scope.Sales.TransactionPlace;
                var tempTransactionType = $scope.SalesDetails.TransactionType;
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Sales/BillingHeadTax?TransactionPlace=' + tempTransactionPlace + '&TransactionType=' + tempTransactionType);
                $scope.SalesCommonPopupCombinedPromise = $q.all({ TaxCode: popupDataPromise });
            }
        } else if ($scope.popupFor == 'LotNo') {
            var productID = $scope.SalesDetails.ProductID || 0;
            var locationId = $scope.Sales.LocationID || 0;
            if (productID > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Sales/PopulateLotSelect?locationID=' + locationId + '&productID=' + productID);
                $scope.SalesCommonPopupCombinedPromise = $q.all({ LotNo: popupDataPromise });
            }
        }

              
        //Service Call
        if ($scope.SalesCommonPopupCombinedPromise != undefined) {
            $scope.SalesCommonPopupCombinedPromise.then(function (responses) {
                if (responses.Customer) {
                    $scope.CustomerArray = responses.Customer.data || [];
                } else if (responses.Referrer) {
                    $scope.ReferrerArray = responses.Referrer.data || [];
                } else if (responses.Referrer) {
                    $scope.ReferrerArray = responses.Referrer.data || [];
                } else if (responses.Product) {
                    $scope.ProductArray = responses.Product.data || [];
                } else if (responses.BillingHead) {
                    $scope.BillingHeadArray = responses.BillingHead.data || [];
                } else if (responses.TaxCode) {
                    $scope.BillingHeadArray = responses.TaxCode.data || [];
                } else if (responses.LotNo) {                  
                    var len = responses.LotNo.data.length;
                    for (i = 0 ; i <= len ; i++) {
                        $scope.parseJsonDate(responses.LotNo.data[i]);
                    }

                    $scope.LotNoArray = responses.LotNo.data || [];
                }

                $('#dvSalesCommonPopup').modal('show');
            });
        }
    };
    $scope.SalesCommonPopup_onSelect = function (item) {
        
        $scope.SalesCommonPopupSelectedItem = item;

        if ($scope.popupFor == 'Customer') {          
            $scope.Sales.Customer = item.Customer;
            $scope.Sales.CustomerID = item.CustomerID;
            $scope.Sales.CustomerGSTNo = item.GSTNo;
            $scope.Sales.CreditDays = item.CreditDays;
            $scope.Sales.BalanceAmount = item.BalanceAmount;
            $scope.Sales.Address = item.Address;
        } else if ($scope.popupFor == 'Referrer') { 
            $scope.Sales.ReferrerID = item.ReferrerId;
            $scope.Sales.Referrer = item.Referrer;
        } else if ($scope.popupFor == 'PriceDesc') {                
            $scope.Sales.PriceDiscRefID = item.ReferrerId;
            $scope.Sales.PriceDiscRefName = item.Referrer;
        } else if ($scope.popupFor == 'Product') {                
            $scope.SalesDetails.ProductName = item.ProductName;
            $scope.SalesDetails.ProductID = item.ProductID;
            $scope.SalesDetails.ProductCategoryID = item.ProductCategoryID;
            $scope.SalesDetails.BillingUnit1ID = item.PurchaseRateUnit;
            $scope.SalesDetails.BillingUnitName = item.PuschaseUnit;
            $scope.SalesDetails.MinStockOnTransDate = item.MinStock;
            $scope.SalesDetails.MaxStockOnTransDate = item.MaxStock;
            $scope.SalesDetails.DisplayUnit1 = item.DisplayUnit1;
            $scope.SalesDetails.DisplayUnit2 = item.DisplayUnit2;
            $scope.SalesDetails.DisplayUnit3 = item.DisplayUnit3;
            $scope.SalesDetails.PerUnit1Content = item.PerUnit1Content;
            $scope.SalesDetails.PerUnit2Content = item.PerUnit2Content;
            $scope.SalesDetails.ShelfNo = item.ShelfNo;
            $scope.SalesDetails.ShelfID = item.ShelfID;
            $scope.SalesDetails.MRP = item.MRP;
            $scope.SalesDetails.TradeRate = item.TradeRate;
            $scope.SalesDetails.Rate = item.SalesRate;  

        } else if ($scope.popupFor == 'Billing') {

            $scope.BillingHeadDetail.BillingHeadID = item.BillingHeadID;
            $scope.BillingHeadDetail.BillingHead = item.BillingHead;
            $scope.BillingHeadDetail.BillingHeadAddLess = item.BillingHeadAddLessText;
            $scope.BillingHeadDetail.AcLedgerID = item.AcLedgerID; 
            $scope.BillingHeadDetail.TransactionID = $scope.Sales.SalesID;
            $scope.BillingHeadDetail.TransactionPlace = $scope.Sales.TransactionPlace;

            $scope.populateBillingHeadTax();
        }
        else if ($scope.popupFor == 'TaxCode') {

            $scope.BillingHeadDetail.TaxCode = item.TaxCode;
            $scope.BillingHeadDetail.TaxID = item.TaxID;
         
        }
        else if ($scope.popupFor == 'LotNo') {         
            $scope.SalesDetails.LotNo = item.LotNo;
           
        }
        $('#dvSalesCommonPopup').modal('hide');
    };
    //#endregion - Sales Common Popup


    //Methods//
    $scope.onLoad = function () {    
        $http.get(retailConstant.serviceBaseUrl + '/Sales/GetEntryNo?TransactionType=' + $routeParams.Type).then(function (resp) {
            if (resp) {              
                $scope.populateEntryNo(resp);               
            }
        });

        $q.all(requestPromise).then(function (data) {
            if (SalesIDForEdit != null && SalesIDForEdit != 0) {
                $scope.Sales.SalesID = SalesIDForEdit;
                $scope.PopulateDetailsGrid(SalesIDForEdit);
                $scope.populateCalAdjTransaction(SalesIDForEdit);
                $scope.populateBillingHeadDetails($routeParams.Type, SalesIDForEdit);
                $scope.Sales.ShippingAndAdjustment = 2;
                $scope.Sales.IsEdit = 1;

            } else {
                $scope.Sales.IsEdit = 0;
            }
        });
      
    }    
    $scope.populateEntryNo = function (resp) {
        var response = resp.data;
        $scope.seriesCollection = response;      
    };        


    $scope.seriesNo_OnChange = function (EntryNoModel) {
        var selectedValue = EntN.value;
        $scope.FilterEntryNoModel = $filter('filter')(EntryNoModel, { 'SeriesID': selectedValue });
        $scope.Sales.EntryNo = $scope.FilterEntryNoModel[0].EntryNo;
        $scope.Sales.LocationID = $scope.FilterEntryNoModel[0].LocationID;
        $scope.Sales.SeriesID = $scope.FilterEntryNoModel[0].SeriesID;
        $scope.Sales.Series = $scope.FilterEntryNoModel[0].Series;
        $scope.SalesDetails.LocationID = $scope.FilterEntryNoModel[0].LocationID;
    }
  
    $scope.populateCarreir = function () {
        $http.get(retailConstant.serviceBaseUrl + '/Sales/GetCarrier').then(function (resp) {
            if (resp) {
                var response = resp.data;
                $scope.carrierCollection = response;

            }
        });

    }
    $scope.populateBillingHeadTax = function () {
        var tempTransactionPlace = $scope.Sales.TransactionPlace;
        var tempTransactionType = $scope.SalesDetails.TransactionType;
        $http.get(retailConstant.serviceBaseUrl + '/Sales/BillingHeadTax?TransactionPlace=' + tempTransactionPlace +'&TransactionType=' + tempTransactionType).then(function (resp) {

            if (resp) {
                var response = resp.data;
                $scope.billingHeadTaxCollection = response;

            }
        });

    }
 
    $scope.populateBillingHeadDetails = function (tempTransactionType, tempTransactionID) {     
     //  var tempTransactionID = 1;
      //  var tempTransactionType = $scope.SalesDetails.TransactionType;
        $http.get(retailConstant.serviceBaseUrl + '/Sales/GetBillingHeadDetail?TransactionType=' + tempTransactionType + '&TransactionID=' + tempTransactionID).then(function (resp) {
            if (resp) {
                var response = resp.data;              
                $scope.billingHeadDtlsCollection = response;
            }
        });

    }
    $scope.deleteBillingHeadDetails = function (billingHeadDtls, BillingHeadDetailID) {


        if (confirm("Are you sure to delete this item?")) {
            var index = $scope.billingHeadDtlsCollection.indexOf(billingHeadDtls);

            $http.post(retailConstant.serviceBaseUrl + '/Sales/DeleteBillingHead?BillingHeadDetailID=' + BillingHeadDetailID)
            .then(function (resp) {
                $scope.billingHeadDtlsCollection.splice(index, 1);
                alert("Billing head deleted successfully!!!");
            }, function () { alert('Error in getting records'); })
        }
    };
    
    $scope.editbillingHeadDtls = function (item) {     
        console.log(item);       


        $scope.BillingHeadDetail.AcLedgerID = item.AcLedgerID;
        $scope.BillingHeadDetail.BillingHeadDetailID = item.BillingHeadDetailID;
        $scope.BillingHeadDetail.BillingHeadID = item.BillingHeadID;
        $scope.BillingHeadDetail.BillingHead = item.BillingHead;
        $scope.BillingHeadDetail.BillingHeadAddLess = item.BillingHeadAddLess;
        $scope.BillingHeadDetail.BillingHeadAmt = item.BillingHeadAmt;
        $scope.BillingHeadDetail.BillingHeadRemark = item.BillingHeadRemark;
        $scope.BillingHeadDetail.TaxCode = item.TaxCode;
        $scope.BillingHeadDetail.TaxID = item.TaxID;
        $scope.BillingHeadDetail.TaxableAmount = item.TaxableAmount;
        $scope.BillingHeadDetail.TaxAddLess = item.TaxAddLess;
        $scope.BillingHeadDetail.TaxRemarks = item.TaxRemarks;
     

    }

    $scope.billingHeadDetailInsert_onClick = function () {

        $scope.BillingHeadDetail.SeriesID = $scope.Sales.SeriesID;
        $scope.BillingHeadDetail.TransactionType = $routeParams.Type;
        $scope.BillingHeadDetail.TransactionID = $scope.Sales.SalesID;
        $scope.BillingHeadDetail.TransactionPlace = $scope.Sales.TransactionPlace;

        var postBillingHeadDetailModel = angular.copy($scope.BillingHeadDetail);

        $http.post(retailConstant.serviceBaseUrl + '/Sales/SaveBillingHead', JSON.stringify(postBillingHeadDetailModel)).then(function (httpResponse) {
            var response = httpResponse.data;
            if (response.Status == 1) {
                $scope.populateBillingHeadDetails($scope.BillingHeadDetail.TransactionType, $scope.BillingHeadDetail.TransactionID);
                $scope.billingHeadDetailClear();
            }

        })
    }

    $scope.billingHeadDetailSave_onClick = function () {
        $scope.populateCalAdjTransaction($scope.Sales.SalesID);
      
       
    }
    $scope.billingHeadDetailClear = function () {

        $scope.BillingHeadDetail.SeriesID = '';
        $scope.BillingHeadDetail.TransactionType = '';
        $scope.BillingHeadDetail.TransactionID = '';
        $scope.BillingHeadDetail.TransactionPlace = '';
        $scope.BillingHeadDetail.BillingHead = '';
        $scope.BillingHeadDetail.BillingHeadAmt = '';
        $scope.BillingHeadDetail.BillingHeadRemark = '';
        $scope.BillingHeadDetail.TaxableAmount = '';
        $scope.BillingHeadDetail.TaxCode = '';
        $scope.BillingHeadDetail.TaxAddLess = '';
        $scope.BillingHeadDetail.TaxRemarks = '';

    }



    $scope.editProduct = function (item) {

        $scope.itemvalue = item;
        console.log(item);
        $scope.SalesDetails.ProductName = item.ProductName;
        $scope.SalesDetails.Qty = item.Quantity;
        $scope.SalesDetails.BillingUnitName = item.Unit;
        $scope.SalesDetails.Rate = item.Rate;
        $scope.SalesDetails.GrossAmount = item.GrossAmount;       
        $scope.SalesDetails.LotDisc = item.LotDisc;
        $scope.SalesDetails.LotDiscType = item.LotDiscType;
        $scope.SalesDetails.LotDiscAmount = item.LotDiscAmount;
        $scope.SalesDetails.LotRemarks = item.LotRemarks;
        $scope.SalesDetails.SchemeDisc = item.SchemeDisc;
        $scope.SalesDetails.SchemeDiscType = item.SchemeDiscType;
        $scope.SalesDetails.SchemeDiscAmount = item.SchemeDiscAmount;
        $scope.SalesDetails.SchemeRemark = item.SchemeRemark;
        $scope.SalesDetails.TradeDisc = item.TradeDisc;
        $scope.SalesDetails.TradeDiscType = item.TradeDiscType;
        $scope.SalesDetails.TradeDiscAmount = item.TradeDiscAmount;
        $scope.SalesDetails.TradeDiscRemark = item.TradeDiscRemark;
        $scope.SalesDetails.FreeQty = item.FreeQty;
        $scope.SalesDetails.FreeQtyUnit = item.FreeQtyUnit;
        $scope.SalesDetails.FreeQtyRemark = item.FreeQtyRemark;
        $scope.SalesDetails.ManufacturingDate = item.ManufacturingDate;
        $scope.SalesDetails.ExpiryDate = item.ExpiryDate;
        $scope.SalesDetails.BatchCode = item.BatchCode;
        $scope.SalesDetails.LotNo = item.LotNo;
        $scope.SalesDetails.Manufacturer = item.Manufacturer;
        $scope.SalesDetails.Remarks = item.Remarks;

    }

    $scope.deleteProduct = function (item) {
        console.log(item);
        if (confirm("Are you sure to delete this item ?")) {
            var CheckStatus = item.CheckStatus;
            var SalesDetailID = item.SalesDetailID;
            var LocationID = $scope.Sales.LocationID
            var TransactionType = $scope.SalesDetails.TransactionType;      
            var index = $scope.SalesDetailsCollection.indexOf(item);
            $http.post(retailConstant.serviceBaseUrl + '/Sales/SalesDetailsDelete?SalesDetailID=' + SalesDetailID + '&LocationID=' + LocationID + '&TransactionType=' + TransactionType + '&CheckStatus=' + CheckStatus)
            .then(function (resp) {
                $scope.SalesDetailsCollection.splice(index, 1);
                alert("Product deleted successfully!!!");
            }, function () { alert('Error in getting records'); })

        }

    }
   
    //////Add OR insert Transaction //////

    $scope.addProduct_onClick = function () {

        if (($scope.SalesDetails.ProductName != '' && $scope.SalesDetails.ProductName != undefined) && ($scope.SalesDetails.Qty != '' && $scope.SalesDetails.Qty != undefined)) {

            var postSalesModel = angular.copy($scope.Sales);
            postSalesModel.SalesDetails = $scope.SalesDetails;

            $http.post(retailConstant.serviceBaseUrl + '/Sales/AddProduct', JSON.stringify(postSalesModel)).then(function (httpResponse) {
                var response = httpResponse.data;


                if (response.Status == 1) {
                    if ($scope.Sales.SalesID == 0) {
                        $scope.Sales.SalesID = response.Data;
                        $scope.PopulateDetailsGrid(response.Data);
                        $scope.populateCalAdjTransaction(response.Data);
                        $scope.ClearSalesDetailsFeild();
                        $scope.Sales.ShippingAndAdjustment = 2;
                    }
                    else {
                        $scope.PopulateDetailsGrid($scope.Sales.SalesID);
                        $scope.populateCalAdjTransaction($scope.Sales.SalesID);
                        $scope.ClearSalesDetailsFeild();
                     
                    }
                } else {
                    $scope.Sales.ShippingAndAdjustment = 1;
                }

                alert(response.Message);
            });
        } else {
            alert('Please enter product details.');
        }
    }

    $scope.submitSales_onClick = function () {

        var postSalesModel = angular.copy($scope.Sales);       
        postSalesModel.SalesDetails = $scope.SalesDetails;

        $http.post(retailConstant.serviceBaseUrl + '/Sales/SubmitSales', JSON.stringify(postSalesModel)).then(function (httpResponse) {
            var response = httpResponse.data;
           
            if (response.Status == 1) {
              
            }

            alert(response.Message);
        });
    }
   
    
    //////Add OR insert Transaction //////

    $scope.moveToChallan_onClick = function () {

        var postSalesModel = angular.copy($scope.Sales);

        $http.post(retailConstant.serviceBaseUrl + '/Sales/MoveToChallan', JSON.stringify(postSalesModel)).then(function (httpResponse) {
            var response = httpResponse.data;          
            if (response.Status == 1) {
                $scope.moveToChallan = "Moved To Challan";
                $scope.challanButton = true;
               
            }
            alert(response.Message);
        });
    }
    $scope.moveToInvoice_onClick = function () {

        var postSalesModel = angular.copy($scope.Sales);

        $http.post(retailConstant.serviceBaseUrl + '/Sales/MoveToInvoice', JSON.stringify(postSalesModel)).then(function (httpResponse) {
            var response = httpResponse.data;          
            if (response.Status == 1) {
                $scope.moveToInvoice = "Moved To Invoice";
                $scope.invoiceButton = true;
            }

            alert(response.Message);
        });
    }

    $scope.carrier_OnChange = function (item) {    
        $scope.Sales.CarrierID = item.CarrierID;
      
    };

    //$scope.billingHead_OnChange = function (item) {     
    //    var billingHead = item.BillingFields;
    //    var arrayHead = billingHead.split('|');

    //    var BillingHeadID = arrayHead[0];
    //    var BillingHead = arrayHead[1];
    //    var BillingHeadAddLess = arrayHead[2];
    //    var AcLedgerID = arrayHead[3];

    //    $scope.BillingHeadDetail.BillingHeadID = BillingHeadID;
    //    $scope.BillingHeadDetail.BillingHead = BillingHeadID;
    //    $scope.BillingHeadDetail.BillingHeadAddLess = BillingHeadID;
    //    $scope.BillingHeadDetail.AcLedgerID = BillingHeadID;

    //    $scope.populateBillingHeadTax();
    //};

    $scope.taxCode_OnChange = function (item) {
        var taxID = item.TaxID;
       
        $scope.BillingHeadDetail.taxID = taxID;
    };
   
    $scope.callMoveToChallan = function () {
        var val = $scope.Sales.OrderNosection;
        var tStatus = parseFloat($scope.Sales.TransactionStatus || 0);
        var tPID = parseFloat($scope.Sales.SalesID || 0);
       
        if (val == '5' && tStatus != 2 && tPID > 0 && tStatus != 5)
            return true;
        else
            return false;
    };

    $scope.callMoveToInVoice = function () {      


        var val = $scope.Sales.OrderNosection;
        var tStatus = parseFloat($scope.Sales.TransactionStatus || 0);
        var tPID = parseFloat($scope.Sales.SalesID || 0);

        if ((val == '5' || val == '6') && tStatus != 3 && tPID > 0 && tStatus != 5)
            return true;
        else
            return false;
    };

    $scope.PopulateDetailsGrid = function (SalesID) {
        $http.get(retailConstant.serviceBaseUrl + '/Sales/SalesDetailsPopulateAllGrid?SalesID=' + SalesID).then(function (resp) {
            if (resp) {
                var response = resp.data;               
                var len = resp.data.length;
                for (i = 0 ; i <= len ; i++) {
                    $scope.parseJsonDate(resp.data[i]);
                }
               
                $scope.SalesDetailsCollection = resp.data;               
              
            }

        });

    }

    $scope.populateCalAdjTransaction = function (SalesID) {
        $http.get(retailConstant.serviceBaseUrl + '/Sales/SalesTransactionCalAdj?SalesID=' + SalesID).then(function (resp) {
            if (resp) {

                var len = resp.data.length;
                for (i = 0 ; i <= len ; i++) {
                    $scope.parseJsonDate(resp.data[i]);
                }
                var response = resp.data;
                console.log(resp.data);
                $scope.Sales.TotalGrossAmountWithTax = response[0].TotalGrossAmountWithTax;
               // $scope.Sales.TotalAmountAfterAdjustments = response[0].TotalAmountAfterAdjustments;
                $scope.Sales.CashDiscAmount = response[0].CashDiscAmount;
                $scope.Sales.TotalTaxAmount = response[0].TotalTaxAmount;
                $scope.Sales.CashDisc = response[0].CashDisc;
                $scope.Sales.CashDiscType = response[0].CashDiscType;
                $scope.Sales.CashDiscAmount = response[0].CashDiscAmount;
                $scope.Sales.RoundOff = response[0].RoundOff;
                $scope.Sales.FinalNetAmountWithShipping = response[0].FinalNetAmountWithShipping;
                $scope.Sales.BillingTotal = response[0].BillingTotal;

                if (response[0].RCM == 1) {
                    $scope.Sales.RCM = true;
                } else {
                    $scope.Sales.RCM = false;
                }  

                


                $scope.Sales.CheckStatus = response[0].CheckStatus;
                $scope.Sales.CheckedByMemberID = response[0].CheckedByMemberID;
                $scope.Sales.TotalDiscounts = response[0].TotalDiscounts;
                $scope.Sales.TotalTaxableAmount = response[0].TotalTaxableAmount;

                ////check///
                $scope.Sales.TotalAdjustmentsAmount = response[0].TotalAdjustmentsAmount;
                ////
                $scope.Sales.TotalAmountAfterAdjustments = response[0].TotalAmountAfterAdjustments;
                $scope.Sales.TotalAmountAfterCashDiscount = response[0].TotalAmountAfterCashDiscount;
                $scope.Sales.TransactionStatus = response[0].TransactionStatus;
                $scope.Sales.Customer = response[0].Customer;
                $scope.Sales.CustomerID = response[0].CustomerID;
                $scope.Sales.CustomerGSTNo = response[0].CustomerGSTNo;
                $scope.Sales.CreditDays = response[0].CreditDays;
                $scope.Sales.BalanceAmount = response[0].BalanceAmount;
                $scope.Sales.Address = response[0].Address;
                $scope.Sales.Referrer = response[0].Referrer;
                $scope.Sales.PriceDiscRefName = response[0].PriceDiscReferrer;
                $scope.Sales.SeriesID = response[0].SeriesID;
                $scope.Sales.ReferrerID = response[0].ReferrerID;
                $scope.Sales.PriceDiscRefID = response[0].PriceDiscRefID;
                $scope.Sales.Series = response[0].Series;
                $scope.Sales.ReferenceNo = response[0].ReferenceNo;
                $scope.Sales.ReferenceDate = response[0].ReferenceDate;
                $scope.Sales.TransactionPlace = response[0].TransactionPlace;
              
                $scope.Sales.SeriesID = response[0].SeriesID;
                $scope.Sales.EntryNo = response[0].EntryNo;
                $scope.Sales.EntryDate = response[0].EntryDate;
                $scope.Sales.DeliveryDate = response[0].DeliveryDate;
                $scope.Sales.LocationID = response[0].LocationID;
                
                $scope.Sales.LRNo = response[0].LRNo;
                $scope.Sales.LRDate = response[0].LRDate;
                $scope.Sales.FreightType = response[0].FreightType;
                $scope.Sales.FreightAmt = response[0].FreightAmt;
                $scope.Sales.RoadPermitNo = response[0].RoadPermitNo;
                $scope.Sales.CarrierID = response[0].CarrierID;
                $scope.Sales.NoOfCases = response[0].NoOfCases;
                $scope.Sales.DeliveryDate = response[0].DeliveryDate;
                
            }
        });

    }


    $scope.ClearSalesDetailsFeild = function () {
        $scope.SalesDetails.ProductName = '';
        $scope.SalesDetails.Qty = '';
        $scope.SalesDetails.Unit = '';
        $scope.SalesDetails.Rate = '';
        $scope.SalesDetails.GrossAmount = '';
        $scope.SalesDetails.LotDisc = '';
        $scope.SalesDetails.LotDiscType = '';
        $scope.SalesDetails.LotDiscAmount = '';
        $scope.SalesDetails.LotRemarks = '';
        $scope.SalesDetails.SchemeDisc = '';
        $scope.SalesDetails.SchemeDiscType = '';
        $scope.SalesDetails.SchemeDiscAmount = '';
        $scope.SalesDetails.SchemeRemark = '';
        $scope.SalesDetails.TradeDisc = '';
        $scope.SalesDetails.TradeDiscType = '';
        $scope.SalesDetails.TradeDiscAmount = '';
        $scope.SalesDetails.TradeDiscRemark = '';
        $scope.SalesDetails.FreeQty = '';
        $scope.SalesDetails.FreeQtyUnit = '';
        $scope.SalesDetails.FreeQtyRemark = '';
        $scope.SalesDetails.ManufacturingDate = '';
        $scope.SalesDetails.ExpiryDate = '';
        $scope.SalesDetails.BatchCode = '';
       // $scope.SalesDetails.BarCode = '';
        $scope.SalesDetails.LotNo = '';
        $scope.SalesDetails.ShelfNo = '';
        $scope.SalesDetails.Manufacturer = '';
        $scope.SalesDetails.Remarks = '';
        $scope.SalesDetails.BillingUnitName = '';

    }

    $scope.ClearSalesTransFeild = function () {
        $scope.Sales.Customer = '';
        $scope.Sales.GSTNo = '';
        $scope.Sales.CreditDays = '';
        $scope.Sales.BalanceAmount = '';
        $scope.Sales.Address = '';
        $scope.Sales.Referrer = '';
        $scope.Sales.PriceDiscRefName = '';
        $scope.Sales.selectedSeries = '';
        $scope.Sales.EntryNo = '';
        $scope.Sales.EntryDate = '';
        $scope.Sales.ReferenceNo = '';
        $scope.Sales.ReferenceDate = '';
        $scope.Sales.TransactionPlace = '';
        $scope.Sales.TotalGrossAmountWithTax = '';
        $scope.Sales.TotalAmountAfterAdjustments = '';
        $scope.Sales.CashDiscAmount = '';
        $scope.Sales.TotalTaxAmount = '';
        $scope.Sales.CashDisc = '';
        $scope.Sales.CashDiscType = '';
        $scope.Sales.CashDiscAmount = '';
       // $scope.Sales.RoundOff = '';
        $scope.Sales.TotalNetAmountWithoutShipping = '';
        $scope.Sales.FinalNetAmountWithShipping = '';
       // $scope.Sales.BillingTotal = '';
        $scope.Sales.RCM = '';
   
        $scope.Sales.FinalNetAmountWithShipping = '';
      
    };

    $scope.CalTotal = function () {
        if ($scope.SalesDetails.Qty || $scope.SalesDetails.Rate != null) {

            var total = ($scope.SalesDetails.Qty * $scope.SalesDetails.Rate)
            $scope.SalesDetails.GrossAmount = total;
        } else {
            $scope.SalesDetails.GrossAmount = '';
        }
        
    };
    $scope.autoGenerateBarCode = function () {
        $scope.SalesDetails.BarCode = 111;//value to be set
       // $scope.SalesDetails.ShelfNo = 222;//value to be set
    };

    $scope.closeShippingPopup_onClick = function () {

       // var temp = ($scope.Sales.TotalAmountAfterAdjustments - $scope.Sales.CashDiscAmount);  
        //$scope.Sales.TotalAmountAfterCashDiscount = temp;
        //$scope.Sales.TotalNetAmountWithoutShipping = (($scope.Sales.TotalAmountAfterAdjustments - $scope.Sales.CashDiscAmount) + $scope.Sales.RoundOff)

       // $scope.Sales.FinalNetAmountWithShipping = ( (( {{$scope.Sales.TotalAmountAfterAdjustments}} - $scope.Sales.CashDiscAmount) + $scope.Sales.RoundOff) + $scope.Sales.FreightAmt)
   
        var total = ((parseFloat($scope.Sales.TotalAmountAfterAdjustments || 0) - parseFloat($scope.Sales.CashDiscAmount || 0)) + parseFloat($scope.Sales.FreightAmt || 0)) + parseFloat($scope.Sales.RoundOff || 0)

        //////////var rtrr= parseFloat($scope.Sales.FreightAmt || 0)


        //////////var rr = rtrr.split('.')[1];
        //////////var ss = rr;
        //////////alert(ss);

        $scope.Sales.FinalNetAmountWithShipping = !isNaN(total) ? total : 0;;
    
    }
    $scope.calRoundOff = function () {
     
        var tempRoundOff = parseFloat($scope.Sales.RoundOff || 0)
        var tempCashDiscAmount = parseFloat($scope.Sales.CashDiscAmount || 0)
        var tempFreightAmt = parseFloat($scope.Sales.FreightAmt || 0)
        var totalAmtAftAdj = parseFloat($scope.Sales.TotalAmountAfterAdjustments || 0)

        var tempFinal = (((totalAmtAftAdj - tempCashDiscAmount) + tempFreightAmt) + tempRoundOff)

        $scope.Sales.FinalNetAmountWithShipping = !isNaN(tempFinal) ? tempFinal : 0;
    }

    $scope.calCashDisType = function (val) {
        var cashDisCount = parseFloat($scope.Sales.CashDisc|| 0);
        var totalTaxableAmt = parseFloat($scope.Sales.TotalTaxableAmount|| 0)
        var totalAmtAftAdj =parseFloat($scope.Sales.TotalAmountAfterAdjustments|| 0)
        var cal = 0;


        if (val == "1") {

            $scope.Sales.CashDiscAmount = cashDisCount
          
            var temp = (totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0));
            $scope.Sales.TotalAmountAfterCashDiscount = temp;
            $scope.Sales.TotalNetAmountWithoutShipping = ((totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0)))         

            cal = (((totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0)) + parseFloat($scope.Sales.FreightAmt || 0)) + parseFloat($scope.Sales.RoundOff || 0)).toFixed(2)
            $scope.Sales.FinalNetAmountWithShipping = !isNaN(cal) ? cal : 0;


        }
        if (val == "2") {

            $scope.Sales.CashDiscAmount = (cashDisCount / 100) * totalTaxableAmt  

            var temp = (totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0));
            $scope.Sales.TotalAmountAfterCashDiscount = temp;
            $scope.Sales.TotalNetAmountWithoutShipping = ((totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0)))

            cal = (((totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0)) + parseFloat($scope.Sales.FreightAmt || 0)) + parseFloat($scope.Sales.RoundOff || 0)).toFixed(2)

            $scope.Sales.FinalNetAmountWithShipping = !isNaN(cal) ? cal : 0;

        }
        if (val == "3") {

            $scope.Sales.CashDiscAmount = (cashDisCount / 100) * totalAmtAftAdj
         
            var temp = (totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0));
            $scope.Sales.TotalAmountAfterCashDiscount = temp;
            $scope.Sales.TotalNetAmountWithoutShipping = ((totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0)))

            cal = (((totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0)) + parseFloat($scope.Sales.FreightAmt || 0)) + parseFloat($scope.Sales.RoundOff || 0)).toFixed(2)

            $scope.Sales.FinalNetAmountWithShipping = !isNaN(cal) ? cal : 0;
        }

    }
    $scope.calculateDiscount = function (val,type) {

        var grossAmt = $scope.SalesDetails.GrossAmount
     
      
        if (type == "Lot") {
      
            if (val == "1") {               
                $scope.SalesDetails.LotDiscAmount = $scope.SalesDetails.LotDisc
            }
            if (val == "2") {
                var lotDis = $scope.SalesDetails.LotDisc;
                $scope.SalesDetails.LotDiscAmount = (lotDis / 100) * grossAmt
            } 
            if (val == "") {
                $scope.SalesDetails.LotDiscAmount = '';
            }        
        }
        else if (type == "Scheme") {
            if (val == "1") { 
                $scope.SalesDetails.SchemeDiscAmount = $scope.SalesDetails.SchemeDisc;                
            }
            if (val == "2") {
                var SchDis = $scope.SalesDetails.SchemeDisc;
                $scope.SalesDetails.SchemeDiscAmount = (SchDis / 100) * grossAmt
            }
            if (val == "")
            {
                $scope.SalesDetails.SchemeDiscAmount = '';
            }

        } else if (type == "Trade") {
            if (val == "1") { 
                $scope.SalesDetails.TradeDiscAmount = $scope.SalesDetails.TradeDisc;
            }
            if (val == "2") { 
                var TradeDis = $scope.SalesDetails.TradeDisc;
                $scope.SalesDetails.TradeDiscAmount = (TradeDis / 100) * grossAmt
            } 
            if (val == "")
            {
                $scope.SalesDetails.TradeDiscAmount = '';
            }

        }

     
    };

    //Methods//
   
    $scope.onLoad();
    $scope.autoGenerateBarCode();
    $scope.populateCarreir();
   
})



