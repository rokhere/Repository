﻿var retailPurchaseApp = angular.module('Retail');


retailPurchaseApp.controller('saleReturnCtrl', function ($scope, $q, $filter, $http, $routeParams, $location, retailConstant) {

    $scope.Sales = { SalesID: 0 };//SalesMaster
    $scope.SalesDetail = { SalesDetailID: 0 };//SalesDetail
    $scope.SalesDetailsCollection = {};
    $scope.CustomerArray = [];
    $scope.ReferrerArray = [];
    $scope.ProductArray = [];  
    $scope.Sales.OrderNosection = $routeParams.Type;
    $scope.SalesDetail.TransactionType = $routeParams.Type;
    $scope.BillingHeadDetail = {}

    $scope.SalesReturn = {}

    $scope.Sales.IsEdit = 0;

    var requestPromise = [];

    $scope.checkList =
       [
           { CheckStatus: "0", StatusName: "Select Check Status" },
           { CheckStatus: "1", StatusName: "Draft" },
           { CheckStatus: "2", StatusName: "Checked" }
       ]; 
   
    $scope.isDisabledInvoice = false;
    $scope.Sales.CheckStatus = 1;
    $scope.parseJsonDate = function (model) {
        // date format - /Date(1507573800000)/
        for (var property in model) {
            if (model.hasOwnProperty(property) && property.indexOf('Date') > -1) {
                var jsonDateString = model[property] || '';
                if (jsonDateString.length > 0) {
                    var date = new Date(parseInt(jsonDateString.substr(6)));
                    model[property] = $filter('date')(date, "dd/MM/yyyy");;
                }
            }
        }
    }
 
    //#region - Sales Common Popup
    $scope.SalesCommonPopupSelectedItem = undefined;
    $scope.SalesCommonPopupCombinedPromise = undefined;
    $scope.popupFor = undefined;
    $scope.SalesCommonPopupSearch = '';
    $scope.showSalesCommonPopup = function (popupFor) {
        
        $scope.SalesCommonPopupCombinedPromise = undefined;
        $scope.popupFor = popupFor;

        //Prepare Promise
        var popupDataPromise = undefined;
        if ($scope.popupFor == 'Customer') {
            var locationId = $scope.Sales.LocationID || 0;
            if (locationId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Sales/GetCustomer?LocationID=' + locationId);
                $scope.SalesCommonPopupCombinedPromise = $q.all({ Customer: popupDataPromise });
            }
        } else if ($scope.popupFor == 'Referrer') {
            var CustomerId = $scope.Sales.CustomerID || 0;
            if (CustomerId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Sales/GetReferrer?CustomerID=' + CustomerId);
                $scope.SalesCommonPopupCombinedPromise = $q.all({ Referrer: popupDataPromise });
            }
        } else if ($scope.popupFor == 'PriceDesc') {
            var CustomerId = $scope.Sales.CustomerID || 0;
            if (CustomerId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Sales/GetReferrer?CustomerID=' + CustomerId);
                $scope.SalesCommonPopupCombinedPromise = $q.all({ Referrer: popupDataPromise });
            }
        } else if ($scope.popupFor == 'Product') {
            var CustomerId = $scope.Sales.CustomerID || 0;
            var locationId = $scope.Sales.LocationID || 0;
            if (CustomerId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Sales/Getproduct?LocationID=' + locationId);
                $scope.SalesCommonPopupCombinedPromise = $q.all({ Product: popupDataPromise });
            }
        } else if ($scope.popupFor == 'InvoiceNo') {
            var searchKeyword = '';
            popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Sales/GetSalesReturnReference?searchKeyword=' + searchKeyword);
                $scope.SalesCommonPopupCombinedPromise = $q.all({ InvoiceNo: popupDataPromise });
          
        } else if ($scope.popupFor == 'Billing') {           
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Sales/BillingHead');
                $scope.SalesCommonPopupCombinedPromise = $q.all({ BillingHead: popupDataPromise });
          
        } else if ($scope.popupFor == 'TaxCode') {                 
                var tempTransactionPlace = $scope.Sales.TransactionPlace;
                var tempTransactionType = $scope.SalesDetail.TransactionType;
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Sales/BillingHeadTax?TransactionPlace=' + tempTransactionPlace + '&TransactionType=' + tempTransactionType);
                $scope.SalesCommonPopupCombinedPromise = $q.all({ TaxCode: popupDataPromise });
            
        }

        //Service Call
        if ($scope.SalesCommonPopupCombinedPromise != undefined) {
            $scope.SalesCommonPopupCombinedPromise.then(function (responses) {
                if (responses.Customer) {
                    $scope.CustomerArray = responses.Customer.data || [];
                } else if (responses.Referrer) {
                    $scope.ReferrerArray = responses.Referrer.data || [];
                } else if (responses.Referrer) {
                    $scope.ReferrerArray = responses.Referrer.data || [];
                } else if (responses.Product) {
                    $scope.ProductArray = responses.Product.data || [];
                } else if (responses.InvoiceNo) {                  
                    var len = responses.InvoiceNo.data.length;
                    for (i = 0 ; i <= len ; i++) {
                        $scope.parseJsonDate(responses.InvoiceNo.data[i]);
                    }
                    $scope.InvoiceNoArray = responses.InvoiceNo.data || [];

                } else if (responses.BillingHead) {
                    $scope.BillingHeadArray = responses.BillingHead.data || [];
                } else if (responses.TaxCode) {
                    $scope.BillingHeadArray = responses.TaxCode.data || [];
                }

                $('#dvSalesCommonPopup').modal('show');
            });
        }
    };
    $scope.SalesCommonPopup_onSelect = function (item) {
        
        $scope.SalesCommonPopupSelectedItem = item;

        if ($scope.popupFor == 'Customer') {
            //Update Sales model by Customer details
            $scope.Sales.Customer = item.Customer;
            $scope.Sales.CustomerID = item.CustomerID;
            $scope.Sales.CustomerGSTNo = item.GSTNo;
            $scope.Sales.CreditDays = item.CreditDays;
            $scope.Sales.BalanceAmount = item.BalanceAmount;
            $scope.Sales.Address = item.Address;
        } else if ($scope.popupFor == 'Referrer') {        
            //Update Sales model by Referrer details
            $scope.Sales.ReferrerID = item.ReferrerId;
            $scope.Sales.Referrer = item.Referrer;
        } else if ($scope.popupFor == 'PriceDesc') {
            //Update Sales model by Referrer details          
            $scope.Sales.PriceDiscRefID = item.ReferrerId;
            $scope.Sales.PriceDiscRefName = item.Referrer;
        } else if ($scope.popupFor == 'Product') {
            //Update Sales model by Referrer details          
            $scope.SalesDetail.ProductName = item.ProductName;
            $scope.SalesDetail.ProductID = item.ProductID;
            $scope.SalesDetail.ProductCategoryID = item.ProductCategoryID;
            $scope.SalesDetail.BillingUnit1ID = item.SalesRateUnit;
            $scope.SalesDetail.BillingUnitName = item.PuschaseUnit;
            $scope.SalesDetail.MinStockOnTransDate = item.MinStock;
            $scope.SalesDetail.MaxStockOnTransDate = item.MaxStock;
            $scope.SalesDetail.DisplayUnit1 = item.DisplayUnit1;
            $scope.SalesDetail.DisplayUnit2 = item.DisplayUnit2;
            $scope.SalesDetail.DisplayUnit3 = item.DisplayUnit3;
            $scope.SalesDetail.PerUnit1Content = item.PerUnit1Content;
            $scope.SalesDetail.PerUnit2Content = item.PerUnit2Content;
            $scope.SalesDetail.ShelfNo = item.ShelfNo;
            $scope.SalesDetail.ShelfID = item.ShelfID;
            $scope.SalesDetail.MRP = item.MRP;
            $scope.SalesDetail.TradeRate = item.TradeRate;  
        } else if ($scope.popupFor == 'InvoiceNo') {               
            $scope.Sales.SalesID = item.SalesID;
            $scope.Sales.Invoice = item.ReferenceInvoiceNo;         
            $scope.PopulateReturnConvert(item.SalesID)

        } else if ($scope.popupFor == 'Billing') {

            $scope.BillingHeadDetail.BillingHeadID = item.BillingHeadID;
            $scope.BillingHeadDetail.BillingHead = item.BillingHead;
            $scope.BillingHeadDetail.BillingHeadAddLess = item.BillingHeadAddLessText;
            $scope.BillingHeadDetail.AcLedgerID = item.AcLedgerID;
            $scope.BillingHeadDetail.TransactionID = $scope.Sales.SalesID;
            $scope.BillingHeadDetail.TransactionPlace = $scope.Sales.TransactionPlace;

            $scope.populateBillingHeadTax();
        }
        else if ($scope.popupFor == 'TaxCode') {

            $scope.BillingHeadDetail.TaxCode = item.TaxCode;
            $scope.BillingHeadDetail.TaxID = item.TaxID;

        }

        $('#dvSalesCommonPopup').modal('hide');
    };
    //#endregion - Sales Common Popup


    //Methods//
    $scope.onLoad = function () {
        ////Add to series
        $http.get(retailConstant.serviceBaseUrl + '/Sales/GetEntryNo?TransactionType=' + $scope.SalesDetail.TransactionType).then(function (resp) {
            if (resp) {              
                $scope.populateEntryNo(resp);
                $scope.populateCarreir();
            }
        });

        $q.all(requestPromise).then(function (data) {
            if ($routeParams.SalesID != null) {           
                $scope.Sales.SalesID = $routeParams.SalesID;
                $scope.populateReturnTransaction($routeParams.SalesID);
                $scope.PopulateDetailsGrid($routeParams.SalesID);
                $scope.Sales.IsEdit = 1;

            } else {
                $scope.Sales.IsEdit = 0;
            }

        });



    }    
    $scope.populateEntryNo = function (resp) {
        var response = resp.data;
        $scope.seriesCollection = response;      
    };
    ///////
    //$scope.seriesNo_OnChange = function (item) {
       
    //    $scope.Sales.EntryNo = item.EntryNo;
    //    $scope.Sales.LocationID = item.LocationID;

    //    $scope.Sales.SeriesID = item.SeriesID;
    //    $scope.Sales.Series = item.Series;

    //    $scope.SalesDetail.LocationID = item.LocationID;
    //};

    $scope.seriesNo_OnChange = function (EntryNoModel) {     
        var selectedValue = EntN.value;
        $scope.FilterEntryNoModel = $filter('filter')(EntryNoModel, { 'SeriesID': selectedValue });
        $scope.Sales.EntryNo = $scope.FilterEntryNoModel[0].EntryNo;   
        $scope.Sales.LocationID = $scope.FilterEntryNoModel[0].LocationID;
        $scope.Sales.SeriesID = $scope.FilterEntryNoModel[0].SeriesID;
        $scope.Sales.Series = $scope.FilterEntryNoModel[0].Series;
        $scope.SalesDetail.LocationID = $scope.FilterEntryNoModel[0].LocationID;
    }





  //////
    $scope.populateCarreir = function () {
        $http.get(retailConstant.serviceBaseUrl + '/Sales/GetCarrier').then(function (resp) {
            if (resp) {
                var response = resp.data;
                $scope.carrierCollection = response;

            }
        });

    }

    $scope.populateBillingHead = function () {
        $http.get(retailConstant.serviceBaseUrl + '/Sales/BillingHead').then(function (resp) {
         
            if (resp) {
                var response = resp.data;             
                $scope.billingHeadCollection = response;
            }
        });

    }

    $scope.populateBillingHeadTax = function () {
        var tempTransactionPlace = $scope.Sales.TransactionPlace;
        var tempTransactionType = $scope.SalesDetail.TransactionType;
        $http.get(retailConstant.serviceBaseUrl + '/Sales/BillingHeadTax?TransactionPlace=' + tempTransactionPlace +'&TransactionType=' + tempTransactionType).then(function (resp) {

            if (resp) {
                var response = resp.data;
                $scope.billingHeadTaxCollection = response;

            }
        });

    }
    //TODO:
    $scope.populateBillingHeadDetails = function () {
       // var tempTransactionID = $scope.Sales.SalesID;;
        var tempTransactionID = 1;
        var tempTransactionType = $scope.SalesDetail.TransactionType;
        $http.get(retailConstant.serviceBaseUrl + '/Sales/GetBillingHeadDetail?TransactionType=' + tempTransactionType + '&TransactionID=' + tempTransactionID).then(function (resp) {
            if (resp) {
                var response = resp.data;
                $scope.billingHeadDtlsCollection = response;
            }
        });

    }
    $scope.deleteBillingHeadDetails = function (billingHeadDtls, BillingHeadDetailID) {

        if (confirm("Are you sure to delete this item?")) {
            var index = $scope.billingHeadDtlsCollection.indexOf(billingHeadDtls);
            $http.post(retailConstant.serviceBaseUrl + '/Sales/DeleteBillingHead?BillingHeadDetailID=' + BillingHeadDetailID)
            .then(function (resp) {
                $scope.billingHeadDtlsCollection.splice(index, 1);
                alert("Billing head deleted successfully!!!");
            }, function () { alert('Error in getting records'); })
        }
    };
    
    $scope.editbillingHeadDtls = function (item) {     
        console.log(item);
        $scope.BillingHeadDetail.BillingHeadAmt = item.BillingHeadID;
        $scope.BillingHeadDetail.BillingHeadAmt = item.BillingHeadAmt; 

    }
        
   
    
    //////Add OR insert Transaction //////

    $scope.addProduct_onClick = function () {     

        var postSalesModel = angular.copy($scope.Sales);
        postSalesModel.SalesDetail = $scope.SalesDetail;
     
        $http.post(retailConstant.serviceBaseUrl + '/Sales/SaveSales', JSON.stringify(postSalesModel)).then(function (httpResponse) {
            var response = httpResponse.data;

     
            if (response.Status == 1) {
                if ($scope.Sales.SalesID == 0) {
                    $scope.Sales.SalesID = response.Data;
                    $scope.PopulateDetailsGrid(response.Data);
                    $scope.populateCalAdjTransaction(response.Data);
                    $scope.ClearSalesDetailsFeild();
                   
                }
                else {
                    $scope.PopulateDetailsGrid($scope.Sales.SalesID);
                    $scope.populateCalAdjTransaction($scope.Sales.SalesID);
                    $scope.ClearSalesDetailsFeild();
                }
            }

            alert(response.Message);
        });
    }

    
    //ToDo:
    $scope.billingHeadDetailInsert_onClick = function () {

        $scope.BillingHeadDetail.SeriesID = $scope.Sales.SeriesID;
        $scope.BillingHeadDetail.TransactionType = $routeParams.Type;
        $scope.BillingHeadDetail.TransactionID = 1;
        $scope.BillingHeadDetail.TransactionPlace = $scope.Sales.TransactionPlace;

        var postBillingHeadDetailModel = angular.copy($scope.BillingHeadDetail);

        $http.post(retailConstant.serviceBaseUrl + '/Sales/SaveBillingHead', JSON.stringify(postBillingHeadDetailModel)).then(function (httpResponse) {
            var response = httpResponse.data;
            if (response.Status == 1) {
                alert(response.Message);
                $scope.ClearBillingHead();
            }

        })
    }
    $scope.ClearBillingHead = function () { 
        $scope.BillingHeadDetail.BillingHeadRemark = '';
        $scope.BillingHeadDetail.BillingHeadAddLess = '';
        $scope.BillingHeadDetail.BillingHeadAmt = '';     
        $scope.BillingHeadDetail.TaxableAmount = '';
        $scope.BillingHeadDetail.TaxAddLess = '';
        $scope.BillingHeadDetail.TaxRemarks = ''
    }

    $scope.editProduct = function (item) {

        $scope.itemvalue = item;
        console.log(item);
        
        $scope.SalesDetail.ProductID = item.ProductID;
        $scope.SalesDetail.ProductName = item.ProductName;
        $scope.SalesDetail.Qty = item.Quantity;
        $scope.SalesDetail.Unit = item.Unit;
        $scope.SalesDetail.Rate = item.Rate;
        $scope.SalesDetail.GrossAmount = item.GrossAmount;
        $scope.SalesDetail.LotDisc = item.LotDisc;
        $scope.SalesDetail.LotDiscType = item.LotDiscType;
        $scope.SalesDetail.LotDiscAmount = item.LotDiscAmount;
        $scope.SalesDetail.LotRemarks = item.LotRemarks;
        $scope.SalesDetail.SchemeDisc = item.SchemeDisc;
        $scope.SalesDetail.SchemeDiscType = item.SchemeDiscType;
        $scope.SalesDetail.SchemeDisc = item.SchemeDiscAmount;
        $scope.SalesDetail.SchemeRemark = item.SchemeRemark;
        $scope.SalesDetail.TradeDisc = item.TradeDisc;
        $scope.SalesDetail.TradeDiscType = item.TradeDiscType;
        $scope.SalesDetail.TradeDiscAmount = item.TradeDiscAmount;
        $scope.SalesDetail.TradeDiscRemark = item.TradeDiscRemark;
        $scope.SalesDetail.FreeQty = item.FreeQty;
        $scope.SalesDetail.FreeQtyUnit = item.FreeQtyUnit;
        $scope.SalesDetail.FreeQtyRemark = item.FreeQtyRemark;
        $scope.SalesDetail.ManufacturingDate = item.ManufacturingDate;
        $scope.SalesDetail.ExpiryDate = item.ExpiryDate;
        $scope.SalesDetail.BatchCode = item.BatchCode;
        $scope.SalesDetail.LotNo = item.LotNo;
        $scope.SalesDetail.Manufacturer = item.Manufacturer;
        $scope.SalesDetail.Remarks = item.Remarks;

    }

      
    
    //////Add OR insert Transaction //////

    $scope.moveToChallan_onClick = function () {

        var postSalesModel = angular.copy($scope.Sales);

        $http.post(retailConstant.serviceBaseUrl + '/Sales/MoveToChallan', JSON.stringify(postSalesModel)).then(function (httpResponse) {
            var response = httpResponse.data;

          
            if (response.Status == 1) {
               
            }

            alert(response.Message);
        });
    }
    $scope.moveToInvoice_onClick = function () {

        var postSalesModel = angular.copy($scope.Sales);

        $http.post(retailConstant.serviceBaseUrl + '/Sales/MoveToInvoice', JSON.stringify(postSalesModel)).then(function (httpResponse) {
            var response = httpResponse.data;

          
            if (response.Status == 1) {
             
            }

            alert(response.Message);
        });
    }

    $scope.carrier_OnChange = function (item) {    
        $scope.Sales.CarrierID = item.CarrierID;
      
    };

    $scope.billingHead_OnChange = function (item) {     
        var billingHead = item.BillingFields;
        var arrayHead = billingHead.split('|');

        var BillingHeadID = arrayHead[0];
        var BillingHead = arrayHead[1];
        var BillingHeadAddLess = arrayHead[2];
        var AcLedgerID = arrayHead[3];

        $scope.BillingHeadDetail.BillingHeadID = BillingHeadID;
        $scope.BillingHeadDetail.BillingHead = BillingHeadID;
        $scope.BillingHeadDetail.BillingHeadAddLess = BillingHeadID;
        $scope.BillingHeadDetail.AcLedgerID = BillingHeadID;

        $scope.populateBillingHeadTax();
    };

    $scope.taxCode_OnChange = function (item) {
        var taxID = item.TaxID;
       
        $scope.BillingHeadDetail.taxID = taxID;
    };
   
    $scope.callMoveToChallan = function () {
        var val = $scope.Sales.OrderNosection;
        var tStatus = parseFloat($scope.Sales.TransactionStatus || 0);
        var tPID = parseFloat($scope.Sales.SalesID || 0);
       
        if (val == '1' && tStatus != 2 && tPID > 0 && tStatus != 5)
            return true;
        else
            return false;
    };

    $scope.callMoveToInVoice = function () {      


        var val = $scope.Sales.OrderNosection;
        var tStatus = parseFloat($scope.Sales.TransactionStatus || 0);
        var tPID = parseFloat($scope.Sales.SalesID || 0);

        if ((val == '1' || val == '2') && tStatus != 3 && tPID > 0 && tStatus != 5)
            return true;
        else
            return false;
    };

    $scope.PopulateDetailsGrid = function (SalesID) {
        $http.get(retailConstant.serviceBaseUrl + '/Sales/SalesDetailsPopulateAllGrid?SalesID=' + SalesID).then(function (resp) {
            if (resp) {
                var response = resp.data;
                var len = resp.data.length;
                for (i = 0 ; i <= len ; i++) {
                    $scope.parseJsonDate(resp.data[i]);
                }
               
                $scope.SalesDetailsCollection = resp.data;               
              
            }

        });

    }

    $scope.populateCalAdjTransaction = function (SalesID) {
        $http.get(retailConstant.serviceBaseUrl + '/Sales/SalesTransactionCalAdj?SalesID=' + SalesID).then(function (resp) {
            if (resp) {
                var response = resp.data;              
                $scope.Sales.TotalGrossAmountWithTax = response[0].TotalGrossAmountWithTax;
               // $scope.Sales.TotalAmountAfterAdjustments = response[0].TotalAmountAfterAdjustments;
                $scope.Sales.CashDiscAmount = response[0].CashDiscAmount;
                $scope.Sales.TotalTaxAmount = response[0].TotalTaxAmount;
                $scope.Sales.CashDisc = response[0].CashDisc;
                $scope.Sales.CashDiscType = response[0].CashDiscType;
                $scope.Sales.CashDiscAmount = response[0].CashDiscAmount;
                $scope.Sales.RoundOff = response[0].RoundOff;
                $scope.Sales.FinalNetAmountWithShipping = response[0].FinalNetAmountWithShipping;
                $scope.Sales.BillingTotal = response[0].BillingTotal;
                $scope.Sales.RCM = response[0].RCM;
                $scope.Sales.CheckStatus = response[0].CheckStatus;
                $scope.Sales.CheckedByMemberID = response[0].CheckedByMemberID;



                $scope.Sales.TotalDiscounts = response[0].TotalDiscounts;


                $scope.Sales.TotalTaxableAmount = response[0].TotalTaxableAmount;
                $scope.Sales.TotalAmountAfterAdjustments = response[0].TotalAmountAfterAdjustments;

                $scope.Sales.TotalAmountAfterCashDiscount = response[0].TotalAmountAfterCashDiscount;
                $scope.Sales.TransactionStatus = response[0].TransactionStatus;

                
            }
        });

    }


    $scope.ClearSalesDetailsFeild = function () {
        $scope.SalesDetail.ProductName = '';
        $scope.SalesDetail.Qty = '';
        $scope.SalesDetail.Unit = '';
        $scope.SalesDetail.Rate = '';
        $scope.SalesDetail.GrossAmount = '';      
        $scope.SalesDetail.ManufacturingDate = '';
        $scope.SalesDetail.ExpiryDate = '';
        $scope.SalesDetail.BatchCode = '';
       // $scope.SalesDetail.BarCode = '';
        $scope.SalesDetail.LotNo = '';
        $scope.SalesDetail.ShelfNo = '';
        $scope.SalesDetail.Manufacturer = '';
        $scope.SalesDetail.Remarks = '';
        $scope.SalesDetail.ReturnAdjustmentAmount = '';
        $scope.SalesDetail.ReturnAdjustmentAddLess = '';
        $scope.SalesDetail.ReturnType = '';
        $scope.SalesDetail.ReturnAdjustmentRemarks = '';
       

    }

    $scope.ClearSalesTransFeild = function () {
        $scope.Sales.Customer = '';
        $scope.Sales.GSTNo = '';
        $scope.Sales.CreditDays = '';
        $scope.Sales.BalanceAmount = '';
        $scope.Sales.Address = '';
        $scope.Sales.Referrer = '';
        $scope.Sales.PriceDiscRefName = '';
        $scope.Sales.selectedSeries = '';
        $scope.Sales.EntryNo = '';
        $scope.Sales.EntryDate = '';
        $scope.Sales.ReferenceNo = '';
        $scope.Sales.ReferenceDate = '';
        $scope.Sales.TransactionPlace = '';
        $scope.Sales.TotalGrossAmountWithTax = '';
        $scope.Sales.TotalAmountAfterAdjustments = '';
        $scope.Sales.CashDiscAmount = '';
        $scope.Sales.TotalTaxAmount = '';
        $scope.Sales.CashDisc = '';
        $scope.Sales.CashDiscType = '';
        $scope.Sales.CashDiscAmount = '';
       // $scope.Sales.RoundOff = '';
        $scope.Sales.TotalNetAmountWithoutShipping = '';
        $scope.Sales.FinalNetAmountWithShipping = '';
       // $scope.Sales.BillingTotal = '';
        $scope.Sales.RCM = '';
      //  $scope.Sales.CheckStatus = '';
        $scope.Sales.FinalNetAmountWithShipping = '';
      
    };

    $scope.CalTotal = function () {
        if ($scope.SalesDetail.Qty || $scope.SalesDetail.Rate != null) {

            var total = ($scope.SalesDetail.Qty * $scope.SalesDetail.Rate)
            $scope.SalesDetail.GrossAmount = total;
        } else {
            $scope.SalesDetail.GrossAmount = '';
        }
        
    };
    $scope.autoGenerateBarCode = function () {
        $scope.SalesDetail.BarCode = 111;//value to be set
       // $scope.SalesDetail.ShelfNo = 222;//value to be set
    };

    $scope.closeShippingPopup_onClick = function () {

       // var temp = ($scope.Sales.TotalAmountAfterAdjustments - $scope.Sales.CashDiscAmount);  
        //$scope.Sales.TotalAmountAfterCashDiscount = temp;
        //$scope.Sales.TotalNetAmountWithoutShipping = (($scope.Sales.TotalAmountAfterAdjustments - $scope.Sales.CashDiscAmount) + $scope.Sales.RoundOff)

       // $scope.Sales.FinalNetAmountWithShipping = ( (( {{$scope.Sales.TotalAmountAfterAdjustments}} - $scope.Sales.CashDiscAmount) + $scope.Sales.RoundOff) + $scope.Sales.FreightAmt)
   
        var total = ((parseFloat($scope.Sales.TotalAmountAfterAdjustments || 0) - parseFloat($scope.Sales.CashDiscAmount || 0)) + parseFloat($scope.Sales.FreightAmt || 0)) + parseFloat($scope.Sales.RoundOff || 0)

        //////////var rtrr= parseFloat($scope.Sales.FreightAmt || 0)


        //////////var rr = rtrr.split('.')[1];
        //////////var ss = rr;
        //////////alert(ss);

        $scope.Sales.FinalNetAmountWithShipping = total;
    
    }
    $scope.calRoundOff = function () {
        var tempRoundOff = parseFloat($scope.Sales.RoundOff || 0)
        var tempCashDiscAmount = parseFloat($scope.Sales.CashDiscAmount || 0)
        var tempFreightAmt = parseFloat($scope.Sales.FreightAmt || 0)
        var totalAmtAftAdj = parseFloat($scope.Sales.TotalAmountAfterAdjustments || 0)

        var tempFinal = (((totalAmtAftAdj - tempCashDiscAmount) + tempFreightAmt) + tempRoundOff)

        $scope.Sales.FinalNetAmountWithShipping = tempFinal
    }

    $scope.calCashDisType = function (val) {
        var cashDisCount = parseFloat($scope.Sales.CashDisc|| 0);
        var totalTaxableAmt = parseFloat($scope.Sales.TotalTaxableAmount|| 0)
        var totalAmtAftAdj =parseFloat($scope.Sales.TotalAmountAfterAdjustments|| 0)



        if (val == "1") {

            $scope.Sales.CashDiscAmount = cashDisCount
          
            var temp = (totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0));
            $scope.Sales.TotalAmountAfterCashDiscount = temp;
            $scope.Sales.TotalNetAmountWithoutShipping = ((totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0)))
         
            $scope.Sales.FinalNetAmountWithShipping = (((totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0)) + parseFloat($scope.Sales.FreightAmt || 0)) + parseFloat($scope.Sales.RoundOff || 0))
        }
        if (val == "2") {

            $scope.Sales.CashDiscAmount = (cashDisCount / 100) * totalTaxableAmt  

            var temp = (totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0));
            $scope.Sales.TotalAmountAfterCashDiscount = temp;
            $scope.Sales.TotalNetAmountWithoutShipping = ((totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0)))

            $scope.Sales.FinalNetAmountWithShipping = (((totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0)) + parseFloat($scope.Sales.FreightAmt || 0)) + parseFloat($scope.Sales.RoundOff || 0))



        }
        if (val == "3") {

            $scope.Sales.CashDiscAmount = (cashDisCount / 100) * totalAmtAftAdj
         
            var temp = (totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0));
            $scope.Sales.TotalAmountAfterCashDiscount = temp;
            $scope.Sales.TotalNetAmountWithoutShipping = ((totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0)))

            $scope.Sales.FinalNetAmountWithShipping = (((totalAmtAftAdj - parseFloat($scope.Sales.CashDiscAmount || 0)) + parseFloat($scope.Sales.FreightAmt || 0)) + parseFloat($scope.Sales.RoundOff || 0))

        }

    }
    $scope.calculateDiscount = function (val,type) {

        var grossAmt = $scope.SalesDetail.GrossAmount
     
      
        if (type == "Lot") {
      
            if (val == "1") {               
                $scope.SalesDetail.LotDiscAmount = $scope.SalesDetail.LotDisc
            }
            if (val == "2") {
                var lotDis = $scope.SalesDetail.LotDisc;
                $scope.SalesDetail.LotDiscAmount = (lotDis / 100) * grossAmt
            } 
            if (val == "") {
                $scope.SalesDetail.LotDiscAmount = '';
            }        
        }
        else if (type == "Scheme") {
            if (val == "1") { 
                $scope.SalesDetail.SchemeDiscAmount = $scope.SalesDetail.SchemeDisc;                
            }
            if (val == "2") {
                var SchDis = $scope.SalesDetail.SchemeDisc;
                $scope.SalesDetail.SchemeDiscAmount = (SchDis / 100) * grossAmt
            }
            if (val == "")
            {
                $scope.SalesDetail.SchemeDiscAmount = '';
            }

        } else if (type == "Trade") {
            if (val == "1") { 
                $scope.SalesDetail.TradeDiscAmount = $scope.SalesDetail.TradeDisc;
            }
            if (val == "2") { 
                var TradeDis = $scope.SalesDetail.TradeDisc;
                $scope.SalesDetail.TradeDiscAmount = (TradeDis / 100) * grossAmt
            } 
            if (val == "")
            {
                $scope.SalesDetail.TradeDiscAmount = '';
            }

        }

     
    };
       //Methods//
    $scope.onLoad();
    $scope.autoGenerateBarCode();
    $scope.populateBillingHead();
    $scope.populateBillingHeadDetails();


    /////////////////////  Sales Return ////////////////////////     


    $scope.PopulateReturnConvert = function (SalesID) {
        $http.post(retailConstant.serviceBaseUrl + '/Sales/SalesReturnConvert?SalesID=' + SalesID).then(function (resp) {
            if (resp) {
                var response = resp.data;
                if (response.Status == 1) {
                    debugger;
                    $scope.Sales.SalesID = response.Data;
                    $scope.PopulateReturnDetails(response.Data);
                    $scope.populateReturnTransaction(response.Data);
                    $scope.isDisabledInvoice = true;
                }
            }
        });
    }

    $scope.PopulateReturnDetails = function (SalesID) {
        $http.get(retailConstant.serviceBaseUrl + '/Sales/SalesReturnTransactionPopulateAllGrid?SalesID=' + SalesID).then(function (resp) {
            if (resp) {
                var response = resp.data;
                var len = resp.data.length;
                for (i = 0 ; i <= len ; i++) {
                    $scope.parseJsonDate(resp.data[i]);
                }

                $scope.SalesDetailsCollection = resp.data;

            }

        });

    }

    $scope.populateReturnTransaction = function (SalesID) {
        $http.get(retailConstant.serviceBaseUrl + '/Sales/SalesTransactionCalAdj?SalesID=' + SalesID).then(function (resp) {
            if (resp) { 
                var len = resp.data.length;
                for (i = 0 ; i <= len ; i++) {
                    $scope.parseJsonDate(resp.data[i]);
                }               
                var response = resp.data;
                console.log(response);
                $scope.Sales.TotalGrossAmountWithTax = response[0].TotalGrossAmountWithTax;              
                $scope.Sales.CashDiscAmount = response[0].CashDiscAmount;
                $scope.Sales.TotalTaxAmount = response[0].TotalTaxAmount;
                $scope.Sales.CashDisc = response[0].CashDisc;
                $scope.Sales.CashDiscType = response[0].CashDiscType;               
                $scope.Sales.RoundOff = response[0].RoundOff;
                $scope.Sales.FinalNetAmountWithShipping = response[0].FinalNetAmountWithShipping;
                $scope.Sales.BillingTotal = response[0].BillingTotal;
                $scope.Sales.RCM = response[0].RCM;
                $scope.Sales.CheckStatus = response[0].CheckStatus;
                $scope.Sales.CheckedByMemberID = response[0].CheckedByMemberID;
                $scope.Sales.TotalDiscounts = response[0].TotalDiscounts;
                $scope.Sales.TotalTaxableAmount = response[0].TotalTaxableAmount;
                $scope.Sales.TotalAmountAfterAdjustments = response[0].TotalAmountAfterAdjustments;
                $scope.Sales.TotalAmountAfterCashDiscount = response[0].TotalAmountAfterCashDiscount;
                $scope.Sales.TransactionStatus = response[0].TransactionStatus;
                $scope.Sales.Customer = response[0].Customer;
                $scope.Sales.CustomerID = response[0].CustomerID;
                $scope.Sales.CustomerGSTNo = response[0].CustomerGSTNo;
                $scope.Sales.CreditDays = response[0].CreditDays;
                $scope.Sales.BalanceAmount = response[0].BalanceAmount;
                $scope.Sales.Address = response[0].Address;
                $scope.Sales.Referrer = response[0].Referrer;
                $scope.Sales.PriceDiscRefName = response[0].PriceDiscReferrer;
                $scope.Sales.SeriesID = response[0].SeriesID;
                $scope.Sales.ReferrerID = response[0].ReferrerID;
                $scope.Sales.PriceDiscRefID = response[0].PriceDiscRefID;
                $scope.Sales.Series = response[0].Series;
                $scope.Sales.ReferenceNo = response[0].ReferenceNo;
                $scope.Sales.ReferenceDate = response[0].ReferenceDate;
                $scope.Sales.TransactionPlace = response[0].TransactionPlace;                  
              //  $scope.SalesDetail.CheckStatus = response[0].CheckStatus;                
                $scope.Sales.SeriesID = response[0].SeriesID;
                $scope.Sales.EntryNo = response[0].EntryNo;
                $scope.Sales.EntryDate = response[0].EntryDate;
                $scope.Sales.LocationID = response[0].LocationID;
                $scope.Sales.LRNo = response[0].LRNo;
                $scope.Sales.LRDate = response[0].LRDate;
                $scope.Sales.FreightType = response[0].FreightType;
                $scope.Sales.FreightAmt = response[0].FreightAmt;
                $scope.Sales.RoadPermitNo = response[0].RoadPermitNo;
                $scope.Sales.CarrierID = response[0].CarrierID;
                $scope.Sales.NoOfCases = response[0].NoOfCases;
                $scope.Sales.DeliveryDate = response[0].DeliveryDate;
                $scope.Sales.returnReferenceInvoiceID = response[0].returnReferenceInvoiceID;
                $scope.Sales.returnReferenceInvoiceSeriesID = response[0].returnReferenceInvoiceSeriesID;
                $scope.Sales.returnReferenceInvoiceSeries = response[0].returnReferenceInvoiceSeries;
                $scope.Sales.returnReferenceInvoiceEntryNo = response[0].returnReferenceInvoiceEntryNo;
                $scope.Sales.returnReferenceInvoiceEntryDate = response[0].returnReferenceInvoiceEntryDate;
                
            }
        });
    }

    $scope.searchInvoice = function (Keywords) {
        if (Keywords.length > 2) {
            $http.get(retailConstant.serviceBaseUrl + '/Sales/GetSalesReturnReference?searchKeyword=' + Keywords).then(function (resp) {
                if (resp.data.length > 0) {                
                    var len = resp.data.length;
                    for (i = 0 ; i <= len ; i++) {
                        $scope.parseJsonDate(resp.data[i]);
                    } 

                    $scope.InvoiceNoArray = resp.data || [];
                }
            });
        }

    }   

    $scope.SalesReturnDetailInsertClick = function () {

        if ($scope.SalesDetail.ProductName != undefined) {

            var postSalesModel = angular.copy($scope.Sales);
            postSalesModel.SalesDetails = $scope.SalesDetail;

            $http.post(retailConstant.serviceBaseUrl + '/Sales/SalesReturnDetailsInsert', JSON.stringify(postSalesModel)).then(function (httpResponse) {
                var response = httpResponse.data;

                if (response.Status == 1) {
                    $scope.PopulateReturnDetails($scope.Sales.SalesID);
                    $scope.populateReturnTransaction($scope.Sales.SalesID);
                    $scope.ClearSalesDetailsFeild();
                    $scope.isDisabledInvoice = true;
                }

                alert(response.Message);
            });
        } else {
            alert('Please edit the product');
        }
    }

    $scope.SalesReturnConfirmationClick = function () {

        var postSalesModel = angular.copy($scope.Sales);
        postSalesModel.SalesDetail = $scope.SalesDetail;

        $http.post(retailConstant.serviceBaseUrl + '/Sales/SalesReturnConfirmationClick', JSON.stringify(postSalesModel)).then(function (httpResponse) {
            var response = httpResponse.data;       
            if (response.Status == 1) {
                $scope.Sales.SalesID
                $scope.PopulateReturnDetails($scope.Sales.SalesID);
                $scope.populateReturnTransaction($scope.Sales.SalesID);
                // $scope.ClearSalesDetailsFeild();
                //  $scope.ClearSalesTransFeild();
                $scope.isDisabledInvoice = true;
            }

            alert(response.Message);
        });
    }

    $scope.saveSalesReturnOnClick = function () {

        var postSalesModel = angular.copy($scope.Sales);
        postSalesModel.SalesDetail = $scope.SalesDetail;

        $http.post(retailConstant.serviceBaseUrl + '/Sales/SalesReturnTransactionUpdate', JSON.stringify(postSalesModel)).then(function (httpResponse) {
            var response = httpResponse.data;

            if (response.Status == 1) {
                $scope.isDisabledInvoice = true;
            }

            alert(response.Message);
        });
    }

    $scope.deleteSalesReturn = function (item) {

        if (confirm("Are you sure to delete this item?")) {
            var index = $scope.SalesDetailsCollection.indexOf(item);
            var SalesDetailID = item.SalesDetailID;
            var LocationID = $scope.Sales.LocationID;
            var CheckStatus = 1;
            var TransactionType = 8;
            $http.post(retailConstant.serviceBaseUrl + '/Sales/SalesDetailsDeleteTest?SalesDetailID=' + SalesDetailID + '&LocationID=' + LocationID + '&TransactionType=' + TransactionType + '&CheckStatus=' + CheckStatus)
            .then(function (resp) {
                $scope.SalesDetailsCollection.splice(index, 1);
                alert("Sales details deleted successfully!!!");
            }, function () { alert('Error in getting records'); })

        }
    }

    //$scope.deleteSalesReturn = function (item) {
    //    var index = $scope.SalesDetailsCollection.indexOf(item);

    //     var pstData = {};
    //        pstData = {
    //            SalesDetailID: item.SalesDetailID,
    //            LocationID: $scope.Sales.LocationID,
    //            CheckStatus: 1,
    //            TransactionType: 8
    //    };   
       

    //        if (confirm("Are you sure to delete this item?")) {

    //            $http.post(retailConstant.serviceBaseUrl + '/Sales/SalesDetailsDeleteTest', pstData).then(function (resp) {
    //                if (resp) {
    //                    $scope.SalesDetailsCollection.splice(index, 1);
    //                    alert("Sales details deleted successfully!!");
    //                }
    //            });
    //        }
    //};






    $scope.billingHeadDetailSave_onClick = function () {
        $scope.populateCalAdjTransaction($scope.Sales.SalesID);


    }

    /////////////////////  Sales Return ////////////////////////

  
})



