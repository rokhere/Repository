﻿var retailPurchaseApp = angular.module('Retail');

retailPurchaseApp.controller('purchasePage2Ctrl', function ($scope) {
    $scope.pageName = "Purchase - Page2";
});