﻿var retailPurchaseApp = angular.module('Retail');


retailPurchaseApp.controller('purchaseTransactionListCtrl', function ($scope, $q, $filter, $http, $routeParams, $location, retailConstant) {
    

    $scope.TransactionTypeList =
      [
          { TransactionTypeID: "-1", TransactionType: "select" },
          { TransactionTypeID: "1", TransactionType: "Order" },
          { TransactionTypeID: "2", TransactionType: "Challan" },
          { TransactionTypeID: "3", TransactionType: "Invoice" },
          { TransactionTypeID: "4", TransactionType: "Return" }
      ];

    $scope.PurchaseList = { TransactionType: "" };
    $scope.PurchaseList.TransactionType = "3";  
  

    ///////Date Time Create/////
    //$scope.PurchaseList.EntryDate = $filter('date')(Date.now(), 'dd/MM/yyyy');
    //$scope.PurchaseList.EndDate = $filter('date')(Date.now(), 'dd/MM/yyyy');


    var date = new Date();
    var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
    var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    var FirstDateOfMonth = (firstDay.getDate()) + '/' + (lastDay.getMonth() + 1) + '/' + lastDay.getFullYear();
    var NowDateOfMonth = (date.getDate()) + '/' + (lastDay.getMonth() + 1) + '/' + lastDay.getFullYear();

    $scope.PurchaseList.EntryDate = FirstDateOfMonth;
    $scope.PurchaseList.ActualDate = NowDateOfMonth;

  

    $scope.parseJsonDate = function (model) {
        // date format - /Date(1507573800000)/
        for (var property in model) {
            if (model.hasOwnProperty(property) && property.indexOf('Date') > -1) {
                var jsonDateString = model[property] || '';
                if (jsonDateString.length > 0) {
                    var date = new Date(parseInt(jsonDateString.substr(6)));
                    model[property] = $filter('date')(date, "dd/MM/yyyy");;
                }
            }
        }
    }
  
    /////
    if ($scope.PurchaseList.Keywor == null || $scope.PurchaseList.Keywor === "") {
        keyWord = '';
    } else {
        keyWord = $scope.PurchaseList.Keyword;
    }
   
    $scope.populateListing = function (type) {

        //if (type == 1) {
        //    var First = $filter('date')(new Date(FirstDateOfMonth), 'dd/MM/yyyy');
        //    var Now = $filter('date')(new Date(NowDateOfMonth), 'dd/MM/yyyy');
        //} else {
        //    var First = $scope.PurchaseList.EntryDate;
        //    var Now = $scope.PurchaseList.EndDate;

        //}

        var pstData = {};
        pstData = {
            KeyWord: $scope.PurchaseList.Keyword,
            EntryDate: $scope.PurchaseList.EntryDate,
            ActualDate: $scope.PurchaseList.ActualDate,
            TransactionType: $scope.PurchaseList.TransactionType
        };

        //////      
        $http.post(retailConstant.serviceBaseUrl + '/Purchase/PurchaseTransactionListing', pstData).then(function (resp) {
            if (resp) {
                var response = resp.data;
                var len = resp.data.length;
                for (i = 0 ; i <= len ; i++) {
                    $scope.parseJsonDate(resp.data[i]);
                }
                $scope.purchaseListCollection = resp.data || [];               
            }
        });

    }

    $scope.deleteTransaction = function (purchaseList, PurchaseID) { 

        if (confirm("Are you sure to delete this item ?")) {
            var index = $scope.purchaseListCollection.indexOf(purchaseList);
            $http.post(retailConstant.serviceBaseUrl + '/Purchase/PurchaseTransactionDelete?PurchaseID=' + PurchaseID + '&TransactionType=' + $scope.PurchaseList.TransactionType)
            .then(function (resp) {
                $scope.purchaseListCollection.splice(index, 1);
                alert("item deleted successfully!!!");
            }, function () { alert('Error in getting records'); })
        };
    }
   
    $scope.populateListing(1);
})



