﻿var retailPurchaseApp = angular.module('Retail');

retailPurchaseApp.controller('purchasePage1Ctrl', function ($scope, $http) {
    $scope.pageName = "Purchase - Page1";

    $scope.getSessionData = function () {
        console.log('GetSessionDateTime');

        //TODO: need fix
        $http.get('http://localhost:51327/purchase/GetDataServer').then(function (response) {
            $scope.sessionDateTime = response.data;
        });
    };
});