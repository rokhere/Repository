﻿var retailPurchaseApp = angular.module('Retail');


retailPurchaseApp.controller('purchaseReturnCtrl', function ($scope, $q, $filter, $http, $routeParams, $location, retailConstant) {

    $scope.Purchase = { PurchaseID: 0 };//PurchaseMaster
    $scope.PurchaseDetail = { PurchaseDetailID: 0 };//PurchaseDetail
    $scope.purchaseDetailsCollection = {};
    $scope.VendorArray = [];
    $scope.ReferrerArray = [];
    $scope.ProductArray = [];  
    $scope.Purchase.OrderNosection = $routeParams.Type;
    $scope.PurchaseDetail.TransactionType = 4;//purchase return 
    $scope.BillingHeadDetail = {}

    $scope.PurchaseReturn = {}

    $scope.Purchase.IsEdit = 0;

    var requestPromise = [];
    $scope.Purchase.CheckStatus = 1;
    $scope.checkList =
       [
           { CheckStatus: "", StatusName: "Select Check Status" },
           { CheckStatus: "1", StatusName: "Draft" },
           { CheckStatus: "2", StatusName: "Checked" }
       ]; 
   
    $scope.isDisabledInvoice = false;

    $scope.Purchase.ShippingAndAdjustment = 1;

    $scope.parseJsonDate = function (model) {
        // date format - /Date(1507573800000)/
        for (var property in model) {
            if (model.hasOwnProperty(property) && property.indexOf('Date') > -1) {
                var jsonDateString = model[property] || '';
                if (jsonDateString.length > 0) {
                    var date = new Date(parseInt(jsonDateString.substr(6)));
                    model[property] = $filter('date')(date, "dd/MM/yyyy");;
                }
            }
        }
    }
 
    //#region - Purchase Common Popup
    $scope.purchaseCommonPopupSelectedItem = undefined;
    $scope.purchaseCommonPopupCombinedPromise = undefined;
    $scope.popupFor = undefined;
    $scope.purchaseCommonPopupSearch = '';
    $scope.showPurchaseCommonPopup = function (popupFor) {
        
        $scope.purchaseCommonPopupCombinedPromise = undefined;
        $scope.popupFor = popupFor;

        //Prepare Promise
        var popupDataPromise = undefined;
        if ($scope.popupFor == 'Vendor') {
            var locationId = $scope.Purchase.LocationID || 0;
            if (locationId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetVendor?LocationID=' + locationId);
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ Vendor: popupDataPromise });
            }
        } else if ($scope.popupFor == 'Referrer') {
            var vendorId = $scope.Purchase.VendorID || 0;
            if (vendorId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetReferrer?VendorID=' + vendorId);
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ Referrer: popupDataPromise });
            }
        } else if ($scope.popupFor == 'PriceDesc') {
            var vendorId = $scope.Purchase.VendorID || 0;
            if (vendorId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetReferrer?VendorID=' + vendorId);
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ Referrer: popupDataPromise });
            }
        } else if ($scope.popupFor == 'Product') {
            var vendorId = $scope.Purchase.VendorID || 0;
            var locationId = $scope.Purchase.LocationID || 0;
            if (vendorId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/Getproduct?LocationID=' + locationId);
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ Product: popupDataPromise });
            }
        } else if ($scope.popupFor == 'InvoiceNo') {
            var searchKeyword = '';
            popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetPurchaseReturnReference?searchKeyword=' + searchKeyword);
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ InvoiceNo: popupDataPromise });
          
        } else if ($scope.popupFor == 'Billing') {           
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/BillingHead');
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ BillingHead: popupDataPromise });
          
        } else if ($scope.popupFor == 'TaxCode') {                 
                var tempTransactionPlace = $scope.Purchase.TransactionPlace;
                var tempTransactionType = $scope.PurchaseDetail.TransactionType;
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/BillingHeadTax?TransactionPlace=' + tempTransactionPlace + '&TransactionType=' + tempTransactionType);
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ TaxCode: popupDataPromise });
            
        }

        //Service Call
        if ($scope.purchaseCommonPopupCombinedPromise != undefined) {
            $scope.purchaseCommonPopupCombinedPromise.then(function (responses) {
                if (responses.Vendor) {
                    $scope.VendorArray = responses.Vendor.data || [];
                } else if (responses.Referrer) {
                    $scope.ReferrerArray = responses.Referrer.data || [];
                } else if (responses.Referrer) {
                    $scope.ReferrerArray = responses.Referrer.data || [];
                } else if (responses.Product) {
                    $scope.ProductArray = responses.Product.data || [];
                } else if (responses.InvoiceNo) {                  
                    var len = responses.InvoiceNo.data.length;
                    for (i = 0 ; i <= len ; i++) {
                        $scope.parseJsonDate(responses.InvoiceNo.data[i]);
                    }
                    $scope.InvoiceNoArray = responses.InvoiceNo.data || [];

                } else if (responses.BillingHead) {
                    $scope.BillingHeadArray = responses.BillingHead.data || [];
                } else if (responses.TaxCode) {
                    $scope.BillingHeadArray = responses.TaxCode.data || [];
                }

                $('#dvPurchaseCommonPopup').modal('show');
            });
        }
    };
    $scope.purchaseCommonPopup_onSelect = function (item) {
        
        $scope.purchaseCommonPopupSelectedItem = item;

        if ($scope.popupFor == 'Vendor') {
            //Update Purchase model by Vendor details
            $scope.Purchase.Vendor = item.Vendor;
            $scope.Purchase.VendorID = item.VendorID;
            $scope.Purchase.VendorGSTNo = item.GSTNo;
            $scope.Purchase.CreditDays = item.CreditDays;
            $scope.Purchase.BalanceAmount = item.BalanceAmount;
            $scope.Purchase.Address = item.Address;
        } else if ($scope.popupFor == 'Referrer') {        
            //Update Purchase model by Referrer details
            $scope.Purchase.ReferrerID = item.ReferrerId;
            $scope.Purchase.Referrer = item.Referrer;
        } else if ($scope.popupFor == 'PriceDesc') {
            //Update Purchase model by Referrer details          
            $scope.Purchase.PriceDiscRefID = item.ReferrerId;
            $scope.Purchase.PriceDiscRefName = item.Referrer;
        } else if ($scope.popupFor == 'Product') {
            //Update Purchase model by Referrer details          
            $scope.PurchaseDetail.ProductName = item.ProductName;
            $scope.PurchaseDetail.ProductID = item.ProductID;
            $scope.PurchaseDetail.ProductCategoryID = item.ProductCategoryID;
            $scope.PurchaseDetail.BillingUnit1ID = item.PurchaseRateUnit;
            $scope.PurchaseDetail.BillingUnitName = item.PuschaseUnit;
            $scope.PurchaseDetail.MinStockOnTransDate = item.MinStock;
            $scope.PurchaseDetail.MaxStockOnTransDate = item.MaxStock;
            $scope.PurchaseDetail.DisplayUnit1 = item.DisplayUnit1;
            $scope.PurchaseDetail.DisplayUnit2 = item.DisplayUnit2;
            $scope.PurchaseDetail.DisplayUnit3 = item.DisplayUnit3;
            $scope.PurchaseDetail.PerUnit1Content = item.PerUnit1Content;
            $scope.PurchaseDetail.PerUnit2Content = item.PerUnit2Content;
            $scope.PurchaseDetail.ShelfNo = item.ShelfNo;
            $scope.PurchaseDetail.ShelfID = item.ShelfID;
            $scope.PurchaseDetail.MRP = item.MRP;
            $scope.PurchaseDetail.TradeRate = item.TradeRate;  
        } else if ($scope.popupFor == 'InvoiceNo') {               
            $scope.Purchase.PurchaseID = item.PurchaseID;
            $scope.Purchase.Invoice = item.ReferenceInvoiceNo;         
            $scope.PopulateReturnConvert(item.PurchaseID)

        } else if ($scope.popupFor == 'Billing') {

            $scope.BillingHeadDetail.BillingHeadID = item.BillingHeadID;
            $scope.BillingHeadDetail.BillingHead = item.BillingHead;
            $scope.BillingHeadDetail.BillingHeadAddLess = item.BillingHeadAddLessText;
            $scope.BillingHeadDetail.AcLedgerID = item.AcLedgerID;
            $scope.BillingHeadDetail.TransactionID = $scope.Purchase.PurchaseID;
            $scope.BillingHeadDetail.TransactionPlace = $scope.Purchase.TransactionPlace;

            $scope.populateBillingHeadTax();
        }
        else if ($scope.popupFor == 'TaxCode') {

            $scope.BillingHeadDetail.TaxCode = item.TaxCode;
            $scope.BillingHeadDetail.TaxID = item.TaxID;

        }

        $('#dvPurchaseCommonPopup').modal('hide');
    };
    //#endregion - Purchase Common Popup


    //Methods//
    $scope.onLoad = function () {
        ////Add to series
        $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetEntryNo?TransactionType=' + $scope.PurchaseDetail.TransactionType).then(function (resp) {
            if (resp) {              
                $scope.populateEntryNo(resp);
                $scope.populateCarreir();
            }
        });

        $q.all(requestPromise).then(function (data) {
            if ($routeParams.PurchaseID != null) {           
                $scope.Purchase.PurchaseID = $routeParams.PurchaseID;
                $scope.populateReturnTransaction($routeParams.PurchaseID);
                $scope.PopulateDetailsGrid($routeParams.PurchaseID);
                $scope.populateBillingHeadDetails(4, $routeParams.PurchaseID);
                $scope.Purchase.IsEdit = 1;
                // $scope.isDisabledInvoice = true;
                $scope.Purchase.ShippingAndAdjustment = 2;

            } else {
                $scope.Purchase.IsEdit = 0;
            }

        });



    }    
    $scope.populateEntryNo = function (resp) {
        var response = resp.data;
        $scope.seriesCollection = response;      
    };
    ///////
    //$scope.seriesNo_OnChange = function (item) {
       
    //    $scope.Purchase.EntryNo = item.EntryNo;
    //    $scope.Purchase.LocationID = item.LocationID;

    //    $scope.Purchase.SeriesID = item.SeriesID;
    //    $scope.Purchase.Series = item.Series;

    //    $scope.PurchaseDetail.LocationID = item.LocationID;
    //};

    $scope.seriesNo_OnChange = function (EntryNoModel) {     
        var selectedValue = EntN.value;
        $scope.FilterEntryNoModel = $filter('filter')(EntryNoModel, { 'SeriesID': selectedValue });
        $scope.Purchase.EntryNo = $scope.FilterEntryNoModel[0].EntryNo;   
        $scope.Purchase.LocationID = $scope.FilterEntryNoModel[0].LocationID;
        $scope.Purchase.SeriesID = $scope.FilterEntryNoModel[0].SeriesID;
        $scope.Purchase.Series = $scope.FilterEntryNoModel[0].Series;
        $scope.PurchaseDetail.LocationID = $scope.FilterEntryNoModel[0].LocationID;
    }





  //////
    $scope.populateCarreir = function () {
        $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetCarrier').then(function (resp) {
            if (resp) {
                var response = resp.data;
                $scope.carrierCollection = response;

            }
        });

    }

    $scope.populateBillingHead = function () {
        $http.get(retailConstant.serviceBaseUrl + '/Purchase/BillingHead').then(function (resp) {
         
            if (resp) {
                var response = resp.data;             
                $scope.billingHeadCollection = response;
            }
        });

    }

    $scope.populateBillingHeadTax = function () {
        var tempTransactionPlace = $scope.Purchase.TransactionPlace;
        var tempTransactionType = $scope.PurchaseDetail.TransactionType;
        $http.get(retailConstant.serviceBaseUrl + '/Purchase/BillingHeadTax?TransactionPlace=' + tempTransactionPlace +'&TransactionType=' + tempTransactionType).then(function (resp) {

            if (resp) {
                var response = resp.data;
                $scope.billingHeadTaxCollection = response;

            }
        });

    }
    //TODO:
    $scope.populateBillingHeadDetails = function (tempTransactionType, tempTransactionID) {   
    
        $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetBillingHeadDetail?TransactionType=' + tempTransactionType + '&TransactionID=' + tempTransactionID).then(function (resp) {
            if (resp) {
                var response = resp.data;
                $scope.billingHeadDtlsCollection = response;
            }
        });

    }
    $scope.deleteBillingHeadDetails = function (billingHeadDtls, BillingHeadDetailID) {

        if (confirm("Are you sure to delete this item?")) {
            var index = $scope.billingHeadDtlsCollection.indexOf(billingHeadDtls);

            $http.post(retailConstant.serviceBaseUrl + '/Purchase/DeleteBillingHead?BillingHeadDetailID=' + BillingHeadDetailID)
            .then(function (resp) {
                $scope.billingHeadDtlsCollection.splice(index, 1);
                alert("Billing head deleted successfully!!!");
            }, function () { alert('Error in getting records'); })
        }
    };
    
    $scope.editbillingHeadDtls = function (item) {     
        console.log(item);
        $scope.BillingHeadDetail.BillingHeadAmt = item.BillingHeadID;
        $scope.BillingHeadDetail.BillingHeadAmt = item.BillingHeadAmt; 

    }
        
   
    
    //////Add OR insert Transaction //////

    $scope.addProduct_onClick = function () {     

        var postPurchaseModel = angular.copy($scope.Purchase);
        postPurchaseModel.PurchaseDetail = $scope.PurchaseDetail;
     
        $http.post(retailConstant.serviceBaseUrl + '/Purchase/SavePurchase', JSON.stringify(postPurchaseModel)).then(function (httpResponse) {
            var response = httpResponse.data;

     
            if (response.Status == 1) {
                if ($scope.Purchase.PurchaseID == 0) {
                    $scope.Purchase.PurchaseID = response.Data;
                    $scope.PopulateDetailsGrid(response.Data);
                    $scope.populateCalAdjTransaction(response.Data);
                    $scope.ClearPurchaseDetailsFeild();
                    $scope.Purchase.ShippingAndAdjustment = 2;
                   
                }
                else {
                    $scope.PopulateDetailsGrid($scope.Purchase.PurchaseID);
                    $scope.populateCalAdjTransaction($scope.Purchase.PurchaseID);
                    $scope.ClearPurchaseDetailsFeild();
                }
            }

            alert(response.Message);
        });
    }

    
    //ToDo billing test:
    $scope.billingHeadDetailInsert_onClick = function () {

        $scope.BillingHeadDetail.SeriesID = $scope.Purchase.SeriesID;
        $scope.BillingHeadDetail.TransactionType = 4;
        $scope.BillingHeadDetail.TransactionID = $routeParams.PurchaseID;
        $scope.BillingHeadDetail.TransactionPlace = $scope.Purchase.TransactionPlace;

        var postBillingHeadDetailModel = angular.copy($scope.BillingHeadDetail);

        $http.post(retailConstant.serviceBaseUrl + '/Purchase/SaveBillingHead', JSON.stringify(postBillingHeadDetailModel)).then(function (httpResponse) {
            var response = httpResponse.data;
            if (response.Status == 1) {             
                $scope.populateBillingHeadDetails(4, $routeParams.PurchaseID);
                $scope.ClearBillingHead();
            }

        })
    }
    $scope.ClearBillingHead = function () {       

        $scope.BillingHeadDetail.BillingHeadRemark = '';
        $scope.BillingHeadDetail.BillingHeadAddLess = '';
        $scope.BillingHeadDetail.BillingHeadAmt = '';     
        $scope.BillingHeadDetail.TaxableAmount = '';
        $scope.BillingHeadDetail.TaxAddLess = '';
        $scope.BillingHeadDetail.TaxRemarks = ''
        $scope.BillingHeadDetail.BillingHead = '';
        $scope.BillingHeadDetail.TaxID = '';
    }

    $scope.editProduct = function (item) {

        $scope.itemvalue = item;
        console.log(item);
        
        $scope.PurchaseDetail.ProductID = item.ProductID;
        $scope.PurchaseDetail.ProductName = item.ProductName;
        $scope.PurchaseDetail.Qty = item.Quantity;
        $scope.PurchaseDetail.BillingUnitName = item.Unit;
        $scope.PurchaseDetail.Rate = item.Rate;
        $scope.PurchaseDetail.GrossAmount = item.GrossAmount;
        $scope.PurchaseDetail.LotDisc = item.LotDisc;
        $scope.PurchaseDetail.LotDiscType = item.LotDiscType;
        $scope.PurchaseDetail.LotDiscAmount = item.LotDiscAmount;
        $scope.PurchaseDetail.LotRemarks = item.LotRemarks;
        $scope.PurchaseDetail.SchemeDisc = item.SchemeDisc;
        $scope.PurchaseDetail.SchemeDiscType = item.SchemeDiscType;
        $scope.PurchaseDetail.SchemeDisc = item.SchemeDiscAmount;
        $scope.PurchaseDetail.SchemeRemark = item.SchemeRemark;
        $scope.PurchaseDetail.TradeDisc = item.TradeDisc;
        $scope.PurchaseDetail.TradeDiscType = item.TradeDiscType;
        $scope.PurchaseDetail.TradeDiscAmount = item.TradeDiscAmount;
        $scope.PurchaseDetail.TradeDiscRemark = item.TradeDiscRemark;
        $scope.PurchaseDetail.FreeQty = item.FreeQty;
        $scope.PurchaseDetail.FreeQtyUnit = item.FreeQtyUnit;
        $scope.PurchaseDetail.FreeQtyRemark = item.FreeQtyRemark;
        $scope.PurchaseDetail.ManufacturingDate = item.ManufacturingDate;
        $scope.PurchaseDetail.ExpiryDate = item.ExpiryDate;
        $scope.PurchaseDetail.BatchCode = item.BatchCode;
        $scope.PurchaseDetail.LotNo = item.LotNo;
        $scope.PurchaseDetail.Manufacturer = item.Manufacturer;
        $scope.PurchaseDetail.Remarks = item.Remarks;

    }

      
    
    //////Add OR insert Transaction //////

    $scope.moveToChallan_onClick = function () {

        var postPurchaseModel = angular.copy($scope.Purchase);

        $http.post(retailConstant.serviceBaseUrl + '/Purchase/MoveToChallan', JSON.stringify(postPurchaseModel)).then(function (httpResponse) {
            var response = httpResponse.data;

          
            if (response.Status == 1) {
               
            }

            alert(response.Message);
        });
    }
    $scope.moveToInvoice_onClick = function () {

        var postPurchaseModel = angular.copy($scope.Purchase);

        $http.post(retailConstant.serviceBaseUrl + '/Purchase/MoveToInvoice', JSON.stringify(postPurchaseModel)).then(function (httpResponse) {
            var response = httpResponse.data;

          
            if (response.Status == 1) {
             
            }

            alert(response.Message);
        });
    }

    $scope.carrier_OnChange = function (item) {    
        $scope.Purchase.CarrierID = item.CarrierID;
      
    };

    $scope.billingHead_OnChange = function (item) {     
        var billingHead = item.BillingFields;
        var arrayHead = billingHead.split('|');

        var BillingHeadID = arrayHead[0];
        var BillingHead = arrayHead[1];
        var BillingHeadAddLess = arrayHead[2];
        var AcLedgerID = arrayHead[3];

        $scope.BillingHeadDetail.BillingHeadID = BillingHeadID;
        $scope.BillingHeadDetail.BillingHead = BillingHeadID;
        $scope.BillingHeadDetail.BillingHeadAddLess = BillingHeadID;
        $scope.BillingHeadDetail.AcLedgerID = BillingHeadID;

        $scope.populateBillingHeadTax();
    };

    $scope.taxCode_OnChange = function (item) {
        var taxID = item.TaxID;
       
        $scope.BillingHeadDetail.taxID = taxID;
    };
   
    $scope.callMoveToChallan = function () {
        var val = $scope.Purchase.OrderNosection;
        var tStatus = parseFloat($scope.Purchase.TransactionStatus || 0);
        var tPID = parseFloat($scope.Purchase.PurchaseID || 0);
       
        if (val == '1' && tStatus != 2 && tPID > 0 && tStatus != 5)
            return true;
        else
            return false;
    };

    $scope.callMoveToInVoice = function () {      


        var val = $scope.Purchase.OrderNosection;
        var tStatus = parseFloat($scope.Purchase.TransactionStatus || 0);
        var tPID = parseFloat($scope.Purchase.PurchaseID || 0);

        if ((val == '1' || val == '2') && tStatus != 3 && tPID > 0 && tStatus != 5)
            return true;
        else
            return false;
    };

    $scope.PopulateDetailsGrid = function (PurchaseID) {
        $http.get(retailConstant.serviceBaseUrl + '/Purchase/PurchaseDetailsPopulateAllGrid?PurchaseID=' + PurchaseID).then(function (resp) {
            if (resp) {
                var response = resp.data;
                var len = resp.data.length;
                for (i = 0 ; i <= len ; i++) {
                    $scope.parseJsonDate(resp.data[i]);
                }
               
                $scope.purchaseDetailsCollection = resp.data;               
              
            }

        });

    }

    $scope.populateCalAdjTransaction = function (PurchaseID) {
        $http.get(retailConstant.serviceBaseUrl + '/Purchase/PurchaseTransactionCalAdj?PurchaseID=' + PurchaseID).then(function (resp) {
            if (resp) {
                var response = resp.data;              
                $scope.Purchase.TotalGrossAmountWithTax = response[0].TotalGrossAmountWithTax;
               // $scope.Purchase.TotalAmountAfterAdjustments = response[0].TotalAmountAfterAdjustments;
                $scope.Purchase.CashDiscAmount = response[0].CashDiscAmount;
                $scope.Purchase.TotalTaxAmount = response[0].TotalTaxAmount;
                $scope.Purchase.CashDisc = response[0].CashDisc;
                $scope.Purchase.CashDiscType = response[0].CashDiscType;
                $scope.Purchase.CashDiscAmount = response[0].CashDiscAmount;
                $scope.Purchase.RoundOff = response[0].RoundOff;
                $scope.Purchase.FinalNetAmountWithShipping = response[0].FinalNetAmountWithShipping;
                $scope.Purchase.BillingTotal = response[0].BillingTotal;
                $scope.Purchase.RCM = response[0].RCM;
                $scope.Purchase.CheckStatus = response[0].CheckStatus;
                $scope.Purchase.CheckedByMemberID = response[0].CheckedByMemberID;



                $scope.Purchase.TotalDiscounts = response[0].TotalDiscounts;


                $scope.Purchase.TotalTaxableAmount = response[0].TotalTaxableAmount;
                $scope.Purchase.TotalAmountAfterAdjustments = response[0].TotalAmountAfterAdjustments;

                $scope.Purchase.TotalAmountAfterCashDiscount = response[0].TotalAmountAfterCashDiscount;
                $scope.Purchase.TransactionStatus = response[0].TransactionStatus;

                
            }
        });

    }


    $scope.ClearPurchaseDetailsFeild = function () {
        $scope.PurchaseDetail.ProductName = '';
        $scope.PurchaseDetail.Qty = '';
        $scope.PurchaseDetail.Unit = '';
        $scope.PurchaseDetail.Rate = '';
        $scope.PurchaseDetail.GrossAmount = '';      
        $scope.PurchaseDetail.ManufacturingDate = '';
        $scope.PurchaseDetail.ExpiryDate = '';
        $scope.PurchaseDetail.BatchCode = '';
       // $scope.PurchaseDetail.BarCode = '';
        $scope.PurchaseDetail.LotNo = '';
        $scope.PurchaseDetail.ShelfNo = '';
        $scope.PurchaseDetail.Manufacturer = '';
        $scope.PurchaseDetail.Remarks = '';
        $scope.PurchaseDetail.ReturnAdjustmentAmount = '';
        $scope.PurchaseDetail.ReturnAdjustmentAddLess = '';
        $scope.PurchaseDetail.ReturnType = '';
        $scope.PurchaseDetail.ReturnAdjustmentRemarks = '';
       

    }

    $scope.ClearPurchaseTransFeild = function () {
        $scope.Purchase.Vendor = '';
        $scope.Purchase.GSTNo = '';
        $scope.Purchase.CreditDays = '';
        $scope.Purchase.BalanceAmount = '';
        $scope.Purchase.Address = '';
        $scope.Purchase.Referrer = '';
        $scope.Purchase.PriceDiscRefName = '';
        $scope.Purchase.selectedSeries = '';
        $scope.Purchase.EntryNo = '';
        $scope.Purchase.EntryDate = '';
        $scope.Purchase.ReferenceNo = '';
        $scope.Purchase.ReferenceDate = '';
        $scope.Purchase.TransactionPlace = '';
        $scope.Purchase.TotalGrossAmountWithTax = '';
        $scope.Purchase.TotalAmountAfterAdjustments = '';
        $scope.Purchase.CashDiscAmount = '';
        $scope.Purchase.TotalTaxAmount = '';
        $scope.Purchase.CashDisc = '';
        $scope.Purchase.CashDiscType = '';
        $scope.Purchase.CashDiscAmount = '';
       // $scope.Purchase.RoundOff = '';
        $scope.Purchase.TotalNetAmountWithoutShipping = '';
        $scope.Purchase.FinalNetAmountWithShipping = '';
       // $scope.Purchase.BillingTotal = '';
        $scope.Purchase.RCM = '';
      //  $scope.Purchase.CheckStatus = '';
        $scope.Purchase.FinalNetAmountWithShipping = '';
      
    };

    $scope.CalTotal = function () {
        if ($scope.PurchaseDetail.Qty || $scope.PurchaseDetail.Rate != null) {

            var total = ($scope.PurchaseDetail.Qty * $scope.PurchaseDetail.Rate)
            $scope.PurchaseDetail.GrossAmount = total;
        } else {
            $scope.PurchaseDetail.GrossAmount = '';
        }
        
    };
    $scope.autoGenerateBarCode = function () {
        $scope.PurchaseDetail.BarCode = 111;//value to be set
       // $scope.PurchaseDetail.ShelfNo = 222;//value to be set
    };

    $scope.closeShippingPopup_onClick = function () {

       // var temp = ($scope.Purchase.TotalAmountAfterAdjustments - $scope.Purchase.CashDiscAmount);  
        //$scope.Purchase.TotalAmountAfterCashDiscount = temp;
        //$scope.Purchase.TotalNetAmountWithoutShipping = (($scope.Purchase.TotalAmountAfterAdjustments - $scope.Purchase.CashDiscAmount) + $scope.Purchase.RoundOff)

       // $scope.Purchase.FinalNetAmountWithShipping = ( (( {{$scope.Purchase.TotalAmountAfterAdjustments}} - $scope.Purchase.CashDiscAmount) + $scope.Purchase.RoundOff) + $scope.Purchase.FreightAmt)
   
        var total = ((parseFloat($scope.Purchase.TotalAmountAfterAdjustments || 0) - parseFloat($scope.Purchase.CashDiscAmount || 0)) + parseFloat($scope.Purchase.FreightAmt || 0)) + parseFloat($scope.Purchase.RoundOff || 0)

        //////////var rtrr= parseFloat($scope.Purchase.FreightAmt || 0)


        //////////var rr = rtrr.split('.')[1];
        //////////var ss = rr;
        //////////alert(ss);

        $scope.Purchase.FinalNetAmountWithShipping = total;
    
    }
    $scope.calRoundOff = function () {
        var tempRoundOff = parseFloat($scope.Purchase.RoundOff || 0)
        var tempCashDiscAmount = parseFloat($scope.Purchase.CashDiscAmount || 0)
        var tempFreightAmt = parseFloat($scope.Purchase.FreightAmt || 0)
        var totalAmtAftAdj = parseFloat($scope.Purchase.TotalAmountAfterAdjustments || 0)

        var tempFinal = (((totalAmtAftAdj - tempCashDiscAmount) + tempFreightAmt) + tempRoundOff)

        $scope.Purchase.FinalNetAmountWithShipping = tempFinal
    }

    $scope.calCashDisType = function (val) {
        var cashDisCount = parseFloat($scope.Purchase.CashDisc|| 0);
        var totalTaxableAmt = parseFloat($scope.Purchase.TotalTaxableAmount|| 0)
        var totalAmtAftAdj =parseFloat($scope.Purchase.TotalAmountAfterAdjustments|| 0)



        if (val == "1") {

            $scope.Purchase.CashDiscAmount = cashDisCount
          
            var temp = (totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0));
            $scope.Purchase.TotalAmountAfterCashDiscount = temp;
            $scope.Purchase.TotalNetAmountWithoutShipping = ((totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0)))
         
            $scope.Purchase.FinalNetAmountWithShipping = (((totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0)) + parseFloat($scope.Purchase.FreightAmt || 0)) + parseFloat($scope.Purchase.RoundOff || 0))
        }
        if (val == "2") {

            $scope.Purchase.CashDiscAmount = (cashDisCount / 100) * totalTaxableAmt  

            var temp = (totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0));
            $scope.Purchase.TotalAmountAfterCashDiscount = temp;
            $scope.Purchase.TotalNetAmountWithoutShipping = ((totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0)))

            $scope.Purchase.FinalNetAmountWithShipping = (((totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0)) + parseFloat($scope.Purchase.FreightAmt || 0)) + parseFloat($scope.Purchase.RoundOff || 0))



        }
        if (val == "3") {

            $scope.Purchase.CashDiscAmount = (cashDisCount / 100) * totalAmtAftAdj
         
            var temp = (totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0));
            $scope.Purchase.TotalAmountAfterCashDiscount = temp;
            $scope.Purchase.TotalNetAmountWithoutShipping = ((totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0)))

            $scope.Purchase.FinalNetAmountWithShipping = (((totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0)) + parseFloat($scope.Purchase.FreightAmt || 0)) + parseFloat($scope.Purchase.RoundOff || 0))

        }

    }
    $scope.calculateDiscount = function (val,type) {

        var grossAmt = $scope.PurchaseDetail.GrossAmount
     
      
        if (type == "Lot") {
      
            if (val == "1") {               
                $scope.PurchaseDetail.LotDiscAmount = $scope.PurchaseDetail.LotDisc
            }
            if (val == "2") {
                var lotDis = $scope.PurchaseDetail.LotDisc;
                $scope.PurchaseDetail.LotDiscAmount = (lotDis / 100) * grossAmt
            } 
            if (val == "") {
                $scope.PurchaseDetail.LotDiscAmount = '';
            }        
        }
        else if (type == "Scheme") {
            if (val == "1") { 
                $scope.PurchaseDetail.SchemeDiscAmount = $scope.PurchaseDetail.SchemeDisc;                
            }
            if (val == "2") {
                var SchDis = $scope.PurchaseDetail.SchemeDisc;
                $scope.PurchaseDetail.SchemeDiscAmount = (SchDis / 100) * grossAmt
            }
            if (val == "")
            {
                $scope.PurchaseDetail.SchemeDiscAmount = '';
            }

        } else if (type == "Trade") {
            if (val == "1") { 
                $scope.PurchaseDetail.TradeDiscAmount = $scope.PurchaseDetail.TradeDisc;
            }
            if (val == "2") { 
                var TradeDis = $scope.PurchaseDetail.TradeDisc;
                $scope.PurchaseDetail.TradeDiscAmount = (TradeDis / 100) * grossAmt
            } 
            if (val == "")
            {
                $scope.PurchaseDetail.TradeDiscAmount = '';
            }

        }

     
    };
       //Methods//
    $scope.onLoad();
    $scope.autoGenerateBarCode();
    $scope.populateBillingHead();  


    /////////////////////  Purchase Return ////////////////////////     


    $scope.PopulateReturnConvert = function (PurchaseID) {
        $http.post(retailConstant.serviceBaseUrl + '/Purchase/PurchaseReturnConvert?PurchaseID=' + PurchaseID).then(function (resp) {
            if (resp) {
                var response = resp.data;
                if (response.Status == 1) {
                                  
                    $scope.Purchase.PurchaseID = response.Data;
                    $scope.PopulateReturnDetails(response.Data);
                    $scope.populateReturnTransaction(response.Data);
                    $scope.populateBillingHeadDetails(4, response.Data);
                    $scope.isDisabledInvoice = true;
                    $scope.Purchase.ShippingAndAdjustment = 2;
                }
            }
        });
    }

    $scope.PopulateReturnDetails = function (PurchaseID) {
        $http.get(retailConstant.serviceBaseUrl + '/Purchase/PurchaseReturnTransactionPopulateAllGrid?PurchaseID=' + PurchaseID).then(function (resp) {
            if (resp) {
                var response = resp.data;
                var len = resp.data.length;
                for (i = 0 ; i <= len ; i++) {
                    $scope.parseJsonDate(resp.data[i]);
                }

                $scope.purchaseDetailsCollection = resp.data;

            }

        });

    }

    $scope.populateReturnTransaction = function (PurchaseID) {
        $http.get(retailConstant.serviceBaseUrl + '/Purchase/PurchaseTransactionCalAdj?PurchaseID=' + PurchaseID).then(function (resp) {
            if (resp) { 
                var len = resp.data.length;
                for (i = 0 ; i <= len ; i++) {
                    $scope.parseJsonDate(resp.data[i]);
                }               
                var response = resp.data;
                console.log(response);
                $scope.Purchase.TotalGrossAmountWithTax = response[0].TotalGrossAmountWithTax;              
                $scope.Purchase.CashDiscAmount = response[0].CashDiscAmount;
                $scope.Purchase.TotalTaxAmount = response[0].TotalTaxAmount;
                $scope.Purchase.CashDisc = response[0].CashDisc;
                $scope.Purchase.CashDiscType = response[0].CashDiscType;               
                $scope.Purchase.RoundOff = response[0].RoundOff;
                $scope.Purchase.FinalNetAmountWithShipping = response[0].FinalNetAmountWithShipping;
                $scope.Purchase.BillingTotal = response[0].BillingTotal;
                $scope.Purchase.RCM = response[0].RCM;
                $scope.Purchase.CheckStatus = response[0].CheckStatus;
                $scope.Purchase.CheckedByMemberID = response[0].CheckedByMemberID;
                $scope.Purchase.TotalDiscounts = response[0].TotalDiscounts;
                $scope.Purchase.TotalTaxableAmount = response[0].TotalTaxableAmount;
                $scope.Purchase.TotalAmountAfterAdjustments = response[0].TotalAmountAfterAdjustments;
                $scope.Purchase.TotalAmountAfterCashDiscount = response[0].TotalAmountAfterCashDiscount;
                $scope.Purchase.TransactionStatus = response[0].TransactionStatus;
                $scope.Purchase.Vendor = response[0].Vendor;
                $scope.Purchase.VendorID = response[0].VendorID;
                $scope.Purchase.VendorGSTNo = response[0].VendorGSTNo;
                $scope.Purchase.CreditDays = response[0].CreditDays;
                $scope.Purchase.BalanceAmount = response[0].BalanceAmount;
                $scope.Purchase.Address = response[0].Address;
                $scope.Purchase.Referrer = response[0].Referrer;
                $scope.Purchase.PriceDiscRefName = response[0].PriceDiscReferrer;
                $scope.Purchase.SeriesID = response[0].SeriesID;
                $scope.Purchase.ReferrerID = response[0].ReferrerID;
                $scope.Purchase.PriceDiscRefID = response[0].PriceDiscRefID;
                $scope.Purchase.Series = response[0].Series;
                $scope.Purchase.ReferenceNo = response[0].ReferenceNo;
                $scope.Purchase.ReferenceDate = response[0].ReferenceDate;
                $scope.Purchase.TransactionPlace = response[0].TransactionPlace;                  
                $scope.PurchaseDetail.CheckStatus = response[0].CheckStatus;                
                $scope.Purchase.SeriesID = response[0].SeriesID;
                $scope.Purchase.EntryNo = response[0].EntryNo;
                $scope.Purchase.EntryDate = response[0].EntryDate;
                $scope.Purchase.LocationID = response[0].LocationID;
                $scope.Purchase.LRNo = response[0].LRNo;
                $scope.Purchase.LRDate = response[0].LRDate;
                $scope.Purchase.FreightType = response[0].FreightType;
                $scope.Purchase.FreightAmt = response[0].FreightAmt;
                $scope.Purchase.RoadPermitNo = response[0].RoadPermitNo;
                $scope.Purchase.CarrierID = response[0].CarrierID;
                $scope.Purchase.NoOfCases = response[0].NoOfCases;
                $scope.Purchase.DeliveryDate = response[0].DeliveryDate;
                $scope.Purchase.returnReferenceInvoiceID = response[0].returnReferenceInvoiceID;
                $scope.Purchase.returnReferenceInvoiceSeriesID = response[0].returnReferenceInvoiceSeriesID;
                $scope.Purchase.returnReferenceInvoiceSeries = response[0].returnReferenceInvoiceSeries;
                $scope.Purchase.returnReferenceInvoiceEntryNo = response[0].returnReferenceInvoiceEntryNo;
                $scope.Purchase.returnReferenceInvoiceEntryDate = response[0].returnReferenceInvoiceEntryDate;
             

            }
        });
    }

    $scope.searchInvoice = function (Keywords) {
        if (Keywords.length > 2) {
            $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetPurchaseReturnReference?searchKeyword=' + Keywords).then(function (resp) {
                if (resp.data.length > 0) {                
                    var len = resp.data.length;
                    for (i = 0 ; i <= len ; i++) {
                        $scope.parseJsonDate(resp.data[i]);
                    } 

                    $scope.InvoiceNoArray = resp.data || [];
                }
            });
        }

    }   

    $scope.PurchaseReturnDetailInsertClick = function () {

        if ($scope.PurchaseDetail.ProductName != undefined) {

            var postPurchaseModel = angular.copy($scope.Purchase);
            postPurchaseModel.PurchaseDetail = $scope.PurchaseDetail;

            $http.post(retailConstant.serviceBaseUrl + '/Purchase/PurchaseReturnDetailsInsert', JSON.stringify(postPurchaseModel)).then(function (httpResponse) {
                var response = httpResponse.data;

                if (response.Status == 1) {
                    $scope.PopulateReturnDetails($scope.Purchase.PurchaseID);
                    $scope.populateReturnTransaction($scope.Purchase.PurchaseID);
                    $scope.ClearPurchaseDetailsFeild();
                    $scope.isDisabledInvoice = true;
                }

                alert(response.Message);
            });
        } else {
            alert('Please edit the product');
        }
    }

    $scope.PurchaseReturnConfirmationClick = function () {

        var postPurchaseModel = angular.copy($scope.Purchase);
        postPurchaseModel.PurchaseDetail = $scope.PurchaseDetail;

        $http.post(retailConstant.serviceBaseUrl + '/Purchase/PurchaseReturnConfirmationClick', JSON.stringify(postPurchaseModel)).then(function (httpResponse) {
            var response = httpResponse.data;       
            if (response.Status == 1) {
                $scope.Purchase.PurchaseID
                $scope.PopulateReturnDetails($scope.Purchase.PurchaseID);
                $scope.populateReturnTransaction($scope.Purchase.PurchaseID);
                // $scope.ClearPurchaseDetailsFeild();
                //  $scope.ClearPurchaseTransFeild();
                $scope.isDisabledInvoice = true;

            }

            alert(response.Message);
        });
    }

    $scope.savePurchaseReturnOnClick = function () {

        var postPurchaseModel = angular.copy($scope.Purchase);
        postPurchaseModel.PurchaseDetail = $scope.PurchaseDetail;

        $http.post(retailConstant.serviceBaseUrl + '/Purchase/PurchaseReturnTransactionUpdate', JSON.stringify(postPurchaseModel)).then(function (httpResponse) {
            var response = httpResponse.data;

            if (response.Status == 1) {
                $scope.isDisabledInvoice = true;
            }

            alert(response.Message);
        });
    }

    $scope.deletePurchaseReturn = function (item) {
        if (confirm("Are you sure to delete this item?")) {

            var index = $scope.purchaseDetailsCollection.indexOf(item);
            var PurchaseDetailID = item.PurchaseDetailID;
            var LocationID = $scope.Purchase.LocationID;
            var TransactionType = 4;
            //  var CheckStatus = $scope.Purchase.CheckStatus;
            var CheckStatus = 1;
            $http.post(retailConstant.serviceBaseUrl + '/Purchase/DeletePurchaseDetails?PurchaseDetailID=' + PurchaseDetailID + '&LocationID=' + LocationID + '&TransactionType=' + TransactionType + '&CheckStatus=' + CheckStatus)
            .then(function (resp) {

                $scope.purchaseDetailsCollection.splice(index, 1);
                alert("Purchase details deleted successfully!!!");
            }, function () { alert('Error in getting records'); })

        }
    }

    $scope.billingHeadDetailSave_onClick = function () {
        $scope.populateCalAdjTransaction($scope.Purchase.PurchaseID);
    }
    /////////////////////  Purchase Return ////////////////////////

  
})



