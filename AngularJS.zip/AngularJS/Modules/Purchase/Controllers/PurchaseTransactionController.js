﻿var retailPurchaseApp = angular.module('Retail');


retailPurchaseApp.controller('purchaseTransactionCtrl', function ($scope, $q, $filter, $http, $routeParams, $location, retailConstant) {

    $scope.Purchase = { PurchaseID: 0 };//PurchaseMaster
    $scope.PurchaseDetail = { PurchaseDetailID: 0, CheckStatus: '1' };//PurchaseDetail
    $scope.purchaseDetailsCollection = {};
    $scope.VendorArray = [];
    $scope.ReferrerArray = [];
    $scope.ProductArray = [];  
    $scope.Purchase.OrderNosection = $routeParams.Type;
    var requestPromise = [];

    $scope.Purchase.ShippingAndAdjustment = 1;

    $scope.challanButton = false;
    $scope.invoiceButton = false;

    var PurchaseIDForEdit = '';  
    if ($routeParams.PurchaseID == undefined) {
        PurchaseIDForEdit = 0;
    } else {
        PurchaseIDForEdit = $routeParams.PurchaseID;
    }
  

    $scope.Purchase.CheckStatus = 1;


    $scope.PurchaseDetail.TransactionType = $routeParams.Type;
    $scope.BillingHeadDetail = {}      
    $scope.checkList =
       [
           { CheckStatus: "0", StatusName: "Select Check Status" },
           { CheckStatus: "1", StatusName: "Draft" },
           { CheckStatus: "2", StatusName: "Checked" }
       ]; 
   
    $scope.FreightTypeCollection =
      [
          { FreightType: "-1", FreightTypeName: "Select Freight Type" },
          { FreightType: "1", FreightTypeName: "FOB to Pay" },
          { FreightType: "2", FreightTypeName: "FOB Paid (Add)" },
          { FreightType: "3", FreightTypeName: "FOR to Pay (Less)" },
          { FreightType: "4", FreightTypeName: "FOR Paid" }
      ];


    $scope.CashDiscTypeCollectionPur =
     [
         { CashDiscType: "-1", CashDiscTypeName: "Select" },
         { CashDiscType: "1", CashDiscTypeName: "Flat Rate" },
         { CashDiscType: "2", CashDiscTypeName: "% on Taxable Amount" },
        { CashDiscType: "3", CashDiscTypeName: "% on Net Amount (before Cash Discount)" }

     ];

    $scope.Purchase.FreightType = '-1';

    $scope.moveToInvoice = "Move To Invoice";
    $scope.moveToChallan = "Move To Challan";

    $scope.parseJsonDate = function (model) {
        // date format - /Date(1507573800000)/
        for (var property in model) {
            if (model.hasOwnProperty(property) && property.indexOf('Date') > -1) {
                var jsonDateString = model[property] || '';
                if (jsonDateString.length > 0) {
                    var date = new Date(parseInt(jsonDateString.substr(6)));
                    model[property] = $filter('date')(date, "dd/MM/yyyy");;
                }
            }
        }
    }
 
    //#region - Purchase Common Popup
    $scope.purchaseCommonPopupSelectedItem = undefined;
    $scope.purchaseCommonPopupCombinedPromise = undefined;
    $scope.popupFor = undefined;
    $scope.purchaseCommonPopupSearch = '';
    $scope.showPurchaseCommonPopup = function (popupFor) {
        
        $scope.purchaseCommonPopupCombinedPromise = undefined;
        $scope.popupFor = popupFor;

        //Prepare Promise
        var popupDataPromise = undefined;
        if ($scope.popupFor == 'Vendor') {
            var locationId = $scope.Purchase.LocationID || 0;
            if (locationId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetVendor?LocationID=' + locationId);
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ Vendor: popupDataPromise });
            }
        } else if ($scope.popupFor == 'Referrer') {
            var vendorId = $scope.Purchase.VendorID || 0;
            if (vendorId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetReferrer?VendorID=' + vendorId);
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ Referrer: popupDataPromise });
            }
        } else if ($scope.popupFor == 'PriceDesc') {
            var vendorId = $scope.Purchase.VendorID || 0;
            if (vendorId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetReferrer?VendorID=' + vendorId);
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ Referrer: popupDataPromise });
            }
        } else if ($scope.popupFor == 'Product') {
            var vendorId = $scope.Purchase.VendorID || 0;
            var locationId = $scope.Purchase.LocationID || 0;
            if (vendorId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/Getproduct?LocationID=' + locationId);
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ Product: popupDataPromise });
            }
        } else if ($scope.popupFor == 'Billing') {
            var vendorId = $scope.Purchase.VendorID || 0;
            if (vendorId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/BillingHead');
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ BillingHead: popupDataPromise });
            } 
        } else if ($scope.popupFor == 'TaxCode') {
            var vendorId = $scope.Purchase.VendorID || 0;
            if (vendorId > 0) {
                var tempTransactionPlace = $scope.Purchase.TransactionPlace;
                var tempTransactionType = $scope.PurchaseDetail.TransactionType;
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/BillingHeadTax?TransactionPlace=' + tempTransactionPlace + '&TransactionType=' + tempTransactionType);
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ TaxCode: popupDataPromise });
            }
        }

        
        //TODO:
        //Service Call
        if ($scope.purchaseCommonPopupCombinedPromise != undefined) {
            $scope.purchaseCommonPopupCombinedPromise.then(function (responses) {
                if (responses.Vendor) {
                    $scope.VendorArray = responses.Vendor.data || [];
                } else if (responses.Referrer) {
                    $scope.ReferrerArray = responses.Referrer.data || [];
                } else if (responses.Referrer) {
                    $scope.ReferrerArray = responses.Referrer.data || [];
                } else if (responses.Product) {
                    $scope.ProductArray = responses.Product.data || [];
                } else if (responses.BillingHead) {
                    $scope.BillingHeadArray = responses.BillingHead.data || [];
                } else if (responses.TaxCode) {
                    $scope.BillingHeadArray = responses.TaxCode.data || [];
                }

                $('#dvPurchaseCommonPopup').modal('show');
            });
        }
    };
    $scope.purchaseCommonPopup_onSelect = function (item) {
        
        $scope.purchaseCommonPopupSelectedItem = item;

        if ($scope.popupFor == 'Vendor') {
            //Update Purchase model by Vendor details
            $scope.Purchase.Vendor = item.Vendor;
            $scope.Purchase.VendorID = item.VendorID;
            $scope.Purchase.VendorGSTNo = item.GSTNo;
            $scope.Purchase.CreditDays = item.CreditDays;
            $scope.Purchase.BalanceAmount = item.BalanceAmount;
            $scope.Purchase.Address = item.Address;
        } else if ($scope.popupFor == 'Referrer') {        
            //Update Purchase model by Referrer details
            $scope.Purchase.ReferrerID = item.ReferrerId;
            $scope.Purchase.Referrer = item.Referrer;
        } else if ($scope.popupFor == 'PriceDesc') {
            //Update Purchase model by Referrer details          
            $scope.Purchase.PriceDiscRefID = item.ReferrerId;
            $scope.Purchase.PriceDiscRefName = item.Referrer;
        } else if ($scope.popupFor == 'Product') {
            //Update Purchase model by Referrer details          
            $scope.PurchaseDetail.ProductName = item.ProductName;
            $scope.PurchaseDetail.ProductID = item.ProductID;
            $scope.PurchaseDetail.ProductCategoryID = item.ProductCategoryID;
            $scope.PurchaseDetail.BillingUnit1ID = item.PurchaseRateUnit;
            $scope.PurchaseDetail.BillingUnitName = item.PuschaseUnit;
            $scope.PurchaseDetail.MinStockOnTransDate = item.MinStock;
            $scope.PurchaseDetail.MaxStockOnTransDate = item.MaxStock;
            $scope.PurchaseDetail.DisplayUnit1 = item.DisplayUnit1;
            $scope.PurchaseDetail.DisplayUnit2 = item.DisplayUnit2;
            $scope.PurchaseDetail.DisplayUnit3 = item.DisplayUnit3;
            $scope.PurchaseDetail.PerUnit1Content = item.PerUnit1Content;
            $scope.PurchaseDetail.PerUnit2Content = item.PerUnit2Content;
            $scope.PurchaseDetail.ShelfNo = item.ShelfNo;
            $scope.PurchaseDetail.ShelfID = item.ShelfID;
            $scope.PurchaseDetail.MRP = item.MRP;
            $scope.PurchaseDetail.TradeRate = item.TradeRate; 
        } else if ($scope.popupFor == 'Billing') {

            $scope.BillingHeadDetail.BillingHeadID = item.BillingHeadID;
            $scope.BillingHeadDetail.BillingHead = item.BillingHead;
            $scope.BillingHeadDetail.BillingHeadAddLess = item.BillingHeadAddLessText;
            $scope.BillingHeadDetail.AcLedgerID = item.AcLedgerID; 
            $scope.BillingHeadDetail.TransactionID = $scope.Purchase.PurchaseID;
            $scope.BillingHeadDetail.TransactionPlace = $scope.Purchase.TransactionPlace;

            $scope.populateBillingHeadTax();
        }
        else if ($scope.popupFor == 'TaxCode') {

            $scope.BillingHeadDetail.TaxCode = item.TaxCode;
            $scope.BillingHeadDetail.TaxID = item.TaxID;
         
        }
        $('#dvPurchaseCommonPopup').modal('hide');
    };
    //#endregion - Purchase Common Popup


    //Methods//
    $scope.onLoad = function () {
        ////Add to series
        $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetEntryNo?TransactionType=' + $routeParams.Type).then(function (resp) {
            if (resp) {              
                $scope.populateEntryNo(resp);
                $scope.populateCarreir();
            }
        });

        $q.all(requestPromise).then(function (data) {
            if (PurchaseIDForEdit != null && PurchaseIDForEdit != 0) {
                $scope.Purchase.PurchaseID = PurchaseIDForEdit;             
                $scope.populateCalAdjTransaction(PurchaseIDForEdit);
                $scope.PopulateDetailsGrid(PurchaseIDForEdit);
                $scope.populateBillingHeadDetails($routeParams.Type, PurchaseIDForEdit);
                $scope.Purchase.IsEdit = 1;
                $scope.Purchase.ShippingAndAdjustment = 2;

            } else {
                $scope.Purchase.IsEdit = 0;
            }
        });

    }    
    $scope.populateEntryNo = function (resp) {
        var response = resp.data;
        $scope.seriesCollection = response;      
    };     
   
    $scope.seriesNo_OnChange = function (EntryNoModel) {
        var selectedValue = EntN.value;
        $scope.FilterEntryNoModel = $filter('filter')(EntryNoModel, { 'SeriesID': selectedValue });
        $scope.Purchase.EntryNo = $scope.FilterEntryNoModel[0].EntryNo;
        $scope.Purchase.LocationID = $scope.FilterEntryNoModel[0].LocationID;
        $scope.Purchase.SeriesID = $scope.FilterEntryNoModel[0].SeriesID;
        $scope.Purchase.Series = $scope.FilterEntryNoModel[0].Series;
        $scope.PurchaseDetail.LocationID = $scope.FilterEntryNoModel[0].LocationID;
    }
          
    $scope.populateCarreir = function () {
        $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetCarrier').then(function (resp) {
            if (resp) {
                var response = resp.data;
                $scope.carrierCollection = response;

            }
        });

    }
       
    $scope.populateBillingHeadTax = function () {
        var tempTransactionPlace = $scope.Purchase.TransactionPlace;
        var tempTransactionType = $scope.PurchaseDetail.TransactionType;
        $http.get(retailConstant.serviceBaseUrl + '/Purchase/BillingHeadTax?TransactionPlace=' + tempTransactionPlace +'&TransactionType=' + tempTransactionType).then(function (resp) {

            if (resp) {
                var response = resp.data;
                $scope.billingHeadTaxCollection = response;

            }
        });

    }
 
    $scope.populateBillingHeadDetails = function (tempTransactionType, tempTransactionID) {     
     //  var tempTransactionID = 1;
      //  var tempTransactionType = $scope.PurchaseDetail.TransactionType;
        $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetBillingHeadDetail?TransactionType=' + tempTransactionType + '&TransactionID=' + tempTransactionID).then(function (resp) {
            if (resp) {
                var response = resp.data;
                $scope.billingHeadDtlsCollection = response;
            }
        });

    }
    $scope.deleteBillingHeadDetails = function (billingHeadDtls, BillingHeadDetailID) {

        if (confirm("Are you sure to delete this item?")) {
            var index = $scope.billingHeadDtlsCollection.indexOf(billingHeadDtls);

            $http.post(retailConstant.serviceBaseUrl + '/Purchase/DeleteBillingHead?BillingHeadDetailID=' + BillingHeadDetailID)
            .then(function (resp) {
                $scope.billingHeadDtlsCollection.splice(index, 1);
                alert("Billing head deleted successfully!!!");
                $scope.billingHeadDetailClear();
            }, function () { alert('Error in getting records'); })
        }
    };
    
    $scope.editbillingHeadDtls = function (item) {     
        console.log(item);       


        $scope.BillingHeadDetail.AcLedgerID = item.AcLedgerID;
        $scope.BillingHeadDetail.BillingHeadDetailID = item.BillingHeadDetailID;
        $scope.BillingHeadDetail.BillingHeadID = item.BillingHeadID;
        $scope.BillingHeadDetail.BillingHead = item.BillingHead;
        $scope.BillingHeadDetail.BillingHeadAddLess = item.BillingHeadAddLess;
        $scope.BillingHeadDetail.BillingHeadAmt = item.BillingHeadAmt;
        $scope.BillingHeadDetail.BillingHeadRemark = item.BillingHeadRemark;
        $scope.BillingHeadDetail.TaxCode = item.TaxCode;
        $scope.BillingHeadDetail.TaxID = item.TaxID;
        $scope.BillingHeadDetail.TaxableAmount = item.TaxableAmount;
        $scope.BillingHeadDetail.TaxAddLess = item.TaxAddLess;
        $scope.BillingHeadDetail.TaxRemarks = item.TaxRemarks;
     

    }

    $scope.billingHeadDetailInsert_onClick = function () {

        $scope.BillingHeadDetail.SeriesID = $scope.Purchase.SeriesID;
        $scope.BillingHeadDetail.TransactionType = $routeParams.Type;
        $scope.BillingHeadDetail.TransactionID = $scope.Purchase.PurchaseID;
        $scope.BillingHeadDetail.TransactionPlace = $scope.Purchase.TransactionPlace;

        var postBillingHeadDetailModel = angular.copy($scope.BillingHeadDetail);

        $http.post(retailConstant.serviceBaseUrl + '/Purchase/SaveBillingHead', JSON.stringify(postBillingHeadDetailModel)).then(function (httpResponse) {
            var response = httpResponse.data;
            if (response.Status == 1) {
                $scope.populateBillingHeadDetails($scope.BillingHeadDetail.TransactionType, $scope.BillingHeadDetail.TransactionID);
                $scope.billingHeadDetailClear();
            }

        })
    }
    $scope.billingHeadDetailClear = function () {

        $scope.BillingHeadDetail.SeriesID = '';
        $scope.BillingHeadDetail.TransactionType = '';
        $scope.BillingHeadDetail.TransactionID = '';
        $scope.BillingHeadDetail.TransactionPlace = '';
        $scope.BillingHeadDetail.BillingHead = '';
        $scope.BillingHeadDetail.BillingHeadAmt = '';
        $scope.BillingHeadDetail.BillingHeadRemark = '';
        $scope.BillingHeadDetail.TaxableAmount = '';
        $scope.BillingHeadDetail.TaxCode = '';
        $scope.BillingHeadDetail.TaxAddLess = '';
        $scope.BillingHeadDetail.TaxRemarks = '';

    }
        
    $scope.editProduct = function (item) {

        $scope.itemvalue = item;
        console.log(item);
        
        $scope.PurchaseDetail.ProductID = item.ProductID;
        $scope.PurchaseDetail.ProductName = item.ProductName;
        $scope.PurchaseDetail.Qty = item.Quantity;
        $scope.PurchaseDetail.BillingUnitName = item.Unit;
        $scope.PurchaseDetail.Rate = item.Rate;
        $scope.PurchaseDetail.GrossAmount = item.GrossAmount;       
        $scope.PurchaseDetail.LotDisc = item.LotDisc;
        $scope.PurchaseDetail.LotDiscType = item.LotDiscType;
        $scope.PurchaseDetail.LotDiscAmount = item.LotDiscAmount;
        $scope.PurchaseDetail.LotRemarks = item.LotRemarks;
        $scope.PurchaseDetail.SchemeDisc = item.SchemeDisc;
        $scope.PurchaseDetail.SchemeDiscType = item.SchemeDiscType;
        $scope.PurchaseDetail.SchemeDiscAmount = item.SchemeDiscAmount;
        $scope.PurchaseDetail.SchemeRemark = item.SchemeRemark;
        $scope.PurchaseDetail.TradeDisc = item.TradeDisc;
        $scope.PurchaseDetail.TradeDiscType = item.TradeDiscType;
        $scope.PurchaseDetail.TradeDiscAmount = item.TradeDiscAmount;
        $scope.PurchaseDetail.TradeDiscRemark = item.TradeDiscRemark;
        $scope.PurchaseDetail.FreeQty = item.FreeQty;
        $scope.PurchaseDetail.FreeQtyUnit = item.FreeQtyUnit;
        $scope.PurchaseDetail.FreeQtyRemark = item.FreeQtyRemark;
        $scope.PurchaseDetail.ManufacturingDate = item.ManufacturingDate;
        $scope.PurchaseDetail.ExpiryDate = item.ExpiryDate;
        $scope.PurchaseDetail.BatchCode = item.BatchCode;
        $scope.PurchaseDetail.LotNo = item.LotNo;
        $scope.PurchaseDetail.Manufacturer = item.Manufacturer;
        $scope.PurchaseDetail.Remarks = item.Remarks;

    }

    $scope.deleteProduct = function (item) {
        if (confirm("Are you sure to delete this item?")) {
            console.log(item);
            var CheckStatus = item.CheckStatus;
            var SalesDetailID = item.PurchaseDetailID;
            var LocationID = $scope.Purchase.LocationID;
            var TransactionType = $scope.PurchaseDetail.TransactionType;
            var CheckStatus = $scope.Purchase.CheckStatus;
            var index = $scope.purchaseDetailsCollection.indexOf(item);
            $http.post(retailConstant.serviceBaseUrl + '/Purchase/DeletePurchaseDetails?PurchaseDetailID=' + SalesDetailID + '&LocationID=' + LocationID + '&TransactionType=' + TransactionType + '&CheckStatus=' + CheckStatus)
            .then(function (resp) {
                $scope.purchaseDetailsCollection.splice(index, 1);
                alert("Product deleted successfully!!!");
            }, function () { alert('Error in getting records'); })

        }
    }   
    
    //////Add OR insert Transaction //////

    $scope.addProduct_onClick = function () {     

        if (($scope.PurchaseDetail.ProductName != '' && $scope.PurchaseDetail.ProductName != undefined) && ($scope.PurchaseDetail.Qty != '' && $scope.PurchaseDetail.Qty != undefined) && ($scope.PurchaseDetail.Rate != '' && $scope.PurchaseDetail.Rate != undefined)) {

            var postPurchaseModel = angular.copy($scope.Purchase);
            postPurchaseModel.PurchaseDetail = $scope.PurchaseDetail;

            $http.post(retailConstant.serviceBaseUrl + '/Purchase/SavePurchase', JSON.stringify(postPurchaseModel)).then(function (httpResponse) {
                var response = httpResponse.data;


                if (response.Status == 1) {
                    if ($scope.Purchase.PurchaseID == 0) {
                        $scope.Purchase.PurchaseID = response.Data;
                        $scope.PopulateDetailsGrid(response.Data);
                        $scope.populateCalAdjTransaction(response.Data);
                        $scope.ClearPurchaseDetailsFeild();
                        $scope.Purchase.ShippingAndAdjustment = 2;
                    }
                    else {
                        $scope.PopulateDetailsGrid($scope.Purchase.PurchaseID);
                        $scope.populateCalAdjTransaction($scope.Purchase.PurchaseID);
                        $scope.ClearPurchaseDetailsFeild();
                       
                    }
                } else {
                    $scope.Purchase.ShippingAndAdjustment = 1;
                }

                alert(response.Message);
            });
        } else {
            alert('Please enter product details.');
        }
    }

    $scope.submitPurchase_onClick = function () {          
    
        if ($scope.purchaseDetailsCollection.length > 0  ) {
            var postPurchaseModel = angular.copy($scope.Purchase);
            postPurchaseModel.PurchaseDetail = $scope.PurchaseDetail;

            $http.post(retailConstant.serviceBaseUrl + '/Purchase/SubmitPurchase', JSON.stringify(postPurchaseModel)).then(function (httpResponse) {
                var response = httpResponse.data;

                if (response.Status == 1) {

                }

                alert(response.Message);
            });
        } else {
            alert('Please enter product details.');
        }
    }
   
    
    //////Add OR insert Transaction //////

    $scope.moveToChallan_onClick = function () {

        var postPurchaseModel = angular.copy($scope.Purchase);

        $http.post(retailConstant.serviceBaseUrl + '/Purchase/MoveToChallan', JSON.stringify(postPurchaseModel)).then(function (httpResponse) {
            var response = httpResponse.data;          
            if (response.Status == 1) {
                $scope.moveToChallan = "Moved To Challan";
                $scope.challanButton = true;
            }
            alert(response.Message);
        });
    }
    $scope.moveToInvoice_onClick = function () {

        var postPurchaseModel = angular.copy($scope.Purchase);

        $http.post(retailConstant.serviceBaseUrl + '/Purchase/MoveToInvoice', JSON.stringify(postPurchaseModel)).then(function (httpResponse) {
            var response = httpResponse.data;          
            if (response.Status == 1) {
                $scope.moveToInvoice = "Moved To Invoice";
                $scope.invoiceButton = true;
            }

            alert(response.Message);
        });
    }

    $scope.carrier_OnChange = function (item) {    
        $scope.Purchase.CarrierID = item.CarrierID;
      
    };
       

    $scope.taxCode_OnChange = function (item) {
        var taxID = item.TaxID;
       
        $scope.BillingHeadDetail.taxID = taxID;
    };
   
    $scope.callMoveToChallan = function () {
        var val = $scope.Purchase.OrderNosection;
        var tStatus = parseFloat($scope.Purchase.TransactionStatus || 0);
        var tPID = parseFloat($scope.Purchase.PurchaseID || 0);
       
        if (val == '1' && tStatus != 2 && tPID > 0 && tStatus != 5)
            return true;
        else
            return false;
    };

    $scope.callMoveToInVoice = function () {      


        var val = $scope.Purchase.OrderNosection;
        var tStatus = parseFloat($scope.Purchase.TransactionStatus || 0);
        var tPID = parseFloat($scope.Purchase.PurchaseID || 0);

        if ((val == '1' || val == '2') && tStatus != 3 && tPID > 0 && tStatus != 5)
            return true;
        else
            return false;
    };

    $scope.PopulateDetailsGrid = function (PurchaseID) {
        $http.get(retailConstant.serviceBaseUrl + '/Purchase/PurchaseDetailsPopulateAllGrid?PurchaseID=' + PurchaseID).then(function (resp) {
            if (resp) {
                var response = resp.data;
                var len = resp.data.length;
                for (i = 0 ; i <= len ; i++) {
                    $scope.parseJsonDate(resp.data[i]);
                }
               
                $scope.purchaseDetailsCollection = resp.data;               
              
            }

        });

    }

    $scope.populateCalAdjTransaction = function (PurchaseID) {
        $http.get(retailConstant.serviceBaseUrl + '/Purchase/PurchaseTransactionCalAdj?PurchaseID=' + PurchaseID).then(function (resp) {
            if (resp) {

                var len = resp.data.length;
                for (i = 0 ; i <= len ; i++) {
                    $scope.parseJsonDate(resp.data[i]);
                }
                var response = resp.data;
                console.log(response);
                $scope.Purchase.TotalGrossAmountWithTax = response[0].TotalGrossAmountWithTax;
               // $scope.Purchase.TotalAmountAfterAdjustments = response[0].TotalAmountAfterAdjustments;
                $scope.Purchase.CashDiscAmount = response[0].CashDiscAmount;
                $scope.Purchase.TotalTaxAmount = response[0].TotalTaxAmount;
                $scope.Purchase.CashDisc = response[0].CashDisc;
                $scope.Purchase.CashDiscType = response[0].CashDiscType;
                $scope.Purchase.CashDiscAmount = response[0].CashDiscAmount;
                $scope.Purchase.RoundOff = response[0].RoundOff;
                $scope.Purchase.FinalNetAmountWithShipping = response[0].FinalNetAmountWithShipping;
                $scope.Purchase.BillingTotal = response[0].BillingTotal;
                $scope.Purchase.RCM = response[0].RCM;
                
               // $scope.PurchaseDetail.CheckStatus = response[0].CheckStatus;
                $scope.Purchase.CheckStatus = response[0].CheckStatus;
                $scope.Purchase.CheckedByMemberID = response[0].CheckedByMemberID;
                $scope.Purchase.TotalDiscounts = response[0].TotalDiscounts;
                $scope.Purchase.TotalTaxableAmount = response[0].TotalTaxableAmount;

                ////check///
                $scope.Purchase.TotalAdjustmentsAmount = response[0].TotalAdjustmentsAmount;
                ////

                $scope.Purchase.TotalAmountAfterAdjustments = response[0].TotalAmountAfterAdjustments;
                $scope.Purchase.TotalAmountAfterCashDiscount = response[0].TotalAmountAfterCashDiscount;
                $scope.Purchase.TransactionStatus = response[0].TransactionStatus;
                $scope.Purchase.Vendor = response[0].Vendor;
                $scope.Purchase.VendorID = response[0].VendorID;
                $scope.Purchase.VendorGSTNo = response[0].VendorGSTNo;
                $scope.Purchase.CreditDays = response[0].CreditDays;
                $scope.Purchase.BalanceAmount = response[0].BalanceAmount;
                $scope.Purchase.Address = response[0].Address;
                $scope.Purchase.Referrer = response[0].Referrer;
                $scope.Purchase.PriceDiscRefName = response[0].PriceDiscReferrer;
                $scope.Purchase.SeriesID = response[0].SeriesID;
                $scope.Purchase.ReferrerID = response[0].ReferrerID;
                $scope.Purchase.PriceDiscRefID = response[0].PriceDiscRefID;
                $scope.Purchase.Series = response[0].Series;
                $scope.Purchase.ReferenceNo = response[0].ReferenceNo;
                $scope.Purchase.ReferenceDate = response[0].ReferenceDate;
                $scope.Purchase.TransactionPlace = response[0].TransactionPlace;
                $scope.PurchaseDetail.CheckStatus = response[0].CheckStatus;
                $scope.Purchase.SeriesID = response[0].SeriesID;
                $scope.Purchase.EntryNo = response[0].EntryNo;
                $scope.Purchase.EntryDate = response[0].EntryDate;
                $scope.Purchase.LocationID = response[0].LocationID;  
                $scope.Purchase.LRNo = response[0].LRNo;
                $scope.Purchase.LRDate = response[0].LRDate;
                $scope.Purchase.FreightType = response[0].FreightType;
                $scope.Purchase.FreightAmt = response[0].FreightAmt;
                $scope.Purchase.RoadPermitNo = response[0].RoadPermitNo;
                $scope.Purchase.CarrierID = response[0].CarrierID;
                $scope.Purchase.NoOfCases = response[0].NoOfCases;
                $scope.Purchase.DeliveryDate = response[0].DeliveryDate;  
                
            }
        });

    }


    $scope.ClearPurchaseDetailsFeild = function () {
        $scope.PurchaseDetail.ProductName = '';
        $scope.PurchaseDetail.Qty = '';
        $scope.PurchaseDetail.Unit = '';
        $scope.PurchaseDetail.Rate = '';
        $scope.PurchaseDetail.GrossAmount = '';
        $scope.PurchaseDetail.LotDisc = '';
        $scope.PurchaseDetail.LotDiscType = '';
        $scope.PurchaseDetail.LotDiscAmount = '';
        $scope.PurchaseDetail.LotRemarks = '';
        $scope.PurchaseDetail.SchemeDisc = '';
        $scope.PurchaseDetail.SchemeDiscType = '';
        $scope.PurchaseDetail.SchemeDiscAmount = '';
        $scope.PurchaseDetail.SchemeRemark = '';
        $scope.PurchaseDetail.TradeDisc = '';
        $scope.PurchaseDetail.TradeDiscType = '';
        $scope.PurchaseDetail.TradeDiscAmount = '';
        $scope.PurchaseDetail.TradeDiscRemark = '';
        $scope.PurchaseDetail.FreeQty = '';
        $scope.PurchaseDetail.FreeQtyUnit = '';
        $scope.PurchaseDetail.FreeQtyRemark = '';
        $scope.PurchaseDetail.ManufacturingDate = '';
        $scope.PurchaseDetail.ExpiryDate = '';
        $scope.PurchaseDetail.BatchCode = '';
       // $scope.PurchaseDetail.BarCode = '';
        $scope.PurchaseDetail.LotNo = '';
        $scope.PurchaseDetail.ShelfNo = '';
        $scope.PurchaseDetail.Manufacturer = '';
        $scope.PurchaseDetail.Remarks = '';
        $scope.PurchaseDetail.BillingUnitName = '';

    }

    $scope.ClearPurchaseTransFeild = function () {
        $scope.Purchase.Vendor = '';
        $scope.Purchase.GSTNo = '';
        $scope.Purchase.CreditDays = '';
        $scope.Purchase.BalanceAmount = '';
        $scope.Purchase.Address = '';
        $scope.Purchase.Referrer = '';
        $scope.Purchase.PriceDiscRefName = '';
        $scope.Purchase.selectedSeries = '';
        $scope.Purchase.EntryNo = '';
        $scope.Purchase.EntryDate = '';
        $scope.Purchase.ReferenceNo = '';
        $scope.Purchase.ReferenceDate = '';
        $scope.Purchase.TransactionPlace = '';
        $scope.Purchase.TotalGrossAmountWithTax = '';
        $scope.Purchase.TotalAmountAfterAdjustments = '';
        $scope.Purchase.CashDiscAmount = '';
        $scope.Purchase.TotalTaxAmount = '';
        $scope.Purchase.CashDisc = '';
        $scope.Purchase.CashDiscType = '';
        $scope.Purchase.CashDiscAmount = '';
       // $scope.Purchase.RoundOff = '';
        $scope.Purchase.TotalNetAmountWithoutShipping = '';
        $scope.Purchase.FinalNetAmountWithShipping = '';
       // $scope.Purchase.BillingTotal = '';
        $scope.Purchase.RCM = '';
      //  $scope.Purchase.CheckStatus = '';
        $scope.Purchase.FinalNetAmountWithShipping = '';
      
    };

    $scope.CalTotal = function () {
        if ($scope.PurchaseDetail.Qty || $scope.PurchaseDetail.Rate != null) {

            var total = ($scope.PurchaseDetail.Qty * $scope.PurchaseDetail.Rate)
            $scope.PurchaseDetail.GrossAmount = total;
        } else {
            $scope.PurchaseDetail.GrossAmount = '';
        }
        
    };
    $scope.autoGenerateBarCode = function () {
        $scope.PurchaseDetail.BarCode = 111;//value to be set
       // $scope.PurchaseDetail.ShelfNo = 222;//value to be set
    };

    $scope.closeShippingPopup_onClick = function () {

       // var temp = ($scope.Purchase.TotalAmountAfterAdjustments - $scope.Purchase.CashDiscAmount);  
        //$scope.Purchase.TotalAmountAfterCashDiscount = temp;
        //$scope.Purchase.TotalNetAmountWithoutShipping = (($scope.Purchase.TotalAmountAfterAdjustments - $scope.Purchase.CashDiscAmount) + $scope.Purchase.RoundOff)

       // $scope.Purchase.FinalNetAmountWithShipping = ( (( {{$scope.Purchase.TotalAmountAfterAdjustments}} - $scope.Purchase.CashDiscAmount) + $scope.Purchase.RoundOff) + $scope.Purchase.FreightAmt)
   
        var total = ((parseFloat($scope.Purchase.TotalAmountAfterAdjustments || 0) - parseFloat($scope.Purchase.CashDiscAmount || 0)) + parseFloat($scope.Purchase.FreightAmt || 0)) + parseFloat($scope.Purchase.RoundOff || 0)

        //////////var rtrr= parseFloat($scope.Purchase.FreightAmt || 0)


        //////////var rr = rtrr.split('.')[1];
        //////////var ss = rr;
        //////////alert(ss);

        $scope.Purchase.FinalNetAmountWithShipping = !isNaN(total) ? total : 0;
    
    }
    $scope.calRoundOff = function () {
        var tempRoundOff = parseFloat($scope.Purchase.RoundOff || 0)
        var tempCashDiscAmount = parseFloat($scope.Purchase.CashDiscAmount || 0)
        var tempFreightAmt = parseFloat($scope.Purchase.FreightAmt || 0)
        var totalAmtAftAdj = parseFloat($scope.Purchase.TotalAmountAfterAdjustments || 0)

        var tempFinal = (((totalAmtAftAdj - tempCashDiscAmount) + tempFreightAmt) + tempRoundOff)

        $scope.Purchase.FinalNetAmountWithShipping = !isNaN(tempFinal) ? tempFinal : 0;
    }

    $scope.calCashDisType = function (val) {
        var cashDisCount = parseFloat($scope.Purchase.CashDisc|| 0);
        var totalTaxableAmt = parseFloat($scope.Purchase.TotalTaxableAmount|| 0)
        var totalAmtAftAdj =parseFloat($scope.Purchase.TotalAmountAfterAdjustments|| 0)
        var cal = 0;


        if (val == "1") {

            $scope.Purchase.CashDiscAmount = cashDisCount
          
            var temp = (totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0));
            $scope.Purchase.TotalAmountAfterCashDiscount = temp;
            $scope.Purchase.TotalNetAmountWithoutShipping = ((totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0)))
         
            cal = (((totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0)) + parseFloat($scope.Purchase.FreightAmt || 0)) + parseFloat($scope.Purchase.RoundOff || 0)).toFixed(2)
            $scope.Purchase.FinalNetAmountWithShipping = !isNaN(cal) ? cal : 0;

        }
        if (val == "2") {

            $scope.Purchase.CashDiscAmount = (cashDisCount / 100) * totalTaxableAmt  

            var temp = (totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0));
            $scope.Purchase.TotalAmountAfterCashDiscount = temp;
            $scope.Purchase.TotalNetAmountWithoutShipping = ((totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0)))

            cal = (((totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0)) + parseFloat($scope.Purchase.FreightAmt || 0)) + parseFloat($scope.Purchase.RoundOff || 0)).toFixed(2)

            $scope.Purchase.FinalNetAmountWithShipping = !isNaN(cal) ? cal : 0;

        }
        if (val == "3") {

            $scope.Purchase.CashDiscAmount = (cashDisCount / 100) * totalAmtAftAdj
         
            var temp = (totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0));
            $scope.Purchase.TotalAmountAfterCashDiscount = temp;
            $scope.Purchase.TotalNetAmountWithoutShipping = ((totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0)))

            cal = (((totalAmtAftAdj - parseFloat($scope.Purchase.CashDiscAmount || 0)) + parseFloat($scope.Purchase.FreightAmt || 0)) + parseFloat($scope.Purchase.RoundOff || 0)).toFixed(2)
            $scope.Purchase.FinalNetAmountWithShipping = !isNaN(cal) ? cal : 0;
        }

    }
    $scope.calculateDiscount = function (val,type) {

        var grossAmt = $scope.PurchaseDetail.GrossAmount
     
      
        if (type == "Lot") {
      
            if (val == "1") {               
                $scope.PurchaseDetail.LotDiscAmount = $scope.PurchaseDetail.LotDisc
            }
            if (val == "2") {
                var lotDis = $scope.PurchaseDetail.LotDisc;
                $scope.PurchaseDetail.LotDiscAmount = (lotDis / 100) * grossAmt
            } 
            if (val == "") {
                $scope.PurchaseDetail.LotDiscAmount = '';
            }        
        }
        else if (type == "Scheme") {
            if (val == "1") { 
                $scope.PurchaseDetail.SchemeDiscAmount = $scope.PurchaseDetail.SchemeDisc;                
            }
            if (val == "2") {
                var SchDis = $scope.PurchaseDetail.SchemeDisc;
                $scope.PurchaseDetail.SchemeDiscAmount = (SchDis / 100) * grossAmt
            }
            if (val == "")
            {
                $scope.PurchaseDetail.SchemeDiscAmount = '';
            }

        } else if (type == "Trade") {
            if (val == "1") { 
                $scope.PurchaseDetail.TradeDiscAmount = $scope.PurchaseDetail.TradeDisc;
            }
            if (val == "2") { 
                var TradeDis = $scope.PurchaseDetail.TradeDisc;
                $scope.PurchaseDetail.TradeDiscAmount = (TradeDis / 100) * grossAmt
            } 
            if (val == "")
            {
                $scope.PurchaseDetail.TradeDiscAmount = '';
            }

        }

     
    };

    $scope.billingHeadDetailSave_onClick = function () {
        $scope.populateCalAdjTransaction($scope.Purchase.PurchaseID);
    }



    //Methods//

    $scope.onLoad();
    $scope.autoGenerateBarCode();
 
  
})



