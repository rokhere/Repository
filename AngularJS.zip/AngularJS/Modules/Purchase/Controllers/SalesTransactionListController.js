﻿var retailPurchaseApp = angular.module('Retail');


retailPurchaseApp.controller('saleTransactionListCtrl', function ($scope, $q, $filter, $http, $routeParams, $location, retailConstant) {
    

    $scope.TransactionTypeList =
      [
          { TransactionTypeID: "-1", TransactionType: "select" },
          { TransactionTypeID: "5", TransactionType: "Order" },
          { TransactionTypeID: "6", TransactionType: "Challan" },
          { TransactionTypeID: "7", TransactionType: "Invoice" },
          { TransactionTypeID: "8", TransactionType: "Return" }
      ];

    $scope.SalesList = { TransactionType: "" };
    $scope.SalesList.TransactionType = "7";
   
   
    var date = new Date();
    var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
    var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
    var FirstDateOfMonth = (firstDay.getDate()) + '/' + (lastDay.getMonth() + 1) + '/' + lastDay.getFullYear();
    var NowDateOfMonth = (date.getDate()) + '/' + (lastDay.getMonth() + 1) + '/' + lastDay.getFullYear();

    $scope.SalesList.EntryDate = FirstDateOfMonth;
    $scope.SalesList.ActualDate = NowDateOfMonth;

  

    $scope.parseJsonDate = function (model) {
        // date format - /Date(1507573800000)/
        for (var property in model) {
            if (model.hasOwnProperty(property) && property.indexOf('Date') > -1) {
                var jsonDateString = model[property] || '';
                if (jsonDateString.length > 0) {
                    var date = new Date(parseInt(jsonDateString.substr(6)));
                    model[property] = $filter('date')(date, "dd/MM/yyyy");;
                }
            }
        }
    }
  
    /////
    if ($scope.SalesList.Keyword == null || $scope.SalesList.Keyword === "") {
        keyWord = '';
    } else {
        keyWord = $scope.SalesList.Keyword;
    }
   
    $scope.populateListing = function () {
       
        var pstData = {};
            pstData = {
            KeyWord: $scope.SalesList.Keyword,
            EntryDate: $scope.SalesList.EntryDate,
            ActualDate: $scope.SalesList.ActualDate,
            TransactionType: $scope.SalesList.TransactionType
        };


        $http.post(retailConstant.serviceBaseUrl + '/Sales/SalesTransactionListing',pstData).then(function (resp) {
            if (resp) {           
                var response = resp.data;
                var len = resp.data.length;
                for (i = 0 ; i <= len ; i++) {
                    $scope.parseJsonDate(resp.data[i]);
                }  
                $scope.SalesListCollection = resp.data || [];
                console.log(resp.data);
            }
        });

    }

    $scope.deleteTransaction = function (item, SalesID) {
        if (confirm("Are you sure to delete this item ?")) {
            var index = $scope.SalesListCollection.indexOf(item);
            $http.post(retailConstant.serviceBaseUrl + '/Sales/SalesTransactionDelete?SalesID=' + SalesID + '&TransactionType=' + $scope.SalesList.TransactionType)
            .then(function (resp) {
                $scope.SalesListCollection.splice(index, 1);
                alert("item deleted successfully!!!");
            }, function () { alert('Error in getting records'); })
        };
    }
    $scope.populateListing();
})



