﻿var retailPurchaseApp = angular.module('Retail');

retailPurchaseApp.config(function ($routeProvider, $locationProvider, retailConstant) {
    $routeProvider.when('/purpage1', {
        controller: 'purchasePage1Ctrl',
        templateUrl: '/AngularJS/Modules/Purchase/Views/page1.html'
    });      
    $routeProvider.when('/purchaseTransaction/:Type', {
        controller: 'purchaseTransactionCtrl',
        templateUrl: '/AngularJS/Modules/Purchase/Views/PurchaseTransaction.html',
        requiredUserPageAction: retailConstant.userPageAction.View,
    });
    $routeProvider.when('/purchaseReturn', {
        controller: 'purchaseReturnCtrl',
        templateUrl: '/AngularJS/Modules/Purchase/Views/PurchaseReturn.html'
    });
    $routeProvider.when('/purchaseTransactionList', {
        controller: 'purchaseTransactionListCtrl',
        templateUrl: '/AngularJS/Modules/Purchase/Views/PurchaseTransactionList.html'
    });
    $routeProvider.when('/purchaseTransactionEdit/:PurchaseID/:Type', {
        controller: 'purchaseTransactionCtrl',
        templateUrl: '/AngularJS/Modules/Purchase/Views/PurchaseTransaction.html'        
    });
    $routeProvider.when('/purchaseReturnEdit/:PurchaseID', {
        controller: 'purchaseReturnCtrl',
        templateUrl: '/AngularJS/Modules/Purchase/Views/PurchaseReturn.html'

    });    
    $routeProvider.when('/salesTransaction/:Type', {
        controller: 'saleTransactionCtrl',
        templateUrl: '/AngularJS/Modules/Purchase/Views/SalesTransaction.html'
    });
    $routeProvider.when('/salesReturn/:Type', {
        controller: 'saleReturnCtrl',
        templateUrl: '/AngularJS/Modules/Purchase/Views/SalesReturn.html'
    });    
    $routeProvider.when('/salesTransactionList', {
        controller: 'saleTransactionListCtrl',
        templateUrl: '/AngularJS/Modules/Purchase/Views/SalesTransactionList.html'
    });


    /////////Edit////////
    $routeProvider.when('/salesTransactionEdit/:SalesID/:Type', {
        controller: 'saleTransactionCtrl',
        templateUrl: '/AngularJS/Modules/Purchase/Views/SalesTransaction.html'
    });
    $routeProvider.when('/salesReturnEdit/:SalesID', {
        controller: 'saleReturnCtrl',
        templateUrl: '/AngularJS/Modules/Purchase/Views/SalesReturn.html'

    });

    //////
});




