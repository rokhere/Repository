﻿var retailSalesApp = angular.module('Retail');

retailSalesApp.config(function ($routeProvider, $locationProvider, retailConstant) {  
    $routeProvider.when('/salesTransaction/:Type', {
        controller: 'salesTransactionCtrl',
        templateUrl: '/AngularJS/Modules/Sales/Views/SalesTransaction.html',
        requiredUserPageAction: retailConstant.userPageAction.View,
    });

   
  
});




