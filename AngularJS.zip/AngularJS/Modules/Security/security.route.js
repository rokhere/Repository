﻿var retailSecurityApp = angular.module('Retail');

retailSecurityApp.config(function ($routeProvider, $locationProvider, retailConstant) {
    $routeProvider.when('/RolePageAssociation', {
        controller: 'RolePageAssociationController',
        templateUrl: '/AngularJS/Modules/Security/Views/RolePageAssociation.html',
        requiredUserPageAction: retailConstant.userPageAction.View
    }).when('/UserRoleAssociation', {
        controller: 'UserRoleAssociationController',
        templateUrl: '/AngularJS/Modules/Security/Views/UserRoleAssociation.html',
        requiredUserPageAction: retailConstant.userPageAction.View
    });
});