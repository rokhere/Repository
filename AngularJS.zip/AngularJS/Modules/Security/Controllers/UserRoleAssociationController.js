﻿var retailSecurityApp = angular.module('Retail');

retailSecurityApp.controller('UserRoleAssociationController', function ($scope, $http, $route, $q, retailConstant, retailSecurityService) {
    $scope.combinedPromise = undefined;

    $scope.populateMember = function (httpResponse) {
        var response = httpResponse.data;

        if (response.Status == 1) {
            $scope.members = response.Data;
        }
    };

    $scope.populateRole = function (httpResponse) {
        var response = httpResponse.data;

        if (response.Status == 1) {
            $scope.roles = response.Data;
        }
    };

    $scope.submit_Onclick = function (formIsValid) {
        if (formIsValid) {
            var memberRole = { MemberId: $scope.selectedMember.MemberId, RoleId: $scope.RoleId };

            $http.post(retailConstant.serviceBaseUrl + '/Security/SaveMemberRole', JSON.stringify(memberRole)).then(function (httpResponse) {
                var response = httpResponse.data;
                alert(response.Message);
            });
        }
    };

    $scope.onLoad = function () {

        var memberPromise = $http.get(retailConstant.serviceBaseUrl + '/Security/GetMembers');
        var rolePromise = $http.get(retailConstant.serviceBaseUrl + '/Security/GetRoles');

        //Add to chain
        $scope.combinedPromise = $q.all({
            member: memberPromise,
            role: rolePromise
        });

        //CombinedPromise then
        $scope.combinedPromise.then(function (responses) {
            
            if (responses.member) {
                $scope.populateMember(responses.member);
            }

            if (responses.role) {
                $scope.populateRole(responses.role);
            }
        });

    };


    $scope.onLoad();
});