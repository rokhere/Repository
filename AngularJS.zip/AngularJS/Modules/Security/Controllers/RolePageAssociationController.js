﻿var retailSecurityApp = angular.module('Retail');

retailSecurityApp.controller('RolePageAssociationController', function ($scope, $http, $route, retailConstant, retailSecurityService) {

    $scope.populateRoles = function () {
        $http.get(retailConstant.serviceBaseUrl + '/Security/GetRoles').then(function (httpResponse) {
            var response = httpResponse.data;

            if (response.Status == 1) {
                $scope.roles = response.Data;
            }
        });
    };
    $scope.role_onChange = function (roleId) {

        $scope.checkedAllView = 0;
        $scope.checkedAllCreate = 0;
        $scope.checkedAllUpdate = 0;
        $scope.checkedAllDelete = 0;

        roleId = roleId + '';
        if (roleId.length > 0) {
            $http.get(retailConstant.serviceBaseUrl + '/Security/GetRolePageAssociation?RoleId=' + roleId).then(function (httpResponse) {
                var response = httpResponse.data;
                if (response.Status == 1) {
                    $scope.rolePageAssociation = response.Data;
                }
            });
        } else {
            $scope.rolePageAssociation = undefined;
        }
    };
    $scope.chkAll_onChange = function (attr, checked) {
        for (var i = 0; i < $scope.rolePageAssociation.length; i++) {
            var item = $scope.rolePageAssociation[i];
            item[attr] = checked ? 1 : 0;
        }
    };
    $scope.save_onClick = function (formIsValid) {
        if (formIsValid) {
            $http.post(retailConstant.serviceBaseUrl + '/Security/SaveRolePageAssociation?RoleId=' + $scope.RoleID, JSON.stringify($scope.rolePageAssociation))
                .then(function (httpResponse) {
                var response = httpResponse.data;
                if (response.Status == 1) {
                    //$scope.resetTaxRateModel();
                }

                alert(response.Message);
            });
        }
    };

    $scope.populateRoles();
});