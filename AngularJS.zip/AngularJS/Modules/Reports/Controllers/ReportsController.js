﻿var retailReportsApp = angular.module('Retail');


retailReportsApp.controller('ReportCtrl', function ($scope,$sce, $q, $filter, $http, $routeParams, $location, retailConstant) {

    

    $scope.url = $sce.trustAsResourceUrl('');
    $scope.objMarketingCompany = {};
    $scope.objProductCategory = {};
    $scope.disabledMarketingCompany = true;

    $scope.bindMarketingCompany = function () {
        ////////////console.log(MarketingGroupID);

        //////////var httpPromise = $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetMarketingCompany?MarketingGroupID=0').then(function (resp) {  
        //////////    if (resp.data.length > 0) {
        //////////        console.log(resp.data);
        //////////        debugger;
        //////////        $scope.objMarketingCompany = resp.data;
        //////////      //  $scope.disabledMarketingCompany = false;
        //////////    } else {
        //////////        $scope.objMarketingCompany = "";
        //////////      //  $scope.disabledMarketingCompany = true;
        //////////    }

        //////////}, function () { alert('Error in getting records in bindMarketingCompany'); })

        //////////requestPromise.push(httpPromise);

        $http.get(retailConstant.serviceBaseUrl + '/MasterData/GetMarketingCompany?MarketingGroupID=0').then(function (resp) {
            if (resp) {
                var response = resp.data;
                $scope.objMarketingCompany = response;

            }
        });

    };
    $scope.bindMarketingCompany( );

    $scope.showPurchaseCommonPopup = function (popupFor) {

        $scope.purchaseCommonPopupCombinedPromise = undefined;
        $scope.popupFor = popupFor;

        //Prepare Promise
        var popupDataPromise = undefined;
        if ($scope.popupFor == 'Vendor') {
            var locationId =   0;//$scope.Purchase.LocationID || 0;
           // if (locationId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetVendor?LocationID=' + locationId);
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ Vendor: popupDataPromise });
            //}
        } else if ($scope.popupFor == 'Referrer') {
            var vendorId = $scope.ReportModel.VendorID || 0;
            if (vendorId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetReferrer?VendorID=' + vendorId);
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ Referrer: popupDataPromise });
            }
        } else if ($scope.popupFor == 'PriceDesc') {
            var vendorId = $scope.Purchase.VendorID || 0;
            if (vendorId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/GetReferrer?VendorID=' + vendorId);
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ Referrer: popupDataPromise });
            }
        } else if ($scope.popupFor == 'Product') {
            var ProductId = $scope.ReportModel.ProductID || 0;
            var locationId = $scope.ReportModel.LocationID || 0;
            //if (ProductId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/Getproduct?LocationID=' + locationId);
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ Product: popupDataPromise });
            //}
        } else if ($scope.popupFor == 'Billing') {
            var vendorId = $scope.Purchase.VendorID || 0;
            if (vendorId > 0) {
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/BillingHead');
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ BillingHead: popupDataPromise });
            }
        } else if ($scope.popupFor == 'TaxCode') {
            var vendorId = $scope.Purchase.VendorID || 0;
            if (vendorId > 0) {
                var tempTransactionPlace = $scope.Purchase.TransactionPlace;
                var tempTransactionType = $scope.PurchaseDetail.TransactionType;
                popupDataPromise = $http.get(retailConstant.serviceBaseUrl + '/Purchase/BillingHeadTax?TransactionPlace=' + tempTransactionPlace + '&TransactionType=' + tempTransactionType);
                $scope.purchaseCommonPopupCombinedPromise = $q.all({ TaxCode: popupDataPromise });
            }
        }


        //TODO:
        //Service Call
        if ($scope.purchaseCommonPopupCombinedPromise != undefined) {
            $scope.purchaseCommonPopupCombinedPromise.then(function (responses) {
                if (responses.Vendor) {
                    $scope.VendorArray = responses.Vendor.data || [];
                } else if (responses.Referrer) {
                    $scope.ReferrerArray = responses.Referrer.data || [];
                } else if (responses.Referrer) {
                    $scope.ReferrerArray = responses.Referrer.data || [];
                } else if (responses.Product) {
                    $scope.ProductArray = responses.Product.data || [];
                } else if (responses.BillingHead) {
                    $scope.BillingHeadArray = responses.BillingHead.data || [];
                } else if (responses.TaxCode) {
                    $scope.BillingHeadArray = responses.TaxCode.data || [];
                }

                $('#dvPurchaseCommonPopup').modal('show');
            });
        }
    };
    $scope.purchaseCommonPopup_onSelect = function (item) {

        $scope.purchaseCommonPopupSelectedItem = item;
        if ($scope.popupFor == 'Vendor') {         
            $scope.ReportModel.Vendor = item.Vendor;
            $scope.ReportModel.VendorID = item.VendorID;
            
        } 
        //if ($scope.popupFor == 'Vendor') {
        //    //Update Purchase model by Vendor details
        //    $scope.Purchase.Vendor = item.Vendor;
        //    $scope.Purchase.VendorID = item.VendorID;
        //    $scope.Purchase.VendorGSTNo = item.GSTNo;
        //    $scope.Purchase.CreditDays = item.CreditDays;
        //    $scope.Purchase.BalanceAmount = item.BalanceAmount;
        //    $scope.Purchase.Address = item.Address;
        //} else if ($scope.popupFor == 'Referrer') {
        //    //Update Purchase model by Referrer details
        //    $scope.Purchase.ReferrerID = item.ReferrerId;
        //    $scope.Purchase.Referrer = item.Referrer;
            //}  
        else if ($scope.popupFor == 'Product') {
            //Update Purchase model by Referrer details          
            $scope.ReportModel.ProductName = item.ProductName;
            $scope.ReportModel.ProductID = item.ProductID;
            //$scope.PurchaseDetail.ProductCategoryID = item.ProductCategoryID;
            //$scope.PurchaseDetail.BillingUnit1ID = item.PurchaseRateUnit;
            //$scope.PurchaseDetail.BillingUnitName = item.PuschaseUnit;
            //$scope.PurchaseDetail.MinStockOnTransDate = item.MinStock;
            //$scope.PurchaseDetail.MaxStockOnTransDate = item.MaxStock;
            //$scope.PurchaseDetail.DisplayUnit1 = item.DisplayUnit1;
            //$scope.PurchaseDetail.DisplayUnit2 = item.DisplayUnit2;
            //$scope.PurchaseDetail.DisplayUnit3 = item.DisplayUnit3;
            //$scope.PurchaseDetail.PerUnit1Content = item.PerUnit1Content;
            //$scope.PurchaseDetail.PerUnit2Content = item.PerUnit2Content;
            //$scope.PurchaseDetail.ShelfNo = item.ShelfNo;
            //$scope.PurchaseDetail.ShelfID = item.ShelfID;
            //$scope.PurchaseDetail.MRP = item.MRP;
            //$scope.PurchaseDetail.TradeRate = item.TradeRate;
        } 
       
        $('#dvPurchaseCommonPopup').modal('hide');
    };

    $scope.GeneratedReports_onClick = function () {
        if ($scope.ReportModel.ProductID === null || $scope.ReportModel.ProductID === undefined)
            $scope.ReportModel.ProductID = 0;
        if ($scope.ReportModel.ProductCategoryID === null || $scope.ReportModel.ProductCategoryID === undefined)
            $scope.ReportModel.ProductCategoryID = 0;
        if ($scope.ReportModel.VendorID === null || $scope.ReportModel.VendorID === undefined)
            $scope.ReportModel.VendorID = 0;
        if ($scope.ReportModel.MktCompanyID.MktCompanyID === null || $scope.ReportModel.MktCompanyID.MktCompanyID === undefined)
            $scope.ReportModel.MktCompanyID.MktCompanyID = 0;
        if ($scope.ReportModel.TransactionSeries === null || $scope.ReportModel.TransactionSeries === undefined)
            $scope.ReportModel.TransactionSeries = 0;//LocationID
        if ($scope.ReportModel.LocationID === null || $scope.ReportModel.LocationID == undefined)
            $scope.ReportModel.LocationID = 0;//LocationID
        debugger;
        $scope.url = $sce.trustAsResourceUrl(retailConstant.serviceBaseUrl + '/Report/purchasedetails?StartDate=' + $scope.ReportModel.StartDate + '&EndDate=' + $scope.ReportModel.EndDate + '&TransactionType=' + $scope.ReportModel.TransactionType + '&ProductID=' + $scope.ReportModel.ProductID + '&ProductCategoryID=' + $scope.ReportModel.ProductCategoryID + '&VendorID=' + $scope.ReportModel.VendorID + '&MarketingCompanyID=' + $scope.ReportModel.MktCompanyID.MktCompanyID + '&TransactionSeries=' + $scope.ReportModel.TransactionSeries + '&LocationID=' + $scope.ReportModel.LocationID);
        //$scope.url = $sce.trustAsResourceUrl(retailConstant.serviceBaseUrl + '/Report/purchasedetails2?StartDate=' + $scope.ReportModel.StartDate + '&EndDate=' + $scope.ReportModel.EndDate + '&TransactionType=' + $scope.ReportModel.TransactionType);// + '&TransactionType=' + $scope.ReportModel.TransactionType + '&ProductID=' + $scope.ReportModel.ProductID + '&ProductCategoryID=' + $scope.ReportModel.ProductCategoryID + '&VendorID=' + $scope.ReportModel.VendorID + '&MarketingCompanyID=' + $scope.ReportModel.MktCompanyID + '&TransactionSeries=' + $scope.ReportModel.TransactionSeries + '&LocationID=' + $scope.ReportModel.LocationID);
        console.log($scope.url);
    };
    //$scope.GeneratedReports_onClick = function () {    

    //    $http.post(retailConstant.serviceBaseUrl + 'Report/PurchaseDetails?StartDate=' + $scope.ReportModel.StartDate + '&EndDate=' + $scope.ReportModel.StartDate + '&VendorID=' + $scope.ReportModel.VendorID)
    //   .then(function () { 
    //   }, function () { alert('Error in getting records'); })



    //}
});



