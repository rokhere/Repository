﻿var retailReportApp = angular.module('Retail');

 
retailReportApp.config(function ($routeProvider, $locationProvider, retailConstant) {
$routeProvider.when('/PurchaseDetailsReport', {
    controller: 'ReportCtrl',
    templateUrl: '/AngularJS/Modules/Reports/Views/PurchaseDetailsReport.html',
        requiredUserPageAction: retailConstant.userPageAction.View,
});
});
     









