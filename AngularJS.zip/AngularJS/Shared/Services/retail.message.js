﻿var retailApp = angular.module('Retail');


retailApp.factory('retailMessageService', function () {
    //Private
    var _successMessageBtn = '#btnShowSuccessMessage'
    var _successMessage = '#pSuccessMessage';

    var _errorMessageBtn = '#btnShowErrorMessage'
    var _errorMessage = '#pErrorMessage';

    var _infoMessageBtn = '#btnShowInfoMessage'
    var _infoMessage = '#pInfoMessage';

    var _showSuccessMessage = function (msg) {
        $(_successMessage).text(msg);
        $(_successMessageBtn).click();
    };

    var _showErrorMessage = function (msg) {
        $(_errorMessage).text(msg);
        $(_errorMessageBtn).click();
    };

    var _showInfoMessage = function (msg) {
        $(_infoMessage).text(msg);
        $(_infoMessageBtn).click();
    };

    //Prublic
    return {
        showSuccessMessage: function (message) {
            _showSuccessMessage(message);
        },
        showErrorMessage: function (message) {
            _showErrorMessage(message);
        },
        showInfoMessage: function (message) {
            _showInfoMessage(message);
        }
    }
});