﻿var retailApp = angular.module('Retail');


retailApp.factory('retailSecurityService', function ($filter, retailConstant) {
    //Private
    var _userPageActionSessionKey = "UserPageActions";
    var _getUserPageActions = function () {
        var userPageActions;
        var userPageActionString = window.localStorage.getItem(_userPageActionSessionKey);
        if (userPageActionString != null && userPageActionString != undefined && userPageActionString.length > 0) {
            userPageActions = JSON.parse(userPageActionString);
        }

        return userPageActions || [];
    };

    //Public
    return {
        //Add user page actions to local storage
        setUserPageActions: function (userPageActions) {
            window.localStorage.setItem(_userPageActionSessionKey, JSON.stringify(userPageActions));
        },

        isUserPageActionAuthorized: function (pageName, pageAction) {
            var isAuthorized = false;

            //remove '/' from page name
            pageName = pageName.replace("/", "");

            //extract only page route
            pageName = pageName.split("/")[0];

            var userPageActions = $filter('filter')(_getUserPageActions(), { PageName: pageName }, true);
            if (userPageActions.length == 1) {
                isAuthorized = (userPageActions[0])[pageAction];
            }
            
            if (!retailConstant.allowClientAuthorization) {
                isAuthorized = true;
            }

            return isAuthorized;
        }
    };
});