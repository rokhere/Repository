﻿var retailApp = angular.module('Retail');


retailApp.factory('retailCommonService', function ($window) {
    return {
        navigateTo: function (route) {
            //TODO: Need to fix
            //$location.path('/' + route);

            var url = "http://" + $window.location.host + "/User/" + route;
            $window.location.href = url;
        }
    }
});