﻿/// <reference path="../../retail.constant.js" />


var retailApp = angular.module('Retail');

retailApp.controller('SettingsController', function ($scope, $http, retailConstant, retailSecurityService) {
    $scope.pageName = "Settings Page"
});