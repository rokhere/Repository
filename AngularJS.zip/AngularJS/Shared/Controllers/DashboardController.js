﻿/// <reference path="../../retail.constant.js" />


var retailApp = angular.module('Retail');

retailApp.controller('dashboardCtrl', function ($scope, $http, retailConstant, retailSecurityService) {

    $scope.populateDashboard = function () {

        $http.get(retailConstant.serviceBaseUrl + '/Security/GetUserPageActions').then(function (httpResponse) {
            var response = httpResponse.data;
            
            if (response.Status == 1 && response.Data.length > 0) {
                retailSecurityService.setUserPageActions(response.Data);
            } else {
                alert(response.Message);
            }

        });
    };

    $scope.getStyle = function (pageNo) {
        var style = {};
        if ($scope.pageNo == pageNo) {
            style["background-color"] = "red";
        }
        return style;
    };
    $scope.getPages = function (num) {
        var pages = [];
        for (var i = 1; i <= num; i++) {
            pages.push(i);
        }

        return pages;
    }
    $scope.populateDashboardPaggedGrid = function (pageNo) {
        $scope.pageNo = pageNo || 1;
        $http.get(retailConstant.serviceBaseUrl + '/Dashboard/GetPagingData?pageNumber=' + $scope.pageNo).then(function (httpResponse) {
            var response = httpResponse.data;
            console.log(response);
            if (response.Status == 1) {
                $scope.dataPage = response.Data;
            } 
        });
    }

    $scope.populateDashboard();
    $scope.populateDashboardPaggedGrid();
});