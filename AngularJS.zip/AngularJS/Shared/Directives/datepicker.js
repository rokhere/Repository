﻿var retailApp = angular.module('Retail');


retailApp.directive("datepicker", function () {
    return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, elem, attrs, ngModelCtrl) {
            console.log('link');

            var updateModel = function (dateText) {
                scope.$apply(function () {
                    ngModelCtrl.$setViewValue(dateText);
                });
            };
            var options = {
                dateFormat: "dd/mm/yy",
                onSelect: function (dateText) {
                    updateModel(dateText);
                }
            };

            //TODO: set ng-pattern
            //attrs.$set("ng-pattern", "/^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d$/");
            //scope.$watch(attrs.ngModel, function (newValue, oldValue) {
            //    console.log(oldValue + ' - ' + newValue);
            //});
            //attrs.$set("readonly", "true");
            $(elem).datepicker(options);
        }
    }
});