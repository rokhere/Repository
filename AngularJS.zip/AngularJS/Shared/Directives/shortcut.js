﻿var retailApp = angular.module('Retail');

//Save
retailApp.directive('shortcutSave', function () {
    return {
        restrict: 'A',
        link: function postLink(scope, element, arrts) {
            jQuery(document).on('keydown', function (e) {
                if (e.altKey) {
                    e.preventDefault();
                    e.stopPropagation();

                    //Alt+S
                    if (e.which == 83) {
                        $(element).click();
                    }
                }
            });
        }
    };
});

//Print
retailApp.directive('shortcutPrint', function () {
    return {
        restrict: 'A',
        link: function postLink(scope, element, arrts) {
            jQuery(document).on('keydown', function (e) {
                if (e.altKey) {
                    e.preventDefault();
                    e.stopPropagation();

                    //Alt+P
                    if (e.which == 80) {
                        $(element).click();
                    }
                }
            });
        }
    };
});

//Draft
retailApp.directive('shortcutDraft', function () {
    return {
        restrict: 'A',
        link: function postLink(scope, element, arrts) {
            jQuery(document).on('keydown', function (e) {
                if (e.altKey) {
                    e.preventDefault();
                    e.stopPropagation();

                    //Alt+R
                    if (e.which == 82) {
                        $(element).click();
                    }
                }
            });
        }
    };
});

//Cancel
retailApp.directive('shortcutCancel', function () {
    return {
        restrict: 'A',
        link: function postLink(scope, element, arrts) {
            jQuery(document).on('keydown', function (e) {
                if (e.altKey) {
                    e.preventDefault();
                    e.stopPropagation();

                    //Alt+A
                    if (e.which == 65) {
                        $(element).click();
                    }
                }
            });
        }
    };
});



