﻿var retailApp = angular.module('Retail');


retailApp.constant('retailConstant', {
    serviceBaseUrl: 'http://localhost:51327',//Client Service URL
    serverServiceBaseUrl: 'http://localhost:51327',//Server Service URL
    userPageAction: { Create: 'IsCreate', View: 'IsView', Update: 'IsUpdate', Delete: 'IsDelete' },
    allowClientAuthorization: false //true/false
});
