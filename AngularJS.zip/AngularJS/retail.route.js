﻿var retailApp = angular.module('Retail');

retailApp.config(function ($routeProvider, $locationProvider) {

    //templateUrl - Root Specific
    $routeProvider.when('/Dashboard', {
        controller: 'dashboardCtrl',
        templateUrl: '/AngularJS/Shared/Views/dashboard.html'
    }).when('/Profile', {
        controller: 'ProfileController',
        templateUrl: '/AngularJS/Shared/Views/Profile.html'
    }).when('/Settings', {
        controller: 'SettingsController',
        templateUrl: '/AngularJS/Shared/Views/Settings.html'
    }).otherwise({
        redirect: '/Dashboard'
    });

}).run(function ($rootScope, $location, retailConstant, retailSecurityService) {

    //$routeChangeStart
    $rootScope.$on("$routeChangeStart", function (event, next, current) {
        if (retailConstant.allowClientAuthorization) {
            if (next != null && next.$$route.originalPath != '/UnAuthorize') {
                //Check from 
                var pageName = next.$$route.originalPath;

                if (pageName.toUpperCase() != '/DASHBOARD') {
                    var isAuthorized = retailSecurityService.isUserPageActionAuthorized(pageName, next.$$route.requiredUserPageAction);
                    if (!isAuthorized) {
                        //UnAuthorized
                        alert('Sorry! you are not authorized to perform this action');
                        event.preventDefault();
                    }
                }
            }
        }
    });

});




