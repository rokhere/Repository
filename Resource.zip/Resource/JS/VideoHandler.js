﻿
$(document).ready(function () {
    $.noConflict();
    //LoadModalDiv();
    var vdotype = 0;

    String.prototype.timeStampFormat = function (args) {

        //replace all accurance of key
        var s = this;
        for (var key in args) {
            var re = new RegExp('{' + key + '}', 'g');
            s = s.replace(re, args[key]);
        }
        return s;
    }

    $("input[id*= 'rdvdotypelst_']").on('change', function (event) {
        event.preventDefault();
        var selectedValue = $(this).val();
        var selectedText = $(this).next().html();
        //alert("Selected Text: " + selectedText + " Selected Value: " + selectedValue);
        $("input[id*= 'updvdotxt_']").val('');
        $('#red_URL').remove();//remove validation text


        $.ajax({
            url: 'ParticipationEntry.aspx/GetVdoType',
            type: 'POST',
            data: "{ 'selval': '" + selectedValue + "', 'seltxt': '" + selectedText + "' }",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                vdotype = data.d;
                if (vdotype == "0") {
                    $("div[id*= 'mbdPnl_']").show();
                    $("div[id*= 'vdoUpdPnl_']").hide();
                }
                else if (vdotype == "1") {
                    $("div[id*= 'mbdPnl_']").hide();
                    $("div[id*= 'vdoUpdPnl_']").show();
                }
                else {
                    $("div[id*= 'mbdPnl_']").hide();
                    $("div[id*= 'vdoUpdPnl_']").hide();
                }

            },
            error: function (err) {
                alert('An error occured.');
            },
            async: false
        });

    }); //edn of radiobtn list selection change

    //To prevent enter for selecting video type.
    $("input[id*= 'rdvdotypelst_'], #ContentBody_updvdotxt_VideoUpload_Pasteembedcode").keypress(function (event) {
        if (event.keyCode == 13) {
            event.preventDefault();
            return false;
        }
    });

    //video handler (Reja)...
    var fluId = $("input[id*= 'fileupd_']")[0].id;
    var FileArray = [];
    var uploadVideoCount = 0;
    var FileNamePrefix = $("#ContentBody_hdnFileName").val();
    var totalPercent = 0;

    $("input[id*= 'fileupd_']").on('change', function (event) {
        event.preventDefault();

        LoadModalDiv();
        var file = event.target.files;

        //UploadFile(file);
        ValidateAndUploadFile(file);
        $("input[id*= 'fileupd_']").val("");
    });

    function ValidateAndUploadFile(TargetFile) {
        var file = TargetFile[0];
        var VideoSize = 0;
        var VideoSizeMB = 0;
        var UploadLimit = 0;
        var UploadLimitMB = 0;
        var MaxFileSizeMB = 1;
        var BufferChunkSize = MaxFileSizeMB * (1024 * 1024);
        var FileType = file.name.substring(file.name.lastIndexOf('.') + 1).toLowerCase();
        VideoSize = file.size;
        var FileStreamPos = 0;
        // set the initial chunk length
        var EndPos = BufferChunkSize;
        var ArrFileType = ['1769172845_mp4', '1836069938_3gp', '1836069938_mp4', '1096173856_avi', '-1495727958_wmv', '150994944_flv', '1903435808_mov', '21165953_mkv', '21165953_webm'];//1769172845>mp4,1836069938>3gp,1096173856>avi,-1495727958>wmv,150994944>flv,1903435808>mov,21165953>mkv
        var fileCode = 0;
        var result = true;
        var file = TargetFile[0];
        var arrayBuffer;
        UploadLimitMB = $('#hdnContestVideoUploadLimit').val();
        UploadLimit = $('#hdnContestVideoUploadLimit').val() * (1024 * 1024);//b

        VideoSizeMB = Math.round(((VideoSize / 1024) / 1024) * 10) / 10 //convert to MB and round off to 1 decimal
        var reader = new FileReader();
        //if (VideoSize <= UploadLimit) {
        if (VideoSizeMB <= UploadLimitMB) {
            reader.onload = function () {
                arrayBuffer = reader.result;

                //console.log(arrayBuffer.byteLength);
                if (arrayBuffer.byteLength <= 0) {
                    $("#dvProgress").dialog('close');
                    alert('Please upload specified video format file(s).');
                    return;
                }

                var dataview = new DataView(arrayBuffer);
                fileCode = dataview.getInt32(8);

                if ($.inArray(fileCode + '_' + FileType, ArrFileType) != -1) {
                    //console.log(fileCode + '_' + FileType);
                    reader = null;
                    UploadFile(file);
                }
                else {
                    $("#dvProgress").dialog('close');
                    alert('Please upload specified video format file(s).');
                }
            };
            reader.readAsArrayBuffer(TargetFile[0].slice(FileStreamPos, EndPos));
        }
        else {
            $("#dvProgress").dialog('close');
            alert('Please upload video within ' + UploadLimitMB + ' MB');
        }
    }

    function UploadFile(file) {
        //alert('Upload started');
        //LoadModalDiv();
        //if ($("#ContentBody_hdnFileName").val() != FileNamePrefix && $("#ContentBody_hdnIsfileUploaded").val() == "1") {
        //    alert("More than one video is not allowed.");
        //    return;
        //}

        // create array to store the buffer chunks
        var FileChunk = [];
        // the file object itself that we will work with
        //var file = TargetFile[0];
        // set up other initial vars

        var DateTimeStampFormat = "{Date}{Month}{Year}{Hour}{Minute}{Second}";
        var d = new Date();
        var DateTimeStamp = DateTimeStampFormat.timeStampFormat({ Date: d.getDate(), Month: (d.getMonth() + 1), Year: d.getFullYear(), Hour: (d.getHours() + 1), Minute: (d.getMinutes() + 1), Second: (d.getSeconds() + 1) });

        //alert('DateTimeStamp :' + DateTimeStamp);

        var fileExt = file.name.substring(file.name.lastIndexOf('.') + 1);
        var AbsoluteFileName = FileNamePrefix + DateTimeStamp + "_" + fileExt + "." + fileExt;
        var MaxFileSizeMB = 1;
        var BufferChunkSize = MaxFileSizeMB * (1024 * 1024);
        var ReadBuffer_Size = 1024;
        var FileStreamPos = 0;
        // set the initial chunk length
        var EndPos = BufferChunkSize;
        var Size = file.size;

        // add to the FileChunk array until we get to the end of the file
        while (FileStreamPos < Size) {
            // "slice" the file from the starting position/offset, to  the required length
            FileChunk.push(file.slice(FileStreamPos, EndPos));
            FileStreamPos = EndPos; // jump by the amount read
            EndPos = FileStreamPos + BufferChunkSize; // set next chunk length
        }
        // get total number of "files" we will be sending
        var TotalParts = FileChunk.length;
        var eachPercent = parseFloat((1 / TotalParts) * 100);

        var PartCount = 0;
        //var ArrFileType = ["video/mp4", "video/x-ms-wmv", "video/3gpp", "video/x-matroska", "video/avi", "video/webm", "video/flv", "video/quicktime", "video/ts"];
        var ArrFileType = ["mp4", "wmv", "3gp", "3gpp", "mkv", "avi", "webm", "flv", "mov", "ts"];
        var FileType = file.type;
        FileType = file.name.substring(file.name.lastIndexOf('.') + 1).toLowerCase();
        /*Check file type */
        //alert('FileType :' + FileType);
        var found = $.inArray(FileType, ArrFileType);
        if (found >= 0) {
            //alert('FileType supported');

            for (var i = 1; i <= 3; i++) {

                if (i == 1) {
                    // loop through, pulling the first item from the array each time and sending it
                    while (chunk = FileChunk.shift()) {
                        PartCount++;
                        // file name convention.name "aaaaaaaa." + file.type.split('/')[1]    file.name
                        var FilePartName = AbsoluteFileName + ".part_" + PartCount + "." + TotalParts;
                        FilePartName = FilePartName.split(' ').join('_');

                        // send the file

                        UploadFileChunk(chunk, FilePartName, PartCount, TotalParts, eachPercent, AbsoluteFileName);
                        //UploadFileChunk(chunk, FilePartName, eachPercent, AbsoluteFileName);
                    }
                }
                else {
                    if (FileArray.length > 0) {

                        ResendFile(TargetFile, AbsoluteFileName);
                    }
                }
            }
        }
        else {
            $("#dvProgress").dialog('close');
            alert('Please upload specified video format file(s).');
        }
    }

    function UploadFileChunk(Chunk, FileName, PartCount, TotalParts, eachPercent, AbsoluteFileName) {//PartCount, TotalParts,
        var FD = new FormData();
        var Perct = parseInt((PartCount / TotalParts) * 100);
        //console.log('[' + PartCount + ',' + TotalParts + ',' + Perct + ']');
        var furl = $("#hdnContestWebAPIURL").val() + Perct;
        //var furl = 'http://180.179.206.34:84/api/FileUpload?Perct=' + Perct;
        var UploadStatus = '';

        FD.append('file', Chunk, FileName);
        $.ajax({
            async: true,
            type: "POST",
            url: furl,
            contentType: false,
            processData: false,
            data: FD,
            success: function (result) {
                UploadStatus = eval('(' + JSON.stringify(result) + ')');
                totalPercent = (totalPercent + eachPercent);
                //console.log(totalPercent);
                updateProgress(parseInt(totalPercent));
                //console.log(UploadStatus.UploadPerct);
                if (UploadStatus.TotalFileCnt == 0) {
                    updateProgress(parseInt(100));
                    setTimeout(function () {
                        $("#ContentBody_hdnIsfileUploaded").val("1");
                        uploadVideoCount = uploadVideoCount + 1;
                        $('#ContentBody_hdntotalFileUploadCount').val(uploadVideoCount);
                        //alert('File uploaded successfully.');
                        $("#dvProgress").dialog('close');
                        totalPercent = 0;
                        $("#ContentBody_lblStatus").text("0%");
                        GetVideoThumbnail(AbsoluteFileName);
                    }, 1000);
                }

            },
            //complete: function () {
            //    updateProgress(Perct);
            //},
            error: function (err) {
                var msg = err;
                FileArray.push(FileName);
            }
        });
    }
    function LoadModalDiv() {
        $("#dvProgress").dialog({
            open: function (event, ui) {
                //$(this).closest('.ui-dialog').find('.ui-dialog-titlebar-close').hide();
                $(this).closest('.ui-dialog').find('.ui-dialog-titlebar').hide();
            },
            title: "", // "Please wait....",
            width: 280,
            //height: 157,
            modal: true
        });
        $('#dvProgress').dialog('open');
    }
    function updateProgress(val) {

        //$("#dvProgress").innerHTML((val).toString() + "%");
        $("#ContentBody_lblStatus").text((val).toString() + "%");

    }
    function ResendFile(TargetFile, AbsoluteFileName) {
        // create array to store the buffer chunks
        var FileChunk = [];
        // the file object itself that we will work with
        var file = TargetFile[0];
        // set up other initial vars
        var MaxFileSizeMB = 1;
        var BufferChunkSize = MaxFileSizeMB * (1024 * 1024);
        var ReadBuffer_Size = 1024;
        var FileStreamPos = 0;
        // set the initial chunk length
        var EndPos = BufferChunkSize;
        var Size = file.size;

        // add to the FileChunk array until we get to the end of the file
        while (FileStreamPos < Size) {
            // "slice" the file from the starting position/offset, to  the required length
            FileChunk.push(file.slice(FileStreamPos, EndPos));
            FileStreamPos = EndPos; // jump by the amount read
            EndPos = FileStreamPos + BufferChunkSize; // set next chunk length
        }
        // get total number of "files" we will be sending
        var TotalParts = FileChunk.length;
        var eachPercent = parseFloat((1 / TotalParts) * 100);
        var PartCount = 0;
        var ArrFileType = ["video/mp4", "video/wmv", "video/3gp", "video/mkv", "video/avi", "video/webm", "video/flv", "video/mov", "video/ts"];
        var FileType = file.type;
        /*Check file type */
        var found = $.inArray(FileType, ArrFileType);

        // loop through, pulling the first item from the array each time and sending it
        while (chunk = FileChunk.shift()) {
            PartCount++;
            // file name convention.name "aaaaaaaa." + file.type.split('/')[1]    file.name
            var FilePartName = AbsoluteFileName + ".part_" + PartCount + "." + TotalParts;
            FilePartName = FilePartName.split(' ').join('_');

            // send the file
            if ($.inArray(FilePartName, FileArray) != -1) {

                FileArray.splice($.inArray(FilePartName, FileArray), 1);

                UploadFileChunk(chunk, FilePartName, PartCount, TotalParts, eachPercent, AbsoluteFileName);

            }
        }

    }

    function GetVideoThumbnail(fname) {

        $.ajax({
            url: 'ParticipationEntry.aspx/GetVideoThumbnailImg',
            type: 'POST',
            //data: "{ 'vidBase64Str': '" + Base64String + "', 'isdelete': 'no', 'isdefault': '0'}",
            data: "{ 'fname': '" + fname + "' }",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                //alert('GetVideoThumbnail success');
                //-------------------------------------------   
                var eText = "";
                var imghtml = "<img src=" + data.d + " class='img-responsive'>";
                var div = document.createElement("div");
                var createDiv = '<div class=\"col-md-6 col-sm-6 col-xs-12 \" style=\"padding-right: 0.5%;\"><div class=\"photo\" style=\"margin-top:15px; position:relative; overflow:hidden; \"><input type=\"button\" value=\"X\" class=\"blue_box4 clearUpdVdo\" style=\"background: #c10b1c; z-index: 100; border: none; color:#fff; padding: 0 15px 0 15px; position:absolute; top:3px; right:4px;\" /><span style=\"display: none;\"></span><span style=\"display: block; margin-top: 28px;\" class=\"noneSpan\">' + imghtml + '</span><div class=\"video-container-default\" style=\"display:none;\"> ';

                var createVideo = eText;
                var endDiv = '</div></div></div>';
                var all = createDiv + createVideo + endDiv;
                div.innerHTML = all;

                $('#vidvdoPreview').append(div);

                $.ajax({
                    url: 'ParticipationEntry.aspx/GetVdoLinks',
                    type: 'POST',
                    data: "{ 'filename': '" + fname + "', 'isdelete': 'no', 'isdefault': '0' }",
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: function (data) {
                        $('#ContentBody_hdntotalFileUploadCount').val(data.d);

                        if (parseInt($('#ContentBody_hdntotalFileUploadCount').val()) > 0) {
                            $("label[for=ContentBody_rdvdotypelst_VideoUpload_Pasteembedcode_1],#ContentBody_rdvdotypelst_VideoUpload_Pasteembedcode_1").hide();
                        }

                        //rearrange...
                        $('.clrBoth').remove();
                        var a = $('#vidvdoPreview div div.col-md-6.col-sm-6.col-xs-12');
                        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Windows Phone|DROID|ZuneWP7|Kindle|Playbook|Nexus|Xoom|SM-N900T|GT-N7100|SAMSUNG-SGH-I717|SM-T330NU/i.test(navigator.userAgent)) {
                            var ua = navigator.userAgent.toLowerCase();
                            if (ua.indexOf("mobile") != -1) {
                                //mobile
                                for (var i = 0; i < a.length; i += 1) {
                                    $('#vidvdoPreview div.col-md-6.col-sm-6.col-xs-12:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                }
                            }
                            else {
                                //tablet
                                for (var i = 0; i < a.length; i += 1) {
                                    $('#vidvdoPreview div.col-md-6.col-sm-6.col-xs-12:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                }
                            }
                        }
                        else {
                            //web:desktop/laptop
                            for (var i = 0; i < a.length; i += 2) {
                                $('#vidvdoPreview div.col-md-6.col-sm-6.col-xs-12:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                            }
                        }
                        //--------------------
                    },
                    error: function (xhr, textStatus, errorThrown) {
                        jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
                    }
                });




                //clicking on clear button...
                div.children[0].children[0].children[0].addEventListener("click", function (event) {
                    //$(".blue_box4.clearUpdVdo").bind("click", function (event) {
                    event.preventDefault();

                    $("input[id*= 'fileupd_']").val('');
                    $.ajax({
                        url: 'ParticipationEntry.aspx/GetVdoLinks',
                        type: 'POST',
                        data: "{ 'filename': '" + fname + "', 'isdelete': 'yes', 'isdefault': '0' }",
                        contentType: "application/json; charset=utf-8", dataType: "json",
                        success: function (data) {
                            $('#ContentBody_hdntotalFileUploadCount').val(data.d);

                            if (parseInt($('#ContentBody_hdntotalFileUploadCount').val()) <= 0) {
                                $("label[for=ContentBody_rdvdotypelst_VideoUpload_Pasteembedcode_1],#ContentBody_rdvdotypelst_VideoUpload_Pasteembedcode_1").show();
                                //$("#ContentBody_hdnFileName").val(FileNamePrefix);
                            }

                            //rearrange...
                            $('.clrBoth').remove();
                            var a = $('#vidvdoPreview div div.col-md-6.col-sm-6.col-xs-12');
                            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Windows Phone|DROID|ZuneWP7|Kindle|Playbook|Nexus|Xoom|SM-N900T|GT-N7100|SAMSUNG-SGH-I717|SM-T330NU/i.test(navigator.userAgent)) {
                                var ua = navigator.userAgent.toLowerCase();
                                if (ua.indexOf("mobile") != -1) {
                                    //mobile
                                    for (var i = 0; i < a.length; i += 1) {
                                        $('#vidvdoPreview div.col-md-6.col-sm-6.col-xs-12:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                    }
                                }
                                else {
                                    //tablet
                                    for (var i = 0; i < a.length; i += 1) {
                                        $('#vidvdoPreview div.col-md-6.col-sm-6.col-xs-12:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                    }
                                }
                            }
                            else {
                                //web:desktop/laptop
                                for (var i = 0; i < a.length; i += 2) {
                                    $('#vidvdoPreview div.col-md-6.col-sm-6.col-xs-12:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                }
                            }

                            //-----------------------------------

                        },
                        error: function (xhr, textStatus, errorThrown) {
                            jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
                        }
                    });

                    $(this).parent().parent().parent().remove();

                });


                //-------------------------------------------

            },
            error: function (err) {
                alert('An error occured.');
            },
            async: false
        });

    }

});