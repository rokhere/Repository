$(window).load(function(){
	$('.image-holder figure').each(function(i) {		
		$(this).delay().fadeTo(1, 1);
	});
})