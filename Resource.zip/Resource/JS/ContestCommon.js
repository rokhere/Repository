﻿// JScript File

function ConfirmStatus(dispMsg, parentPage) {
    var ans = confirm(dispMsg, "Confirm Window");
    if (ans == false) {
        ConfirmContinuation('Record added successfully.  Want to add other detail ?', parentPage);
    }
}
function ConfirmContinuation(dispMsg, parentPage) {
    var ans = confirm(dispMsg, "Confirm Window");
    if (ans == false) {
        window.location.href = window.location.href.replace(/\?.*$/, "");
    }
    else {
        if (parentPage != "") {
            window.location.href = parentPage;
        }
    }
}
function AlertWithLocation(dispMsg, parentPage) {
    if (dispMsg != "")
        window.alert(dispMsg);
    window.location.href = parentPage;
}

function OnlyLocation(dispMsg, parentPage) {
    if (dispMsg != "")
        parent.location = parentPage;
}

function AlertLocationFromIframe(dispMsg, parentPage) {
    if (dispMsg != "")
        window.alert(dispMsg);
    parent.location = parentPage;
}

//Custom validation function for Calender
function ValidateCalenderDate(sender, arg) {
    //alert('Inside Validator');
    var val = arg.Value.split('/');
    if (val.length != 3) {
        arg.IsValid = false;
        return
    }
    var d, m, y;
    d = parseInt(val[0], 10);
    m = parseInt(val[1], 10);
    y = parseInt(val[2], 10);
    //alert(d+","+m+","+y);
    if (isNaN(d) || isNaN(m) || isNaN(y)) {
        arg.IsValid = false;
        return
    }
    if ((d < 1 || d > 31) || (m < 1 || m > 12) || (y < 1900 || y > 2100)) {
        arg.IsValid = false;
        return
    }
    try {
        var calDate = new Date(y + "/" + m + "/" + d);
        if (calDate.getDate() != d) {
            arg.IsValid = false;
            return
        }
    }
    catch (e) {
        arg.IsValid = false;
        return
    }
    if (sender != undefined ? sender.controltovalidate != undefined : false) {
        var strDate = "";
        if (d.toString().length == 1) {
            strDate = "0" + d.toString();
        }
        else {
            strDate = d.toString();
        }
        if (m.toString().length == 1) {
            strDate = strDate + '/' + "0" + m.toString();
        }
        else {
            strDate = strDate + '/' + m.toString();
        }
        strDate = strDate + '/' + y.toString();
        document.getElementById(sender.controltovalidate).value = strDate;
    }
}
/*************************************************/
function OpenToCenterPopup(url, name, width, height) {
    //alert(url);
    var centerWidth = (window.screen.width - width) / 2;
    var centerHeight = (window.screen.height - height) / 2;
    var mywindow = window.open(url, 'Thanks', 'height=' + height + ',width=' + width + ',left=' + centerWidth + ',top=' + centerHeight + 'toolbar=no,directories=no,status=no,linemenubar=no,scrollbars=yes,resizable=yes ,modal=yes');
    return false;
}
function ddlvalidate(source, args) {
    if (document.getElementById(source.controltovalidate).value == "-10")
        args.IsValid = false;
    else
        args.IsValid = true;
}
function URLvalidate(source, args) {
    if (document.getElementById(source.controltovalidate).value.indexOf("http://") == 0 || document.getElementById(source.controltovalidate).value.indexOf("https://") == 0)
        args.IsValid = true;
    else
        args.IsValid = false;
}
function UserInterfaceCharactervalidate(source, args) {
    if (document.getElementById(source.controltovalidate).value.search(">") >= 0 || document.getElementById(source.controltovalidate).value.search("<") >= 0 || document.getElementById(source.controltovalidate).value.indexOf('+') >= 0 || document.getElementById(source.controltovalidate).value.indexOf('&') >= 0 || document.getElementById(source.controltovalidate).value.indexOf('"') >= 0 || document.getElementById(source.controltovalidate).value.indexOf("'") >= 0 || document.getElementById(source.controltovalidate).value.indexOf('%') >= 0 || document.getElementById(source.controltovalidate).value.indexOf(';') >= 0 || document.getElementById(source.controltovalidate).value.indexOf(")") >= 0 || document.getElementById(source.controltovalidate).value.indexOf("(") >= 0 || document.getElementById(source.controltovalidate).value.indexOf('-') >= 0)
        args.IsValid = false;
    else
        args.IsValid = true;
}
function jAlert(paramMSG) {
    $j.msgbox(paramMSG);
}
function jAlertWithHref(paramMSG, url) {
    $j.msgbox(paramMSG,
        {
            type: "alert",
            buttons: [{ type: "submit", value: "Ok" }]
        }, function (result) {
            if (result) {
                if (url != "") {
                    window.location.href = url;
                }
            }
        });
}
function jConfirmWithHref(paramMSG, url) {
    $j.msgbox(paramMSG,
        {
            type: "confirm",
            buttons: [{ type: "submit", value: "Yes" }, { type: "cancel", value: "No" }]
        }, function (result) {
            if (result) {
                if (url != "") {
                    window.location.href = url;
                }
            }
        });
}
function jConfirm(paramMSG) {
    $j.msgbox(paramMSG, {
        type: "confirm",
        buttons: [{ type: "submit", value: "Yes" }, { type: "submit", value: "No" },//{ type: "cancel", value: "Cancel" }
        ]
    }, function (result) {
        $j("#result2").text(result);
    });
}
function jError(paramMSG) {
    $j.msgbox(paramMSG, { type: "error" });
}
function alertRestrictionCommon(refferPage) {
    alert("Access of this page is restricted for you.");
    window.location.href = refferPage;
}
//  function CustomConfirm(paramMSG) {
//      jConfirm(paramMSG, 'Confirmation Dialog',

//	function (r) {
//	    if (r == true) {
//	        //$j("#box").fadeOut(300);
//	        return true;
//	    }
//	    else
//	        return false;
//	});
//  }
function controlEnter(obj, event) {
    var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
    if (keyCode == 13) {
        document.getElementById(obj).click();
        return false;
    }
    else {
        return true;
    }
}