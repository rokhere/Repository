﻿

$(document).ready(function () {
    var vdotype = 0;
    $("input[id*= 'rdvdotypelst_']").on('change', function (event) {
        event.preventDefault();
        var selectedValue = $(this).val();
        var selectedText = $(this).next().html();
        $("input[id*= 'updvdotxt_']").val('');
        $('#red_URL').remove(); //remove validation text

        if (selectedValue == 0) {
            $("div[id*= 'mbdPnl_']").show();
            $("div[id*= 'vdoUpdPnl_']").hide();
        }
        else if (selectedValue == 1) 
        {
            $("div[id*= 'mbdPnl_']").hide();
            $("div[id*= 'vdoUpdPnl_']").show();
        }
        else{
            $("div[id*= 'mbdPnl_']").hide();
            $("div[id*= 'vdoUpdPnl_']").hide();
        }

    }); //edn of radiobtn list selection change

});



var fluId = $("input[id*= 'fileupd_']")[0].id;

var vfilelist = [];

$("input[id*= 'fileupd_']").on('change', function (event) {
    event.preventDefault();
    var file = event.target.files;
    var fname = "defaultvideothumbnail.jpg";
    for (var i = 0; i < file.length; i++) {

        if ($.inArray(file[i].name, vfilelist) == -1) {
            // not found it...
            vfilelist.push(file[i].name);
            GetVideoThumbnailDmy(fname, file[i].name);
        }         
        
    }
  
});


function GetVideoThumbnailDmy(fname,actname) {
    $.ajax({
        url: 'ParticipationEntryReplica.aspx/GetVideoThumbnailImgDummy',
        type: 'POST',
        data: "{ 'fname': '" + fname + "' }",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            //-------------------------------------------   
            var eText = "";
            var imghtml = "<img src=" + data.d + " class='img-responsive' >";
            var div = document.createElement("div");
            var createDiv = '<div class=\"col-md-6 col-sm-6 col-xs-12 \" style=\"padding-right: 0.5%;\"><div class=\"photo\" style=\"margin-top:15px\"><input type=\"button\" value=\"Clear\" class=\"blue_box4\" style=\"background: #c10b1c; z-index: 999; border: none; color:#fff; padding: 0 10px 0 10px\" /><span style=\"display: none;\"></span><span style=\"display: block;\" class=\"noneSpan\">' + imghtml + '</span><div class=\"video-container-default\">';
            var createVideo = eText; var endDiv = '</div></div></div>';
            var all = createDiv + createVideo + endDiv; div.innerHTML = all;
            $('#vidvdoPreview').append(div);
            
            //clear btn...
            div.children[0].children[0].children[0].addEventListener("click", function (event) {
                event.preventDefault();
                $("input[id*= 'fileupd_']").val('');
                vfilelist.remove(actname, true);                
                $(this).parent().parent().parent().remove();
            });
            //-------------------------------------------

        },
        error: function (err) {
            alert('error');
        },
        async: false
    });

}


if (!Array.prototype.remove) {
    Array.prototype.remove = function (val, all) {
        var i, removedItems = [];
        if (all) {
            for (i = this.length; i--;) {
                if (this[i] === val) removedItems.push(this.splice(i, 1));
            }
        }
        else {  //same as before...
            i = this.indexOf(val);
            if (i > -1) removedItems = this.splice(i, 1);
        }
        return removedItems;
    };
}

String.prototype.format = function () {
    var str = this; for (var i = 0; i < arguments.length; i++) {
        var reg = new RegExp("\\{" + i + "\\}", "gm");
        str = str.replace(reg, arguments[i]);
    } return str;
}