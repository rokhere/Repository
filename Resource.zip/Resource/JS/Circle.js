function openNav() {
    OnCloseClick('0');
    document.getElementById("mySidenav").style.width = "60px";
    document.getElementById("mySidenav1").style.width = "40px";
    $('#divArrow').removeClass();
    $('#divArrow').addClass('cirImgNext');
}

function closeNav() {
    OnCloseClick('1');
    document.getElementById("mySidenav").style.width = "0px";
    document.getElementById("mySidenav1").style.width = "40px";

    $('#divArrow').removeClass();
    $('#divArrow').addClass('cirImgPrev');
}

var a = true;;
function openClose() {
    //console.log('click fire');
    a = !a;
    if (a == true) {
        openNav();
    }
    else {
        closeNav();
    }
}

function OnCloseClick(ofrDtlId) {

    $.ajax({
        url: "GamePlay.aspx/OnCloseClick",
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        data: '{ofrDtlId :' + ofrDtlId + '}',
        beforeSend: function () {
        },
        success: function (response) {
        },
        complete: function () {
        },
        error: function (response) {
            console.log('Error: Some thing is wrong');
        }
    });
}

/*Carousal Start*/


function fn_PrepareCarousel() {
    var foresee = $("#");
    //find items to display
    var items = foresee.data('carousel-items') || 1;
    var foresee1 = $("#foresee-demo-carousel1, #foresee-demo-carousel2");
    foresee.foreseeCarousel({
        items: items, //10 items above 1000px browser width
        itemsDesktop: [1000, 5], //5 items between 1000px and 901px
        itemsDesktopSmall: [900, 4], // betweem 900px and 601px
        itemsTablet: [600, 3], //2 items between 600 and 361
        itemsMobile: true, // itemsMobile disabled - inherit from itemsTablet option
        autoPlay: true,
    });

    foresee1.foreseeCarousel({
        items: items, //10 items above 1000px browser width
        itemsDesktop: [1000, 5], //5 items between 1000px and 901px
        itemsDesktopSmall: [900, 4], // betweem 900px and 601px
        itemsTablet: [600, 3], //2 items between 600 and 361
        itemsMobile: [360, 2],
        autoPlay: true,
    });






    //use for mobile listing banner//
    var foresee3 = $("#foresee-demo-carousel3");
    foresee3.foreseeCarousel({
        items: items, //10 items above 1000px browser width
        itemsDesktop: [1000, 5], //5 items between 1000px and 901px
        itemsDesktopSmall: [900, 1], // betweem 900px and 601px
        itemsTablet: [600, 1], //2 items between 600 and 361
        itemsMobile: [360, 1], // itemsMobile disabled - inherit from itemsTablet option
        autoPlay: true,
    });
    var foresee4 = $("#foresee-demo-carousel4");
    foresee4.foreseeCarousel({
        items: items, //10 items above 1000px browser width
        itemsDesktop: [1000, 1], //5 items between 1000px and 901px
        itemsDesktopSmall: [900, 1], // betweem 900px and 601px
        itemsTablet: [600, 1], //2 items between 600 and 361
        itemsMobile: [360, 1],
        autoPlay: true,
        mouseDrag: true,
        touchDrag: true,
    });
};



/*Carousal End*/