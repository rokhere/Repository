﻿//---------------------------------------------------
//Embed Videos: Youtube,Facebook,Google+
//---------------------------------------------------
function youtube_parser(url) {
    var regExp = "^.*((youtu.be\\/)|(v\\/)|(\\/u\\/\\w\\/)|(embed\\/)|(watch\\?))\\??v?=?([^#\\&\\?]*).*";
    var match = url.match(regExp); if (match && match[7].length == 11) { return match[7]; } else { return ''; }
}

function build_youtube_embed(vdovid) {
    var ifrm = "<iframe width='560' height='315' src='https://www.youtube.com/embed/{0}' frameborder='0' allowfullscreen></iframe>";
    var _ifrm = ifrm.format(vdovid); return _ifrm;
}
//---------------------------------------------------
function extract_facebook_url(rawembed) {
    var _rawembed = rawembed.replace(/"/g, '');
    var indxofQsmrk = _rawembed.indexOf('?');
    if (indxofQsmrk > 0) {
        _rawembed = _rawembed.substr(0, indxofQsmrk);
    }

    if (valid_facebook_url(rawembed) == false) {
        var s2 = ''; var s1 = _rawembed.split('data-href=');
        if (s1.length > 0) { s2 = s1[1].split('>')[0]; } return s2;
    }
    else { return _rawembed; }
}

function extract_facebook_vedioid(fburl) {
    var _url = fburl; var _elms = _url.split('/');
    if (_url.substr(_url.length - 1) == '/') {
        return _elms[_elms.length - 2];
    }
    else { return _elms[_elms.length - 1]; }
}

function valid_facebook_url(url) {
    var regExp = /^(http\:\/\/|https\:\/\/)?(?:www\.)?facebook\.com\/(?:(?:\w\.)*#!\/)?(?:pages\/)?(?:[\w\-\.]*\/)*([\w\-\.]*)/;
    var match = url.match(regExp);
    if (match) return true; else return false;
}

function build_facebook_grapgh_call(_id) {
    var _date = new Date().toUTCString();
    var ifrm = "<iframe width='450' height='315' src='https://www.facebook.com/video/embed?video_id={0}' frameborder='0' allowfullscreen></iframe>";
    var _ifrm = ifrm.format(_id);
    var x = { 'data': [{ 'id': _id, 'created_time': _date, 'description': '', 'embed_html': _ifrm, 'format': [] }] }; return $(x.data)[0].embed_html;
}
//---------------------------------------------------
function gplus_parser(url) {
    var regExp = /^(http\:\/\/|https\:\/\/)?(?:www\.)?google\.com\/(?:(?:\w\.)*#!\/)?(?:[\w\-\.]*\/)*([\w\-\.]*)/;
    var match = url.match(regExp); if (match) {
        if (url.contains('.txt'))
            return false;
        else
            return true;

    } else { return false; }
}

function build_gplus_embed(vdovid) {
    var ifrm = "<iframe width='480' height='315' src='{0}' width='480' height='320' frameborder='0' allowfullscreen></iframe>";
    var _ifrm = ifrm.format(vdovid); return _ifrm;
}
//---------------------------------------------------
function jAlertWithHref(paramMSG, url) {
    $.msgbox(paramMSG); //it is defined in "jquery.msgbox.min.js"
    if (url != "")
        window.location.href = url;
}

String.prototype.format = function () {
    var str = this; for (var i = 0; i < arguments.length; i++) {
        var reg = new RegExp("\\{" + i + "\\}", "gm");
        str = str.replace(reg, arguments[i]);
    } return str;
}

String.prototype.contains = function (s) {
    var str = this; if (arguments.length > 0) { if (str.indexOf(s) != -1) return true; } return false;
}

//---------------------------------------------------
if (window.File && window.FileList && window.FileReader && window.Blob) {
    //NoOfFiles = 0;
    $(document).on('change', $('#ContentBody_flu_video'), onChange);
}

function onChange(event) {
    //event.preventDefault();
    //var _files = event.target.files;      
    //var _dataURL = "File1";


    //for (var i = 0; i < _files.length; i++) {
    //    var filename = _files[i];

    //    var reader = new FileReader();
    //    reader.readAsDataURL(filename);
    //    console.log(reader);

    //    var _dataURL = reader.result;

    //    console.log('--------------------------');
    //    console.log(_dataURL);
    //    console.log('--------------------------');

    //    reader.onload = function (readerEvent) {
    //        alert('reader load...');
    //        var video = document.getElementById(vidPreview);
    //        var canvas = document.createElement("canvas");
    //        //canvas.getContext('2d').drawImage(video, 0, 0, 200, 150)
    //        var dataURL = canvas.toDataURL('video/mp4');
    //        //alert('Hello ' + dataURL);


    //        $.ajax({
    //            url: 'ParticipationEntry.aspx/GetVideoFiles',
    //            type: 'POST',
    //            //data: "{ 'filename': '" + filename.name + "', 'isdelete': 'no', 'isdefault': '0'}",
    //            //data: {}, // "{ 'filename': '" + _dataURL + "' }",
    //            data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '0'}",
    //            contentType: "application/json; charset=utf-8",
    //            dataType: "json",
    //            success: function (data) {
    //                //if (uploadfCnt < data.d)
    //                //    uploadfCnt = data.d;
    //                //$('#ContentBody_hdntotalFileUploadCount').val(uploadfCnt);
    //                console.log(data.d);
    //                alert(data.d);
    //            },
    //            async: false
    //        });
    //    };

    //} //end of for 

    //-----------------------------------------------
    //alert('change called');
    //var files = event.target.files;
    //var fileUpload = $("#fupload").get(0);
    //var files = fileUpload.files;

    //var fileUpload = $("#ContentBody_flu_video").get(0);
    //var files = fileUpload.files;
    //console.log(files);

    //var data = new FormData();
    //for (var i = 0; i < files.length; i++) {
    //    data.append(files[i].name, files[i]);
    //    console.log(data);
    //}

    //$.ajax({
    //    url: "http://192.168.2.69:8090/UploadVideo.ashx?m=150",
    //    type: "POST",
    //    data: data,
    //    contentType: false,
    //    processData: false,
    //    success: function (result) { alert(result); },
    //    error: function (err) {
    //        //alert(err.statusText)
    //    }
    //});

    //-----------------------------------------------

};

//---------------------------------------------------
//only for youtube
$(document).on('click', '#btn_SetVideo', function () {
    var tb = $('input[id*="ContentBody_updvdotxt_"]'); //text box starts with  "updvdotxt_"
    if ($(tb).val().length > 0) {
        if ($(tb).val().toLowerCase().indexOf('alert') >= 0) {
            return;
        }
        var utb_url = $(tb).val().trim();
        if (utb_url.contains('youtu')) //if youtu
        {

            if ($(tb).val().toLowerCase().indexOf('script') < 0 && $(tb).val().toLowerCase().indexOf('javascript') < 0) {

                var video_url = utb_url.split(' ');
                var _vdosrc = "\\";
                if (video_url.length == 1)
                { _vdosrc = video_url[0]; }
                else
                {
                    for (var i = 0; i < video_url.length; i++) {
                        if (video_url[i].indexOf("src=") != -1) {
                            _vdosrc = video_url[i].split("src=")[1]; _vdosrc = _vdosrc.replace(/"/g, "");
                            break;
                        }
                    }
                }

                var utid = youtube_parser(_vdosrc);
                if (utid == '') { $(tb).val(''); return; }
                var eText = build_youtube_embed(utid);
                var str = build_youtube_embed(utid);
                eText = eText.replace(/'/g, '"'); //**
                var encodedText; var result = {}; str = str.replace(/\\s+/g, ' ').replace(/\\=s/g, '=').replace(/\\s=/g, '=');
                str.split(' ').forEach(function (x) {
                    var arr = x.split('='); arr[1] && (result[arr[0]] = arr[1]);
                    if (arr[0] == 'src')
                    { encodedText = escape(arr[1]); }
                });

                if ($("span:contains(" + encodedText + ")").text().length <= 0) {
                    var div = document.createElement("div");
                    var createDiv = '<div class=\"col-md-6 col-sm-6 col-xs-12 \" style=\"padding-right: 0.5%;\"><div class=\"photo\" style=\"margin-top:15px; position:relative; overflow:hidden;\"><input type=\"button\" value=\"X\" class=\"blue_box4 clearVdo\" style=\"background: #c10b1c; z-index: 999; border: none; color:#fff; padding: 0 15px 0 15px; position:absolute; top:3px; right:4px;\" /><span style=\"display: none;\">' + escape(eText) + '</span><span style=\"display: none;\" class=\"noneSpan\">' + encodedText + '</span><div class=\"video-container\"  style=\"margin-top:28px;\">';

                    var createVideo = eText;
                    var endDiv = '</div></div></div>';
                    var all = createDiv + createVideo + endDiv;
                    div.innerHTML = all;

                    $('#vidPreview').append(div);


                    $.ajax({
                        url: 'ParticipationEntry.aspx/GetLinks',
                        type: 'POST',
                        data: "{ 'link': '" + eText + "', 'isdelete': 'no' }",
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: function (data) {
                            $('#ContentBody_hdntotalFileUploadCount').val(data.d);

                            if (parseInt($('#ContentBody_hdntotalFileUploadCount').val()) > 0) {
                                $("label[for=ContentBody_rdvdotypelst_VideoUpload_Pasteembedcode_0],#ContentBody_rdvdotypelst_VideoUpload_Pasteembedcode_0").hide()
                            }

                            //rearrange...
                            $('.clrBoth').remove();
                            var a = $('#vidPreview div div.col-md-6.col-sm-6.col-xs-12');
                            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Windows Phone|DROID|ZuneWP7|Kindle|Playbook|Nexus|Xoom|SM-N900T|GT-N7100|SAMSUNG-SGH-I717|SM-T330NU/i.test(navigator.userAgent)) {
                                var ua = navigator.userAgent.toLowerCase();
                                if (ua.indexOf("mobile") != -1) {
                                    //mobile
                                    for (var i = 0; i < a.length; i += 1) {
                                        $('#vidvdoPreview div.col-md-6.col-sm-6.col-xs-12:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                    }
                                }
                                else {
                                    //tablet
                                    for (var i = 0; i < a.length; i += 1) {
                                        $('#vidvdoPreview div.col-md-6.col-sm-6.col-xs-12:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                    }
                                }
                            }
                            else {
                                //web:desktop/laptop
                                for (var i = 0; i < a.length; i += 2) {
                                    $('#vidvdoPreview div.col-md-6.col-sm-6.col-xs-12:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                }
                            }

                            //-----------------------------------

                        },
                        error: function (xhr, textStatus, errorThrown) {
                            jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
                        }
                    });

                    //clicking on clear button...
                    div.children[0].children[0].children[0].addEventListener("click", function (event) {
                    //$(".blue_box4.clearVdo").bind("click", function (event) {
                        event.preventDefault();
                        
                        $.ajax({
                            url: 'ParticipationEntry.aspx/GetLinks',
                            type: 'POST',
                            data: "{ 'link': '" + unescape($(this).next().text()) + "', 'isdelete': 'yes' }",
                            contentType: "application/json; charset=utf-8",
                            dataType: "json",
                            success: function (data) {
                                $('#ContentBody_hdntotalFileUploadCount').val(data.d);
                                
                                if (parseInt($('#ContentBody_hdntotalFileUploadCount').val()) <= 0) {
                                    $("label[for=ContentBody_rdvdotypelst_VideoUpload_Pasteembedcode_0],#ContentBody_rdvdotypelst_VideoUpload_Pasteembedcode_0").show();
                                }

                                //rearrange...
                                $('.clrBoth').remove();
                                var a = $('#vidPreview div div.col-md-6.col-sm-6.col-xs-12');
                                if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Windows Phone|DROID|ZuneWP7|Kindle|Playbook|Nexus|Xoom|SM-N900T|GT-N7100|SAMSUNG-SGH-I717|SM-T330NU/i.test(navigator.userAgent)) {
                                    var ua = navigator.userAgent.toLowerCase();
                                    if (ua.indexOf("mobile") != -1) {
                                        //mobile
                                        for (var i = 0; i < a.length; i += 1) {
                                            $('#vidvdoPreview div.col-md-6.col-sm-6.col-xs-12:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                        }
                                    }
                                    else {
                                        //tablet
                                        for (var i = 0; i < a.length; i += 1) {
                                            $('#vidvdoPreview div.col-md-6.col-sm-6.col-xs-12:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                        }
                                    }
                                }
                                else {
                                    //web:desktop/laptop
                                    for (var i = 0; i < a.length; i += 2) {
                                        $('#vidvdoPreview div.col-md-6.col-sm-6.col-xs-12:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                    }
                                }

                                //-----------------------------------
                            },
                            error: function (xhr, textStatus, errorThrown) {
                                jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
                            }
                        });

                        $(this).parent().parent().parent().remove();
                        //this.parentNode.parentNode.parentNode.remove(div);
                    });

                }//end duplicate embedtext check 

            }

        } //end of youtube

        $(tb).val(''); //clear the input box
        $('#red_URL').remove();
    }
});//only youtube

// $(document).on('click', '#btn_SetVideo', function () {
//    var tb = $('input[id*="ContentBody_updvdotxt_"]'); //text box starts with  "updvdotxt_"

//    if ($(tb).val().length > 0) {

//        if ($(tb).val().toLowerCase().indexOf('alert') >= 0) {
//            return;
//        }

//        var utb_url = $(tb).val().trim();

//        if (utb_url.contains('facebook.com')) {
//            if ($(tb).val().toLowerCase().indexOf('script') >= 0) {               
//                var scriptEndTagIndx = utb_url.indexOf('</script>');
//                if (scriptEndTagIndx > 0) {
//                    var fbembedhtml = utb_url.substr(scriptEndTagIndx + 9);                    
//                    //var fburl = extract_facebook_url(utb_url);
//                    var fburl = extract_facebook_url(fbembedhtml);
//                    if (valid_facebook_url(fburl) == true) {
//                        var vdoid = extract_facebook_vedioid(fburl);
//                        var encodedText = escape(fburl);
//                        if ($("span:contains(" + encodedText + ")").text().length <= 0) {
//                            var eText = build_facebook_grapgh_call(vdoid);
//                            eText = eText.replace(/'/g, '"'); //**   
//                            var div = document.createElement('div');
//                            var createDiv = '<div class=\"col-md-6 col-sm-6 col-xs-12\"  style=\"padding-right: 0.5%;\"><div class=\"photo\" style=\"margin-top:15px\"><input type=\"button\" value=\"Clear\" class=\"blue_box4\" style=\"background: #c10b1c; z-index: 999; border: none; color:#fff; padding: 0 10px 0 10px\" /><span style=\"display: none;\">' + escape(eText) + '</span><span style=\"display:none\"; class=\"noneSpan\">' + encodedText + '</span><div class=\"video-container\">';
//                            var createVideo = eText; var endDiv = '</div></div></div>';
//                            var all = createDiv + createVideo + endDiv; div.innerHTML = all; $('#vidPreview').append(div);
//                            $.ajax({
//                                url: 'ParticipationEntry.aspx/GetLinks', type: 'POST', data: "{ 'link': '" + eText + "', 'isdelete': 'no' }", contentType: "application/json; charset=utf-8", dataType: "json", success: function (data) { $('#ContentBody_hdntotalFileUploadCount').val(data.d) }, error: function (xhr, textStatus, errorThrown) {
//                                    jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
//                                    //console.log('error:' + errorThrown);
//                                }
//                            });
//                            div.children[0].children[0].children[0].addEventListener("click", function (event) {
//                                event.preventDefault();
//                                $.ajax({
//                                    url: 'ParticipationEntry.aspx/GetLinks', type: 'POST', data: "{ 'link': '" + unescape($(this).next().text()) + "', 'isdelete': 'yes' }", contentType: "application/json; charset=utf-8", dataType: "json", success: function (data) { $('#ContentBody_hdntotalFileUploadCount').val(data.d) }, error: function (xhr, textStatus, errorThrown) {
//                                        jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
//                                    }
//                                });

//                                $(this).parent().parent().parent().remove();
//                                //this.parentNode.parentNode.parentNode.remove(div);
//                            });
//                        }//end duplicate embedtext check 
//                    }

//                }   //end of  scriptEndTagIndx>0            

//            }
//            else {
//                //if script tag not there...
//                var fburl = extract_facebook_url(utb_url);
//                if (valid_facebook_url(fburl) == true) {
//                    var vdoid = extract_facebook_vedioid(fburl);
//                    var encodedText = escape(fburl);
//                    if ($("span:contains(" + encodedText + ")").text().length <= 0) {
//                        var eText = build_facebook_grapgh_call(vdoid);
//                        eText = eText.replace(/'/g, '"'); //**   
//                        var div = document.createElement('div');
//                        var createDiv = '<div class=\"col-md-6 col-sm-6 col-xs-12\"  style=\"padding-right: 0.5%;\"><div class=\"photo\" style=\"margin-top:15px\"><input type=\"button\" value=\"Clear\" class=\"blue_box4\" style=\"background: #c10b1c; z-index: 999; border: none; color:#fff; padding: 0 10px 0 10px\" /><span style=\"display: none;\">' + escape(eText) + '</span><span style=\"display:none\"; class=\"noneSpan\">' + encodedText + '</span><div class=\"video-container\">';
//                        var createVideo = eText; var endDiv = '</div></div></div>';
//                        var all = createDiv + createVideo + endDiv; div.innerHTML = all; $('#vidPreview').append(div);
//                        $.ajax({
//                            url: 'ParticipationEntry.aspx/GetLinks', type: 'POST', data: "{ 'link': '" + eText + "', 'isdelete': 'no' }", contentType: "application/json; charset=utf-8", dataType: "json", success: function (data) { $('#ContentBody_hdntotalFileUploadCount').val(data.d) }, error: function (xhr, textStatus, errorThrown) {
//                                jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
//                                //console.log('error:' + errorThrown);
//                            }
//                        });
//                        div.children[0].children[0].children[0].addEventListener("click", function (event) {
//                            event.preventDefault();
//                            $.ajax({
//                                url: 'ParticipationEntry.aspx/GetLinks', type: 'POST', data: "{ 'link': '" + unescape($(this).next().text()) + "', 'isdelete': 'yes' }", contentType: "application/json; charset=utf-8", dataType: "json", success: function (data) { $('#ContentBody_hdntotalFileUploadCount').val(data.d) }, error: function (xhr, textStatus, errorThrown) {
//                                    jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
//                                }
//                            });


//                            $(this).parent().parent().parent().remove();
//                            //this.parentNode.parentNode.parentNode.remove(div);
//                        });
//                    }//end duplicate embedtext check 
//                }
//            }
//        } //end of facebook
//        else if (utb_url.contains('youtu')) //if youtu
//        {

//            if ($(tb).val().toLowerCase().indexOf('script') < 0 && $(tb).val().toLowerCase().indexOf('javascript') < 0) {

//                var video_url = utb_url.split(' ');
//                var _vdosrc = "\\";
//                if (video_url.length == 1)
//                { _vdosrc = video_url[0]; }
//                else
//                {
//                    for (var i = 0; i < video_url.length; i++) {
//                        if (video_url[i].indexOf("src=") != -1) {
//                            _vdosrc = video_url[i].split("src=")[1]; _vdosrc = _vdosrc.replace(/"/g, "");
//                            break;
//                        }
//                    }
//                }

//                var utid = youtube_parser(_vdosrc);
//                if (utid == '') { $(tb).val(''); return; }
//                var eText = build_youtube_embed(utid);
//                var str = build_youtube_embed(utid);
//                eText = eText.replace(/'/g, '"'); //**
//                var encodedText; var result = {}; str = str.replace(/\\s+/g, ' ').replace(/\\=s/g, '=').replace(/\\s=/g, '=');
//                str.split(' ').forEach(function (x) {
//                    var arr = x.split('='); arr[1] && (result[arr[0]] = arr[1]);
//                    if (arr[0] == 'src')
//                    { encodedText = escape(arr[1]); }
//                });

//                if ($("span:contains(" + encodedText + ")").text().length <= 0) {
//                    var div = document.createElement("div");
//                    var createDiv = '<div class=\"col-md-6 col-sm-6 col-xs-12 \" style=\"padding-right: 0.5%;\"><div class=\"photo\" style=\"margin-top:15px\"><input type=\"button\" value=\"Clear\" class=\"blue_box4\" style=\"background: #c10b1c; z-index: 999; border: none; color:#fff; padding: 0 10px 0 10px\" /><span style=\"display: none;\">' + escape(eText) + '</span><span style=\"display: none;\" class=\"noneSpan\">' + encodedText + '</span><div class=\"video-container\">';
//                    var createVideo = eText; var endDiv = '</div></div></div>';
//                    var all = createDiv + createVideo + endDiv; div.innerHTML = all; $('#vidPreview').append(div);
//                    $.ajax({
//                        url: 'ParticipationEntry.aspx/GetLinks', type: 'POST', data: "{ 'link': '" + eText + "', 'isdelete': 'no' }", contentType: "application/json; charset=utf-8", dataType: "json", success: function (data) { $('#ContentBody_hdntotalFileUploadCount').val(data.d) }, error: function (xhr, textStatus, errorThrown) {
//                            jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
//                        }
//                    });
//                    div.children[0].children[0].children[0].addEventListener("click", function (event) {
//                        event.preventDefault(); $.ajax({
//                            url: 'ParticipationEntry.aspx/GetLinks', type: 'POST', data: "{ 'link': '" + unescape($(this).next().text()) + "', 'isdelete': 'yes' }", contentType: "application/json; charset=utf-8", dataType: "json", success: function (data) { $('#ContentBody_hdntotalFileUploadCount').val(data.d) }, error: function (xhr, textStatus, errorThrown) {
//                                jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
//                            }
//                        });

//                        $(this).parent().parent().parent().remove();
//                        //this.parentNode.parentNode.parentNode.remove(div);
//                    });

//                }//end duplicate embedtext check 

//            }

//        } //end of youtube
//        else if (utb_url.contains('google.com')) {

//            var fburl = gplus_parser(utb_url);
//            //alert(fburl);
//            //if (fburl == false) {
//            //    return;
//            //}

//            var fburl = utb_url; //*
//            var eText = build_gplus_embed(fburl);
//            var encodedText = escape(fburl);

//            if ($("span:contains(" + encodedText + ")").text().length <= 0) {
//                eText = eText.replace(/'/g, '"'); //**   
//                var div = document.createElement('div');
//                var createDiv = '<div class=\"col-md-6 col-sm-6 col-xs-12\"  style=\"padding-right: 0.5%;\"><div class=\"photo\" style=\"margin-top:15px\"><input type=\"button\" value=\"Clear\" class=\"blue_box4\" style=\"background: #c10b1c; z-index: 999; border: none; color:#fff; padding: 0 10px 0 10px\" /><span style=\"display: none;\">' + escape(eText) + '</span><span style=\"display:none\"; class=\"noneSpan\">' + encodedText + '</span><div class=\"video-container\">';
//                var createVideo = eText; var endDiv = '</div></div></div>';
//                var all = createDiv + createVideo + endDiv; div.innerHTML = all; $('#vidPreview').append(div);


//                $.ajax({
//                    url: 'ParticipationEntry.aspx/GetLinks', type: 'POST', data: "{ 'link': '" + eText + "', 'isdelete': 'no' }", contentType: "application/json; charset=utf-8", dataType: "json", success: function (data) { $('#ContentBody_hdntotalFileUploadCount').val(data.d) }, error: function (xhr, textStatus, errorThrown) {
//                        jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
//                    }
//                });
//                div.children[0].children[0].children[0].addEventListener("click", function (event) {
//                    event.preventDefault();
//                    $.ajax({
//                        url: 'ParticipationEntry.aspx/GetLinks', type: 'POST', data: "{ 'link': '" + unescape($(this).next().text()) + "', 'isdelete': 'yes' }", contentType: "application/json; charset=utf-8", dataType: "json", success: function (data) { $('#ContentBody_hdntotalFileUploadCount').val(data.d) }, error: function (xhr, textStatus, errorThrown) {
//                            jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
//                        }
//                    });

//                    $(this).parent().parent().parent().remove();
//                    //this.parentNode.parentNode.parentNode.remove(div);

//                });

//            }//end duplicate embedtext check
//        } //end of google+

//        $(tb).val(''); //clear the input box
//        $('#red_URL').remove();


//        //if ($(tb).val().toLowerCase().indexOf('script') < 0 && $(tb).val().toLowerCase().indexOf('alert') < 0 && $(tb).val().toLowerCase().indexOf('javascript') < 0)
//        //{
//        //    var utb_url = $(tb).val().trim();
//        //    if (utb_url.contains('youtu')) //if youtu
//        //    {
//        //        var video_url = utb_url.split(' ');
//        //        var _vdosrc = "\\";
//        //        if (video_url.length == 1)
//        //        { _vdosrc = video_url[0]; }
//        //        else
//        //        {
//        //            for (var i = 0; i < video_url.length; i++) {
//        //                if (video_url[i].indexOf("src=") != -1) {
//        //                    _vdosrc = video_url[i].split("src=")[1]; _vdosrc = _vdosrc.replace(/"/g, "");
//        //                    break;
//        //                }
//        //            }
//        //        }

//        //        var utid = youtube_parser(_vdosrc);
//        //        if (utid == '') { $(tb).val(''); return; }
//        //        var eText = build_youtube_embed(utid);
//        //        var str = build_youtube_embed(utid);
//        //        eText = eText.replace(/'/g, '"'); //**
//        //        var encodedText; var result = {}; str = str.replace(/\\s+/g, ' ').replace(/\\=s/g, '=').replace(/\\s=/g, '=');
//        //        str.split(' ').forEach(function (x) {
//        //            var arr = x.split('='); arr[1] && (result[arr[0]] = arr[1]);
//        //            if (arr[0] == 'src')
//        //            { encodedText = escape(arr[1]); }
//        //        });

//        //        if ($("span:contains(" + encodedText + ")").text().length <= 0) {
//        //            var div = document.createElement("div");
//        //            var createDiv = '<div class=\"col-md-6 col-sm-6 col-xs-12 \" style=\"padding-right: 0.5%;\"><div class=\"photo\" style=\"margin-top:15px\"><input type=\"button\" value=\"Clear\" class=\"blue_box4\" style=\"background: #c10b1c; z-index: 999; border: none; color:#fff; padding: 0 10px 0 10px\" /><span style=\"display: none;\">' + escape(eText) + '</span><span style=\"display: none;\" class=\"noneSpan\">' + encodedText + '</span><div class=\"video-container\">';
//        //            var createVideo = eText; var endDiv = '</div></div></div>';
//        //            var all = createDiv + createVideo + endDiv; div.innerHTML = all; $('#vidPreview').append(div);
//        //            $.ajax({
//        //                url: 'ParticipationEntry.aspx/GetLinks', type: 'POST', data: "{ 'link': '" + eText + "', 'isdelete': 'no' }", contentType: "application/json; charset=utf-8", dataType: "json", success: function (data) { $('#ContentBody_hdntotalFileUploadCount').val(data.d) }, error: function (xhr, textStatus, errorThrown) {
//        //                    jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
//        //                }
//        //            });
//        //            div.children[0].children[0].children[0].addEventListener("click", function (event) {
//        //                event.preventDefault(); $.ajax({
//        //                    url: 'ParticipationEntry.aspx/GetLinks', type: 'POST', data: "{ 'link': '" + unescape($(this).next().text()) + "', 'isdelete': 'yes' }", contentType: "application/json; charset=utf-8", dataType: "json", success: function (data) { $('#ContentBody_hdntotalFileUploadCount').val(data.d) }, error: function (xhr, textStatus, errorThrown) {
//        //                        jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
//        //                    }
//        //                });

//        //                $(this).parent().parent().parent().remove();
//        //                //this.parentNode.parentNode.parentNode.remove(div);
//        //            });

//        //        }//end duplicate embedtext check 
//        //    }//end if youtu
//        //    else if (utb_url.contains('facebook.com')) {
//        //        var fburl = extract_facebook_url(utb_url);
//        //        if (valid_facebook_url(fburl) == true) {
//        //            var vdoid = extract_facebook_vedioid(fburl);
//        //            var encodedText = escape(fburl);
//        //            if ($("span:contains(" + encodedText + ")").text().length <= 0) {
//        //                var eText = build_facebook_grapgh_call(vdoid);
//        //                eText = eText.replace(/'/g, '"'); //**   
//        //                var div = document.createElement('div');
//        //                var createDiv = '<div class=\"col-md-6 col-sm-6 col-xs-12\"  style=\"padding-right: 0.5%;\"><div class=\"photo\" style=\"margin-top:15px\"><input type=\"button\" value=\"Clear\" class=\"blue_box4\" style=\"background: #c10b1c; z-index: 999; border: none; color:#fff; padding: 0 10px 0 10px\" /><span style=\"display: none;\">' + escape(eText) + '</span><span style=\"display:none\"; class=\"noneSpan\">' + encodedText + '</span><div class=\"video-container\">';
//        //                var createVideo = eText; var endDiv = '</div></div></div>';
//        //                var all = createDiv + createVideo + endDiv; div.innerHTML = all; $('#vidPreview').append(div);
//        //                $.ajax({
//        //                    url: 'ParticipationEntry.aspx/GetLinks', type: 'POST', data: "{ 'link': '" + eText + "', 'isdelete': 'no' }", contentType: "application/json; charset=utf-8", dataType: "json", success: function (data) { $('#ContentBody_hdntotalFileUploadCount').val(data.d) }, error: function (xhr, textStatus, errorThrown) {
//        //                        jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
//        //                        //console.log('error:' + errorThrown);
//        //                    }
//        //                });
//        //                div.children[0].children[0].children[0].addEventListener("click", function (event) {
//        //                    event.preventDefault();
//        //                    $.ajax({
//        //                        url: 'ParticipationEntry.aspx/GetLinks', type: 'POST', data: "{ 'link': '" + unescape($(this).next().text()) + "', 'isdelete': 'yes' }", contentType: "application/json; charset=utf-8", dataType: "json", success: function (data) { $('#ContentBody_hdntotalFileUploadCount').val(data.d) }, error: function (xhr, textStatus, errorThrown) {
//        //                            jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
//        //                        }
//        //                    });


//        //                    $(this).parent().parent().parent().remove();
//        //                    //this.parentNode.parentNode.parentNode.remove(div);
//        //                });
//        //            }//end duplicate embedtext check 
//        //        }

//        //    } //end if facebook
//        //    else if (utb_url.contains('google.com')) {

//        //        var fburl = gplus_parser(utb_url);
//        //        //alert(fburl);
//        //        //if (fburl == false) {
//        //        //    return;
//        //        //}

//        //        var fburl = utb_url; //*
//        //        var eText = build_gplus_embed(fburl);
//        //        var encodedText = escape(fburl);

//        //        if ($("span:contains(" + encodedText + ")").text().length <= 0) {
//        //            eText = eText.replace(/'/g, '"'); //**   
//        //            var div = document.createElement('div');
//        //            var createDiv = '<div class=\"col-md-6 col-sm-6 col-xs-12\"  style=\"padding-right: 0.5%;\"><div class=\"photo\" style=\"margin-top:15px\"><input type=\"button\" value=\"Clear\" class=\"blue_box4\" style=\"background: #c10b1c; z-index: 999; border: none; color:#fff; padding: 0 10px 0 10px\" /><span style=\"display: none;\">' + escape(eText) + '</span><span style=\"display:none\"; class=\"noneSpan\">' + encodedText + '</span><div class=\"video-container\">';
//        //            var createVideo = eText; var endDiv = '</div></div></div>';
//        //            var all = createDiv + createVideo + endDiv; div.innerHTML = all; $('#vidPreview').append(div);


//        //            $.ajax({
//        //                url: 'ParticipationEntry.aspx/GetLinks', type: 'POST', data: "{ 'link': '" + eText + "', 'isdelete': 'no' }", contentType: "application/json; charset=utf-8", dataType: "json", success: function (data) { $('#ContentBody_hdntotalFileUploadCount').val(data.d) }, error: function (xhr, textStatus, errorThrown) {
//        //                    jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
//        //                }
//        //            });
//        //            div.children[0].children[0].children[0].addEventListener("click", function (event) {
//        //                event.preventDefault();
//        //                $.ajax({
//        //                    url: 'ParticipationEntry.aspx/GetLinks', type: 'POST', data: "{ 'link': '" + unescape($(this).next().text()) + "', 'isdelete': 'yes' }", contentType: "application/json; charset=utf-8", dataType: "json", success: function (data) { $('#ContentBody_hdntotalFileUploadCount').val(data.d) }, error: function (xhr, textStatus, errorThrown) {
//        //                        jAlertWithHref('<p>Process failed. Please check your internet connection.</p>', '" + url + "');
//        //                    }
//        //                });

//        //                $(this).parent().parent().parent().remove();
//        //                //this.parentNode.parentNode.parentNode.remove(div);

//        //            });
//        //        }//end duplicate embedtext check 

//        //    } //end google

//        //    $(tb).val(''); //clear the input box
//        //    $('#red_URL').remove();
//        //} //end of script/alert/javascript



//    }

//}); //end of click


