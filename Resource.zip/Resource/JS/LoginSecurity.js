﻿var cursorPos;
var passArray = new Array();

function copyPW(e) {

    var key = e.which || e.keyCode;
    //alert(key);
    console.log(e);
    //console.log('onkeypress');
    //console.log(document.getElementById('txtPassword').value);
    //console.log(key);

    if (key != 13 && key != 9 && key != 27 && key != 8
        && key != 12 && key != 19 && key != 3) {
        if (e.code != "End" && e.code != "PageUp" && e.code != "PageDown"
            && e.code != "Home" && e.code != "ArrowLeft" && e.code != "ArrowUp"
            && e.code != "ArrowDown" && e.code != "ArrowRight" && e.code != "Delete"
            && e.code != "Insert" && e.code != "ContextMenu") {
            e.preventDefault();
            if (isTextSelected(document.getElementById('txtPassword'))) {
                while (passArray.length > 0) {
                    passArray.pop();
                }
                passArray.push(String.fromCharCode(key));
                cursorPos = passArray.length;
                document.getElementById("hdnPW").value = "";
                document.getElementById("txtPassword").value = key;
                document.getElementById("hdnPW").value = passArray.join('');
                var len = document.getElementById("hdnPW").value.length;
                var newPW = "*";
                for (i = 1; i < len; i++) {
                    newPW += "*";
                }
                document.getElementById("txtPassword").value = newPW.trim();
                //alert(document.getElementById("hdnPW").value);
            }
            else {
                passArray.splice(cursorPos, 0, String.fromCharCode(key));
                cursorPos = passArray.length;
                //alert(cursorPos);
                document.getElementById("hdnPW").value = passArray.join('');
                //alert(document.getElementById("hdnPW").value);
                var len = document.getElementById("hdnPW").value.length;
                var newPW = "*";
                for (i = 1; i < len; i++) {
                    newPW += "*";
                }
                //alert(newPW);
                document.getElementById("txtPassword").value = newPW.trim();
                //alert(document.getElementById("hdnPW").value);
            }
        }
    }    
}
function isTextSelected(input) {
    if (typeof input.selectionStart == "number") {
        return input.selectionStart == 0 && input.selectionEnd == input.value.length;
    } else if (typeof document.selection != "undefined") {
        input.focus();
        return document.selection.createRange().text == input.value;
    }
}
function trackBackspace(e) {
    var key = e.which || e.keyCode;
    //alert(key);
    //console.log(e);
    //console.log('onkeyup');
    //console.log(document.getElementById('txtPassword').value);
    //console.log(key);

    //alert(key);
    if (key == 8) {
        if (cursorPos > -1) {
            cursorPos = cursorPos - 1;
            //alert(cursorPos);
            passArray.splice(cursorPos, 1);
            //alert(passArray.join());
            document.getElementById("hdnPW").value = passArray.join('');            
            //alert(document.getElementById("hdnPW").value);
            //alert(cursorPos);
        }        
    }    
}
function trackDelete(e) {
    var key = e.which || e.keyCode;
    //console.log(e);
    //console.log('onkeydown');
    //console.log(document.getElementById('txtPassword').value);
    //console.log(key);
    //alert(key);
    if (key == 46) {
        if (cursorPos > -1) {
            passArray.splice(cursorPos, 1);
            document.getElementById("hdnPW").value = passArray.join('');
            //alert(document.getElementById("hdnPW").value);
            //alert(cursorPos);
        }
    }    
    else if (key == 112 || key == 113 || key == 114 || key == 115 || key == 116
        || key == 117 || key == 118 || key == 119 || key == 120 || key == 121 || key == 122 || key == 123) {
        e.preventDefault();
        return false;
    }
    else if (key == 37) {
        if (passArray.length > 0) {
            cursorPos = cursorPos - 1;
            //alert(cursorPos);
        }
    }
    else if (key == 39) {
        if (cursorPos != passArray.length) {
            cursorPos = cursorPos + 1;
            //alert(cursorPos);
        }
    }
}
$(document).ready(function () {
    $('#txtPassword').bind("cut copy paste", function (e) {
        e.preventDefault();
    });

    $('#txtPassword').on('drop', function (e) {
        e.preventDefault();
    });
});