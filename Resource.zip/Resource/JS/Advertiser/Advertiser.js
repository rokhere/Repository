﻿$("document").ready(function () {
    $('#ContentBody_grvAdvertiserStatus tr').each(function () {
        var readstatus = $(this).find('span[id$="lblreadstatus"]').text();
        switch (readstatus) {
            case 'Open':
                $(this).children('td:eq(1)').find('a').addClass('Open');
                break;
            case 'Checked':
                $(this).children('td:eq(1)').find('a').addClass('Checked');

                break;
            case 'Acknowledged':
                $(this).children('td:eq(1)').find('a').addClass('Acknowledged');
                break;
            default:
                break;
        }
    });
    $('#ContentBody_grvAdvertiserStatus td').hover(function () {
        var grid = $(this).parent();
        $(grid).addClass('selectedCell');
    }, function () { $(this).parent().removeClass('selectedCell'); });
});

function CFOtherMobile(source, args) {
    if (document.getElementById(source.controltovalidate).value.length < 10)
        args.IsValid = false;
    else
        args.IsValid = true;
}

function OpenModelPopup(AdvertiserID, CalledFor) {
    $("#ModalPopupDiv").fadeIn();
    $('body').append('<div id="mask" class="mask"></div>');
    $('#mask').fadeIn(1);
    if (CalledFor == 'PWD') {
        $("#ModalPopupDiv").css({ top: "50%", left: "50%", marginLeft: "-225px", marginTop: "-218px" });
    }
}

function CloseModelPopup() {   
    $("#mask").fadeOut();   
    $("#ModalPopupDiv").fadeOut();
}
function CloseModelPopupChangePwd(ParamMsg) {
    jAlert("Password has been updated successfully.");
    document.getElementById('mask').style.display = 'none';
    document.getElementById('ModalPopupDiv').style.display = 'none';
}