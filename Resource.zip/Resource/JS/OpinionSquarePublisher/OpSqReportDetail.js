﻿var objJson = [];
var currRow = 0;
//var reportID;
$(document).ready(function () {  
    var qStr = document.URL;
    qStr = qStr.split("/");
    var reportID = qStr[4];

    $.ajax({
        type: "post",
        data: "{reportID:'" + reportID + "'}",
        url: "" + appWebPath + "/user/OpSqDetailWindow.aspx/DecryptParam",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function(data){
            $.ajax({
                type: "post",
                data: "{reportID:" + parseInt(data.d[0].outVal) + "}",
                url: "" + appWebPath + "/user/OpSqDetailWindow.aspx/LoadDetails",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (data) {
                    if (data.d.length > 0) {
                        objJson = data.d;
                        var defaultRecord = objJson[currRow];

                        if (objJson.length > 1) {
                            if (defaultRecord.FilePath == '') {
                                //var Desc = "<div class='eachcontentarea'><h3>" + defaultRecord.Heading + "</h3>";
                                var Desc = "<div class='eachcontentarea'>";
                                Desc += "<p>" + defaultRecord.Description + "</p></div>";
                                Desc += "<div class='eachcontentarea botomborderline'><div class='pre_next_link pullright'><a onclick='javascript:return showNextDesc(" + currRow + ")'>Next ></a></div></div>";
                            }
                            else {
                                //var Desc = "<div class='eachcontentarea'><h3>" + defaultRecord.Heading + "</h3>";
                                var Desc = "<div class='eachcontentarea'>";
                                Desc += "<p>" + defaultRecord.Description + "</p>";
                                Desc += "<p><span class='downloadlink'><a href=" + defaultRecord.FilePath + " target='_blank'>Download <img src='" + appSitePath + "/Resource/images/opsqpub/pdficon.png' alt='PDF' / ></a></span></p></div>";
                                Desc += "<div class='eachcontentarea botomborderline'><div class='pre_next_link pullright'><a onclick='javascript:return showNextDesc(" + currRow + ")'>Next ></a></div></div>";
                            }                    
                        }
                        else {
                            if (defaultRecord.FilePath == '') {
                                //var Desc = "<div class='eachcontentarea'><h3>" + defaultRecord.Heading + "</h3>";
                                var Desc = "<div class='eachcontentarea'>";
                                Desc += "<p>" + defaultRecord.Description + "</p></div>";
                            }
                            else {
                                var Desc = "<div class='eachcontentarea'>";
                                //var Desc = "<div class='eachcontentarea'><h3>" + defaultRecord.Heading + "</h3>";
                                Desc += "<p>" + defaultRecord.Description + "</p>";
                                Desc += "<p><span class='downloadlink'><a href=" + defaultRecord.FilePath + " target='_blank'>Download <img src='" + appSitePath + "/Resource/images/opsqpub/pdficon.png' alt='PDF' /></a></span></p></div>";
                            }                    
                        }

                        $(".rptDesc").empty();
                        $(".rptDesc").append(Desc);
                    }
                },
                error: function (result) {
                    alert("Something went wrong!!");
                }
            });
        },
        error: function (result) {
            alert("Something went wrong!!");
        }
    });    
});

function showNextDesc(rowIndex) {
    var ldiv = $('<div></div>').attr('id', 'loaderDiv');
    ldiv.appendTo('body');
    ldiv.append("<div id='innerloaderDiv' style='width:100%; height:100%; min-height:768px; position:absolute; background:rgba(0,0,0,0.5); z-index:299; left:0; top:0'>" +
        "<div class='loadingDiv'><div class='loadingbanner'></div></div></div>");
    $('html, body').css({
        'overflow': 'hidden',
        'height': '100%'
    });

    setTimeout(function () {
        rowIndex = rowIndex + 1;
        var recordSet = objJson[rowIndex];
        if (objJson.length - 1 > rowIndex) {
            if (recordSet.FilePath == '') {
                //var Desc = "<div class='eachcontentarea'><h3>" + recordSet.Heading + "</h3>";
                var Desc = "<div class='eachcontentarea'>";
                Desc += "<p>" + recordSet.Description + "</p></div>";
                Desc += "<div class='eachcontentarea botomborderline'><div class='pre_next_link pullleft'><a onclick='javascript:return showPrevDesc(" + rowIndex + ")'>< Previous</a></div>";
                Desc += "<div class='pre_next_link pullright'><a onclick='javascript:return showNextDesc(" + rowIndex + ")'>Next ></a></div></div>";
            }
            else {
                //var Desc = "<div class='eachcontentarea'><h3>" + recordSet.Heading + "</h3>";
                var Desc = "<div class='eachcontentarea'>";
                Desc += "<p>" + recordSet.Description + "</p>"; //
                Desc += "<p><span class='downloadlink'><a href=" + recordSet.FilePath + " target='_blank'>Download <img src='" + appSitePath + "/Resource/images/opsqpub/pdficon.png' alt='PDF' / ></a></span></p></div>";
                Desc += "<div class='eachcontentarea botomborderline'><div class='pre_next_link pullleft'><a onclick='javascript:return showPrevDesc(" + rowIndex + ")'>< Previous</a></div>";
                Desc += "<div class='pre_next_link pullright'><a onclick='javascript:return showNextDesc(" + rowIndex + ")'>Next ></a></div></div>";
            }
        }
        else {
            if (recordSet.FilePath == '') {
                //var Desc = "<div class='eachcontentarea'><h3>" + recordSet.Heading + "</h3>";
                var Desc = "<div class='eachcontentarea'>";
                Desc += "<p>" + recordSet.Description + "</p></div>";
                Desc += "<div class='eachcontentarea botomborderline'><div class='pre_next_link pullleft'><a onclick='javascript:return showPrevDesc(" + rowIndex + ")'>< Previous</a></div></div>";
            }
            else {
                //var Desc = "<div class='eachcontentarea'><h3>" + recordSet.Heading + "</h3>";
                var Desc = "<div class='eachcontentarea'>";
                Desc += "<p>" + recordSet.Description + "</p>";
                Desc += "<p><span class='downloadlink'><a href=" + recordSet.FilePath + " target='_blank'>Download <img src='" + appSitePath + "/Resource/images/opsqpub/pdficon.png' alt='PDF' / ></a></span></p></div>";
                Desc += "<div class='eachcontentarea botomborderline'><div class='pre_next_link pullleft'><a onclick='javascript:return showPrevDesc(" + rowIndex + ")'>< Previous</a></div></div>";
            }
        }

        $(".rptDesc").empty();
        $(".rptDesc").append(Desc);

        $("#loaderDiv").remove();
        $('html, body').css({
            'overflow': 'auto',
            'height': 'auto'
        });

        $('html, body').animate({ scrollTop: 0 }, 'slow');

    }, 1000);       
}

function showPrevDesc(rowIndex) {
    var ldiv = $('<div></div>').attr('id', 'loaderDiv');
    ldiv.appendTo('body');
    ldiv.append("<div id='innerloaderDiv' style='width:100%; height:100%; min-height:768px; position:absolute; background:rgba(0,0,0,0.5); z-index:299; left:0; top:0'>" +
        "<div class='loadingDiv'><div class='loadingbanner'></div></div></div>");
    $('html, body').css({
        'overflow': 'hidden',
        'height': '100%'
    });

    setTimeout(function () {
        rowIndex = rowIndex - 1;
        var recordSet = objJson[rowIndex];
        if (rowIndex == 0) {
            if (recordSet.FilePath == '') {
                //var Desc = "<div class='eachcontentarea'><h3>" + recordSet.Heading + "</h3>";
                var Desc = "<div class='eachcontentarea'>";
                Desc += "<p>" + recordSet.Description + "</p></div>";
                Desc += "<div class='eachcontentarea botomborderline'><div class='pre_next_link pullright'><a onclick='javascript:return showNextDesc(" + rowIndex + ")'>Next ></a></div></div>";
            }
            else {
                //var Desc = "<div class='eachcontentarea'><h3>" + recordSet.Heading + "</h3>";
                var Desc = "<div class='eachcontentarea'>";
                Desc += "<p>" + recordSet.Description + "</p>";
                Desc += "<p><span class='downloadlink'><a href=" + recordSet.FilePath + " target='_blank'>Download <img src='" + appSitePath + "/Resource/images/opsqpub/pdficon.png' alt='PDF' / ></a></span></p></div>";
                Desc += "<div class='eachcontentarea botomborderline'><div class='pre_next_link pullright'><a onclick='javascript:return showNextDesc(" + rowIndex + ")'>Next ></a></div></div>";
            }
        }
        else {
            if (recordSet.FilePath == '') {
                //var Desc = "<div class='eachcontentarea'><h3>" + recordSet.Heading + "</h3>";
                var Desc = "<div class='eachcontentarea'>";
                Desc += "<p>" + recordSet.Description + "</p></div>";
                Desc += "<div class='eachcontentarea botomborderline'><div class='pre_next_link pullleft'><a onclick='javascript:return showPrevDesc(" + rowIndex + ")'>< Previous</a></div>";
                Desc += "<div class='pre_next_link pullright'><a onclick='javascript:return showNextDesc(" + rowIndex + ")'>Next ></a></div></div>";
            }
            else {
                //var Desc = "<div class='eachcontentarea'><h3>" + recordSet.Heading + "</h3>";
                var Desc = "<div class='eachcontentarea'>";
                Desc += "<p>" + recordSet.Description + "</p>";
                Desc += "<p><span class='downloadlink'><a href=" + recordSet.FilePath + " target='_blank'>Download <img src='" + appSitePath + "/Resource/images/opsqpub/pdficon.png' alt='PDF' / ></a></span></p></div>";
                Desc += "<div class='eachcontentarea botomborderline'><div class='pre_next_link pullleft'><a onclick='javascript:return showPrevDesc(" + rowIndex + ")'>< Previous</a></div>";
                Desc += "<div class='pre_next_link pullright'><a onclick='javascript:return showNextDesc(" + rowIndex + ")'>Next ></a></div></div>";
            }
        }

        $(".rptDesc").empty();
        $(".rptDesc").append(Desc);

        $("#loaderDiv").remove();
        $('html, body').css({
            'overflow': 'auto',
            'height': 'auto'
        });

        $('html, body').animate({ scrollTop: 0 }, 'slow');

    }, 1000);    
}