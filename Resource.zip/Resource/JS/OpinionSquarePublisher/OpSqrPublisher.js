﻿// Logic flow: if left hand side has sub section then count
// if count is 0 then check if description is present
// show description and hide child panel part
// if count is > 0 then check build child panel and respective description

var chldPan = '';
var isDetailsWindow = '';
var leftColArr = [];
var pdF = '';
var NextPrevButton = '';
var leftAllArr = [];
var pageIndex;
$(document).ready(function () {
    $.ajax({
        type: "post",
        beforeSend: function () {
            var ldiv = $('<div></div>').attr('id', 'loaderDiv');
            ldiv.appendTo('body');
            ldiv.append("<div id='innerloaderDiv' style='width:100%; height:100%; min-height:768px; position:absolute; background:rgba(0,0,0,0.5); z-index:599; left:0; top:0px;'>" +
                "<div class='loadingDiv'><div class='loadingbanner'></div></div></div>");
            $('html, body').css({
                'overflow': 'hidden',
                'height': '100%'
            });
        },
        async: false,
        url: "" + appWebPath + "/user/opinionsquare.aspx/BindLeftPart",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            setTimeout(function () {
                if (data.d.length > 0) {
                    pageIndex = 0;
                    leftAllArr = data.d;
                    LoadLeftCol(pageIndex, leftAllArr);
                }

                $("#loaderDiv").remove();
                $('html, body').css({
                    'overflow': 'auto',
                    'height': 'auto'
                });
            }, 1000);
            
        },
        error: function (result) {
            alert("Something went wrong!!");
        }
    });
});

function goNext() {
    pageIndex = pageIndex + 1;
    LoadLeftCol(pageIndex, leftAllArr);
    $('html, body').animate({ scrollTop: 0 }, 'slow');
}

function goLast() {
    var division = (leftAllArr.length) / 10;
    var mod = (leftAllArr.length) % 10;
    if (mod > 0) {
        mod = 1;
    }
    pageIndex = parseInt(division + mod) - 1;
    LoadLeftCol(pageIndex, leftAllArr);
    $('html, body').animate({ scrollTop: 0 }, 'slow');
}

function goFirst() {
    pageIndex = 0;
    LoadLeftCol(pageIndex, leftAllArr);
    $('html, body').animate({ scrollTop: 0 }, 'slow');
}

function goPrev() {
    pageIndex = pageIndex - 1;
    LoadLeftCol(pageIndex, leftAllArr);
    $('html, body').animate({ scrollTop: 0 }, 'slow');
}

function LoadLeftCol(pageIndex, Arr) {
    var startRow, endRow;
    NextPrevButton = '';
    if (Arr.length <= 10) {
        NextPrevButton = "<div style='width:90%; float:left;'><div class='opinionsq_paginationarea opinion_prenxtbtn'>" +
                    "<ul>" +
                    "<li class='pagiicon_disable' style='border-right:1px solid #D8D8D8;' title='First'><img src='" + appSitePath + "/Resource/images/opsqpub/firsticon.png' alt='First' /></li>" +
                    "<li class='pagiicon_disable' title='Previous'><img src='" + appSitePath + "/Resource/images/opsqpub/previousicon.png' alt='Previous' /></li>" +
                    "<li style='border-left:1px solid #D8D8D8; border-right:1px solid #D8D8D8;' title='Next' class='pagiicon_disable'><img src='" + appSitePath + "/Resource/images/opsqpub/nexticon.png' alt='Next' /></li>" +
                    "<li class='pagiicon_disable' title='Last'><img src='" + appSitePath + "/Resource/images/opsqpub/lasticon.png' alt='Last' /></li>" +
                    "</ul>" +
                    "</div></div>";

        bindLeftCol(0, Arr.length - 1, Arr);
        $(".leftpart").append(NextPrevButton);
    }
    else {
        if (pageIndex > 0) {
            startRow = (pageIndex * 10) + 1;
            endRow = startRow + 9;
            if (Arr.length > endRow) {
                NextPrevButton = "<div style='width:90%; float:left;'><div class='opinionsq_paginationarea opinion_prenxtbtn'>" +
                        "<ul>" +
                        "<li onclick='goFirst();' class='pagiicon_enable' style='border-right:1px solid #D8D8D8;' title='First'><img src='" + appSitePath + "/Resource/images/opsqpub/firsticon.png' alt='First' /></li>" +
                        "<li onclick='goPrev();' class='pagiicon_enable' title='Previous'><img src='" + appSitePath + "/Resource/images/opsqpub/previousicon.png' alt='Previous' /></li>" +
                        "<li onclick='goNext();' style='border-left:1px solid #D8D8D8; border-right:1px solid #D8D8D8;' title='Next' class='pagiicon_enable'><img src='" + appSitePath + "/Resource/images/opsqpub/nexticon.png' alt='Next' /></li>" +
                        "<li onclick='goLast();' class='pagiicon_enable' title='Last'><img src='" + appSitePath + "/Resource/images/opsqpub/lasticon.png' alt='Last' /></li>" +
                        "</ul>" +
                        "</div></div>";
            }
            else {
                NextPrevButton = "<div style='width:90%; float:left;'><div class='opinionsq_paginationarea opinion_prenxtbtn'>" +
                        "<ul>" +
                        "<li onclick='goFirst();' class='pagiicon_enable' style='border-right:1px solid #D8D8D8;' title='First'><img src='" + appSitePath + "/Resource/images/opsqpub/firsticon.png' alt='First' /></li>" +
                        "<li onclick='goPrev();' class='pagiicon_enable' title='Previous'><img src='" + appSitePath + "/Resource/images/opsqpub/previousicon.png' alt='Previous' /></li>" +
                        "<li style='border-left:1px solid #D8D8D8; border-right:1px solid #D8D8D8;' title='Next' class='pagiicon_disable'><img src='" + appSitePath + "/Resource/images/opsqpub/nexticon.png' alt='Next' /></li>" +
                        "<li class='pagiicon_disable' title='Last'><img src='" + appSitePath + "/Resource/images/opsqpub/lasticon.png' alt='Last' /></li>" +
                        "</ul>" +
                        "</div></div>";
            }

            bindLeftCol(startRow, endRow, Arr);
            $(".leftpart").append(NextPrevButton);
        }
        else {
            NextPrevButton = "<div style='width:90%; float:left;'><div class='opinionsq_paginationarea opinion_prenxtbtn'>" +
                        "<ul>" +
                        "<li style='border-right:1px solid #D8D8D8;' title='First' class='pagiicon_disable'><img src='" + appSitePath + "/Resource/images/opsqpub/firsticon.png' alt='First' /></li>" +
                        "<li class='pagiicon_disable' title='Previous'><img src='" + appSitePath + "/Resource/images/opsqpub/previousicon.png' alt='Previous' /></li>" +
                        "<li onclick='goNext();' style='border-left:1px solid #D8D8D8; border-right:1px solid #D8D8D8;' title='Next' class='pagiicon_enable'><img src='" + appSitePath + "/Resource/images/opsqpub/nexticon.png' alt='Next' /></li>" +
                        "<li onclick='goLast();' class='pagiicon_enable' title='Last'><img src='" + appSitePath + "/Resource/images/opsqpub/lasticon.png' alt='Last' /></li>" +
                        "</ul>" +
                        "</div></div>";

            startRow = pageIndex;
            endRow = startRow + 9;
            bindLeftCol(startRow, endRow, Arr);
            $(".leftpart").append(NextPrevButton);
        }
    }    
}

function bindLeftCol(startRow, endRow, Arr) {
    leftColArr = [];
    $(".leftpart").empty();
    $(".rightpart").empty();
    if (startRow != 0) {
        startRow = startRow - 1;
        endRow = endRow - 1;
    }
    for (var i = startRow; i <= endRow; i++) {
        if (i < Arr.length) {
            bindDetailWindowLink(Arr[i].ReportID);

            var leftCol = '';
            if (i == 0 || ((i % 10) == 0)) {
                LoadDefaultChild(Arr[i].ReportID);

                leftCol += "<div id='left" + Arr[i].ReportID + "' class='blog_leftpart_active'><div id='actvarrow" + Arr[i].ReportID + "' class='whitearrow'></div><div id=" + Arr[i].ReportID + "><div style='width:100%; margin:0 auto; overflow:hidden;'>";

                if (Arr[i].FilePath != '') {
                    if (isDetailsWindow != '') {
                        pdF = "<div class='col-lg-6 col-md-6 col-sm-12 col-s-12'><a href='" + Arr[i].FilePath + "' target='_blank'><div class='pdflink'>Download</div></a></div><div class='col-lg-6 col-md-6 col-sm-12 col-s-12'>" + isDetailsWindow + "</div>";
                    }
                    else {
                        pdF = "<div class='col-lg-12 col-md-12 col-sm-12 col-s-12'><a href='" + Arr[i].FilePath + "' target='_blank'><div class='pdflink'>Download</div></a></div>";
                    }
                }
                else {
                    if (isDetailsWindow != '') {
                        pdF = "<div class='col-lg-12 col-md-12 col-sm-12 col-s-12'>" + isDetailsWindow + "</div>";
                    }
                }

                if (chldPan == '') {
                    leftCol += "<div class='col-lg-12 col-md-12 col-sm-12 col-s-12 blog_heading'>" +
                        " <a href='javascript:void(0)' class='active' id=rptHead" + Arr[i].ReportID + "" +
                        " onclick='javascript:return expandpanel(" + Arr[i].ReportID + ", " + i + ");'>" + Arr[i].Title + "<br />" +
                        " <h2>Publish date:  " + Arr[i].PublishDate + "</h2></a></div>" + pdF + "</div></div></div>";
                }
                else {
                    leftCol += "<div class='col-lg-12 col-md-12 col-sm-12 col-s-12 blog_heading'>" +
                        " <a href='javascript:void(0)' class='active' id=rptHead" + Arr[i].ReportID + "" +
                        " onclick='javascript:return expandpanel(" + Arr[i].ReportID + ", " + i + ");'>" + Arr[i].Title + "<br />" +
                        " <h2>Publish date:  " + Arr[i].PublishDate + "</h2></a></div>" + pdF + "</div></div>" + chldPan + "</div></div>";
                }
            }
            else {
                if (i < Arr.length) {
                    leftCol += "<div id='left" + Arr[i].ReportID + "' class='blog_leftpart'><div id='actvarrow" + Arr[i].ReportID + "'></div><div id=" + Arr[i].ReportID + "><div style='width:100%; margin:0 auto; overflow:hidden;'>";

                    if (Arr[i].FilePath != '') {
                        if (isDetailsWindow != '') {
                            pdF = "<div class='col-lg-6 col-md-6 col-sm-12 col-s-12'><a href='" + Arr[i].FilePath + "' target='_blank'><div class='pdflink'>Download</div></a></div><div class='col-lg-6 col-md-6 col-sm-12 col-s-12'>" + isDetailsWindow + "</div>";
                        }
                        else {
                            pdF = "<div class='col-lg-12 col-md-12 col-sm-12 col-s-12'><a href='" + Arr[i].FilePath + "' target='_blank'><div class='pdflink'>Download</div></a></div>";
                        }
                    }
                    else {
                        if (isDetailsWindow != '') {
                            pdF = "<div class='col-lg-12 col-md-12 col-sm-12 col-s-12'>" + isDetailsWindow + "</div>";
                        }
                    }

                    leftCol += "<div class='col-lg-12 col-md-12 col-sm-12 col-s-12 blog_heading'>" +
                        " <a href='javascript:void(0)' id=rptHead" + Arr[i].ReportID + "" +
                        " onclick='javascript:return expandpanel(" + Arr[i].ReportID + ", " + i + ");'>" + Arr[i].Title + "<br />" +
                        " <h2>Publish date:  " + Arr[i].PublishDate + "</h2></div></a></div>" + pdF + "</div></div>";
                }
            }

            leftColArr.push(leftCol);
            $(".leftpart").append(leftCol);
            chldPan = '';
            isDetailsWindow = '';
            pdF = '';
        }        
    }
}

function LoadLeftColReArranged(arr) {
    $(".leftpart").empty();
    for (var i = 0; i < arr.length; i++) {
        $(".leftpart").append(arr[i]);
    }
    $(".leftpart").append(NextPrevButton);    
}

function LoadDefaultChild(reportID) {
    $.ajax({
        type: "post",
        async: false,
        data: "{reportID:" + reportID + "}",
        url: "" + appWebPath + "/user/opinionsquare.aspx/LoadSubSection",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            if (data.d.length > 0) {
                if (data.d.length > 1) {
                    chldPan += "<div style='padding-top:10px;' class='col-lg-12 col-md-12 col-sm-12 col-s-12 chPan'><div class='leftlink'><ul>";
                    for (var i = 0; i < data.d.length; i++) {
                        if (data.d[i].Heading == '') {
                            data.d[i].Heading = "View Section";
                        }

                        if (i == 0) {
                            chldPan += "<li><a href='javascript:void(0)' class='active1' id=chld" + data.d[i].OpinionSquarePublisherID + "" +
                                " onclick='javascript:return loadDescription(" + data.d[i].OpinionSquarePublisherID + ");'><span>" +
                                " <i class='fa fa-caret-right'></i></span>" + data.d[i].Heading + "</a></li>";
                        }
                        else {
                            chldPan += "<li><a href='javascript:void(0)' id=chld" + data.d[i].OpinionSquarePublisherID + "" +
                                " onclick='javascript:return loadDescription(" + data.d[i].OpinionSquarePublisherID + ");'><span>" +
                                " <i class='fa fa-caret-right'></i></span>" + data.d[i].Heading + "</a></li>";
                        }
                    }
                    chldPan += "</ul></div></div>";
                }
                else {
                    if (data.d[0].Heading == '') {
                        chldPan = '';
                    }
                    else {
                        chldPan = "<div style='padding-top:10px;' class='col-lg-12 col-md-12 col-sm-12 col-s-12 chPan'><div class='leftlink'><ul>";
                        chldPan += "<li><a href='javascript:void(0)' class='active1' id=chld" + data.d[0].OpinionSquarePublisherID + "" +
                            " onclick='javascript:return loadDescription(" + data.d[0].OpinionSquarePublisherID + ");'><span>" +
                            " <i class='fa fa-caret-right'></i></span>" + data.d[0].Heading + "</a></li>";
                        chldPan += "</ul></div></div>";
                    }
                }
                
                bindDefaultDesc(data.d[0].OpinionSquarePublisherID);
            }
        },
        error: function (result) {
            alert("Something went wrong!!");
        }
    });
}

function bindDefaultDesc(opsqpubID) {
    $.ajax({
        type: "post",
        data: "{opsqpubID:" + opsqpubID + "}",
        url: "" + appWebPath + "/user/opinionsquare.aspx/LoadSubDescription",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            if (data.d.length > 0) {
                $(".rightpart").empty();
                //var Desc = "";
                //if (data.d[0].Heading != '') {
                //    Desc = "<div style='width:100%; float:left;'><div style='width:100%; float:left; text-align:center;'>" +
                //        " <h3>" + data.d[0].Heading + "</h3></div></div>";
                //}
                var Desc = "<div style='width:100%; float:left;'><div style='width:100%; float:left;'>" +
                    data.d[0].Description + "</div></div>";

                $(".rightpart").append(Desc);
            }
        },
        error: function (result) {
            alert("Something went wrong!!");
        }
    });
}

function bindDetailWindowLink(reportID) {
    $.ajax({
        type: "post",
        async: false,
        data: "{reportID:" + reportID + "}",
        url: "" + appWebPath + "/user/opinionsquare.aspx/BindDetailWindowLink",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            if (data.d.length > 0) {
                isDetailsWindow = data.d[0].DetailsWindowLink;
            }
        },
        error: function (result) {
            alert("Something went wrong!!");
        }
    });
}

function expandpanel(reportID, index) {
    //alert(pageIndex);
    if (pageIndex > 0) {
        if ((index % 10) == 0) {
            //index = 9;            
            index = index;
        }
        else {
            index = (index % 10);
        }        
    }
    else {
        index = (index % 10);
    }    
    var cloneArr = [];
    cloneArr = leftColArr.slice(); // assign the base array into the newly created variable
    var elem = cloneArr[index]; // assign the clicked element into the newly created variable
    cloneArr.splice(index, 1); // remove the clicked element from the clone array
    cloneArr.unshift(elem); // push the clicked item to the begining of the array
    LoadLeftColReArranged(cloneArr);
            $.ajax({
                type: "post",
                data: "{reportID:" + reportID + "}",
                url: "" + appWebPath + "/user/opinionsquare.aspx/LoadSubSection",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (data) {
                    var childPanel = "";
                    if (data.d.length > 0) {
                        $(".chPan").remove();
                        if (data.d.length > 1) {
                            childPanel = "<div class='col-lg-12 col-md-12 col-sm-12 col-s-12 chPan' style='padding-top:10px;'><div class='leftlink'><ul>";
                                for (var i = 0; i < data.d.length; i++) {
                                    if (data.d[i].Heading == '') {
                                        data.d[i].Heading = 'View Section';
                                    }

                                    if (i == 0) {
                                        childPanel += "<li><a href='javascript:void(0)' class='active1' id=chld" + data.d[i].OpinionSquarePublisherID + "" +
                                            " onclick='javascript:return loadDescription(" + data.d[i].OpinionSquarePublisherID + ");'>" +
                                            " <span><i class='fa fa-caret-right'></i></span>" + data.d[i].Heading + "</a></li>";
                                        loadDescription(data.d[i].OpinionSquarePublisherID);
                                    }
                                    else {
                                        childPanel += "<li><a href='javascript:void(0)' id=chld" + data.d[i].OpinionSquarePublisherID + "" +
                                            " onclick='javascript:return loadDescription(" + data.d[i].OpinionSquarePublisherID + ");'>" +
                                            " <span><i class='fa fa-caret-right'></i></span>" + data.d[i].Heading + "</a></li>";
                                    }
                                }

                            childPanel += "</ul></div></div>";
                        }
                        else {
                            if (data.d[0].Heading == '') {
                                childPanel = "";
                                loadDescription(data.d[0].OpinionSquarePublisherID);
                            }
                            else {
                                childPanel = "<div style='padding-top:10px;' class='col-lg-12 col-md-12 col-sm-12 col-s-12 chPan'><div class='leftlink'><ul>";

                                childPanel += "<li><a href='javascript:void(0)' class='active1' id=chld" + data.d[0].OpinionSquarePublisherID + "" +
                                            " onclick='javascript:return loadDescription(" + data.d[0].OpinionSquarePublisherID + ");'>" +
                                            " <span><i class='fa fa-caret-right'></i></span>" + data.d[0].Heading + "</a></li>";

                                childPanel += "</ul></div></div>";
                                loadDescription(data.d[0].OpinionSquarePublisherID);
                            }
                        }

                        $("#" + reportID).append(childPanel);
                    }
                    else {
                        $(".blogrightarea").empty();
                        $(".chPan").remove();
                    }
                },
                error: function (result) {
                    alert("Something went wrong!!");
                }
            });
            $(".active").removeClass("active");            
            $(".redbox_top").removeClass("redbox_top").addClass("bluebox_top");            
            $(".redbox_bottom_active").removeClass("redbox_bottom_active");
            $(".whiteroundbg2").removeClass("whiteroundbg2").addClass("whiteroundbg");
            $("#sp" + parseInt(reportID)).removeClass("whiteroundbg").addClass("whiteroundbg2");
            $("#pdfbx" + parseInt(reportID)).addClass("redbox_top");
            $("#pdfbxImg" + parseInt(reportID)).addClass("redbox_bottom_active");
            $("#rptHead" + parseInt(reportID)).addClass("active");
            $(".whitearrow").removeClass("whitearrow");
            $("#actvarrow" + parseInt(reportID)).addClass("whitearrow");
            $(".blog_leftpart_active").removeClass("blog_leftpart_active").addClass("blog_leftpart");
            $("#left" + parseInt(reportID)).addClass("blog_leftpart_active");
            $('html, body').animate({ scrollTop: 0 }, 'slow');
            
}

function loadDescription(opsqpubID) {
    $.ajax({
        type: "post",
        beforeSend: function () {
            var ldiv = $('<div></div>').attr('id', 'loaderDiv');
            ldiv.appendTo('body');
            ldiv.append("<div id='innerloaderDiv' style='width:100%; height:100%; min-height:768px; position:absolute; background:rgba(0,0,0,0.5); z-index:599; left:0; top:0px;'>" +
                "<div class='loadingDiv'><div class='loadingbanner'></div></div></div>");
            $('html, body').css({
                'overflow': 'hidden',
                'height': '100%'
            });
        },
        data: "{opsqpubID:" + opsqpubID + "}",
        url: "" + appWebPath + "/user/opinionsquare.aspx/LoadSubDescription",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            setTimeout(function () {
                var chldDesc = '';
                if (data.d.length > 0) {
                    for (var i = 0; i < data.d.length; i++) {
                        //if (!data.d[i].Heading == '') {
                        //    chldDesc += "<div style='width:100%; float:left;'><div style='width:100%; float:left; text-align:center;'><h3>" + data.d[i].Heading + "</h3></div></div>";
                        //}
                        chldDesc += "<div style='width:100%; float:left;'><div style='width:100%; float:left;'>" + data.d[i].Description + "</div></div>";
                    }
                }

                $(".blogrightarea").empty();
                $(".blogrightarea").append(chldDesc);

                $(".active1").removeClass("active1");
                $("#chld" + opsqpubID).addClass("active1");

                $("#loaderDiv").remove();
                $('html, body').css({
                    'overflow': 'auto',
                    'height': 'auto'
                });

                $('html, body').animate({ scrollTop: 0 }, 'slow');

            }, 1000);            
        },
        error: function (result) {
            alert("Something went wrong!!");
        }
    });
}
