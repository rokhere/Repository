
(function($) {                                          // Compliant with jquery.noConflict()
$.fn.brand_gall_ban = function(o) {
    o = $.extend({
        btnPrev: null,
        btnNext: null,
        btnGo: null,
        mouseWheel: false,
        auto: true, 

        speed: 2000,
        easing: null,

        vertical: false,
        circular: true,
        visible: 3,
        start: 0,
        scroll: 1,

        beforeStart: null,
        afterEnd: null
    }, o || {});

    return this.each(function() {                       // Returns the element collection. Chainable.
        var curr = o.start, running = false, animCss=o.vertical?"top":"left", sizeCss=o.vertical?"height":"width";
        var div = $(this), ul = div.find("ul"), li = div.find("li"), itemLength = li.size();                       
        div.css("visibility", "visible");

        li.css("overflow", "hidden")                        // If the list item size is bigger than required
            .css("float", o.vertical ? "none" : "left")     // Horizontal list
            .children().css("overflow", "hidden");          // If the item within li overflows its size, hide'em

        ul.css("margin", "5")                               // Browsers apply default margin 
			.css("margin-left", "-5")
			.css("margin-top", "13")
            .css("padding", "5")                            // and padding. It is reset here.
            .css("position", "relative")                    // IE BUG - width as min-width
            .css("list-style-type", "none")                 // We dont need any icons representing each list item.
            .css("z-index", "1");                           // IE doesnt respect width. So z-index smaller than div

        div.css("overflow", "hidden")                       // Overflows - works in FF
            .css("position", "relative")                    // position relative and z-index for IE
            .css("z-index", "2")                            // more than ul so that div displays on top of ul
            .css("left", "0px");                            // after creating carousel show it on screen
                
        var liSize = o.vertical ? height(li) : width(li);   // Full li size(incl margin)-Used for animation
        var ulSize = liSize * itemLength;                   // size of full ul(total length, not just for the visible items)
        var divSize = liSize * o.visible;                   // size of entire div(total length for just the visible items)

        li.css("width", li.width())                         // inner li width. this is the box model width
            .css("height", li.height());                    // inner li height. this is the box model height

        ul.css(sizeCss, ulSize+"px")                        // Width of the UL is the full length for all the images
            .css(animCss, -(curr*liSize));                  // Set the starting item

        div.css(sizeCss, divSize+"px");                     // Width of the DIV. length of visible images

        if(o.btnPrev) {
            $(o.btnPrev).click(function() { 
                return go(curr-o.scroll); 
            });
        }
        
        if(o.btnNext) {
            $(o.btnNext).click(function() { 
                return go(curr+o.scroll); 
            });
        }
        
        if(o.btnGo) {
            $.each(o.btnGo, function(i, val) {
                $(val).click(function() {
                    return go(i);
                });
            });
        }
        
        if(o.mouseWheel && div.mousewheel) {
            div.mousewheel(function(e, d) {
                return d>0 ? go(curr-o.scroll) : go(curr+o.scroll);
            });
        }    
        
        if(o.auto){ 
            setInterval(function() { 
                go(curr+1); 
            }, o.auto+o.speed);
        }        

        function vis() {
            return li.gt(curr-1).lt(o.visible);
        };

        function go(to) {
            if(!running) {
                running = true;
                if(o.beforeStart) o.beforeStart.call(this, vis());

                if(to<0 && curr==0) {                                               // If first, then goto last
                    if(o.circular) curr=itemLength-o.visible; 
                    else return;
                } else if(to>=itemLength-o.visible && curr+o.visible>=itemLength) { // If last, then goto first
                    if(o.circular) curr = 0; 
                    else return;
                } else curr = to;

                ul.animate(
                    animCss == "left" ? { left: -(curr*liSize) } : { top: -(curr*liSize) } , o.speed, o.easing,
                    function() {
                        ul.css(animCss, -(curr*liSize)+"px");    // For some reason the animation was not making left:0
                        if(o.afterEnd) o.afterEnd.call(this, vis());
                        running = false;
                    }
                );
            }
            return false;
        };
    });
};

function css(el, prop) {
    return parseInt($.css(el.jquery ? el[0] : el,prop)) || 0;
};
function width(el) {
    return  el[0].offsetWidth + css(el, 'marginLeft') + css(el, 'marginRight');
};
function height(el) {
    return el[0].offsetHeight + css(el, 'marginTop') + css(el, 'marginBottom');
};

})(jQuery);


//---------------------------------easy-gallery.js-------------------------------

$.fn.egallery = function (options) {
    // Default settings.
    var settings = {
        width: 388, // Width for gallery holder, li
        height: 290, // Height for each element
        speed: 600, // Animation speed in MS
        delay: 3000, // delay for auto play to transact.
        easing: 'swing', // 
        thumbs: 'none', //  Thumbs: none, numbers, image OR custom
        thumbClass: '', // Thumb CSS class
        thumbImage: '', // Image url for thumbs.
        aClass: '', // Thumb active class
        auto: true // True to enable auto play
    };
    // Exteding options
    settings = $.extend(settings, options);

    // sgObj is a holder for #gallery container.. Cashing it.
    var sgObj = $(this);
    // anim used for animation.. to stop any action while animating.
    var anim = false;
    // Auto play handler.
    var ap = null;
    // Item index for autoplay
    var aind = 0;

    /**
    * This function applies CSS for container and inside elements.
    */
    function _css() {
        $(sgObj).css({ 'overflow': 'hidden', 'width': settings.width + 'px', 'height': settings.height + 'px', 'position': 'relative' });
        $(sgObj).find("ul").css({ 'list-style': 'none', 'position': 'absolute', 'top': 0, 'left': 0, 'width': (settings.width * $(sgObj).find("li").length) + 'px', 'height': settings.height + 'px' });
        $(sgObj).find("li").css({ "float": "left", 'width': settings.width + 'px' });
    }

    /**
    * Creating numeric thumbs. Depending on elements count.
    */
    function _createThumbsNumbers() {
        var htm = '<ul>';
        for (i = 0; i < $(sgObj).find("li").length; i++) {
            htm += '<li class="' + settings.thumbClass + '">' + (i + 1) + '</' + 'li>';
        }
        htm += '</' + 'ul>';
        return htm;
    }

    function _createThumbsImage() {
        var htm = '<ul>';
        for (i = 0; i < $(sgObj).find("li").length; i++) {
            htm += '<li class="' + settings.thumbClass + '" style="background:url(\'' + settings.thumbImage + '\') center 0 no-repeat;"></' + 'li>';
        }
        htm += '</' + 'ul>';
        return htm;
    }

    /**
    * This function calls functions to generate thumbs depending on the settings.
    */
    function _thumbs() {
        if ($("#ssgThumbs").length < 1) {
            return false;
        }
        var animated = false;
        switch (settings.thumbs) {
            case "numbers":
                $("#ssgThumbs").html(_createThumbsNumbers());
                break;
            case "image":
                $("#ssgThumbs").html(_createThumbsImage());
                break;
            default:
                return;
                break;
        }
        $("#ssgThumbs li").click(function () { _cthumbs($("#ssgThumbs li").index(this), true); });
        $("#ssgThumbs li").eq(0).addClass(settings.aClass);
    }

    /**
    * This function animates the gallery to the clicked thumb OR animate the gallery for AutoPlay
    * @param ind index of clicked object
    */
    function _cthumbs(ind, c) {
        if (anim == false) {
            clearInterval(ap);
            anim = true;
            if (settings.thumbs != "none") {
                $("#ssgThumbs li").removeClass(settings.aClass); //alert(settings.aClass);
                $("#ssgThumbs li").eq(ind).addClass(settings.aClass);
                $(sgObj).find('ul').animate({ 'left': -(ind * settings.width) + 'px' }, settings.speed, settings.easing, function () {
                    anim = false;
                    if (c == true) {
                        aind = ind;
                    }
                    if (settings.auto == true) { ap = setInterval(function () { _autoplay(); }, settings.delay) }
                });
            } else {
                $(sgObj).find('ul').animate({ 'left': -(ind * settings.width) + 'px' }, settings.speed, settings.easing, function () {
                    anim = false;
                    if (settings.auto == true) { ap = setInterval(function () { _autoplay(); }, settings.delay) }
                });
            }
        }
    }

    function _prepare() {
        _thumbs(settings.thumbs);
    }

    /**
    * Starts the auto play.
    */
    function _run() {
        // Runs autoplay
        ap = setInterval(function () {
            _autoplay();
        }, settings.delay);
    }

    /**
    * Animate the gallery on Auto play
    */
    function _autoplay() {
        aind++;
        if (aind >= $(sgObj).find("li").length) {
            aind = 0;
        }
        _cthumbs(aind, false);
    }

    /**
    * The initializer for this plugin.
    */
    function _init() {
        _css();
        _prepare();
        if (settings.auto == true) {
            _run();
        }
    }

    return _init();

};


//---------------------------------jquery_page.js-------------------------------



// t: current time, b: begInnIng value, c: change In value, d: duration
jQuery.easing['jswing'] = jQuery.easing['swing'];

jQuery.extend(jQuery.easing,
{
    def: 'easeOutQuad',
    swing: function (x, t, b, c, d) {
        //alert(jQuery.easing.default);
        return jQuery.easing[jQuery.easing.def](x, t, b, c, d);
    },
    easeInQuad: function (x, t, b, c, d) {
        return c * (t /= d) * t + b;
    },
    easeOutQuad: function (x, t, b, c, d) {
        return -c * (t /= d) * (t - 2) + b;
    },
    easeInOutQuad: function (x, t, b, c, d) {
        if ((t /= d / 2) < 1) return c / 2 * t * t + b;
        return -c / 2 * ((--t) * (t - 2) - 1) + b;
    },
    easeInCubic: function (x, t, b, c, d) {
        return c * (t /= d) * t * t + b;
    },
    easeOutCubic: function (x, t, b, c, d) {
        return c * ((t = t / d - 1) * t * t + 1) + b;
    },
    easeInOutCubic: function (x, t, b, c, d) {
        if ((t /= d / 2) < 1) return c / 2 * t * t * t + b;
        return c / 2 * ((t -= 2) * t * t + 2) + b;
    },
    easeInQuart: function (x, t, b, c, d) {
        return c * (t /= d) * t * t * t + b;
    },
    easeOutQuart: function (x, t, b, c, d) {
        return -c * ((t = t / d - 1) * t * t * t - 1) + b;
    },
    easeInOutQuart: function (x, t, b, c, d) {
        if ((t /= d / 2) < 1) return c / 2 * t * t * t * t + b;
        return -c / 2 * ((t -= 2) * t * t * t - 2) + b;
    },
    easeInQuint: function (x, t, b, c, d) {
        return c * (t /= d) * t * t * t * t + b;
    },
    easeOutQuint: function (x, t, b, c, d) {
        return c * ((t = t / d - 1) * t * t * t * t + 1) + b;
    },
    easeInOutQuint: function (x, t, b, c, d) {
        if ((t /= d / 2) < 1) return c / 2 * t * t * t * t * t + b;
        return c / 2 * ((t -= 2) * t * t * t * t + 2) + b;
    },
    easeInSine: function (x, t, b, c, d) {
        return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
    },
    easeOutSine: function (x, t, b, c, d) {
        return c * Math.sin(t / d * (Math.PI / 2)) + b;
    },
    easeInOutSine: function (x, t, b, c, d) {
        return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
    },
    easeInExpo: function (x, t, b, c, d) {
        return (t == 0) ? b : c * Math.pow(2, 10 * (t / d - 1)) + b;
    },
    easeOutExpo: function (x, t, b, c, d) {
        return (t == d) ? b + c : c * (-Math.pow(2, -10 * t / d) + 1) + b;
    },
    easeInOutExpo: function (x, t, b, c, d) {
        if (t == 0) return b;
        if (t == d) return b + c;
        if ((t /= d / 2) < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
        return c / 2 * (-Math.pow(2, -10 * --t) + 2) + b;
    },
    easeInCirc: function (x, t, b, c, d) {
        return -c * (Math.sqrt(1 - (t /= d) * t) - 1) + b;
    },
    easeOutCirc: function (x, t, b, c, d) {
        return c * Math.sqrt(1 - (t = t / d - 1) * t) + b;
    },
    easeInOutCirc: function (x, t, b, c, d) {
        if ((t /= d / 2) < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
        return c / 2 * (Math.sqrt(1 - (t -= 2) * t) + 1) + b;
    },
    easeInElastic: function (x, t, b, c, d) {
        var s = 1.70158; var p = 0; var a = c;
        if (t == 0) return b; if ((t /= d) == 1) return b + c; if (!p) p = d * .3;
        if (a < Math.abs(c)) { a = c; var s = p / 4; }
        else var s = p / (2 * Math.PI) * Math.asin(c / a);
        return -(a * Math.pow(2, 10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p)) + b;
    },
    easeOutElastic: function (x, t, b, c, d) {
        var s = 1.70158; var p = 0; var a = c;
        if (t == 0) return b; if ((t /= d) == 1) return b + c; if (!p) p = d * .3;
        if (a < Math.abs(c)) { a = c; var s = p / 4; }
        else var s = p / (2 * Math.PI) * Math.asin(c / a);
        return a * Math.pow(2, -10 * t) * Math.sin((t * d - s) * (2 * Math.PI) / p) + c + b;
    },
    easeInOutElastic: function (x, t, b, c, d) {
        var s = 1.70158; var p = 0; var a = c;
        if (t == 0) return b; if ((t /= d / 2) == 2) return b + c; if (!p) p = d * (.3 * 1.5);
        if (a < Math.abs(c)) { a = c; var s = p / 4; }
        else var s = p / (2 * Math.PI) * Math.asin(c / a);
        if (t < 1) return -.5 * (a * Math.pow(2, 10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p)) + b;
        return a * Math.pow(2, -10 * (t -= 1)) * Math.sin((t * d - s) * (2 * Math.PI) / p) * .5 + c + b;
    },
    easeInBack: function (x, t, b, c, d, s) {
        if (s == undefined) s = 1.70158;
        return c * (t /= d) * t * ((s + 1) * t - s) + b;
    },
    easeOutBack: function (x, t, b, c, d, s) {
        if (s == undefined) s = 1.70158;
        return c * ((t = t / d - 1) * t * ((s + 1) * t + s) + 1) + b;
    },
    easeInOutBack: function (x, t, b, c, d, s) {
        if (s == undefined) s = 1.70158;
        if ((t /= d / 2) < 1) return c / 2 * (t * t * (((s *= (1.525)) + 1) * t - s)) + b;
        return c / 2 * ((t -= 2) * t * (((s *= (1.525)) + 1) * t + s) + 2) + b;
    },
    easeInBounce: function (x, t, b, c, d) {
        return c - jQuery.easing.easeOutBounce(x, d - t, 0, c, d) + b;
    },
    easeOutBounce: function (x, t, b, c, d) {
        if ((t /= d) < (1 / 2.75)) {
            return c * (7.5625 * t * t) + b;
        } else if (t < (2 / 2.75)) {
            return c * (7.5625 * (t -= (1.5 / 2.75)) * t + .75) + b;
        } else if (t < (2.5 / 2.75)) {
            return c * (7.5625 * (t -= (2.25 / 2.75)) * t + .9375) + b;
        } else {
            return c * (7.5625 * (t -= (2.625 / 2.75)) * t + .984375) + b;
        }
    },
    easeInOutBounce: function (x, t, b, c, d) {
        if (t < d / 2) return jQuery.easing.easeInBounce(x, t * 2, 0, c, d) * .5 + b;
        return jQuery.easing.easeOutBounce(x, t * 2 - d, 0, c, d) * .5 + c * .5 + b;
    }
});






