﻿var _URL = window.URL || window.webkitURL;
var imgCount = 0;
 
String.prototype.format = function () {
    var str = this; for (var i = 0; i < arguments.length; i++) {
        var reg = new RegExp("\\{" + i + "\\}", "gm");
        str = str.replace(reg, arguments[i]);
    } return str;
}

$(document).ready(function () {

    var output2 = document.getElementById("result");

    //--------------------------
    //Album image size...
    var IMAGE_WIDTH = 800;
    var IMAGE_HEIGHT = 600;
    //--------------------------
    uploadfCnt = 0;
    var NoOfCompress = 0;

    if (window.File && window.FileList && window.FileReader) {
        NoOfCompress = 0;
        var fluId = $("input[id*= 'flu_']")[0].id;
        //$(document).on('change', $('#' + fluId), onChange);
        $('#' +fluId).on('change', onChange);
    }

    var isViolated = true; //added on 2015-12-23
    var filesRemaining = 0; //**
    var allowedFiles = [];

    function onChange(event) {       
        allowedFiles = [];//clear the array
        event.preventDefault();
        var files = event.target.files;

        //----------------------------------------------
        var maxlmt = $("input[id*= '_hdnMaxFiles']").val();
        //var minlmt = $("input[id*= '_hdnMinFiles']").val();
        var totalfiles = $("input[id*= '_hdntotalFileUploadCount']").val();
        filesRemaining = maxlmt - totalfiles;
        if (filesRemaining <= 0) {
            alert("Allowed upload limit is reached!");
            return;//exit
        }
        //----------------------------------------------

        var file;
        var fileExtn = "";
        var __fname;
        var extnIndx = -1;
        //var fileExtension = ['jpeg', 'jpg', 'png', 'bmp'];
        //var fileExtension = ['jpg', 'jpeg', 'pjpeg', 'png', 'x-png', 'gif'];     
        var fileExtension = ['jpg', 'jpeg', 'png', 'gif'];
        
        //check if the different file format selected...
        for (var i = 0; i < files.length; i++) {

            fileExtn = "";
            file = files[i];
            __fname = file.name;
            var ext = __fname.split('.').pop().toLowerCase(); 
            if ($.inArray(ext, fileExtension) == -1) {
                alert("Please upload image files only. Allowed formats are jpg, jpeg, png and gif.");
                var fluId = $("input[id*= 'flu_']")[0].id;
                $('#' + fluId).val('');//clear the browse
                return; //no file added in UI from selected
            }           
        }
        //----------------------------------------------

        var uploadedImages = [];
        //check the file if uploaded or not
        $('#result .photo .img-responsive').each(function (i) {
            uploadedImages.push($(this).attr('imgname'));             
        });

     
        //var maxlmt = $("input[id*= '_hdnMaxFiles']").val();
        ////var minlmt = $("input[id*= '_hdnMinFiles']").val();
        //var totalfiles = $("input[id*= '_hdntotalFileUploadCount']").val();
        //filesRemaining = maxlmt - totalfiles; 

        var validFiles = files;
        //console.log('validFiles before:');
        //console.log(validFiles);
        if (files.length > filesRemaining) {
            //for (var i = 0; i < filesRemaining; i++) {
            //        allowedFiles.push(files[i]);
            //}
           
            for (var i = 0; i < files.length; i++) {
                var innercntr = 0;
                if ($.inArray(files[i].name, uploadedImages) == -1) {
                    filesRemaining--;
                    if (filesRemaining>=0)
                        allowedFiles.push(files[i]);
                }                              
            }                
        }
        else {
            for (var i = 0; i < files.length; i++) {
                allowedFiles.push(files[i]);
            }
        }
        fn_ImageFilesSelected(allowedFiles);               
        
    };

    var _files_dimn_violated = [];
    var _files_size_violated = [];

    var _fileIndex = 0;
    var _selectedImgFiles = null; 
    function fn_ImageFilesSelected(files) {
        _selectedImgFiles = files;
        fn_ValidateFile(_selectedImgFiles[_fileIndex]);
    }

    function fn_ValidateFile(file) {            

        try {
            if (file.size > 10485760) {                 
                _files_size_violated.push(file.name);
                alert('Size of the file ' + file.name + ' should be less than 10MB');
                //var fluId = $("input[id*= 'flu_']")[0].id;
                //$('#' + fluId).val('');

                _files_dimn_violated = [];
                _files_size_violated = [];
                _selectedImgFiles = [];
                _fileIndex = 0;
                var fluId = $("input[id*= 'flu_']")[0].id;
                $('#' + fluId).val('');

                return;
            }

            var reader = new FileReader();
            reader.onload = function (readerEvent) {
                var imgParticipant = new Image();
                imgParticipant.onload = function (imgEvent) {

                    // calculates images ratio based on fixed image dimension..
                    var imageWidth = imgParticipant.width;
                    var imageHeight = imgParticipant.height;

                    if ((imgParticipant.width >= 400 && imgParticipant.height >= 300) && (imgParticipant.width <= 4920 && imgParticipant.height <= 3264)) {
                        // when width is bigger than height
                        if (imageWidth > imageHeight) {
                            if (imageWidth > IMAGE_WIDTH) {
                                imageWidth = IMAGE_WIDTH;
                                imageHeight *= IMAGE_WIDTH / imgParticipant.width;
                            }
                        }
                            // when height is bigger than width
                        else {
                            if (imageHeight > IMAGE_HEIGHT) {
                                imageHeight = IMAGE_HEIGHT;
                                imageWidth *= IMAGE_HEIGHT / imgParticipant.height;
                            }
                        }

                        var canvas = document.createElement("canvas");
                        // set canvas dimension exactly same as image dimension
                        canvas.width = imageWidth;
                        canvas.height = imageHeight;

                        // drawing the image as par above caluclated dimension...
                        canvas.getContext('2d').drawImage(imgParticipant, 0, 0, imageWidth, imageHeight)
                        var _dataURL = canvas.toDataURL('image/jpeg');

                        var _isSameFile = false;
                        var _dataURLCurrnt;
                        var _imgFiles = [];

                        $('#result .photo .img-responsive').each(function (i) {
                            _dataURLCurrnt = $(this).attr('src');
                            if (_dataURLCurrnt == _dataURL) {
                                _isSameFile = true;
                                return false; //exit the each loop   
                            }
                            else {
                                //different image
                            } //end of different img
                        });

                        if (_isSameFile == false) {
                            //var div = document.createElement("div"); div.className = div.className + "col-md-2 col-sm-2 col-xs-2 ";
                            var div = document.createElement("div"); div.className = div.className + "col-md-2 col-sm-4 col-xs-6 ";                            
                            $(div).css({ overflow: 'hidden' });

                            div.innerHTML = ("<div class='photo' style='overflow:hidden;'><div class='cross' style='z-index: 100; width: 20px; height: 20px; background-color:#9f1907; text-align:center; color:#fff; line-height:20px;font-weight: bold;'>X</div>" +
                                //"<div id='divRotateX' style='z-index: 100; width: 25%; float: left;' onclick=rotatecntrl2(this); rott='0' ><input type='button' style='display:none;' value='Rotate' class='imgRotate'><img src='../Resource/images/rotate.jpg' alt='Rotate' id='divRotate' style='z-index: 100; width: 25%; width:auto; float: left' onclick=rotatecntrl2(this); rott='0'></div>" +

                                //"<img title='Rotate (rotating will not crop your image)' id='divRotate' class='rotationImages' onclick=rotatecntrl2(this); rott='0' alt='.' />" +
                                "<div title='Rotate (rotating will not crop your image)' id='divRotate' class='rotationImages' onclick=rotatecntrl2(this); rott='0' >&nbsp;</div>" +
                                "<img class='img-responsive' src='" + _dataURL + "' imgname='{0}' />" +
                                "<div class='op hidden-sm hidden-xs' style='font: italic bold 12px/30px Georgia, serif; background: rgba(23, 102, 148, 0.8); position: absolute; z-index: 10; color: #fff; padding-top: 10%; padding-left: 2%; display: none; width: 100%; height: 100%; top: 0em;'><input type='checkbox' />&nbsp;Set as cover photo</div></div>").format(file.name);

                            
                            output2.insertBefore(div, null); //attach the div 


                            $.ajax({
                                url: 'ParticipationEntry.aspx/GetFiles',
                                type: 'POST',
                                //data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '0'}",
                                data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '0', 'rotmode': '0' }",
                                contentType: "application/json; charset=utf-8",
                                dataType: "json",
                                beforeSend: function (msg) {
                                    $(".white_content2, .black_overlay2").css("display", "block");
                                },
                                success: function (data) {
                                    //$('#backgroundOverlayX').hide();

                                    if (uploadfCnt < data.d)
                                        uploadfCnt = data.d;
                                    //var a = $('output#result div.col-md-2.col-sm-2.col-xs-2');
                                    var a = $('output#result div.col-md-2.col-sm-4.col-xs-6');
                                    $('#ContentBody_hdntotalFileUploadCount').val(a.length);

                                    //----------------------------------- 
                                    //2015-12-30
                                    //alert($('#result .photo .img-responsive').length);
                                    if ($('#result .photo .img-responsive').length > 0) {
                                        $('#lblShowonCndn').show();
                                    }
                                    else {
                                        $('#lblShowonCndn').hide();
                                    }
                                    //----------------------------------- 
                                    //rearrange the photoes...
                                    $('.clrBoth').remove();
                                    var a = $('output#result div.col-md-2.col-sm-4.col-xs-6');
                                    //for (var i = 0; i < a.length; i += 6) {
                                    //    $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                    //}

                                    //if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                                    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Windows Phone|DROID|ZuneWP7|Kindle|Playbook|Nexus|Xoom|SM-N900T|GT-N7100|SAMSUNG-SGH-I717|SM-T330NU/i.test(navigator.userAgent)) {
                                        var ua = navigator.userAgent.toLowerCase();
                                        if (ua.indexOf("mobile") != -1) {
                                            //mobile
                                            for (var i = 0; i < a.length; i += 2) {
                                                $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                            }
                                        }
                                        else {
                                            //tablet
                                            for (var i = 0; i < a.length; i += 3) {
                                                $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                            }
                                        }
                                    }
                                    else {
                                        //web:desktop/laptop
                                        for (var i = 0; i < a.length; i += 6) {
                                            $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                        }
                                    }

                                    //-----------------------------------                                    

                                },
                                complete: function (data) {
                                    $(".white_content2, .black_overlay2").css("display", "none");
                                },
                                async: true
                            });

                            //}//not same file

                            ////----------------------------
                            ////rearrange the photoes...
                            //$('.clrBoth').remove();
                            //var a = $('output#result div.col-md-2.col-sm-4.col-xs-6');
                            ////for (var i = 0; i < a.length; i += 6) {
                            ////    $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                            ////}

                            ////if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                            //if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Windows Phone|DROID|ZuneWP7|Kindle|Playbook|Nexus|Xoom|SM-N900T|GT-N7100|SAMSUNG-SGH-I717|SM-T330NU/i.test(navigator.userAgent)) {
                            //    var ua = navigator.userAgent.toLowerCase();
                            //    if (ua.indexOf("mobile") != -1) {
                            //        //mobile
                            //        for (var i = 0; i < a.length; i += 2) {
                            //            $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                            //        }
                            //    }
                            //    else {
                            //        //tablet
                            //        for (var i = 0; i < a.length; i += 3) {
                            //            $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                            //        }
                            //    }                                
                            //}
                            //else {
                            //    //web:desktop/laptop
                            //    for (var i = 0; i < a.length; i += 6) {
                            //        $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                            //    }
                            //}

                            ////-----------------------------------
                             
                            //+++++++++++++++++++++++++


                            //----------------------------
                            //div.children[0].addEventListener("mouseover", function (event) { event.preventDefault(); $(this).find('.op').show(); });
                            //div.children[0].addEventListener("mouseout", function (event) { event.preventDefault(); $(this).find('.op').hide() });

                            //close btn event listener...
                            div.children[0].children[0].addEventListener("click", function (event) {
                                event.preventDefault();
                                //filesRemaining += 1;

                                var x = div.previousElementSibling;
                                if (x.style.clear == 'both') {
                                    if (x.previousElementSibling.nodeName.toLowerCase() != 'div') {
                                        x.parentNode.removeChild(x); imgCount = 0;
                                    }
                                    imgCount = imgCount - 1;
                                    if (imgCount <= 0) { imgCount = 0; }
                                }
                                else {
                                    imgCount = imgCount - 1;
                                    if (imgCount <= 0) { imgCount = 0; }
                                }
                                div.parentNode.removeChild(div);
                                $("#red_picUpload").remove();
                                //-----------------------------------
                                //close btn...
                                $.ajax({
                                    url: 'ParticipationEntry.aspx/GetFiles',
                                    type: 'POST',
                                    //data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'yes', 'isdefault': '0' }",
                                    data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'yes', 'isdefault': '0', 'rotmode': '0' }",
                                    contentType: "application/json; charset=utf-8",
                                    dataType: "json",
                                    beforeSend: function (msg) {
                                        $(".white_content2, .black_overlay2").css("display", "block");
                                    },
                                    success: function (data) {

                                        //$('#" + hdntotalFileUploadCount.ClientID + "').val(data.d)
                                        $('#ContentBody_hdntotalFileUploadCount').val(data.d);

                                        //rearrange the photoes...
                                        //$('.clrBoth').remove();
                                        //var a = $('output#result div.col-md-2.col-sm-4.col-xs-6');
                                        //for (var i = 0; i < a.length; i += 6) {
                                        //    $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                        //}

                                        $('.clrBoth').remove();
                                        var a = $('output#result div.col-md-2.col-sm-4.col-xs-6');
                                        //for (var i = 0; i < a.length; i += 6) {
                                        //    $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                        //}
                                                
                                        //if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                                        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Windows Phone|DROID|ZuneWP7|Kindle|Playbook|Nexus|Xoom|SM-N900T|GT-N7100|SAMSUNG-SGH-I717|SM-T330NU/i.test(navigator.userAgent)) {
                                            var ua = navigator.userAgent.toLowerCase();
                                            if (ua.indexOf("mobile") != -1) {
                                                //mobile
                                                for (var i = 0; i < a.length; i += 2) {
                                                    $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                                }
                                            }
                                            else {
                                                //tablet
                                                for (var i = 0; i < a.length; i += 3) {
                                                    $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                                }
                                            }
                                        }
                                        else {
                                            //web:desktop/laptop
                                            for (var i = 0; i < a.length; i += 6) {
                                                $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                            }
                                        }

                                        //-----------------------------------
                                         
                                        //-----------------------------------  
                                        //2015-12-29

                                        var fluId = $("input[id*= 'flu_']")[0].id;
                                        $('#' + fluId).val('');                                                                  
                                        //-----------------------------------  

                                        //----------------------------------- 
                                        //2015-12-30
                                        //alert($('#result .photo .img-responsive').length);
                                        if ($('#result .photo .img-responsive').length > 0) {
                                            $('#lblShowonCndn').show();
                                        }
                                        else {
                                            $('#lblShowonCndn').hide();
                                        }
                                        //----------------------------------- 

                                    },
                                    complete: function (data) {
                                        $(".white_content2, .black_overlay2").css("display", "none");
                                    },
                                    async: true
                                });


                            }); //end of close btn


                            //-----------------------------------              
                            //rotation btn event listener...
                            div.children[0].children[0].nextElementSibling.addEventListener("click", function (event) {

                                var rm = $(div.children[0].children[0].nextElementSibling).attr('rott');
                                $.ajax({
                                    url: 'ParticipationEntry.aspx/GetFiles',
                                    type: 'POST',
                                    //data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '0'}",
                                    data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '99', 'rotmode': '" + rm + "' }",
                                    contentType: "application/json; charset=utf-8",
                                    dataType: "json",
                                    beforeSend: function (msg) {

                                        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Windows Phone|DROID|ZuneWP7|Kindle|Playbook|Nexus|Xoom|SM-N900T|GT-N7100|SAMSUNG-SGH-I717|SM-T330NU/i.test(navigator.userAgent)) {
                                            var ua = navigator.userAgent.toLowerCase();
                                            if (ua.indexOf("mobile") != -1) {
                                                //mobile
                                                $(".white_content2, .black_overlay2").css("display", "block");
                                            }
                                            else {
                                                //tablet
                                                $(".white_content2, .black_overlay2").css("display", "block");
                                            }
                                        }
                                        else {
                                            //web:desktop/laptop                                            
                                        }                                        

                                    },
                                    success: function (data) {
                                        $('#ContentBody_hdntotalFileUploadCount').val(data.d);
                                    },
                                    complete: function (data) {
                                        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Windows Phone|DROID|ZuneWP7|Kindle|Playbook|Nexus|Xoom|SM-N900T|GT-N7100|SAMSUNG-SGH-I717|SM-T330NU/i.test(navigator.userAgent)) {
                                            var ua = navigator.userAgent.toLowerCase();
                                            if (ua.indexOf("mobile") != -1) {
                                                //mobile
                                                $(".white_content2, .black_overlay2").css("display", "none");
                                            }
                                            else {
                                                //tablet
                                                $(".white_content2, .black_overlay2").css("display", "none");
                                            }
                                        }
                                        else {
                                            //web:desktop/laptop

                                        }

                                        
                                    },
                                    async: true
                                });

                            });//end of rotation btn event listener...

                            //-----------------------------------
                            //checkbox change event...
                            $(div).find(':checkbox').on("change", function (event) {
                                event.preventDefault();
                                if ($(this).prop("checked")) {
                                    $(':checkbox').prop('checked', false);
                                    $(this).prop('checked', true);
                                    $.ajax({
                                        url: 'ParticipationEntry.aspx/GetFiles',
                                        type: 'POST',
                                        //data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '1' }",
                                        data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '1', 'rotmode': '0' }",
                                        contentType: "application/json; charset=utf-8",
                                        dataType: "json",
                                        success: function (data) {
                                            $('#ContentBody_hdntotalFileUploadCount').val(data.d);
                                        },
                                        async: false
                                    });
                                }
                            }); //end of //checkbox change event...
                            //----------------------

                            //+++++++++++++++++++++++++

                            //-----------------------------------
                            //return _dataURL;

                        }//not same file //@@@

                    }//image dimention check
                    else {
                        _files_dimn_violated.push(file.name);
                        //alert('Please check the file(s) dimension');
                        //return;                     
                    }


                    _fileIndex += 1;
                    if (_fileIndex < _selectedImgFiles.length) {
                        //var maxlmt = $("input[id*= '_hdnMaxFiles']").val();
                        //var totalfiles = $("input[id*= '_hdntotalFileUploadCount']").val();
                        //alert('totalfiles>>' + totalfiles);
                        //filesRemaining = maxlmt - totalfiles;
                        ////alert(filesRemaining);
                        //if (filesRemaining > 1) {
                            fn_ValidateFile(_selectedImgFiles[_fileIndex]); //recursive call   
                        //}
                    }
                    else {                  
 

                        if (_files_dimn_violated.length > 0) {
                            //alert('Please check the dimension for the file(s) ' + _files_dimn_violated.join("; "));
                            alert('Please upload image within the specified dimension.');
                        }
                        //clear the array...
                        _files_dimn_violated = [];
                        _files_size_violated = [];
                        _selectedImgFiles = [];
                        _fileIndex = 0;
                        var fluId = $("input[id*= 'flu_']")[0].id;
                        $('#' + fluId).val('');
                    }

                }; //imgParticipant.onload

                imgParticipant.src = readerEvent.target.result;

            }; //reader.onload

            reader.readAsDataURL(file);

        } //end of try
        catch (e) {

        }
    }

    function ProcessImage2(file) {

        // create a reader instance
        var reader = new FileReader();
        // create an image instance
        var imgParticipant = new Image();


        //check file size...
        if (file.size > 10485760) {
            _files_size_violated.push(file.name);
            alert('File size should be less than 10MB');
            return;
        }
        // load the images into file reader...

        //console.log(file.name);

        reader.readAsDataURL(file);

        reader.onload = function (readerEvent) {
            imgParticipant.src = readerEvent.target.result;

            imgParticipant.onload = function (imgEvent) {

                // calculates images ratio based on fixed image dimension..
                var imageWidth = imgParticipant.width;
                var imageHeight = imgParticipant.height;

                if ((imgParticipant.width >= 400 && imgParticipant.height >= 300) && (imgParticipant.width <= 4920 && imgParticipant.height <= 3264)) {
                    // when width is bigger than height
                    if (imageWidth > imageHeight) {
                        if (imageWidth > IMAGE_WIDTH) {
                            imageWidth = IMAGE_WIDTH;
                            imageHeight *= IMAGE_WIDTH / imgParticipant.width;
                        }
                    }
                        // when height is bigger than width
                    else {
                        if (imageHeight > IMAGE_HEIGHT) {
                            imageHeight = IMAGE_HEIGHT;
                            imageWidth *= IMAGE_HEIGHT / imgParticipant.height;
                        }
                    }

                    var canvas = document.createElement("canvas");
                    // set canvas dimension exactly same as image dimension
                    canvas.width = imageWidth;
                    canvas.height = imageHeight;

                    // drawing the image as par above caluclated dimension...
                    canvas.getContext('2d').drawImage(imgParticipant, 0, 0, imageWidth, imageHeight)
                    var _dataURL = canvas.toDataURL('image/jpeg');

                    //var div = document.createElement("div"); div.className = div.className + "col-md-2 col-sm-2 col-xs-2 ";
                    var div = document.createElement("div"); div.className = div.className + "col-md-2 col-sm-4 col-xs-6 ";
                    $(div).css({ overflow: 'hidden' });


                    var _isSameFile = false;
                    var _dataURLCurrnt;
                    var _imgFiles = [];

                    $('#result .photo .img-responsive').each(function (i) {
                        _dataURLCurrnt = $(this).attr('src');
                        if (_dataURLCurrnt == _dataURL) {
                            _isSameFile = true;
                            return false; //exit the each loop                        
                        }
                    });

                    if (_isSameFile == false) {
                        div.innerHTML = "<div class='photo' style='overflow:hidden;'><div class='cross' style='z-index: 100; width: 20px; height: 20px; background-color:#9f1907; text-align:center; color:#fff; line-height:20px;font-weight: bold;'>X</div>" +
                            //"<div id='divRotateX' style='z-index: 100; width: 25%; float: left;' onclick=rotatecntrl2(this); rott='0' ><input type='button' style='display:none;' value='Rotate' class='imgRotate'><img src='../Resource/images/rotate.jpg' alt='Rotate' id='divRotate' style='z-index: 100; width: 25%; width:auto; float: left' onclick=rotatecntrl2(this); rott='0'></div>" +

                            "<img title='Rotate (rotating will not crop your image)' id='divRotate' class='rotationImages' onclick=rotatecntrl2(this); rott='0' alt='.' />" +
                            //"<div title='Rotate (rotating will not crop your image)' id='divRotate' class='rotationImages' onclick=rotatecntrl2(this); rott='0' >&nbsp;</div>" +
                            "<img class='img-responsive' src='" + _dataURL + "' />" +
                            "<div class='op hidden-sm hidden-xs' style='font: italic bold 12px/30px Georgia, serif; background: rgba(23, 102, 148, 0.8); position: absolute; z-index: 10; color: #fff; padding-top: 10%; padding-left: 2%; display: none; width: 100%; height: 100%; top: 0em;'><input type='checkbox' />&nbsp;Set as cover photo</div></div>";



                        output2.insertBefore(div, null); //attach the div  

                        $.ajax({
                            url: 'ParticipationEntry.aspx/GetFiles',
                            type: 'POST',
                            //data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '0'}",
                            data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '0', 'rotmode': '0' }",
                            contentType: "application/json; charset=utf-8",
                            dataType: "json",
                            success: function (data) {
                                if (uploadfCnt < data.d)
                                    uploadfCnt = data.d;
                                //var a = $('output#result div.col-md-2.col-sm-2.col-xs-2');
                                var a = $('output#result div.col-md-2.col-sm-4.col-xs-6');
                                $('#ContentBody_hdntotalFileUploadCount').val(a.length);
                            },
                            async: false
                        });

                    }//not same file

                    //----------------------------
                    //rearrange the photoes...
                    $('.clrBoth').remove();
                    //var a = $('output#result div.col-md-2.col-sm-2.col-xs-2');
                    //for (var i = 0; i < a.length; i += 6) {
                    //    $('output#result div.col-md-2.col-sm-2.col-xs-2:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                    //}
                    var a = $('output#result div.col-md-2.col-sm-4.col-xs-6');
                    for (var i = 0; i < a.length; i += 6) {
                        $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                    }

                    //----------------------------
                    //div.children[0].addEventListener("mouseover", function (event) { event.preventDefault(); $(this).find('.op').show(); });
                    //div.children[0].addEventListener("mouseout", function (event) { event.preventDefault(); $(this).find('.op').hide() });
                    //close btn event listener...
                    div.children[0].children[0].addEventListener("click", function (event) {
                        event.preventDefault();
                        var x = div.previousElementSibling;
                        if (x.style.clear == 'both') {
                            if (x.previousElementSibling.nodeName.toLowerCase() != 'div') {
                                x.parentNode.removeChild(x); imgCount = 0;
                            }
                            imgCount = imgCount - 1;
                            if (imgCount <= 0) { imgCount = 0; }
                        }
                        else {
                            imgCount = imgCount - 1;
                            if (imgCount <= 0) { imgCount = 0; }
                        }
                        div.parentNode.removeChild(div);
                        $("#red_picUpload").remove();
                        //-----------------------------------
                        //close btn...
                        $.ajax({
                            url: 'ParticipationEntry.aspx/GetFiles',
                            type: 'POST',
                            //data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'yes', 'isdefault': '0' }",
                            data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'yes', 'isdefault': '0', 'rotmode': '0' }",
                            contentType: "application/json; charset=utf-8",
                            dataType: "json",
                            success: function (data) {
                                //$('#" + hdntotalFileUploadCount.ClientID + "').val(data.d)
                                $('#ContentBody_hdntotalFileUploadCount').val(data.d);

                                //rearrange the photoes...
                                $('.clrBoth').remove();
                                //var a = $('output#result div.col-md-2.col-sm-2.col-xs-2');
                                //for (var i = 0; i < a.length; i += 6) {
                                //    $('output#result div.col-md-2.col-sm-2.col-xs-2:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                //}

                                var a = $('output#result div.col-md-2.col-sm-4.col-xs-6');
                                for (var i = 0; i < a.length; i += 6) {
                                    $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
                                }

                            },
                            async: false
                        });
                    });


                    //-----------------------------------              
                    //rotation btn event listener...
                    div.children[0].children[0].nextElementSibling.addEventListener("click", function (event) {
                        var rm = $(div.children[0].children[0].nextElementSibling).attr('rott');
                        $.ajax({
                            url: 'ParticipationEntry.aspx/GetFiles',
                            type: 'POST',
                            //data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '0'}",
                            data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '99', 'rotmode': '" + rm + "' }",
                            contentType: "application/json; charset=utf-8",
                            dataType: "json",
                            success: function (data) {
                                $('#ContentBody_hdntotalFileUploadCount').val(data.d);
                            },
                            async: false
                        });

                    });

                    //-----------------------------------
                    //checkbox change event...
                    $(div).find(':checkbox').on("change", function (event) {
                        event.preventDefault();
                        if ($(this).prop("checked")) {
                            $(':checkbox').prop('checked', false);
                            $(this).prop('checked', true);
                            $.ajax({
                                url: 'ParticipationEntry.aspx/GetFiles',
                                type: 'POST',
                                //data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '1' }",
                                data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '1', 'rotmode': '0' }",
                                contentType: "application/json; charset=utf-8",
                                dataType: "json",
                                success: function (data) {
                                    $('#ContentBody_hdntotalFileUploadCount').val(data.d);
                                },
                                async: false
                            });
                        }
                    });
                    //-----------------------------------
                    //return _dataURL;

                }//image dimention check
                else {
                    isViolated = false;
                    _files_dimn_violated.push(file.name);
                    //console.log(_files_dimn_violated);
                    //console.log(file.name);
                    alert('Please check the file(s) dimension');
                    //return;
                }
                //console.log(_files_dimn_violated);               

            };

        };

    }


    //function ProcessImage2(file) {

    //    // create a reader instance
    //    var reader = new FileReader();
    //    // create an image instance
    //    var imgParticipant = new Image();


    //    //check file size...
    //    if (file.size > 10485760) {
    //        _files_size_violated.push(file.name);
    //        alert('File size should be less than 10MB');
    //        return;
    //    }
    //    // load the images into file reader...

    //    console.log(file.name);

    //    reader.readAsDataURL(file);

    //    reader.onload = function (readerEvent) {
    //        imgParticipant.src = readerEvent.target.result;

    //        imgParticipant.onload = function (imgEvent) {

    //            // calculates images ratio based on fixed image dimension..
    //            var imageWidth = imgParticipant.width;
    //            var imageHeight = imgParticipant.height;

    //            if ((imgParticipant.width >= 400 && imgParticipant.height >= 300) && (imgParticipant.width <= 4920 && imgParticipant.height <= 3264)) {
    //                // when width is bigger than height
    //                if (imageWidth > imageHeight) {
    //                    if (imageWidth > IMAGE_WIDTH) {
    //                        imageWidth = IMAGE_WIDTH;
    //                        imageHeight *= IMAGE_WIDTH / imgParticipant.width;
    //                    }
    //                }
    //                    // when height is bigger than width
    //                else {
    //                    if (imageHeight > IMAGE_HEIGHT) {
    //                        imageHeight = IMAGE_HEIGHT;
    //                        imageWidth *= IMAGE_HEIGHT / imgParticipant.height;
    //                    }
    //                }

    //                var canvas = document.createElement("canvas");
    //                // set canvas dimension exactly same as image dimension
    //                canvas.width = imageWidth;
    //                canvas.height = imageHeight;

    //                // drawing the image as par above caluclated dimension...
    //                canvas.getContext('2d').drawImage(imgParticipant, 0, 0, imageWidth, imageHeight)
    //                var _dataURL = canvas.toDataURL('image/jpeg');

    //                //var div = document.createElement("div"); div.className = div.className + "col-md-2 col-sm-2 col-xs-2 ";
    //                var div = document.createElement("div"); div.className = div.className + "col-md-2 col-sm-4 col-xs-6 ";
    //                $(div).css({ overflow: 'hidden' });


    //                var _isSameFile = false;
    //                var _dataURLCurrnt;
    //                var _imgFiles = [];

    //                $('#result .photo .img-responsive').each(function (i) {
    //                    _dataURLCurrnt = $(this).attr('src');
    //                    if (_dataURLCurrnt == _dataURL) {
    //                        _isSameFile = true;
    //                        return false; //exit the each loop                        
    //                    }
    //                });

    //                if (_isSameFile == false) {
    //                    div.innerHTML = "<div class='photo'><div class='cross' style='z-index: 100; width: 20px; height: 20px; background-color:#9f1907; text-align:center; color:#fff; line-height:20px;font-weight: bold;'>X</div>" +
    //                        //"<div id='divRotateX' style='z-index: 100; width: 25%; float: left;' onclick=rotatecntrl2(this); rott='0' ><input type='button' style='display:none;' value='Rotate' class='imgRotate'><img src='../Resource/images/rotate.jpg' alt='Rotate' id='divRotate' style='z-index: 100; width: 25%; width:auto; float: left' onclick=rotatecntrl2(this); rott='0'></div>" +

    //                        "<img title='Rotate (rotating will not crop your image)' id='divRotate' class='rotationImages' onclick=rotatecntrl2(this); rott='0' alt='.' />" +
    //                        //"<div title='Rotate (rotating will not crop your image)' id='divRotate' class='rotationImages' onclick=rotatecntrl2(this); rott='0' >&nbsp;</div>" +
    //                        "<img class='img-responsive' src='" + _dataURL + "' title='img' />" +
    //                        "<div class='op hidden-sm hidden-xs' style='font: italic bold 12px/30px Georgia, serif; background: rgba(23, 102, 148, 0.8); position: absolute; z-index: 10; color: #fff; padding-top: 10%; padding-left: 2%; display: none; width: 100%; height: 100%; top: 0em;'><input type='checkbox' />&nbsp;Set as cover photo</div></div>";



    //                    output2.insertBefore(div, null); //attach the div  

    //                    $.ajax({
    //                        url: 'ParticipationEntry.aspx/GetFiles',
    //                        type: 'POST',
    //                        //data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '0'}",
    //                        data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '0', 'rotmode': '0' }",
    //                        contentType: "application/json; charset=utf-8",
    //                        dataType: "json",
    //                        success: function (data) {
    //                            if (uploadfCnt < data.d)
    //                                uploadfCnt = data.d;
    //                            //var a = $('output#result div.col-md-2.col-sm-2.col-xs-2');
    //                            var a = $('output#result div.col-md-2.col-sm-4.col-xs-6');
    //                            $('#ContentBody_hdntotalFileUploadCount').val(a.length);
    //                        },
    //                        async: false
    //                    });

    //                }//not same file

    //                //----------------------------
    //                //rearrange the photoes...
    //                $('.clrBoth').remove();
    //                //var a = $('output#result div.col-md-2.col-sm-2.col-xs-2');
    //                //for (var i = 0; i < a.length; i += 6) {
    //                //    $('output#result div.col-md-2.col-sm-2.col-xs-2:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
    //                //}
    //                var a = $('output#result div.col-md-2.col-sm-4.col-xs-6');
    //                for (var i = 0; i < a.length; i += 6) {
    //                    $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
    //                }

    //                //----------------------------
    //                //div.children[0].addEventListener("mouseover", function (event) { event.preventDefault(); $(this).find('.op').show(); });
    //                //div.children[0].addEventListener("mouseout", function (event) { event.preventDefault(); $(this).find('.op').hide() });
    //                //close btn event listener...
    //                div.children[0].children[0].addEventListener("click", function (event) {
    //                    event.preventDefault();
    //                    var x = div.previousElementSibling;
    //                    if (x.style.clear == 'both') {
    //                        if (x.previousElementSibling.nodeName.toLowerCase() != 'div') {
    //                            x.parentNode.removeChild(x); imgCount = 0;
    //                        }
    //                        imgCount = imgCount - 1;
    //                        if (imgCount <= 0) { imgCount = 0; }
    //                    }
    //                    else {
    //                        imgCount = imgCount - 1;
    //                        if (imgCount <= 0) { imgCount = 0; }
    //                    }
    //                    div.parentNode.removeChild(div);
    //                    $("#red_picUpload").remove();
    //                    //-----------------------------------
    //                    //close btn...
    //                    $.ajax({
    //                        url: 'ParticipationEntry.aspx/GetFiles',
    //                        type: 'POST',
    //                        //data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'yes', 'isdefault': '0' }",
    //                        data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'yes', 'isdefault': '0', 'rotmode': '0' }",
    //                        contentType: "application/json; charset=utf-8",
    //                        dataType: "json",
    //                        success: function (data) {
    //                            //$('#" + hdntotalFileUploadCount.ClientID + "').val(data.d)
    //                            $('#ContentBody_hdntotalFileUploadCount').val(data.d);

    //                            //rearrange the photoes...
    //                            $('.clrBoth').remove();
    //                            //var a = $('output#result div.col-md-2.col-sm-2.col-xs-2');
    //                            //for (var i = 0; i < a.length; i += 6) {
    //                            //    $('output#result div.col-md-2.col-sm-2.col-xs-2:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
    //                            //}

    //                            var a = $('output#result div.col-md-2.col-sm-4.col-xs-6');
    //                            for (var i = 0; i < a.length; i += 6) {
    //                                $('output#result div.col-md-2.col-sm-4.col-xs-6:eq(' + i + ')').before('<div class="clrBoth" style="clear: both"></div>');
    //                            }

    //                        },
    //                        async: false
    //                    });
    //                });


    //                //-----------------------------------              
    //                //rotation btn event listener...
    //                div.children[0].children[0].nextElementSibling.addEventListener("click", function (event) {
    //                    var rm = $(div.children[0].children[0].nextElementSibling).attr('rott');
    //                    $.ajax({
    //                        url: 'ParticipationEntry.aspx/GetFiles',
    //                        type: 'POST',
    //                        //data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '0'}",
    //                        data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '99', 'rotmode': '" + rm + "' }",
    //                        contentType: "application/json; charset=utf-8",
    //                        dataType: "json",
    //                        success: function (data) {
    //                            $('#ContentBody_hdntotalFileUploadCount').val(data.d);
    //                        },
    //                        async: false
    //                    });

    //                });

    //                //-----------------------------------
    //                //checkbox change event...
    //                $(div).find(':checkbox').on("change", function (event) {
    //                    event.preventDefault();
    //                    if ($(this).prop("checked")) {
    //                        $(':checkbox').prop('checked', false);
    //                        $(this).prop('checked', true);
    //                        $.ajax({
    //                            url: 'ParticipationEntry.aspx/GetFiles',
    //                            type: 'POST',
    //                            //data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '1' }",
    //                            data: "{ 'filename': '" + _dataURL + "', 'isdelete': 'no', 'isdefault': '1', 'rotmode': '0' }",
    //                            contentType: "application/json; charset=utf-8",
    //                            dataType: "json",
    //                            success: function (data) {
    //                                $('#ContentBody_hdntotalFileUploadCount').val(data.d);
    //                            },
    //                            async: false
    //                        });
    //                    }
    //                });
    //                //-----------------------------------
    //                //return _dataURL;

    //            }//image dimention check
    //            else {
    //                _files_dimn_violated.push(file.name);
    //                console.log(_files_dimn_violated);
    //                //console.log(file.name);
    //                alert('Please check the file(s) dimension');
    //                //return;
    //            }
    //            //console.log(_files_dimn_violated);               

    //        };

    //    };       

    //}


    //alert(_files_dimn_violated);
    //console.log(_files_dimn_violated);
    //if (_files_dimn_violated.length > 0) {
    //    alert('Please check the dimension for the file(s) ' + _files_dimn_violated.join("; "));
    //}
});

function rotatecntrl2(selector) {
    var setMultipleDegree = $(selector).attr('rott');
    setMultipleDegree = parseInt(setMultipleDegree) >= 3000 ? 0 : parseInt(setMultipleDegree) + 1;
    $(selector).attr('rott', setMultipleDegree);
    var rotate = "rotate(" + setMultipleDegree * 90 + "deg)";
    var trans = "all 0.3s ease-out";

    $(selector).next().css({
        "-webkit-transform": rotate,
        "-moz-transform": rotate,
        "-o-transform": rotate,
        "msTransform": rotate,
        "transform": rotate,
        "-webkit-transition": trans,
        "-moz-transition": trans,
        "-o-transition": trans,
        "transition": trans
    });
}


