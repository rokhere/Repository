﻿
//document.onkeydown = function (e) {
//    if (event.keyCode == 123) {
//        return false;
//    }
//    if (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
//        return false;
//    }
//    if (e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
//        return false;
//    }
//    if (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
//        return false;
//    }
//}

var siteurl = "";

String.prototype.format = function (args) {

    //replace all accurance of key
    var s = this;
    for (var key in args) {
        var re = new RegExp('{' + key + '}', 'g');
        s = s.replace(re, args[key]);
    }
    return s;
}

function AdminGetBlogData(SiteURL, pageIndex, BlogCategoryId, postid, searchbytag) {
    siteurl = SiteURL;
    $.ajax({
        type: "POST",
        //url: WebURL + "/FGBlog/BlogCategory.aspx/GetBlog","
        url: SiteURL + "/FGEngine/PrevBlog/AdminBlogService.asmx/AdminGetBlog",
        data: '{"BlogCategoryId":"' + BlogCategoryId + '","pageIndex":"' + pageIndex + '"}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var names = response.d;
            var BlogPl = '';
           

            if (response.d.length > 0) {
                var blogdata = response.d;
                var BlogCategoryName = blogdata[0].CategoryName
                var path = window.location.pathname.split('/');


              

                if ((postid != undefined && postid != "") || path[2] == "BlogAboutUs") {
                    $('#dropmenu').removeClass('active')
                    $('#dropmenu p span').removeClass('dropmenuiconnarea')                 
                  //  window.location.href = WebURL + "/FGEngine/PrevBlog/BlogCategory.aspx?catid=" + BlogCategoryId;
                }
             
                else {
                    $('#dropmenu').removeClass('active');
                    $('#dropmenu p span').removeClass('dropmenuiconnarea');
                    if (BlogCategoryId != 0) {
                        $('#blog').removeClass('active');
                        //if (typeof (history.pushState) != "undefined") {
                        //    var obj = { Page: WebURL + "blog/all", Url: WebURL + "/blog/" + BlogCategoryId + "/" + BlogCategoryName };
                        //    history.pushState(obj, obj.Page, obj.Url);
                        //} else {
                        //    alert("Browser does not support HTML5.");
                        //}
                      //  window.location.href = WebURL + "/FGEngine/PrevBlog/BlogCategory.aspx?catid=" + BlogCategoryId;
                        $('#dropmenu').addClass('active')
                        $('#dropmenu p span').removeClass('dropmenuiconnarea')
                    }
                    else {
                        $('#dropmenu').removeClass('active');
                        $('#dropmenu p span').removeClass('dropmenuiconnarea')
                        $('#blog').addClass('active')

                    }
                    BlogDetailsLoad(blogdata);
                }




            }
            else {
                var v = window.location.pathname.split('/');
                if (v.length != 3) {
                   // window.location.href = weburl + "/blog/home";
                }
            }

        },
        failure: function (response) {
            alert(response.d);
        }
    });
}
function BlogDetailsLoad(blogdata) {  

    $('#Blogarea').html('');
    var stringhtml = '<div class="eachblogcomentarea">' +
                        '<div class="headingarea">' +
                            '<div class="hleftpart">' +
                            '<h2><a href=' + siteurl + '/FGEngine/PrevBlog/BlogDetails.aspx?postid={Postid}&Action=2&Category={CatName}&Formatedtitle={TitleFormat}>{Title}</a></h2>' +
                            '</div>' +
                            '<div class="hrightpart">{Date}</div>' +
                        '</div>' +
                        '<div class="contarea">' +
                          '<p>' +
                            '<a href=' + siteurl + '/FGEngine/PrevBlog/BlogDetails.aspx?postid={Postid}&Action=2&Category={CatName}&Formatedtitle={TitleFormat}><img src="{CoverImage}" alt="{coverimagetag}" class="imgspace img-responsive" title="{CoverImageTitle}"></a>' +
                                '{ShortDescription}' +
                                '<span class="blogreadmore"><a href=' + siteurl + '/FGEngine/PrevBlog/BlogDetails.aspx?postid={Postid}&Action=2&Category={CatName}&Formatedtitle={TitleFormat} target="_self">Read More</a></span>' +
                           '</p>' +
                        '</div>' +
                   ' </div> ';
    var outputhtml = '';

    if (blogdata.length > 0) {
        if ($('#hdnpagecount').val() == "") {
            $('#hdnpagecount').val(blogdata[0].Pagecount);
        }
    }
    if (blogdata[0].Pagecount <= 1) {
        $('.paginationarea').hide();
    }

    for (var i = 0; i < blogdata.length; i++) {

        outputhtml += stringhtml.format({
            Title: blogdata[i].Title,
            Date: blogdata[i].Date,
            ShortDescription: blogdata[i].ShortDescription,
            CoverImage: blogdata[i].CoverImage,
            Postid: blogdata[i].PostID,
            TitleFormat: blogdata[i].FormatedTitle,
            CatName: blogdata[i].CategoryName,
            CoverImageTitle: blogdata[i].Coverimagetitle,
            coverimagetag: blogdata[i].CoverImageTag
        });
        if (i == 2 && blogdata.length > 3) {

            if (getBanner != "") {
                var bannerhtml = '<div id="homemiddlebanner">'
                if (getBanner.others.middlehome != undefined) {

                    if (getBanner.others.middlehome.type == 0 || getBanner.others.middlehome.type == 2) {
                        bannerhtml += '<a ';//href={hyperlink}  target={targetmode}><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></a></div>'
                        if (getBanner.others.middlehome.Hyperlink != "") {
                            bannerhtml += 'href={hyperlink}  target={targetmode}';
                        }
                        bannerhtml += '><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></a></div>'
                        outputhtml += bannerhtml.format({
                            imagesrc: getBanner.others.middlehome.imagepath,
                            alttext: getBanner.others.middlehome.AltTag,
                            hyperlink: getBanner.others.middlehome.Hyperlink,
                            targetmode: getBanner.others.middlehome.Hyperlinktype,
                            imgtitle: getBanner.others.middlehome.Tittle
                        })
                    }
                    if (getBanner.others.middlehome.type == 1) {
                        outputhtml += getBanner.others.middlehome.imagepath;
                    }
                }
                bannerhtml = '';
                bannerhtml = '<div id="midlecategory">'
                if (getBanner.others.midlecategory != undefined) {
                    if (getBanner.others.midlecategory.type == 0 || getBanner.others.midlecategory.type == 2) {
                        bannerhtml += '<a href={hyperlink}  target={targetmode}><li><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></li></a></div>'
                        outputhtml += bannerhtml.format({
                            imagesrc: getBanner.others.midlecategory.imagepath,
                            alttext: getBanner.others.midlecategory.AltTag,
                            hyperlink: getBanner.others.midlecategory.Hyperlink,
                            targetmode: getBanner.others.midlecategory.Hyperlinktype,
                            imgtitle: getBanner.others.midlecategory.Tittle
                        })
                    }
                    if (getBanner.others.midlecategory.type == 1) {
                        outputhtml += getBanner.others.midlecategory.imagepath;
                    }
                }
            }

        }

    }
    $('#Blogarea').html();

    $('#Blogarea').append(outputhtml);
    var pagedisplay = '';
    var output = '';
    var nextpage = parseInt($('#hdnpageindex').val());
    pagedisplay = '{pagecount} of {pagetotalcount}';
    output += pagedisplay.format({ pagecount: nextpage, pagetotalcount: parseInt($('#hdnpagecount').val()) });
    $('#pageingdisp').html('');
    $('#pageingdisp').html(output);
    if (parseInt($('#hdnpagecount').val()) > parseInt($('#hdnpageindex').val())) {
        $('#next').removeClass('disabled');
        $('#next').addClass('active');
        $('#next').css('cursor', 'pointer');
        $('#last').removeClass('disabled');
        $('#last').addClass('active');
        $('#last').css('cursor', 'pointer');

    }
    if (blogdata.length > 0) {
        PreparePagingHtml(blogdata[0].Pagecount);
    }
    if (getBanner != "") {
        var bannerhtml = '<div>'
        var banneroutputhtml = "";
        if (getBanner.others.bottomhome != undefined) {
            if (getBanner.others.bottomhome.type == 0 || getBanner.others.bottomhome.type == 2) {
                bannerhtml += '<a '//href={hyperlink} target={targetmode}><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></a></div>'
                if (getBanner.others.bottomhome.Hyperlink != "") {
                    bannerhtml += 'href={hyperlink} target={targetmode}';
                }
                bannerhtml += '><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></a></div>';
                banneroutputhtml += bannerhtml.format({
                    imagesrc: getBanner.others.bottomhome.imagepath,
                    alttext: getBanner.others.bottomhome.AltTag,
                    hyperlink: getBanner.others.bottomhome.Hyperlink,
                    targetmode: getBanner.others.bottomhome.Hyperlinktype,
                    imgtitle: getBanner.others.bottomhome.Tittle
                })
            }
            if (getBanner.others.bottomhome.type == 1) {
                banneroutputhtml += getBanner.others.bottomhome.imagepath;
            }
        }
    }
    if ($('#bottombanner').find('img').length <= 0)
        $('#bottombanner').append(banneroutputhtml);
    var v = window.location.pathname;
    if (v == "/FGEngine/PrevBlog/BlogCategory.aspx") {
        $('#midlecategory').hide();
        $('#homemiddlebanner').show();
    } else {
        $('#midlecategory').show();
        $('#homemiddlebanner').hide();
    }

}
//Category Section
function Movenext(BlogCategoryId) {


    var pagedisplay = '';
    var output = '';
    var totalpagecount = parseInt($('#hdnpagecount').val());
    var nextpage = parseInt($('#hdnpageindex').val()) + 1;
    if (parseInt($('#hdnpagecount').val()) >= nextpage) {

        AdminGetBlogData(siteurl, nextpage, BlogCategoryId);
        $('body,html').animate({ scrollTop: 0 }, 500);
        $('#hdnpageindex').val(nextpage);
        if (parseInt($('#hdnpagecount').val()) == nextpage) {
            $('#next').addClass('disabled');
            $('#next').removeAttr('style');
            $('#next').removeClass('active');
            $('#last').removeClass('active');
            $('#last').addClass('disabled');
            $('#last').removeAttr('style');
        }
        else {

        }
        pagedisplay = '{pagecount} - {pagetotalcount}';
        output += pagedisplay.format({ pagecount: nextpage, pagetotalcount: parseInt($('#hdnpagecount').val()) });
        $('#pageingdisp').html('');
        $('#pageingdisp').html(output);
        $('#first').removeClass('disabled');
        $('#first').addClass('active');
        $('#first').css('cursor', 'pointer');

        $('#previous').removeClass('disabled');
        $('#previous').addClass('active');
        $('#previous').css('cursor', 'pointer');
    }
    else {
        $('#next').addClass('disabled');
    }
}
function Movelast(BlogCategoryId) {
    var totalpagecount = parseInt($('#hdnpagecount').val());
    var nextpage = totalpagecount;

    AdminGetBlogData(siteurl, nextpage, BlogCategoryId);
    $('body,html').animate({ scrollTop: 0 }, 500);
    $('#hdnpageindex').val(nextpage);
    if (parseInt($('#hdnpagecount').val()) == nextpage) {
        $('#last').addClass('disabled');
        $('#last').removeAttr('style');
        $('#last').removeClass('active');

        $('#next').addClass('disabled');
        $('#next').removeAttr('style');

        $('#first').removeClass('disabled');
        $('#first').addClass('active');
        $('#first').css('cursor', 'pointer');

        $('#previous').removeClass('disabled');
        $('#previous').addClass('active');
        $('#previous').css('cursor', 'pointer');
    }
    else {
        pagedisplay = '{pagecount} of {pagetotalcount}';
        output += pagedisplay.format({ pagecount: nextpage, pagetotalcount: parseInt($('#hdnpagecount').val()) });
        $('#pageingdisp').html('');
        $('#pageingdisp').html(output);


    }
}
function Movefirst(BlogCategoryId) {
    var nextpage = 1;
    AdminGetBlogData(siteurl, nextpage, BlogCategoryId);
    $('body,html').animate({ scrollTop: 0 }, 500);
    $('#hdnpageindex').val(nextpage);
    if (nextpage == 1) {
        $('#last').removeClass('disabled');
        $('#last').addClass('active');
        $('#last').css('cursor', 'pointer');

        $('#next').addClass('active');
        $('#next').css('cursor', 'pointer');

        $('#previous').addClass('disabled');
        $('#previous').removeAttr('style');
        $('#previous').removeClass('active');

        $('#first').addClass('disabled');
        $('#first').removeAttr('style');
        $('#first').removeClass('active');
    }
    pagedisplay = '{pagecount} of {pagetotalcount}';
    output += pagedisplay.format({ pagecount: nextpage, pagetotalcount: parseInt($('#hdnpagecount').val()) });
    $('#pageingdisp').html('');
    $('#pageingdisp').html(output);
}
function Moveprevious(BlogCategoryId) {
    var pagedisplay = '';
    var output = '';
    var totalpagecount = parseInt($('#hdnpagecount').val());
    var nextpage = (parseInt($('#hdnpageindex').val()) - 1) == 0 ? 1 : (parseInt($('#hdnpageindex').val()) - 1);
    if (nextpage >= 0) {

        AdminGetBlogData(siteurl, nextpage, BlogCategoryId);
        $('body,html').animate({ scrollTop: 0 }, 500);
        $('#hdnpageindex').val(nextpage);
        if (nextpage == 1) {
            $('#previous').removeClass('active');
            $('#previous').addClass('disabled');
            $('#previous').removeAttr('style');

            $('#first').removeClass('active');
            $('#first').addClass('disabled');
            $('#first').removeAttr('style');

            $('#next').removeClass('disabled');
            $('#next').addClass('active');
            $('#next').css('cursor', 'pointer');

            $('#last').removeClass('disabled');
            $('#last').addClass('active');
            $('#last').css('cursor', 'pointer');
        }
        else {
            pagedisplay = '{pagecount} of {pagetotalcount}';
            output += pagedisplay.format({ pagecount: nextpage, pagetotalcount: parseInt($('#hdnpagecount').val()) });
            $('#pageingdisp').html('');
            $('#pageingdisp').html(output);
            $('#last').removeClass('disabled');
            $('#last').addClass('active');
            $('#last').css('cursor', 'pointer');

            $('#next').removeClass('disabled');
            $('#next').addClass('active');
            $('#next').css('cursor', 'pointer');
        }


    }
    else {
        $('#previous').removeClass('active');
        $('#previous').addClass('disabled');
    }
}
function PreparePagingHtml(pagecount) {
    var stringhtml = '<li><a>{PageNo}</a></li>'
    var outputhtml = '';
    for (var i = 0; i < pagecount ; i++) {
        outputhtml += stringhtml.format({ "PageNo": i + 1 });
    }
    if (pagecount > 1) {
        outputhtml += '<li><a  >Next Page</a></li>'
    }
    //$('#myul').html('');
    //$('#myul').append(outputhtml);
    BindClicktopaging();
}
function BindClicktopaging() {
 
    $('#myul li a').each(function () {
        var $a = $(this);
        $a.click(function () {
            if ($a.html() == "Next Page") {
            }
            else {
                var nextpage = parseInt($a.html());
                AdminGetBlogData(siteurl, nextpage, 0);
            }
        });
    });
}
//End of Category section

//Blog Details Section

function BlogDetailsLoads(url, getBlogDetailsdata) {
    siteurl = url;
    var getBlogDetails = getBlogDetailsdata;
    if (getBlogDetails != undefined) {
        if (getBlogDetails.length > 0) {
            if (getBlogDetails[0] != undefined) {

                var URL = siteurl + window.location.pathname;
                if (sessionStorage.getItem('data') != "" && sessionStorage.getItem('data') != undefined) {
                    $('#txtsearch').val(sessionStorage.getItem('data'));
                }
                $('title').html(getBlogDetails[0].PageTitle);
                $('meta[name=keywords]').attr('content', getBlogDetails[0].BlogMetakeywords)
                $('meta[name=description]').attr('content', getBlogDetails[0].BlogMetadescription)
                $('meta[name="og:url"]').attr('content', URL)
                $('meta[name="twitter:url"]').attr('content', URL)

            }


            var stringhtml = '<div class="eachblogcomentarea">' +
                           '<div class="headingarea">' +
                                '<div class="hleftpart">' +
                                    '<h2>{Title}</h2>' +
                                    '<h3>Author: {AuthorName}</h3>' +
                                '</div>' +
                               '<div class="hrightpart">{Date}</div>' +
                           '</div>' +
                           '<div class="contarea">' +
                                '<p>' +
                                   '<div class="picarea_blog">' +
                                        '<img src="{FeatureImage}" alt="{featureimagealttag}" title={FeatureImageTitle}>' +
                                        '<span>{Caption}<span>' +
                                   '</div>' +
                                   '{Description}' +
                                   '<br>' +
                                '</p>' +
                           '</div>' //+
            '<div class="tag_blogdetails">'// +
            //' </div> ';
            var outputhtml = '';
            outputhtml += stringhtml.format({
                Title: getBlogDetails[0].Title,
                Date: getBlogDetails[0].PublishDate,
                Description: getBlogDetails[0].Description,
                FeatureImage: getBlogDetails[0].FeatureImage,
                AuthorName: getBlogDetails[0].AuthorName,
                Caption: getBlogDetails[0].FeatureImageCaption,
                //Tags: getBlogDetails[0].Tags,
                FeatureImageTitle: getBlogDetails[0].FeatureImageTitle,
                featureimagealttag: getBlogDetails[0].FeatureImagealttag.split(',')
            });

            //var taghtml = "<a style='cursor:pointer' onclick=searchtagdetails('{Tags}','" + weburl + "/blogsearch/{formatedTags}')>{Tags}</a>,";
            var taghtml = "<a style='cursor:pointer' onclick=searchtagdetails(event,'" + siteurl + "/blogsearch/{formatedTags}')>{displayTags}</a>";
            var tagoutputhtml = '';
            if (getBlogDetails[0].Tags.length > 0) {
                var blogdata = getBlogDetails[0].Tags.split(',');
                for (var i = 0; i < blogdata.length; i++) {
                    tagoutputhtml += taghtml.format({
                        Tags: $.trim(blogdata[i]),
                        categoryid: getBlogDetails[0].CategoryId,
                        categoryname: getBlogDetails[0].CategoryName,
                        formatedTags: replace(getBlogDetails[0].FormatedTag[i]),
                        displayTags: $.trim(blogdata[i]).replace('|', '')
                    });
                }

                outputhtml += '<div class="tag_blogdetails">' + tagoutputhtml.substring(0, tagoutputhtml.length - 1) + '</div>';
                outputhtml += ' </div></div> '

            }
            $('#BlogContent').html('');
            $('#BlogContent').append(outputhtml);
            $('#dropmenu').addClass('active');
            //$('#headermenu').addClass('active');
            sessionStorage.setItem('data', '');
        }
        else {
            window.location.href = siteurl + "/FGEngine/PrevBlog/BlogCategory.aspx";
        }
    }

    $('body,html').animate({ scrollTop: 0 }, 500);
}
function CheckCaptcha() {
    var isValid = Page_ClientValidate("vgComment");
    if (isValid) {
        var captcha = document.getElementById("hdnCaptcha").value;

        if (captcha != $('#txtCode').val() && $('#txtCode').val().length > 0) {
            $('#lblCapVeri').css("display", "block");
            $('#lblCapVeri').text("Invalid Captcha Code.");
            $('#txtCode').focus();
            return false;
        }
        else {
            $('#lblCapVeri').html('');
            alert('Your remark has been successfully submitted.');
            return true;
        }
    }
    else {
        return false;
    }
}
//End of Details Section

//Start Master page section
//function GetPopularBlog() {



//    if (getPopularBlog.length > 0) {//' + siteurl + '/FGEngine/PrevBlog/BlogDetails.aspx?postid={Postid}&Action=1&Category={CatName}&Formatedtitle={TitleFormat}
//        var stringhtml = '<li><a href=' + siteurl + '/FGEngine/PrevBlog/BlogDetails.aspx?postid={Postid}&Action=1&Category={CatName}&Formatedtitle={FormatedBlogTitle}>{BlogTitle}</a></li>';
//        var outputhtml = '';
//        for (var i = 0; i < getPopularBlog.length; i++) {
//            outputhtml += stringhtml.format({ Postid: getPopularBlog[i].BLOGPOSTID, BlogTitle: getPopularBlog[i].TITLE, CatName: getPopularBlog[i].CategoryName, FormatedBlogTitle: replace(getPopularBlog[i].FormatedTitle) });
//        }
//        $('#ulpopularblog').append(outputhtml);
//    }
//}
//function GetRecentPost() {


//    if (getRecentpost.length > 0) {
//        var stringhtml = '<li><a href=' + siteurl + '/FGEngine/PrevBlog/BlogDetails.aspx?postid={Postid}&Action=1&Category={CatName}&Formatedtitle={FormatedBlogTitle}>{BlogTitle}</a></li>';
//        var outputhtml = '';
//        for (var i = 0; i < getRecentpost.length; i++) {
//            outputhtml += stringhtml.format({ Postid: getRecentpost[i].BLOGPOSTID, BlogTitle: getRecentpost[i].TITLE, CatName: replace(getRecentpost[i].CategoryName), FormatedBlogTitle: replace(getRecentpost[i].FormatedTitle) });
//        }
//        $('#RecPosts').append(outputhtml);
//    }
//}
function GetBanner() {
    var v = window.location.pathname.split('/');

    var stringhtml = ''//href={hyperlink}  target={targetmode}><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></a></li>';

    var outputhtml = '';
    var sliderhtml = '';
    if (getBlogBanner.Slider != undefined) {
        for (var i = 0; i < getBlogBanner.Slider.length; i++) {
            stringhtml = '<li><a ';
            if (getBlogBanner.Slider[i].type == 0 || getBlogBanner.Slider[i].type == 2) {
                if (getBlogBanner.Slider[i].Hyperlink != "") {
                    stringhtml += 'href={hyperlink}  target={targetmode}'
                }
                stringhtml += '><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></a></li>';
                sliderhtml = stringhtml;
                outputhtml += sliderhtml.format({
                    imagesrc: getBlogBanner.Slider[i].imagepath,
                    alttext: getBlogBanner.Slider[i].AltTag,
                    hyperlink: getBlogBanner.Slider[i].Hyperlink,
                    targetmode: getBlogBanner.Slider[i].Hyperlinktype,
                    imgtitle: getBlogBanner.Slider[i].Tittle
                })
            }
            if (getBlogBanner.Slider[i].type == 1) {
                getBlogBanner.Slider[i].imagepath
                var div = document.createElement('div');
                $(div).append(getBlogBanner.Slider[i].imagepath);

                sliderhtml = stringhtml;
                outputhtml += sliderhtml.format({
                    imagesrc: $(div).find('img').attr('src'),
                    alttext: $(div).find('img').attr('alt'),
                    hyperlink: '#',
                    targetmode: getBlogBanner.Slider[i].Hyperlinktype,
                    imgtitle: getBlogBanner.Slider[i].Tittle
                });
                $(div).html('');

            }
            //if (getBlogBanner.Slider[i].type == 2) {
            //    sliderhtml = stringhtml;
            //    outputhtml += sliderhtml.format({
            //        imagesrc: getBlogBanner.Slider[i].imagepath,
            //        alttext: getBlogBanner.Slider[i].AltTag,
            //        hyperlink: getBlogBanner.Slider[i].Hyperlink,
            //        targetmode: getBlogBanner.Slider[i].Hyperlinktype,
            //        imgtitle: getBlogBanner.Slider[i].Tittle
            //    });
            //}

            //$('#flexiselDemo3').append(outputhtml);
            //outputhtml = ''

        }
    }
    $('#flexiselDemo3').append(outputhtml);
    $("#flexiselDemo3").flexisel({
        visibleItems: 3,
        animationSpeed: 1000,
        autoPlay: true,
        autoPlaySpeed: 3000,
        pauseOnHover: true,
        enableResponsiveBreakpoints: true,
        responsiveBreakpoints: {
            portrait: {
                changePoint: 480,
                visibleItems: 1
            },
            landscape: {
                changePoint: 640,
                visibleItems: 2
            },
            tablet: {
                changePoint: 768,
                visibleItems: 3
            }
        }
    });
    if (getBlogBanner.others.toprightbanner != undefined) {
        var html = '';
        outputhtml = ''
        if (getBlogBanner.others.toprightbanner.type == 0 || getBlogBanner.others.toprightbanner.type == 2) {
            html = '<a ';
            if (getBlogBanner.others.toprightbanner.Hyperlink != "") {
                html += 'href={hyperlink} target={targetmode}';
            }
            html += '><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></a>';
            outputhtml = html.format({
                imagesrc: getBlogBanner.others.toprightbanner.imagepath,
                alttext: getBlogBanner.others.toprightbanner.AltTag,
                hyperlink: getBlogBanner.others.toprightbanner.Hyperlink,
                targetmode: getBlogBanner.others.toprightbanner.Hyperlinktype,
                imgtitle: getBlogBanner.others.toprightbanner.Tittle
            })
        }
        if (getBlogBanner.others.toprightbanner.type == 1) {
            outputhtml = html = getBlogBanner.others.toprightbanner.imagepath;
        }
        $('#toprightbanner').html('')
        $('#toprightbanner').append(outputhtml);
    }
    // stringhtml.format({imagesrc:getBlogBanner.Slider[i].imagepath})
    if (getBlogBanner.others.topmiddlecategory != undefined) {
        var html = '';
        outputhtml = ''
        if (getBlogBanner.others.topmiddlecategory.type == 0 || getBlogBanner.others.topmiddlecategory.type == 2) {
            html = '<a';
            if (getBlogBanner.others.topmiddlecategory.Hyperlink != "") {
                html += ' href={hyperlink} target={targetmode}';
            }
            html += '><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></a>'
            outputhtml = html.format({
                imagesrc: getBlogBanner.others.topmiddlecategory.imagepath,
                alttext: getBlogBanner.others.topmiddlecategory.AltTag,
                hyperlink: getBlogBanner.others.topmiddlecategory.Hyperlink,
                targetmode: getBlogBanner.others.topmiddlecategory.Hyperlinktype,
                imgtitle: getBlogBanner.others.topmiddlecategory.Tittle
            })
        }
        if (getBlogBanner.others.topmiddlecategory.type == 1) {
            outputhtml = html = getBlogBanner.others.topmiddlecategory.imagepath;
        }
        if ($('#topmidddlecategory') != undefined) {
            $('#topmidddlecategory').html('')
            $('#topmidddlecategory').append(outputhtml);
        }
    }
    if (getBlogBanner.others.toprightcategory != undefined) {
        var html = '';
        outputhtml = ''
        if (getBlogBanner.others.toprightcategory.type == 0 || getBlogBanner.others.toprightcategory.type == 2) {
            html = '<a';
            if (getBlogBanner.others.toprightcategory.Hyperlink != "") {
                html += ' href="{hyperlink}" target={targetmode}';
            }
            html += '><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></a>';
            outputhtml = html.format({
                imagesrc: getBlogBanner.others.toprightcategory.imagepath,
                alttext: getBlogBanner.others.toprightcategory.AltTag,
                hyperlink: getBlogBanner.others.toprightcategory.Hyperlink,
                targetmode: getBlogBanner.others.toprightcategory.Hyperlinktype,
                imgtitle: getBlogBanner.others.topmiddlecategory.Tittle
            })
        }
        if (getBlogBanner.others.toprightcategory.type == 1) {
            outputhtml = html = getBlogBanner.others.toprightcategory.imagepath;
        }

        $('#toprightcategory').html('')
        $('#toprightcategory').append(outputhtml);

    }
    if (getBlogBanner.others.toprightblogdetails != undefined) {
        var html = '';
        outputhtml = ''
        if (getBlogBanner.others.toprightblogdetails.type == 0 || getBlogBanner.others.toprightblogdetails.type == 2) {
            html = '<a '
            if (getBlogBanner.others.toprightblogdetails.Hyperlink != "") {
                html += 'href={hyperlink} target={targetmode}';
            }
            html += '><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></a>';
            outputhtml = html.format({
                imagesrc: getBlogBanner.others.toprightblogdetails.imagepath,
                alttext: getBlogBanner.others.toprightblogdetails.AltTag,
                hyperlink: getBlogBanner.others.toprightblogdetails.Hyperlink,
                targetmode: getBlogBanner.others.toprightblogdetails.Hyperlinktype,
                imgtitle: getBlogBanner.others.toprightblogdetails.Tittle
            })
        }
        if (getBlogBanner.others.toprightblogdetails.type == 1) {
            outputhtml = html = getBlogBanner.others.toprightblogdetails.imagepath;
        }

        $('#toprightblogdetails').html('')
        $('#toprightblogdetails').append(outputhtml);

    }
    if (getBlogBanner.others.bottommiddleblogdetails != undefined) {
        var html = '';
        outputhtml = ''
        if (getBlogBanner.others.bottommiddleblogdetails.type == 0 || getBlogBanner.others.bottommiddleblogdetails.type == 2) {
            html = '<a ';
            if (getBlogBanner.others.bottommiddleblogdetails.Hyperlink != "") {
                html += 'href={hyperlink} target={targetmode}';
            }
            html += '><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></a>';
            outputhtml = html.format({
                imagesrc: getBlogBanner.others.bottommiddleblogdetails.imagepath,
                alttext: getBlogBanner.others.bottommiddleblogdetails.AltTag,
                hyperlink: getBlogBanner.others.bottommiddleblogdetails.Hyperlink,
                targetmode: getBlogBanner.others.bottommiddleblogdetails.Hyperlinktype,
                imgtitle: getBlogBanner.others.bottommiddleblogdetails.Tittle
            })
        }
        if (getBlogBanner.others.bottommiddleblogdetails.type == 1) {
            outputhtml = html = getBlogBanner.others.bottommiddleblogdetails.imagepath;
        }

        $('#bottommiddleblogdetails').html('')
        $('#bottommiddleblogdetails').append(outputhtml);

    }
    if (v[3]=="BlogDetails.aspx") {
        //$('#toprightbanner').hide();
        //$('#dvslider').hide();
        //$('#bottombanner').hide();
        //$('#homemiddlebanner').hide();
        //$('#toprightblogdetails').hide();
        //$('#bottommiddleblogdetails').hide();
        $('#toprightcategory').hide();
        $('#topmidddlecategory').hide();
        $('#toprightblogdetails').hide();
        $('#bottommiddleblogdetails').hide();
        $('#dvslider').hide();
    }
    else if (v[3]=="BlogCategory.aspx") {
        //$('#toprightbanner').hide();
        //$('#toprightcategory').hide();
        //$('#topmidddlecategory').hide();
        $('#toprightbanner').show();

        $('#toprightcategory').hide();
        $('#topmidddlecategory').hide();
        $('#toprightblogdetails').hide();
        $('#bottommiddleblogdetails').hide();
        $('#dvslider').show();

    }
    else {
        //$('#toprightcategory').hide();
        //$('#topmidddlecategory').hide();
        //$('#toprightblogdetails').hide();
        //$('#bottommiddleblogdetails').hide();
        //$('#dvslider').show();
        $('#toprightbanner').hide();
        $('#toprightbanner').hide();
        $('#toprightcategory').show();
        $('#topmidddlecategory').hide();
        $('#dvslider').hide();
    }

}
//function Search(getBlogsearch) {
//    var txtSearch = $("#txtsearch");
//    searchchar = txtSearch.val().trim();

//    var outputhtml = '';
//    if (searchchar != "") {
//        var resultSet = $.grep(getBlogsearch, function (e) {
//            if (e.title.toLowerCase().indexOf(searchchar.toLowerCase()) >= 0) {
//                return e;
//            }
//            else if (e.tags.toLowerCase().indexOf(searchchar.toLowerCase()) >= 0) {
//                return e;
//            }
//            else if (e.CategoryName.toLowerCase().indexOf(searchchar.toLowerCase()) >= 0) {
//                return e;
//            }

//        });
//        var result = resultSet;
//        //var serachoptionhtml = "<a href=''><p class='searchclick' onclick=getdata({BlogId},'{CategoryName}','{FormatedTitle}','{FormatedTitle}')>{Title}</p></a><hr>"
//        var serachoptionhtml = "<a class='searchclick' href='" + weburl + "/blog/{BlogId}/1/{CategoryName}/{FormatedTitles}' onclick=getdata({BlogId},'{CategoryName}','{FormatedTitle}','{FormatedTitle}')><p>{Title}</p></a><hr>"
//        var outputhtml = '';
//        if (result.length > 0) {
//            for (var i = 0; i < (result.length <= 15 ? result.length : 15) ; i++) {
//                outputhtml += serachoptionhtml.format({
//                    Title: result[i].title,
//                    BlogId: result[i].blogid,
//                    CategoryName: replace(result[i].FormatedCategoryName),
//                    FormatedTitle: escape(result[i].title),
//                    FormatedTitles: replace(result[i].title)

//                });

//            }
//            $('#dvsearchlist').html('');

//            $('#dvsearchlist').append(outputhtml);
//            $('#dvsearchlist').show();
//        }
//        else {
//            $('#dvsearchlist').hide();
//            $('#dvsearchlist').html('');
//        }
//    }
//    else {
//        $('#dvsearchlist').hide();
//        $('#dvsearchlist').html('');
//    }
//}
function replace(string) {
    return $.trim(string.replace(/[^a-zA-Z0-9]/g, '-').replace(/-+/g, '-'));
}
//function SearchByTag(txtsearch) {
//    //if (typeof (history.pushState) != "undefined") {
//    //    var obj = { Page: weburl + "/BlogTagSearch.aspx", Url: weburl + "/BlogTagSearch.aspx?searchbytag=" + txtsearch };
//    //    history.pushState(obj, obj.Page, obj.Url);
//    //} else {
//    //    alert("Browser does not support HTML5.");
//    //}
//    $.ajax({
//        type: "POST",
//        //url: WebURL + "/FGBlog/BlogCategory.aspx/GetBlog","
//        url: weburl + "/FGBlog/BlogService.asmx/GetSearchbyTag",
//        data: '{"searchstring":"' + txtsearch + '","pageIndex":"' + 1 + '"}',
//        contentType: "application/json; charset=utf-8",
//        dataType: "json",
//        success: function (response) {
//            var names = response.d;
//            var BlogPl = '';

//            if (response.d.length > 0) {

//                //while (txtsearch.indexOf(' ') != -1) {
//                //    txtsearch = txtsearch.replace(' ', '-');
//                //}

//                window.location.href = weburl + "/blogsearch/" + replace(txtsearch);


//            }
//            else {
//                //var v = window.location.pathname.split('/');
//                //if (v.length != 3) {
//                //    window.location.href = weburl + "/blog/home";

//                //}
//                $('#lblsearcherror').html('No match found');
//                $('#lblsearcherror').show();
//                // alert('No match found');

//            }

//        },
//        failure: function (response) {
//            alert(response.d);
//        }
//    });

//}

//function SaveSubscriptionMailRecord() {

//    var Mail = $.trim($('#txtEmail').val());
//    var Messege = "";

//    if (Mail == '') {
//        Messege = "Please enter your Email ID";
//        $('#lblerrMsg1').css({ color: 'red' });
//    }
//    else {
//        var emailformat = /^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$/;
//        if (Mail.search(emailformat) == -1) {
//            Messege = "Please enter valid Email ID";
//            $('#lblerrMsg1').css({ color: 'red' });
//        }
//    }
//    if (Messege.length == 0) {
//        setTimeout(function () {
//            $.ajax({
//                type: "POST",
//                dataType: "json",
//                contentType: "application/json; charset=utf-8",
//                url: weburl + "/FGBlog/BlogService.asmx/SaveUser",
//                data: "{'Mail':'" + Mail + "'}",
//                success: function (response) {

//                    $('#txtEmail').val();

//                    $('#lblerrMsg1').text(response.d.ErrorMsg);
//                    if (response.d.ErrorCode == 0) {
//                        $('#lblerrMsg1').css({ color: 'green' });
//                    }
//                    else {
//                        $('#lblerrMsg1').css({ color: 'red' });
//                    }

//                    $('#btnblogsubmit').hide();
//                    //if (Record.d == true) {  

//                    //    $('#lblerrMsg').text("Your Record insert");  
//                    //}  
//                    //else {  
//                    //    $('#lblerrMsg').text("Your Record Not Insert");  
//                    //}  

//                },
//                Error: function (textMsg) {

//                    $('#lblerrMsg1').text("Error: " + Error);
//                }
//            });
//        }, 100)
//    }
//    else {
//        $('#lblerrMsg1').html('');
//        $('#lblerrMsg1').html(Messege);
//    }
//    $('#lblerrMsg1').fadeIn();
//}

//function URLvalidate(source, args) {
//    if (document.getElementById(source.controltovalidate).value.indexOf("<") >= 0 || document.getElementById(source.controltovalidate).value.indexOf(">") >= 0 || document.getElementById(source.controltovalidate).value.indexOf(";") >= 0 || document.getElementById(source.controltovalidate).value.indexOf("http://") == -1 || document.getElementById(source.controltovalidate).value.indexOf("https://") == -1)
//        args.IsValid = false;
//    else
//        args.IsValid = true;
//}

//function AdminInterfaceCharactervalidate(source, args) {

//    if (
//               document.getElementById(source.controltovalidate).value.indexOf(">") >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf("<") >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('+') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('&') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('"') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf("'") >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('%') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf(';') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf(")") >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf("(") >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('/') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf("\\") >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('|') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('=') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('{') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('}') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf(']') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('[') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf(':') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('~') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('`') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('^') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('*') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('!') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('@') >= 0
//            || document.getElementById(source.controltovalidate).value.indexOf('$') >= 0
//        )
//        args.IsValid = false;
//    else
//        args.IsValid = true;
//}
//function CommentCharactervalidate(source, args) {
//    if (document.getElementById(source.controltovalidate).value.indexOf(">") >= 0 || document.getElementById(source.controltovalidate).value.indexOf("<") >= 0)
//        args.IsValid = false;
//    else
//        args.IsValid = true;
//}

////Search Page
//function GetSearchData(url, Searchdata) {
//    weburl = url;
//    if (Searchdata.length > 0) {
//        var blogdata = Searchdata;
//        SBlogDetailsLoad(blogdata);
//    }

//    else {
//        /*
//        var v = window.location.pathname.split('/');
//        //if (v.length != 3) {
//            window.location.href = weburl + "/blog/home";
//       // }
//      window.alert('No match found')*/




//        alert('No match found');
//        var v = window.location.pathname.split('/');
//        //if (v.length != 3) {
//        window.location.href = weburl + "/blog/home";
//        // }
//    }
//}
//function SBlogDetailsLoad(blogdata) {

//    if (blogdata[0] != undefined && blogdata[0].PageTitle !== "") {
//        //$('title').html(blogdata[0].PageTitle);
//        $('meta[name=keywords]').attr('content', blogdata[0].MetaKeyword)
//        $('meta[name=description]').attr('content', blogdata[0].MetaDescription)
//    }

//    $('#Blogarea').html('');
//    var stringhtml = '<div class="eachblogcomentarea">' +
//                        '<div class="headingarea">' +
//                            '<div class="hleftpart">' +
//                            '<h2><a href=' + weburl + '/blog/{Postid}/1/{CatName}/{TitleFormat}>{Title}</a></h2>' +
//                            '</div>' +
//                            '<div class="hrightpart">{Date}</div>' +
//                        '</div>' +
//                        '<div class="contarea">' +
//                          '<p>' +
//                            '<a href=' + weburl + '/blog/{Postid}/1/{CatName}/{TitleFormat}><img src="{CoverImage}" alt="" class="imgspace img-responsive" title="{CoverImageTitle}"></a>' +
//                                '{ShortDescription}' +
//                                '<span class="blogreadmore"><a href=' + weburl + '/blog/{Postid}/1/{CatName}/{TitleFormat} target="_self">Read More</a></span>' +
//                           '</p>' +
//                        '</div>' +
//                   ' </div> ';
//    var outputhtml = '';

//    if (blogdata.length > 0) {
//        if ($('#hdnpagecount').val() == "") {
//            $('#hdnpagecount').val(blogdata[0].Pagecount);
//        }
//    }
//    if (blogdata[0].Pagecount <= 1) {
//        $('.paginationarea').hide();
//    }

//    for (var i = 0; i < blogdata.length; i++) {

//        outputhtml += stringhtml.format({
//            Title: blogdata[i].Title,
//            Date: blogdata[i].Date,
//            ShortDescription: blogdata[i].ShortDescription,
//            CoverImage: blogdata[i].CoverImage,
//            Postid: blogdata[i].PostID,
//            TitleFormat: blogdata[i].FormatedTitle,
//            CatName: blogdata[i].CategoryName,
//            CoverImageTitle: blogdata[i].Coverimagetitle
//        });
//        if (i == 2 && blogdata.length > 3) {

//            if (getBanner != "") {
//                var bannerhtml = '<div id="homemiddlebanner">'
//                if (getBanner.others.middlehome != undefined) {

//                    if (getBanner.others.middlehome.type == 0 || getBanner.others.middlehome.type == 2) {
//                        bannerhtml += '<a ';//href={hyperlink}  target={targetmode}><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></a></div>'
//                        if (getBanner.others.middlehome.Hyperlink != "") {
//                            bannerhtml += 'href={hyperlink}  target={targetmode}';
//                        }
//                        bannerhtml += '><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></a></div>'
//                        outputhtml += bannerhtml.format({
//                            imagesrc: getBanner.others.middlehome.imagepath,
//                            alttext: getBanner.others.middlehome.AltTag,
//                            hyperlink: getBanner.others.middlehome.Hyperlink,
//                            targetmode: getBanner.others.middlehome.Hyperlinktype,
//                            imgtitle: getBanner.others.middlehome.Tittle
//                        })
//                    }
//                    if (getBanner.others.middlehome.type == 1) {
//                        outputhtml += getBanner.others.middlehome.imagepath;
//                    }
//                }
//                bannerhtml = '';
//                bannerhtml = '<div id="midlecategory">'
//                if (getBanner.others.midlecategory != undefined) {
//                    if (getBanner.others.midlecategory.type == 0 || getBanner.others.midlecategory.type == 2) {
//                        bannerhtml += '<a href={hyperlink}  target={targetmode}><li><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></li></a></div>'
//                        outputhtml += bannerhtml.format({
//                            imagesrc: getBanner.others.midlecategory.imagepath,
//                            alttext: getBanner.others.midlecategory.AltTag,
//                            hyperlink: getBanner.others.midlecategory.Hyperlink,
//                            targetmode: getBanner.others.midlecategory.Hyperlinktype,
//                            imgtitle: getBanner.others.midlecategory.Tittle
//                        })
//                    }
//                    if (getBanner.others.midlecategory.type == 1) {
//                        outputhtml += getBanner.others.midlecategory.imagepath;
//                    }
//                }
//            }

//        }

//    }
//    $('#Blogarea').html();

//    $('#Blogarea').append(outputhtml);
//    var pagedisplay = '';
//    var output = '';
//    var nextpage = parseInt($('#hdnpageindex').val());
//    pagedisplay = '{pagecount} of {pagetotalcount}';
//    output += pagedisplay.format({ pagecount: nextpage, pagetotalcount: parseInt($('#hdnpagecount').val()) });
//    $('#pageingdisp').html('');
//    $('#pageingdisp').html(output);
//    if (parseInt($('#hdnpagecount').val()) > parseInt($('#hdnpageindex').val())) {
//        $('#snext').removeClass('disabled');
//        $('#snext').addClass('active');
//        $('#snext').css('cursor', 'pointer');
//        $('#slast').removeClass('disabled');
//        $('#slast').addClass('active');
//        $('#slast').css('cursor', 'pointer');

//    }
//    if (blogdata.length > 0) {
//        PreparePagingHtml(blogdata[0].Pagecount);
//    }
//    if (getBanner != "") {
//        var bannerhtml = '<div>'
//        var banneroutputhtml = "";
//        if (getBanner.others.bottomhome != undefined) {
//            if (getBanner.others.bottomhome.type == 0 || getBanner.others.bottomhome.type == 2) {
//                bannerhtml += '<a '//href={hyperlink} target={targetmode}><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></a></div>'
//                if (getBanner.others.bottomhome.Hyperlink != "") {
//                    bannerhtml += 'href={hyperlink} target={targetmode}';
//                }
//                bannerhtml += '><img src="{imagesrc}" alt="{alttext}" title="{imgtitle}"></a></div>';
//                banneroutputhtml += bannerhtml.format({
//                    imagesrc: getBanner.others.bottomhome.imagepath,
//                    alttext: getBanner.others.bottomhome.AltTag,
//                    hyperlink: getBanner.others.bottomhome.Hyperlink,
//                    targetmode: getBanner.others.bottomhome.Hyperlinktype,
//                    imgtitle: getBanner.others.bottomhome.Tittle
//                })
//            }
//            if (getBanner.others.bottomhome.type == 1) {
//                banneroutputhtml += getBanner.others.bottomhome.imagepath;
//            }
//        }
//    }
//    if ($('#bottombanner').find('img').length <= 0)
//        $('#bottombanner').append(banneroutputhtml);
//    var v = window.location.search;
//    if (v == "") {
//        $('#midlecategory').hide();
//    }
//    if (sessionStorage.getItem('data') != "" && sessionStorage.getItem('data') != undefined) {
//        $('#txtsearch').val(sessionStorage.getItem('data'));
//        sessionStorage.setItem('data', '')
//    }

//}

//function SMovenext(searchdata) {


//    var pagedisplay = '';
//    var output = '';
//    var totalpagecount = parseInt($('#hdnpagecount').val());
//    var nextpage = parseInt($('#hdnpageindex').val()) + 1;
//    if (parseInt($('#hdnpagecount').val()) >= nextpage) {

//        getsearchblogdata(searchdata, nextpage);
//        $('body,html').animate({ scrollTop: 0 }, 500);
//        $('#hdnpageindex').val(nextpage);
//        if (parseInt($('#hdnpagecount').val()) == nextpage) {
//            $('#snext').addClass('disabled');
//            $('#snext').removeAttr('style');
//            $('#snext').removeClass('active');
//            $('#slast').removeClass('active');
//            $('#slast').addClass('disabled');
//            $('#slast').removeAttr('style');
//        }
//        else {

//        }
//        pagedisplay = '{pagecount} - {pagetotalcount}';
//        output += pagedisplay.format({ pagecount: nextpage, pagetotalcount: parseInt($('#hdnpagecount').val()) });
//        $('#pageingdisp').html('');
//        $('#pageingdisp').html(output);
//        $('#sfirst').removeClass('disabled');
//        $('#sfirst').addClass('active');
//        $('#sfirst').css('cursor', 'pointer');

//        $('#sprevious').removeClass('disabled');
//        $('#sprevious').addClass('active');
//        $('#sprevious').css('cursor', 'pointer');
//    }
//    else {
//        $('#snext').addClass('disabled');
//    }
//}
//function SMovelast(searchdata) {
//    var totalpagecount = parseInt($('#hdnpagecount').val());
//    var nextpage = totalpagecount;
//    getsearchblogdata(searchdata, nextpage);
//    $('body,html').animate({ scrollTop: 0 }, 500);
//    $('#hdnpageindex').val(nextpage);
//    if (parseInt($('#hdnpagecount').val()) == nextpage) {
//        $('#slast').addClass('disabled');
//        $('#slast').removeAttr('style');
//        $('#slast').removeClass('active');

//        $('#snext').addClass('disabled');
//        $('#snext').removeAttr('style');

//        $('#sfirst').removeClass('disabled');
//        $('#sfirst').addClass('active');
//        $('#sfirst').css('cursor', 'pointer');

//        $('#sprevious').removeClass('disabled');
//        $('#sprevious').addClass('active');
//        $('#sprevious').css('cursor', 'pointer');
//    }
//    else {
//        pagedisplay = '{pagecount} of {pagetotalcount}';
//        output += pagedisplay.format({ pagecount: nextpage, pagetotalcount: parseInt($('#hdnpagecount').val()) });
//        $('#pageingdisp').html('');
//        $('#pageingdisp').html(output);


//    }
//}

//function SMovefirst(searchdata) {
//    var nextpage = 1;
//    getsearchblogdata(searchdata, nextpage);
//    $('body,html').animate({ scrollTop: 0 }, 500);
//    $('#hdnpageindex').val(nextpage);
//    if (nextpage == 1) {
//        $('#slast').removeClass('disabled');
//        $('#slast').addClass('active');
//        $('#slast').css('cursor', 'pointer');

//        $('#snext').addClass('active');
//        $('#snext').css('cursor', 'pointer');

//        $('#sprevious').addClass('disabled');
//        $('#sprevious').removeAttr('style');

//        $('#sfirst').addClass('disabled');
//        $('#sfirst').removeAttr('style');
//    }
//    pagedisplay = '{pagecount} of {pagetotalcount}';
//    output += pagedisplay.format({ pagecount: nextpage, pagetotalcount: parseInt($('#hdnpagecount').val()) });
//    $('#pageingdisp').html('');
//    $('#pageingdisp').html(output);
//}
//function SMoveprevious(searchdata) {
//    var pagedisplay = '';
//    var output = '';
//    var totalpagecount = parseInt($('#hdnpagecount').val());
//    var nextpage = (parseInt($('#hdnpageindex').val()) - 1) == 0 ? 1 : (parseInt($('#hdnpageindex').val()) - 1);
//    if (nextpage >= 0) {

//        getsearchblogdata(searchdata, nextpage);
//        $('body,html').animate({ scrollTop: 0 }, 500);
//        $('#hdnpageindex').val(nextpage);
//        if (nextpage == 1) {
//            $('#sprevious').removeClass('active');
//            $('#sprevious').addClass('disabled');
//            $('#sprevious').removeAttr('style');

//            $('#sfirst').removeClass('active');
//            $('#sfirst').addClass('disabled');
//            $('#sfirst').removeAttr('style');

//            $('#snext').removeClass('disabled');
//            $('#snext').addClass('active');
//            $('#snext').css('cursor', 'pointer');

//            $('#slast').removeClass('disabled');
//            $('#slast').addClass('active');
//            $('#slast').css('cursor', 'pointer');
//        }
//        else {
//            pagedisplay = '{pagecount} of {pagetotalcount}';
//            output += pagedisplay.format({ pagecount: nextpage, pagetotalcount: parseInt($('#hdnpagecount').val()) });
//            $('#pageingdisp').html('');
//            $('#pageingdisp').html(output);
//            $('#slast').removeClass('disabled');
//            $('#slast').addClass('active');
//            $('#slast').css('cursor', 'pointer');

//            $('#snext').removeClass('disabled');
//            $('#snext').addClass('active');
//            $('#snext').css('cursor', 'pointer');
//        }


//    }
//    else {
//        $('#sprevious').removeClass('active');
//        $('#sprevious').addClass('disabled');
//    }
//}

//function getsearchblogdata(strserach, nextpage) {
//    $.ajax({
//        type: "POST",
//        //url: WebURL + "/FGBlog/BlogCategory.aspx/GetBlog","
//        url: weburl + "/FGBlog/BlogService.asmx/GetSearchbyTag",
//        data: '{"searchstring":"' + strserach + '","pageIndex":"' + nextpage + '"}',
//        contentType: "application/json; charset=utf-8",
//        dataType: "json",
//        success: function (response) {
//            var names = response.d;
//            var BlogPl = '';
//            var searchsting = strserach;
//            if (response.d.length > 0) {

//                SBlogDetailsLoad(names);


//            }
//            else {
//                var v = window.location.pathname.split('/');
//                if (v.length != 3) {
//                    window.location.href = weburl + "/blog/home";

//                }

//            }

//        },
//        failure: function (response) {
//            alert(response.d);
//        }
//    });

//}


//function SaveComment(IDPost, LoginName, LoginEmail) {
//    $('#lblerrMsg').val('');
//    var isValid = Page_ClientValidate("vgComment");
//    if (isValid) {

//        var Name = $.trim($('#txtname').val());
//        var Comment = $.trim($('#txtcomment').val());
//        var EMail = $.trim($('#txtemail').val());

//        var Messege = '';

//        //if (document.getElementById("hdnCaptcha").value != $('#txtCode').val() && $('#txtCode').val().length > 0) {
//        //    Messege = "Invalid Captcha Code.";
//        //    $('#lblerrMsg').css({ color: 'red' });
//        //    $('#txtCode').focus();
//        //}
//        if (Name == '') {
//            Messege = "Please enter your name.";
//            $('#lblerrMsg').css({ color: 'red' });
//            $('#txtname').focus();
//        }

//        if (EMail == '') {
//            Messege = "Please enter your Email ID";
//            $('#lblerrMsg').css({ color: 'red' });
//            $('#txtemail').focus();
//        }
//        else {
//            var emailformat = /^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$/;
//            if (EMail.search(emailformat) == -1) {
//                Messege = "Please enter valid Email ID.";
//                $('#lblerrMsg').css({ color: 'red' });
//                $('#txtemail').focus();
//            }
//        }
//        if (Comment == '') {
//            Messege = "Please enter your comment.";
//            $('#lblerrMsg').css({ color: 'red' });
//            $('#txtcomment').focus();
//        }

//        if (Messege.length == 0) {

//            $.ajax({
//                type: "POST",
//                dataType: "json",
//                contentType: "application/json; charset=utf-8",
//                url: weburl + "/FGBlog/BlogService.asmx/SaveUserComment",
//                data: "{'IDPost':'" + IDPost + "','Name':'" + Name + "','EMail':'" + EMail + "','Comment':'" + Comment + "', 'Captcha':'" + $('#txtCode').val() + "'}",
//                success: function (response) {

//                    $('#txtname').val();
//                    $('#txtcomment').val();
//                    $('#txtemail').val();

//                    $('#lblerrMsg').text(response.d.ErrorMsg);
//                    if (response.d.ErrorCode == 0) {
//                        $('#lblerrMsg').css({ color: 'green' });

//                        if (LoginName != "") {
//                            $('#txtname').val(LoginName);
//                        } else {
//                            $('#txtname').val('');
//                        }


//                        if (LoginEmail != "") {
//                            $('#txtemail').val(LoginEmail);
//                        } else {
//                            $('#txtemail').val('');
//                        }

//                        //$('#txtname').val('');
//                        //$('#txtemail').val('');
//                        $('#txtcomment').val('');
//                        $('#txtCode').val('');
//                        $('#hdnCaptcha').val(response.d.captachcode);
//                        $('#imgCaptcha').attr('src', response.d.imageurl);
//                    }
//                    else {
//                        $('#lblerrMsg').css({ color: 'red' });
//                        $('#hdnCaptcha').val(response.d.captachcode);
//                        $('#imgCaptcha').attr('src', response.d.imageurl);
//                    }
//                },
//                Error: function (textMsg) {

//                    $('#lblerrMsg').text("Error: " + Error);
//                }
//            });
//        }
//        else {
//            $('#lblerrMsg').html('');
//            $('#lblerrMsg').html(Messege);
//        }
//        $('#lblerrMsg').fadeIn();
//        //$('#lblerrMsg').focus();
//        $('html, body').animate({
//            scrollTop: $("#cmntBtn").offset().top
//        }, 1000);
//    }
//}

//function clear(FieldName, Name, Email, hdnCaptcha) {
//    // alert(FieldName);
//    $('#lblerrMsg').val('');

//    if (FieldName == 'CaptchaCode') {
//        //$('#lblCapVeri').css("display", "none");
//        //$('#lblerrMsg').css("display", "none");
//        $('#lblCapVeri').fadeOut();
//        $('#lblerrMsg').fadeOut();
//    }
//    else if (FieldName == 'errMsg') {

//        //$('#lblerrMsg').css("display", "none");
//        $('#lblerrMsg').fadeOut();
//    }
//    else {
//        $('#dvcommentbox input,textarea').val('');
//        $("#submit").attr('value', 'Submit');
//        $("#hdnCaptcha").attr('value', hdnCaptcha);


//        if (Name != "") {
//            $('#txtname').val(Name);
//        }

//        if (Email != "") {
//            $('#txtemail').val(Email);
//        }


//        $('#RequiredFieldValidator1').css("display", "none");
//        $('#cvCharactervalidate').css("display", "none");
//        $('#RequiredFieldValidator2').css("display", "none");
//        $('#revOtherEmailID').css("display", "none");
//        $('#RequiredFieldValidator15').css("display", "none");
//        $('#cvImageURL').css("display", "none");
//        $('#lblCapVeri').css("display", "none");
//        $('#lblerrMsg').css("display", "none");
//        //$('#lblerrMsg').fadeOut();
//        $('#RequiredFieldValidator4').css("display", "none");

//    }
//}


