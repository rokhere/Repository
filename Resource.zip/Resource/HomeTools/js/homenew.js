﻿
function goTo(sender) {

    var $sender = $(sender);
    var jdata = JSON.parse($sender.attr('data-jdata'));

    Section = jdata.Section;
    At = jdata.At;
    ACI = jdata.ACI;
    Oid = jdata.Oid;
    Purl = jdata.Purl;
    Src = jdata.Src;
    Alt = jdata.Alt;
    OfferDetails = jdata.OfferDetails;

    webUrl = $("#hidWebUrl").val();
    siteUrl = $("#hidSiteUrl").val();

    //// store brand image in local storage    
    if (Section == 'QS' || Src != 'No') {
        localStorage.setItem("Frwdurl", (siteUrl + Src));
    } else {
        localStorage.setItem("Frwdurl", "");
    }
    localStorage.setItem('Frwdalt', Alt);

    var Url = webUrl + "/coupons-discounts-cashback/get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl;
    window.open(Url, '_blank');
}
function SetUrl(sender) {
    //debugger;
    var $sender = $(sender);
    var jdata = JSON.parse($sender.attr('data-jdata'));

    Section = jdata.Section;
    At = jdata.At;
    ACI = jdata.ACI;
    Oid = jdata.Oid;
    Purl = jdata.Purl;
    Src = jdata.Src;
    Alt = jdata.Alt;
    OfferDetails = jdata.OfferDetails;

    webUrl = $("#hidWebUrl").val();
    siteUrl = $("#hidSiteUrl").val();
    loginstate = $("#hidLoginState").val();

    if (Alt != '') {
        $("#spnBrndName").html(Alt);
    } else {
        $("#spnBrndName").hide();
    }

    $('.couponCodeArea').show();

    if (loginstate == 'False') {
        $("#divGoToStore").hide();
        $('#divhrefWithoutlogin').attr("style", "");
        $('#divhrefLogin').attr("style", "");
        $("#divRedBtn").show();
    } else {
        $('#divGoToStore').attr("style", "");
        $("#divGoToStore").show();
        $("#divRedBtn").hide();
    }

    if (OfferDetails != '') {

        $("#spnOfferDetails").show();

        if (Section == 'QS') {
            //OfferDetails = 'Store Offers + ' + OfferDetails;
            OfferDetails = 'Store Offers <span style="color:red;">+ ' + OfferDetails + '</span>'
        }

        $("#spnOfferDetails").html(OfferDetails);

    } else {
        $("#spnOfferDetails").hide();
    }

    $("#hrefLogin").attr("href", webUrl + "/FGLogin.aspx?Rpage=CASHBACK&At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);
    $("#hrefWithoutlogin").attr("href", webUrl + "/coupons-discounts-cashback/get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);
    $("#hrefGoToStore").attr("href", webUrl + "/coupons-discounts-cashback/get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);

    if (Src != '' && Src != 'No') {
        $("#myModalLabel").show();
        $("#myModalLabel").html("<img id='brndImg' class='center-block' src='" + (siteUrl + Src) + "' alt='" + Alt + "' />");
    } else if (Src == 'No') {
        $("#myModalLabel").hide();
    } else {
        $("#myModalLabel").show();
        $("#myModalLabel").html("<div class='breakImage' title='" + Alt + "'>" + Alt + "</div>");
    }

    //// store brand image in local storage  
    if (Section == 'QS' || Src != 'No') {
        localStorage.setItem("Frwdurl", (siteUrl + Src));
    } else {
        localStorage.setItem("Frwdurl", "");
    }
    localStorage.setItem('Frwdalt', Alt);

}

function hideContent(ctrlId) {
    if (ctrlId == 1) {
        $('#divhrefWithoutlogin').attr("style", "display:none");
    }
    if (ctrlId == 2) {
        $('#divhrefLogin').attr("style", "display:none");
    }
    else if (ctrlId == 3) {
        $('#divGoToStore').attr("style", "display:none");
    }

    if ($('#divhrefWithoutlogin').is(':hidden') == true && $('#divGoToStore').is(':hidden') == true) {
        $('.couponCodeArea').hide();
    }
}
function OnPopupClose() {
    var webUrl = $("#hidWebUrl").val();
    console.log(webUrl);
    $.ajax({
        url: webUrl + "/Home.aspx/OnPopupClose",
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        data: {},
        beforeSend: function () {
        },
        success: function (response) {
            //debugger;
            var JMemberId = (response.d.JMemberId);
            var JMemberName = (response.d.JMemberName);
            var JPCity = (response.d.JPCity);
            var JAvailableCashWalletAmount = (response.d.JAvailableCashWalletAmount);
            var JAvailableRewardPoint = (response.d.JAvailableRewardPoint);

            loginstate = JMemberId > 0 ? "True" : "False";
            membername = JMemberName;
            $('#hidMemberName').val(JMemberName);
            $("#hidLoginState").val(JMemberId > 0 ? "True" : "False");
            $('#hidpCity').val(JPCity);

            //$('#ContentPlaceHolder1_hidMemberId').val(JMemberId);
            //$('#ContentPlaceHolder1_hidMemberName').val(JMemberName);

            PopulateLoginPanel1(loginstate, JAvailableCashWalletAmount, JAvailableRewardPoint);
        },
        complete: function () {
        },
        error: function (response) {
            console.log('Error: Some thing is wrong');
        }
    });
}

function PopulateLoginPanel1(loginstate, JAvailableCashWalletAmount, JAvailableRewardPoint) {
    //debugger;
    var pCity = $('#hidpCity').val();
    var userName = $('#hidMemberName').val();

    if (loginstate == 'True' && ($(".userAfterLoginMobile").html() == undefined || $(".userAfterLoginMobile").html().toLowerCase().indexOf(userName.toLowerCase()) == -1)) {

        $('.progress-button').remove();
        $('.userAfterLoginMobile').remove();

        $('#topMenu').append(
        "<li class='userAfterLoginMobile dropdown'>"
        +"<a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false' style='color: rgb(0, 0, 0);'>"
        +"<i class='fa fa-user' aria-hidden='true'></i> Hi, " + userName + "!"
        +"<span class='caret'></span>"
        +"</a>"
        +"<ul class='dropdown-menu subDropMenu'>"
        +"<li id='pcity'>"
        +"<a id='aPreCity' onclick='CityBoxShow_PreCityTrigger();' style='cursor: pointer; text-align: center; color: rgb(0, 0, 0);'>"
        +"<i class='fa fa-map-marker' aria-hidden='true'></i> "+ pCity 
        +"</a>"
        +"</li>"
        + "<li class='progress-button rightSpace'><span><a <a id='btnMyAccount' onclick='btnProfile_onClick();' href='javascript:void(0)'> Profile</a></span></li>"
        + "<li class='progress-button rightSpace'><span><a id='btnLogout' onclick='btnLogout_onClick();' href='javascript:void(0)'> Log Out</a></span></li>"
        + "</ul>"
        + "</li>");
    }
}

function btnProfile_onClick() {
    WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions("ctl00$btnMyAccount", "", true, "", "", false, true));
}
function btnLogout_onClick() {
WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions("ctl00$btnLogout", "", true, "", "", false, true));
}