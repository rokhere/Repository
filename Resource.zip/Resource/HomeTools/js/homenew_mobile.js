﻿
function goTo(sender) {

    window.localStorage.removeItem('isredirected');

    var $sender = $(sender);
    var jdata = JSON.parse($sender.attr('data-jdata'));

    Section = jdata.Section;
    At = jdata.At;
    ACI = jdata.ACI;
    Oid = jdata.Oid;
    Purl = jdata.Purl;
    Src = jdata.Src;
    Alt = jdata.Alt;
    OfferDetails = jdata.OfferDetails;

    webUrl = $("#hidWebUrl").val();
    siteUrl = $("#hidSiteUrl").val();

    //// store brand image in local storage    
    if (Section == 'QS' || Src != 'No') {
        localStorage.setItem("Frwdurl", (siteUrl + Src));
    } else {
        localStorage.setItem("Frwdurl", "");
    }
    localStorage.setItem('Frwdalt', Alt);

    var Url = webUrl + "/m-coupons-discounts-cashback/get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl;
    window.open(Url, '_blank');
}
function SetUrl(sender) {

    window.localStorage.removeItem('isredirected');

    //debugger;
    var $sender = $(sender);
    var jdata = JSON.parse($sender.attr('data-jdata'));

    Section = jdata.Section;
    At = jdata.At;
    ACI = jdata.ACI;
    Oid = jdata.Oid;
    Purl = jdata.Purl;
    Src = jdata.Src;
    Alt = jdata.Alt;
    OfferDetails = jdata.OfferDetails;

    webUrl = $("#hidWebUrl").val();
    siteUrl = $("#hidSiteUrl").val();
    loginstate = $("#hidLoginState").val();

    if (Alt != '') {
        $("#spnBrndName").html(Alt);
    } else {
        $("#spnBrndName").hide();
    }

    $('.couponCodeArea').show();

    if (loginstate == 'False') {
        $("#divGoToStore").hide();
        $('#divhrefWithoutlogin').attr("style", "");
        $('#divhrefLogin').attr("style", "");
        $("#divRedBtn").show();
    } else {
        $('#divGoToStore').attr("style", "");
        $("#divGoToStore").show();
        $("#divRedBtn").hide();
    }

    if (OfferDetails != '') {

        $("#spnOfferDetails").show();

        if (Section == 'QS') {
            //OfferDetails = 'Store Offers + ' + OfferDetails;
            OfferDetails = 'Store Offers <span style="color:red;">+ ' + OfferDetails + '</span>'
        }

        $("#spnOfferDetails").html(OfferDetails);

    } else {
        $("#spnOfferDetails").hide();
    }

    $("#hrefLogin").attr("href", webUrl + "/Muser/MemberLogin.aspx?Rpage=CASHBACK&At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);
    $("#hrefWithoutlogin").attr("href", webUrl + "/m-coupons-discounts-cashback/get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);
    $("#hrefGoToStore").attr("href", webUrl + "/m-coupons-discounts-cashback/get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);

    if (Src != '' && Src != 'No') {
        $("#myModalLabel").show();
        $("#myModalLabel").html("<img id='brndImg' class='center-block' src='" + (siteUrl + Src) + "' alt='" + Alt + "' />");
    } else if (Src == 'No') {
        $("#myModalLabel").hide();
    } else {
        $("#myModalLabel").show();
        $("#myModalLabel").html("<div class='breakImage' title='" + Alt + "'>" + Alt + "</div>");
    }

    //// store brand image in local storage  
    if (Section == 'QS' || Src != 'No') {
        localStorage.setItem("Frwdurl", (siteUrl + Src));
    } else {
        localStorage.setItem("Frwdurl", "");
    }
    localStorage.setItem('Frwdalt', Alt);

}

function hideContent(ctrlId) {
    if (ctrlId == 1) {
        $('#divhrefWithoutlogin').attr("style", "display:none");
    }
    if (ctrlId == 2) {
        $('#divhrefLogin').attr("style", "display:none");
    }
    else if (ctrlId == 3) {
        $('#divGoToStore').attr("style", "display:none");
    }

    if ($('#divhrefWithoutlogin').is(':hidden') == true && $('#divGoToStore').is(':hidden') == true) {
        $('.couponCodeArea').hide();
    }
}
function OnPopupClose() {
    webUrl = $("#hidWebUrl").val();

    $.ajax({
        url: webUrl + "/Muser/index.aspx/OnPopupClose",
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        data: {},
        beforeSend: function () {
        },
        success: function (response) {
            //debugger;
            var JMemberId = (response.d.JMemberId);
            var JMemberName = (response.d.JMemberName);
            var JPCity = (response.d.JPCity);

            loginstate = JMemberId > 0 ? "True" : "False";
            membername = JMemberName;
            $('#hidMemberName').val(JMemberName);
            $("#hidLoginState").val(JMemberId > 0 ? "True" : "False");
            $('#hidpCity').val(JPCity);

            //$('#ContentPlaceHolder1_hidMemberId').val(JMemberId);
            //$('#ContentPlaceHolder1_hidMemberName').val(JMemberName);

            PopulateLoginPanel1(loginstate);
        },
        complete: function () {
        },
        error: function (response) {
            console.log('Error: Some thing is wrong');
        }
    });
}

function PopulateLoginPanel1(loginstate) {
    //debugger;
    var pCity = $('#hidpCity').val();
    var userName = $('#hidMemberName').val();

    if (loginstate == 'True' && $(".progress-button").html().toLowerCase().indexOf(userName) == -1) {

        //$('#dvprofileLogin').html(html);
        $('.hi').remove();
        $('#pcity').remove();
        $('.progress-button').remove();

        $('#cityClosePreCity').css("display", "block");

        //$(".welcomsection").append("<span><a href='#'><i class='fa fa-bell-o' aria-hidden='true'></i></a></span>"
                    //+ "<span><a href='#'><i class='fa fa-th' aria-hidden='true'></i></a></span>"
        $(".welcomsection").append("<span class='hi'>" + userName + "</span>" + "<span id='pcity'><a id='aPreCity' onclick='CityBoxShow_PreCityTrigger();' style='cursor: pointer;'>" + pCity + "<i class='fa fa-caret-down' aria-hidden='true'></i></a></span>");
        $('#bs-example-navbar-collapse-1 ul').append("<li class='progress-button rightSpace'><span class='signbtn'><a id='btnMyAccount' onclick='btnProfile_onClick();' href='javascript:void(0)'> Profile</a></span></li>"
        + "<li class='progress-button rightSpace'><span class='signbtn'><a id='btnLogout' onclick='btnLogout_onClick();' href='javascript:void(0)'> Log Out</a></span></li>");
    }
}

function btnProfile_onClick() {
    WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions("ctl00$btnMyAccount", "", true, "", "", false, true));
}
function btnLogout_onClick() {
    WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions("ctl00$btnLogout", "", true, "", "", false, true));
}