﻿var membername = '';
var siteUrl = '';
var webUrl = '';

function ShowMessage(message, messagetype, isReload) {
    var cssclass;
    switch (messagetype) {
        case 'Success':
            cssclass = 'alert-success'
            break;
        case 'Error':
            cssclass = 'alert-danger'
            break;
        case 'Warning':
            cssclass = 'alert-warning'
            break;
        default:
            cssclass = 'alert-info'
    }
    $('#alert_container').show();
    $('#alert_container').append("<div style='width:100%; max-width:600px; margin:0 auto; overflow:hidden;'><div id='alert_div' style='margin: 0 0.5%; -webkit-box-shadow: 3px 4px 6px #999;' class='alert fade in " + cssclass + "'><a href='#' class='close' data-dismiss='alert' aria-label='close' onclick=hide('" + isReload + "')>OK</a><span>" + message + "</span></div></div>");//<strong>" + messagetype + "!</strong>
}
function hide(isReload) {
    $('#alert_container').hide();
    if (isReload == '1') {
        window.location.reload();
    }
}

function checkID(type) {

    var inputVal = $.trim($('#txtPaytmLoginID').val());

    var numericReg = /^\d*[0-9](|.\d*[0-9]|,\d*[0-9])?$/;
    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    //var characterReg = /^([a-zA-Z0-9]{0,10})$/;
    var characterReg = /^([a-zA-Z0-9]{10})$/;
    var spcharacterReg = /^\s*[a-zA-Z0-9,\s]+\s*$/;

    if (inputVal != "") {

        //numeric check
        if (!numericReg.test(inputVal)) {

            //Email format check
            if (!emailReg.test(inputVal)) {

                $('#tranfsferToPayTM').hide();
                $('#validationMsg').show();
                $('#validationMsg').html("Please enter a vaild Email ID.");

            } else { // proper email

                $('#tranfsferToPayTM').show();
                $('#validationMsg').html("");
                $('#validationMsg').hide();
                $('#tranfsferToPayTM').show();
            }
            
        } else {
            // 10 digit check
            if (!characterReg.test(inputVal)) {

                $('#tranfsferToPayTM').hide();
                $('#validationMsg').show();
                $('#validationMsg').html("Please enter a valid 10 digit Mobile Number.");

            } else { // proper mobile

                $('#tranfsferToPayTM').show();
                $('#validationMsg').html("");
                $('#validationMsg').hide();
                $('#tranfsferToPayTM').show();

            }
        }

    } else {
        $('#tranfsferToPayTM').hide();
        if (type == '1') {
            $('#validationMsg').show();
            $('#validationMsg').html("Please enter a vaild Email ID or valid 10 digit Mobile Number.");
        } else {
            $('#validationMsg').html("");
            $('#validationMsg').hide();
        }
    }
}

function SetAttr(sender) {

    var $sender = $(sender);
    var jdata = JSON.parse($sender.attr('data-jdata'));

    TransactionNo = jdata.TransactionNo;
    TransactionID = jdata.TransactionID;
    DirectCashback = jdata.DirectCashback;
    ExtraCashbackAvailable = jdata.ExtraCashbackAvailable;
    RewardPointConversion = jdata.RewardPointConversion;
    TotalCashback = jdata.TotalCashback;

    $('#divPaytmLoginID').hide();

    membername = $("#hidMemberName").val();
    siteUrl = $("#hidSiteUrl").val();
    webUrl = $("#hidWebUrl").val();

    $('#hdnTransactionNo').val(TransactionNo);
    $('#hdnTransactionID').val(TransactionID);
    $('#hdnDirectCashback').val(DirectCashback);
    $('#hndExtraCashbackAvailable').val(ExtraCashbackAvailable);
    $('#hndRewardPointConversion').val(RewardPointConversion);
    $('#hdnTotalCashback').val(TotalCashback);
    $('#tranfsferToPayTM').hide();
    $('#lnkConfirm').show();


    document.getElementById("myModalLabel").innerHTML = "Get Extra Cashback";

    var TotalRewardPointAvailable = $('#hdnTotalRewardPointAvailable').val();

    $("#divContent").show();

    if (RewardPointConversion != null && TotalRewardPointAvailable != null) {
        if (parseInt(RewardPointConversion) > parseInt(TotalRewardPointAvailable)) {

            $("#divContent").html("Dear " + membername + ", you need " + (parseInt(RewardPointConversion) - parseInt(TotalRewardPointAvailable)) + " Reward Points more to increase your Cashback amount from <i class='fa fa-rupee' aria-hidden='true'></i>" + DirectCashback + " to  <i class='fa fa-rupee' aria-hidden='true'></i>" + (parseInt(DirectCashback) + parseInt(ExtraCashbackAvailable)) + ".<br /><br />Collect Reward Points by participating in our <a href = '" + webUrl + "/games/play-games/All/2c02363aa65ef4e7'> Fun Games </a> or <a href = '" + webUrl + "/contest/listing.aspx'> Exciting Contests</a>.");
            $('#lnkConfirm').hide();
        } else {
            $("#divContent").html("Dear " + membername + ", your Cashback amount will be increased from <i class='fa fa-rupee' aria-hidden='true'></i>" + DirectCashback + " to <i class='fa fa-rupee' aria-hidden='true'></i>" + (parseInt(DirectCashback) + parseInt(ExtraCashbackAvailable)) + "<br /> and " + RewardPointConversion + " Reward Points will be deducted from your Reward Point Bucket.<br /><br />Do you wish to Proceed?");
            $('#lnkConfirm').show();
        }
    } else {
        $("#divContent").html("Incorrect data.");
        $('#lnkConfirm').hide();
    }
}

function fn_SetAttrForPaytm(sender) {   

    $('#divPaytmLoginID').show();

    var $sender = $(sender);
    var id = $sender.attr('data-id');

    $('#tranfsferToPayTM').show();
    $('#lnkConfirm').hide();

    $('#tranfsferToPayTM').attr('data-id', id);
    $("#myModalLabel").html("Transfer cashback amount to Paytm");

    $("#divContent").html("");
    $("#divContent").hide();
    //$("#divContent").html("Are you sure to transfer the amount?");

    checkID('0');
}
function fn_DoTransfer(sender) {    

    //$("#cancelModal").trigger("click");
    //$(".modal").modal("hide");
    //$(".modal-backdrop").hide();
    //$('#myModal_cashback').modal('hide');
    //if ($.trim($('#txtPaytmLoginID').val()) != "") {

        $('#validationMsg').hide();
        $('.CouponLoader').show();

        var $sender = $(sender);
        var id = $sender.attr('data-id');
        $.ajax({
            url: "cashback-stats.aspx/ThirdPartyTransfer",
            type: "POST",
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({transferId: id, paytmLoginID: $.trim($('#txtPaytmLoginID').val()) }),
            beforeSend: function () {

            },
            success: function (response) {
                var response = JSON.parse(response.d);

                $('.CouponLoader').hide();

                if (response.Status > 0) {
                    ShowMessage(response.Message, 'Success', '1');
                    //window.location.reload();
                }
                else {
                    ShowMessage(response.Message, 'Error', '1');
                }
            },
            complete: function () {

            },
            error: function (response) {

            }
        });
    //} else {
    //    $('#validationMsg').show();

    //    $('#validationMsg').val("Please enter your Paytm Mobile or Email ID as per your Paytm account");
    //}
 
}

function fn_DoConfirm() {
    //$('#divPaytmLoginID').hide();
    //$("#cancelModal").trigger("click");
    //$(".modal").modal("hide");
    //$(".modal-backdrop").hide();
    //$('#myModal_cashback').modal('hide');

    var transactionNo = $('#hdnTransactionNo').val();
    var transactionID = $('#hdnTransactionID').val();

    $('.CouponLoader').show();

    $.ajax({
        url: "cashback-stats.aspx/ConfirmCashback",
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        data: '{transactionNo :' + transactionNo + ', transactionID: ' + transactionID + '}',
        beforeSend: function () {

        },
        success: function (response) {
            //var response = JSON.parse(response.d);

            $('.CouponLoader').hide();

            if (response.d.length > 0) {

            var paramStatus = '';
            var paramOutMsg = '';

            var arrOutPut = response.d.split('©');

            if (arrOutPut.length > 0)
            {
                paramStatus = arrOutPut[0];
                paramOutMsg = arrOutPut[1];
            }

            if (paramStatus == "1")
                ShowMessage(paramOutMsg, 'Success', '1');
            else if (paramStatus == "2")
                ShowMessage(paramOutMsg, 'Info', "0");
            else if (paramStatus == "3")
                ShowMessage(paramOutMsg, 'Warning', "0");
            else
                ShowMessage(paramOutMsg, 'Error', "0");
            }
            else {
                ShowMessage(response.Message, 'Error', '1');
            }
            //if (response.Status > 0) {
            //    ShowMessage(response.Message, 'Success', '1');
            //    window.location.reload();
            //}
            //else {
            //    ShowMessage(response.Message, 'Error', '1');
            //}
        },
        complete: function () {

        },
        error: function (response) {

        }
    });

}
