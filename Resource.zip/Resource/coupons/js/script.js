// these script is for all thumb carousel including banner carousel in this home page ------------

function fn_PrepareCarousel() {
    var foresee = $("#foresee-demo-carousel1, #foresee-demo-carousel2, #foresee-demo-carousel3, #foresee-demo-carousel4, #foresee-demo-carousel5, #foresee-demo-carousel6, #foresee-demo-carousel7, #foresee-demo-carousel8, #foresee-demo-carousel9");
    var foresee1 = $("#foresee-demo-carousel1");
    var foresee2 = $("#foresee-demo-carousel2");
    var foresee3 = $("#foresee-demo-carousel3");
    var foresee4 = $("#foresee-demo-carousel4");
    var foresee5 = $("#foresee-demo-carousel5");
    var foresee6 = $("#foresee-demo-carousel6");
    var foresee7 = $("#foresee-demo-carousel7");
    var foresee8 = $("#foresee-demo-carousel8");
    var foresee9 = $("#foresee-demo-carousel9");

    //find items to display
    var items = foresee.data('carousel-items') || 5;

    foresee.foreseeCarousel({
        items: items, //10 items above 1000px browser width
        itemsDesktop: [1000, 5], //5 items between 1000px and 901px
        itemsDesktopSmall: [900, 3], // betweem 900px and 601px
        itemsTablet: [600, 2], //2 items between 600 and 361
        itemsMobile: [360, 1], //2 items between 360 and 0
        //itemsMobile : false // itemsMobile disabled - inherit from itemsTablet option
    });
    // Custom Navigation Events
    $("#CarouselSetOnenext").click(function () {
        foresee1.trigger('foresee.next');
    });
    $("#CarouselSetOneprev").click(function () {
        foresee1.trigger('foresee.prev');
    });

    $("#CarouselSetTwonext").click(function () {
        foresee2.trigger('foresee.next');
    });
    $("#CarouselSetTwoprev").click(function () {
        foresee2.trigger('foresee.prev');
    });

    $("#CarouselSetThreenext").click(function () {
        foresee3.trigger('foresee.next');
    });
    $("#CarouselSetThreeprev").click(function () {
        foresee3.trigger('foresee.prev');
    });

    $("#CarouselSetFournext").click(function () {
        foresee4.trigger('foresee.next');
    });
    $("#CarouselSetFourprev").click(function () {
        foresee4.trigger('foresee.prev');
    });

    $("#CarouselSetFivenext").click(function () {
        foresee5.trigger('foresee.next');
    });
    $("#CarouselSetFiveprev").click(function () {
        foresee5.trigger('foresee.prev');
    });

    $("#CarouselSetSixnext").click(function () {
        foresee6.trigger('foresee.next');
    });
    $("#CarouselSetSixprev").click(function () {
        foresee6.trigger('foresee.prev');
    });

    $("#CarouselSetSevennext").click(function () {
        foresee7.trigger('foresee.next');
    });
    $("#CarouselSetSevenprev").click(function () {
        foresee7.trigger('foresee.prev');
    });

    $("#CarouselSetEightnext").unbind().click(function () {
        foresee8.trigger('foresee.next');
    });
    $("#CarouselSetEightprev").unbind().click(function () {
        foresee8.trigger('foresee.prev');
    });

    $("#CarouselSetNinenext").click(function () {
        foresee9.trigger('foresee.next');
    });
    $("#CarouselSetNineprev").click(function () {
        foresee9.trigger('foresee.prev');
    });

    $(".play").click(function () {
        foresee.trigger('foresee.play', 1000); //foresee.play event accept autoPlay speed as second parameter
    });
    $(".stop").click(function () {
        foresee.trigger('foresee.stop');
    });

};
// these script is for all thumb carousel including banner carousel in this home page ------------


//$(document).ready(function () {
    
//});
// this js for main banner carousel -----   

// start this below js for top header on scroll height shrink animation effect------------

$(function () {
    var shrinkHeader = 100;
    $(window).scroll(function () {
        var scroll = getCurrentScroll();
        if (scroll >= shrinkHeader) {
            $('.header').addClass('shrink');
            $('.header a').css('color', '#000');
            $('.header .signbtn').css('border-color', '#000');
            $('.header .hi').css('color', '#3c3e4d');
        }
        else {
            $('.header').removeClass('shrink');
            $('.header a').css('color', '#fff');
            $('.header .signbtn').css('border-color', '#fff');
            $('.header .welcomsection .hi').css('color', '#fff');
        }
    });
    function getCurrentScroll() {
        return window.pageYOffset;
    }
});

//$('.UserSearch').Watermark("Search", "#999");
//$(document).ready(function() {
//	$(".header").mouseover(function() {
//		$(this).addClass("shrink");	
//	});	
//});
// -------------------end this below js for top header on scroll height shrink animation effect


function fn_PrepareCarouselById(carouselContainer) {
        var $carouselContainer = $('#' + carouselContainer);

        var nextBtn = $carouselContainer.attr('data-carouselNext');
        var prevBtn = $carouselContainer.attr('data-carouselPrev');

        $carouselContainer.foreseeCarousel({
            items: 5, //10 items above 1000px browser width
            itemsDesktop: [1000, 5], //5 items between 1000px and 901px
            itemsDesktopSmall: [900, 3], // betweem 900px and 601px
            itemsTablet: [600, 2], //2 items between 600 and 361
            itemsMobile: [360, 1], //2 items between 360 and 0
            //itemsMobile : false // itemsMobile disabled - inherit from itemsTablet option
        });


        $('#' + nextBtn).click(function () {
            $carouselContainer.trigger('foresee.next');
        });
        $('#' + prevBtn).click(function () {
            $carouselContainer.trigger('foresee.prev');
        });

        $(".play").click(function () {
            $carouselContainer.trigger('foresee.play', 1000);
        });
        $(".stop").click(function () {
            $carouselContainer.trigger('foresee.stop');
        });
}

function OnCloseClick(ofrDtlId) {
   
    $.ajax({
        url: "offers-deals.aspx/OnCloseClick",
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        data: '{ofrDtlId :' + ofrDtlId + '}',
        beforeSend: function () {
        },
        success: function (response) {
        },
        complete: function () {
        },
        error: function (response) {
            console.log('Error: Some thing is wrong');
        }
    });
}

function SetLoginPanel(loginstate, siteUrl, webUrl, userName, availablecashwalletamount, availableaewardpoint) {

    if (loginstate == 'True') {
        var html = "<div class='profileLogin' id='dvprofileLogin'>" +
            "<div style='width: auto; float: left; margin-right: 10px;'><a href='#' style='color: #fff;'><span class='fa fa-user fa-lg' aria-hidden='true'></span></a></div>"+
            "<span id='spName'>Hi " + userName + "</span><span class='fa fa-caret-down' aria-hidden='true' style='margin-left: 5px;'></span>" +
             "<div class='profileLoginSubCat-content'>" +
             "<ul><li><a href= '" + webUrl + "/MemberProfile'>Profile</a></li>" +
             "<li><a href='#' onclick='logout_Click();'>Logout</a></li></ul></div></div>"
        $('#dvprofileLogin').html(html);
        $('#spWithoutLogin').remove();

        $('#spnACWA').text("");
        $('#spnACWA').text(availablecashwalletamount);

        $('#spnARP').text("");
        $('#spnARP').text(availableaewardpoint);

    }
}


