﻿var membername = '';
var siteUrl = '';
var webUrl = '';
var loginstate = '';
var availablecashwalletamount = '';
var availableaewardpoint = '';

$(document).ready(function () {
    //$(".homeCategorylink li").hover(function () {
    //    $(this).find(".subCategoryBox").show();
    //    $(this).addClass('active5');
    //    console.log('over');
    //});
    //$(".homeCategorylink li").mouseleave(function () {
    //    $(".subCategoryBox").hide();
    //    $(this).removeClass('active5');
    //    console.log('leave');
    //});

    scrollfix();

    //$("#spnText").text("Quick Stores");
    //$('#hidPosition').val("0");
    //$("#hidIsClick").val("0");
    //$("#divSetPosition").show();

    fn_PrepareCarousel();

});


$(document).on('click', 'ul#CouponSubcategoryLinkArea>li>a', function () {
    $(this).siblings(".subCategoryMobile").stop().slideToggle();
    $(this).closest("li").siblings("li").find(".subCategoryMobile").stop().slideUp();
    $(this).find(".plusMinusIcons").html("-");
    $(this).closest("li").siblings("li").find(".plusMinusIcons").html("+");
});


var toggle = true;

$(".sidebar-icon").click(function () {
    if (toggle) {
        $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
        $("#menu span").css({ "position": "absolute" });
    }
    else {
        $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
        setTimeout(function () {
            $("#menu span").css({ "position": "relative" });
        }, 400);
    }

    toggle = !toggle;

});


// BS tabs hover (instead - hover write - click)
$('.quickStoreNewLink').hover(function () {
    $(".tab-content").addClass('displayNone');
    e.preventDefault()
});// PatchUp Code

$('.tab-menu li a').hover(function (e) {
    $(".tab-content").removeClass('displayNone');
    e.preventDefault()
    $(this).tab('show')
})
$('#leftTabFunction').mouseleave(function (e) {
    $(".tab-content").addClass('displayNone');
    e.preventDefault()
    $("#leftTabFunction .tab-pane").removeClass('active in');
    $(".tab-menu li").removeClass('active');
    //$(this).tab('hide')
   
})




function SetUrl(sender) {
    //debugger;
    var $sender = $(sender);
    var jdata = JSON.parse($sender.attr('data-jdata'));

    Section = jdata.Section;
    At = jdata.At;
    ACI = jdata.ACI;
    Oid = jdata.Oid;
    Purl = jdata.Purl;
    Src = jdata.Src;
    Alt = jdata.Alt;
    OfferDetails = jdata.OfferDetails;

    webUrl = $("#hidWebUrl").val();
    siteUrl = $("#hidSiteUrl").val();
    loginstate = $("#hidLoginState").val();

    if (Alt != '') {
        $("#spnBrndName").html(Alt);
    } else {
        $("#spnBrndName").hide();
    }

    $('.couponCodeArea').show();

    if (loginstate == 'False') {
        $("#divGoToStore").hide();
        $('#divhrefWithoutlogin').attr("style", "");
        $('#divhrefLogin').attr("style", "");
        $("#divRedBtn").show();
    } else {
        $('#divGoToStore').attr("style", "");
        $("#divGoToStore").show();
        $("#divRedBtn").hide();
    }

    if (OfferDetails != '') {

        $("#spnOfferDetails").show();

        if (Section == 'QS') {
            //OfferDetails = 'Store Offers + ' + OfferDetails;
            OfferDetails = 'Store Offers <span style="color:red !important;"> + ' + OfferDetails + ' from Foreseegame </span>';
        }

        $("#spnOfferDetails").html(OfferDetails);

    } else {
        $("#spnOfferDetails").hide();
    }

    $("#hrefLogin").attr("href", webUrl + "/FGLogin.aspx?Rpage=CASHBACK&At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);
    $("#hrefWithoutlogin").attr("href", "get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);
    $("#hrefGoToStore").attr("href", "get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);

    if (Src != '' && Src != 'No') {
        $("#myModalLabel").show();
        $("#myModalLabel").html("<img id='brndImg' class='center-block' src='" + (siteUrl + Src) + "' alt='" + Alt + "' />");
    } else if (Src == 'No') {
        $("#myModalLabel").hide();
    } else {
        $("#myModalLabel").show();
        $("#myModalLabel").html("<div class='breakImage' title='" + Alt + "'>" + Alt + "</div>");
    }

    //// store brand image in local storage  
    if (Section == 'QS' || Src != 'No') {
        localStorage.setItem("Frwdurl", (siteUrl + Src));
    } else {
        localStorage.setItem("Frwdurl", "");
    }
    localStorage.setItem('Frwdalt', Alt);

}

function hideContent(ctrlId) {
    if (ctrlId == 1) {
        $('#divhrefWithoutlogin').attr("style", "display:none");
    }
    if (ctrlId == 2) {
        $('#divhrefLogin').attr("style", "display:none");
    }
    else if (ctrlId == 3) {
        $('#divGoToStore').attr("style", "display:none");
    }

    if ($('#divhrefWithoutlogin').is(':hidden') == true && $('#divGoToStore').is(':hidden') == true) {
        $('.couponCodeArea').hide();
    }
}
function OnPopupClose() {
    webUrl = $("#hidWebUrl").val();

    $.ajax({
        url: webUrl + "/coupons-discounts-cashback/best-deals.aspx/OnPopupClose",
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        data: {},
        beforeSend: function () {
        },
        success: function (response) {
            //debugger;
            var JMemberId = (response.d.JMemberId);
            var JMemberName = (response.d.JMemberName);
            var JAvailableCashWalletAmount = (response.d.JAvailableCashWalletAmount);
            var JAvailableRewardPoint = (response.d.JAvailableRewardPoint);

            loginstate = JMemberId > 0 ? "True" : "False";
            membername = JMemberName;
            availablecashwalletamount = JAvailableCashWalletAmount;
            availableaewardpoint = JAvailableRewardPoint;

            $('#hidMemberName').val(JMemberName);
            $("#hidLoginState").val(JMemberId > 0 ? "True" : "False");
            //$('#ContentPlaceHolder1_hidMemberId').val(JMemberId);
            //$('#ContentPlaceHolder1_hidMemberName').val(JMemberName);

            PopulateLoginPanel1(loginstate, availablecashwalletamount, availableaewardpoint);
        },
        complete: function () {
        },
        error: function (response) {
            console.log('Error: Some thing is wrong');
        }
    });
}

function PopulateLoginPanel1(loginstate, availablecashwalletamount, availableaewardpoint) {
    siteUrl = $("#hidSiteUrl").val();
    webUrl = $("#hidWebUrl").val();
    var userName = $('#hidMemberName').val();

    SetLoginPanel(loginstate, siteUrl, webUrl, userName, availablecashwalletamount, availableaewardpoint);
}
function SetPosition() {

    var winHeight = $(window).height();
    var winSTop = $(window).scrollTop();
    var HeaderHeight = 0;
    var position = $('#hidPosition').val();
    var id = "";
    $("#hidIsClick").val("1");
    if (position == '0') {
        id = "ContentPlaceHolder1_divQuickStores";
        HeaderHeight = $('#divQuickStoreHeader').height() * 4;
        //$("#spnText").text("Hot Deals");
        $("#divSetPosition").show();
        $('#hidPosition').val("1");
    }
    else if (position == '1') {
        id = "ContentPlaceHolder1_divTopStores";
        HeaderHeight =  $('#divTopStoreHeader').height();
        $("#spnText").text("");
        $("#divSetPosition").hide();
        $('#hidPosition').val("0");
    }
    //console.log($("#ContentPlaceHolder1_divQuickStores").offset().top); //1079.953125,1806.953125
    $('html,body').animate({ scrollTop: $("#" + id).offset().top - HeaderHeight }, 'slow');
    //$('html,body').animate({ scrollTop: $("#" + id).offset().top - $("#" + id).height() }, 'slow');
    //$('html, body').animate({
    //    scrollTop: $("#" + id).offset().top
    //}, 'slow')
    
}
function scrollfix() {


    var winHeight = $(window).height();
    var winSTop = $(window).scrollTop();
    var qsHeaderHeight = $('#divQuickStoreHeader').height() * 2;
    var tsHeaderHeight = $('#divTopStoreHeader').height() * 2;

    if (winHeight + winSTop < $('#ContentPlaceHolder1_divQuickStores').offset().top) {
        $('#hidPosition').val("0");
        $("#spnText").text("Quick Stores");
        $("#divSetPosition").show();
    }

    if ((winHeight + winSTop - qsHeaderHeight) > $('#ContentPlaceHolder1_divQuickStores').offset().top) {
        $('#hidPosition').val("1");
        $("#spnText").text("Hot Deals");
    }

    if ((winHeight + winSTop - tsHeaderHeight) > $('#ContentPlaceHolder1_divTopStores').offset().top) {
        $('#hidPosition').val("0");
        $("#divSetPosition").hide();
    }


}

$(window).scroll(function () {

    //console.log('Window Scroll Top ' + $(window).scrollTop());
    //console.log('QuickStores Offset Top ' + $('#ContentPlaceHolder1_divQuickStores').height() + ' : ' + $('#ContentPlaceHolder1_divQuickStores').offset().top);
    //console.log('TopStores Offset Top ' + $('#ContentPlaceHolder1_divTopStores').height() + ' : ' + $('#ContentPlaceHolder1_divTopStores').offset().top);
    //console.log('----------------------------------------------');

    scrollfix();


    /*
    if ($('#hidIsClick').val() == "0") {
        //alert($(document).scrollTop());
        if ($(document).scrollTop() < 600) {
            $("#divSetPosition").show();
            $("#spnText").text("Quick Stores");
            $('#hidPosition').val("0");
        }
        else if ($(document).scrollTop() > 600 && $(document).scrollTop() < 1400) {
            //$("#divSetPosition").show();
            $("#spnText").text("Hot Deals");
            $('#hidPosition').val("1");
        }
        else if ($(document).scrollTop() > 1400) {//&& $(document).scrollTop() < 2400
            $("#spnText").text("");
            $("#divSetPosition").hide();
            $('#hidPosition').val("0");
        }
    } else if ($('#hidIsClick').val() == "1" && $('#hidPosition').val() == "1" && $(document).scrollTop() > 1400) {
        $("#spnText").text("");
        $("#divSetPosition").hide();
        $('#hidPosition').val("0");
    }
    */
});

function goTo(sender) {

    var $sender = $(sender);
    var jdata = JSON.parse($sender.attr('data-jdata'));

    Section = jdata.Section;
    At = jdata.At;
    ACI = jdata.ACI;
    Oid = jdata.Oid;
    Purl = jdata.Purl;
    Src = jdata.Src;
    Alt = jdata.Alt;
    OfferDetails = jdata.OfferDetails;

    siteUrl = $("#hidSiteUrl").val();

    //// store brand image in local storage    
    if (Section == 'QS' ||  Src != 'No') {
        localStorage.setItem("Frwdurl", (siteUrl + Src));
    } else {
        localStorage.setItem("Frwdurl", "");
    }
    localStorage.setItem('Frwdalt', Alt);

    var Url = "get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl;
    window.open(Url, '_blank');
}

