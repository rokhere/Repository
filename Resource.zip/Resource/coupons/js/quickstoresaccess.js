﻿var membername = '';
var siteUrl = '';
var webUrl = '';
var loginstate = '';
var availablecashwalletamount = '';
var availableaewardpoint = '';

function SetUrl(sender) {

    var $sender = $(sender);
    var jdata = JSON.parse($sender.attr('data-jdata'));

    At = jdata.At;
    ACI = jdata.ACI;
    Oid = jdata.Oid;
    Purl = jdata.Purl;
    Src = jdata.Src;
    Alt = jdata.Alt;
    OfferDetails = jdata.OfferDetails;

    webUrl = $("#hidWebUrl").val();
    siteUrl = $("#hidSiteUrl").val();
    loginstate = $("#hidLoginState").val();

    if (Alt != '') {
        $("#spnOfferDetails").show();
        $("#spnBrndName").html(Alt);
    } else {
        $("#spnBrndName").hide();
    }

    $('.couponCodeArea').show();

    if (loginstate == 'False') {
        $("#divGoToStore").hide();
        $('#divhrefWithoutlogin').attr("style", "");
        $('#divhrefLogin').attr("style", "");
        $("#divRedBtn").show();
    } else {
        $('#divGoToStore').attr("style", "");
        $("#divGoToStore").show();
        $("#divRedBtn").hide();
    }


    if (OfferDetails != '') {
        $("#spnOfferDetails").html('Store Offers <span style="color:red;">+ ' + OfferDetails + ' from Foreseegame </span>');
    } else {
        $("#spnOfferDetails").hide();
    }

    $("#hrefLogin").attr("href", webUrl + "/FGLogin.aspx?Rpage=CASHBACK&At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);
    $("#hrefWithoutlogin").attr("href", "get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);
    $("#hrefGoToStore").attr("href", "get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);

    if (Src != '' && Src != 'No') {
        $("#myModalLabel").show();
        $("#myModalLabel").html("<img id='brndImg' class='center-block' src='" + (siteUrl + Src) + "' alt='" + Alt + "' />");
    } else if (Src == 'No') {
        $("#myModalLabel").hide();
    } else {
        $("#myModalLabel").show();
        $("#myModalLabel").html("<div class='breakImage' title='" + Alt + "'>" + Alt + "</div>");
    }

    //// store brand image in local storage    
    if (Src != "") {
        localStorage.setItem("Frwdurl", (siteUrl + Src));
    } else {
        localStorage.setItem("Frwdurl", null);
    }
    localStorage.setItem('Frwdalt', Alt);
}

function hideContent(ctrlId) {
    if (ctrlId == 1) {
        $('#divhrefWithoutlogin').attr("style", "display:none");
    }
    if (ctrlId == 2) {
        $('#divhrefLogin').attr("style", "display:none");
    }
    else if (ctrlId == 3) {
        $('#divGoToStore').attr("style", "display:none");
    }

    if ($('#divhrefWithoutlogin').is(':hidden') == true && $('#divGoToStore').is(':hidden') == true) {
        $('.couponCodeArea').hide();
    }
}
function searchStores(txt, attr) {

    siteUrl = $("#hidSiteUrl").val();

    attr = attr || 'type';

    if (attr == 'type') {
        $('#txtSearchStore').val("");
    } else {
        $('#ddlStoreType').val("");
    }

    var re = txt.split(' ').join('');
    var searchTerm = re.toLowerCase();
    var isfound = false;
    var count = 0;
    $('.ebrand[data-' + attr + ']').each(function () {
        var $sender = $(this);

        var datastore = $sender.attr("data-" + attr);
        //console.log(datastore + '/' + searchTerm);
        //console.log(datastore.toLowerCase().indexOf(searchTerm) > -1);
        if (datastore.toLowerCase().indexOf(searchTerm) > -1) {
            $sender.stop(true, true).fadeIn(500);
            isfound = true;
            count = count + 1;
        }
        else {
            $sender.stop(true, true).fadeOut(500);
        }
    });

    if (isfound) {
        $('#searchCount').show();
        $('#noSearchFound').hide();
        $('#searchCount').text(count + ' Record(s) found.');
    } else {

        $('#searchCount').hide();
        $('#noSearchFound').show();

        if (attr == 'type') {
            $('#noSearchFound').html("<img src='" + siteUrl + "/Resource/coupons/images/whyPeoplePreferUsHeadingIcon.png' /> <br/> <b>We will provide you the requested Stores with exciting Deals shortly.</b>");
        } else {
            $('#noSearchFound').html("<img src='" + siteUrl + "/Resource/coupons/images/whyPeoplePreferUsHeadingIcon.png' /> <br/> <b>No matching Stores! Search other Stores.</b>");
        }
    }
}
function OnPopupClose() {
    webUrl = $("#hidWebUrl").val();

    $.ajax({
        url: webUrl + "/coupons-discounts-cashback/best-deals.aspx/OnPopupClose",
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        data: {},
        beforeSend: function () {
        },
        success: function (response) {
            //debugger;
            var JMemberId = (response.d.JMemberId);
            var JMemberName = (response.d.JMemberName);
            var JAvailableCashWalletAmount = (response.d.JAvailableCashWalletAmount);
            var JAvailableRewardPoint = (response.d.JAvailableRewardPoint);

            loginstate = JMemberId > 0 ? "True" : "False";
            membername = JMemberName;
            availablecashwalletamount = JAvailableCashWalletAmount;
            availableaewardpoint = JAvailableRewardPoint;

            $('#hidMemberName').val(JMemberName);
            $("#hidLoginState").val(JMemberId > 0 ? "True" : "False");
            //$('#ContentPlaceHolder1_hidMemberId').val(JMemberId);
            //$('#ContentPlaceHolder1_hidMemberName').val(JMemberName);

            PopulateLoginPanel1(loginstate, availablecashwalletamount, availableaewardpoint);
        },
        complete: function () {
        },
        error: function (response) {
            console.log('Error: Some thing is wrong');
        }
    });
}

function PopulateLoginPanel1(loginstate, availablecashwalletamount, availableaewardpoint) {
    siteUrl = $("#hidSiteUrl").val();
    webUrl = $("#hidWebUrl").val();
    var userName = $('#hidMemberName').val();

    SetLoginPanel(loginstate, siteUrl, webUrl, userName, availablecashwalletamount, availableaewardpoint);
}

function goTo(sender) {

    var $sender = $(sender);
    var jdata = JSON.parse($sender.attr('data-jdata'));

    At = jdata.At;
    ACI = jdata.ACI;
    Oid = jdata.Oid;
    Purl = jdata.Purl;
    Src = jdata.Src;
    Alt = jdata.Alt;
    OfferDetails = jdata.OfferDetails;

    siteUrl = $("#hidSiteUrl").val();

    //// store brand image in local storage    
    if (Src != "") {
        localStorage.setItem("Frwdurl", (siteUrl + Src));
    } else {
        localStorage.setItem("Frwdurl", "");
    }
    localStorage.setItem('Frwdalt', Alt);

    var Url = "get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl;
    window.open(Url, '_blank');
}