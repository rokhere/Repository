﻿
var indexLevel = 0, indexSeq = 0, LastIndexLevel = 0;
var levelId, seqId, flipQuestionId;
var innerRank;
var isInsertedInMemberGamePlayed = false;
var isFlipped = false;
var IsFlipClicked = false;
var Is50_50Clicked = false;
var isFifty = false;
var ansStatus = false;
var timeOutFlag = false;
var arrQkrGameLevels = [];
var arrQkrGameLevelSequences = [];
var arrQkrMemberAnswers = [];
var indexMemberAns = 0;
var objJSONQuesAnsDtl;
var QuestionTime;
var SubmitTime;
var AnswerTime;
var GamePlayStatus = 0; //Right Answers=0, GameLevelChanged=1, GameOver=2, Wrong Answers=3
var isPlaying = false;
var siteURL = '<%=Application["siteurl"] %>/MUser/';
var webURL = '<%=Application["WebURL"] %>/MUser/';
var isGamestartByUser = false;

//====Document Ready function====
$(document).ready(function () {
    $('#txtSearch').val('');
    ////====Check if the game started/played for this member====                        
    //CheckGamePlayedByMember();

    //====To hide level wise right & bottom panel images and display right panel guide lene====//
    $('#dvRightPanelWrapperLevel').hide();
    $('#dvGameBottomAdCointainer').hide();
    $('#dvRightPanelGuideLine').show();
});

$(document).unload(function () {
    // To re-enable f5 
    $(document).unbind("keydown", disable_fresh);
});

$(document).on("mousedown", function () {
    //Disable right mouse click Script  
    if (event.button == 2) return false
});

function SecurityMessage() {
    $('#dvSecurityMsg').fadeIn();
}

function CheckGamePlayedByMember(data) {
    if (data != null && data != undefined && data.length > 0) {
        if (data[0].MemberPlayingMode == false) {//Start to check Member is in playing mode or not
            if (data[0].IsAlreadyPlayed == true) {
                GameAlreadyPlayed();
                $("#GameDoorLoader").hide();
                return false;
            }
            //Start of Game Start Countdown
            else if (data[0].IsAlreadyPlayed == false && data[0].GameIsStartable == false) {
                $("#GameStatusInfoWrapperDv").show();
                $(".StartGameWrapperDv").hide();
                $("#GameStartsOnDateCount").show();

                //GameTitle show/hide
                if (data[0].GameTitle != '' && data[0].GameTitle != null && data[0].GameTitle != undefined) {
                    $("#GameStatusInfoGameTitle").show();
                    $("#GameStatusInfoGameTitle").html(data[0].GameTitle);
                }
                else {
                    $("#GameStatusInfoGameTitle").hide();
                }

                //GameActualDuration show/hide
                if (data[0].GameActualDuration != '' && data[0].GameActualDuration != null && data[0].GameActualDuration != undefined) {
                    var gameActualDuration = CalculateAcutalGameDurationInHMS(data[0].GameActualDuration);
                    var gameDurationHtml = 'Game Duration : ' + gameActualDuration;
                    $("#GameStatusInfoGameDuration span").show();
                    $("#GameStatusInfoGameDuration span").html(gameDurationHtml);
                }
                else {
                    $("#GameStatusInfoGameDuration span").hide();
                }

                //Remaining Time
                totsec = data[0].GameTotalSeconds;
                if (totsec >= 0) {
                    StartGameCountDown();
                }
                else {
                    $("#GameStartsOnDateCount").hide();
                    $("#GameStatusInfoMsg").html("Sorry! Game expired.");
                }
            } //End of Game Start Countdown

            //Start of Game Ready To Start
            else if (data[0].IsAlreadyPlayed == false && data[0].GameIsStartable == true) {

                //$('#<%=dvStartGameBtn.ClientID %>').show();
                $('#dvStartGameBtn').show();
                //GameTitle show/hide
                if (data[0].GameTitle != '' && data[0].GameTitle != null && data[0].GameTitle != undefined) {
                    $("#dvGameStatusInfoGameTitle").show();
                    $("#dvGameStatusInfoGameTitle").html(data[0].GameTitle);
                }
                else {
                    $("#dvGameStatusInfoGameTitle").hide();
                }
                //GameActualDuration show/hide
                if (data[0].GameActualDuration != '' && data[0].GameActualDuration != null && data[0].GameActualDuration != undefined) {
                    var gameActualDuration = CalculateAcutalGameDurationInHMS(data[0].GameActualDuration);
                    var gameDurationHtml = 'Game Duration : ' + gameActualDuration;
                    $("#pGameStatusInfoGameDuration span").show();
                    $("#pGameStatusInfoGameDuration span").html(gameDurationHtml);
                }
                else {
                    $("#pGameStatusInfoGameDuration span").hide();
                }
            } //End of Game Ready To Start
        } //End to check Member is in playing mode or not
        else {
            $("#GameStatusInfoWrapperDv").show();
            $(".StartGameWrapperDv").hide();
            $("#GameStatusInfoMsg").hide();
            $("#PlatingOtherGames").show();
            $("#PlatingOtherGames").css("height", "145px");
            if (data[0].GameId == '<%=GlobalSettings.QkrActiveGameID %>')

            //$("#PlatingOtherGames").html('You are not allowed to play this game at present. Please try after some time');
                $("#PlatingOtherGames").html('Sorry! You have been temporarily locked from playing this quicker game for <br/><span onclick=\'SecurityMessage();\'>security reasons</span>.<br/>Please try after some time.');

            else
                $("#PlatingOtherGames").html('Sorry! You are not allowed to play this game at present. Please try at after some time.');

            //$("#PlatingOtherGames").html('You are not allowed to play this game at present. Please try at after ' + data[0].LastPlayedGameEndTime.substr(7, 7));

            //GameTitle show/hide
            if (data[0].GameTitle != '' && data[0].GameTitle != null && data[0].GameTitle != undefined) {
                $("#GameStatusInfoGameTitle").show();
                $("#GameStatusInfoGameTitle").html(data[0].GameTitle);
            }
            else {
                $("#GameStatusInfoGameTitle").hide();
            }
            //GameActualDuration show/hide
            if (data[0].GameActualDuration != '' && data[0].GameActualDuration != null && data[0].GameActualDuration != undefined) {
                var gameActualDuration = CalculateAcutalGameDurationInHMS(data[0].GameActualDuration);
                var gameDurationHtml = 'Game Duration : ' + gameActualDuration;
                $("#GameStatusInfoGameDuration span").show();
                $("#GameStatusInfoGameDuration span").html(gameDurationHtml);
            }
            else {
                $("#GameStatusInfoGameDuration span").hide();
            }

            $("#GameStatusInfoMsg span").html(data[0].LastPlayedGameEndTime.substr(7, 7));
        }
    }
}


function StartGame(sender) {
    //To Prevent Double Click On Submit Button
    var returnVal = CheckQkrGameIsPlayable();
    if (returnVal == true) {
        $(sender).removeAttr("onclick");

        //====To show level wise right & bottom panel images and hide right panel guide line====//
        $('#dvRightPanelWrapperLevel').show();
        $('#dvGameBottomAdCointainer').show();
        $('#dvRightPanelGuideLine').hide();
    }
    return returnVal;
}

function CheckQkrGameIsPlayable() {
    var qkrAtiveGameID = $('#hfEncryptedGameID').val();    
    var url = webURL + 'QkrGame.aspx/CheckQkrGameIsPlayable';
    var data = CheckQkrGameIsPlayableResponse(url, '{"qkrGameID":"' + qkrAtiveGameID + '"}');

    if (data != null && data != undefined && data.d.length > 0) {
        if (data.d[0].IsSessionLoggedOut == true) {
            var strMessage = "Sorry! Active session has been expired. <br/> Please log in to continue.";
            jAlert(strMessage, 'QkrHome.aspx');
            $("#GameDoorLoader").hide();
            return false;
        }
        if (data.d[0].GameStatus != 1) {
            var strMessage = "Sorry! Game abandoned.";
            jAlertHref(strMessage, 'QkrHome.aspx');
            $("#GameDoorLoader").hide();
            return false;
        }
        if (data.d[0].HasReqRewardPoints != true) { //
            var strMessage = "Sorry! You have insufficient reward points to play this game.";
            jAlertHref(strMessage, 'QkrHome.aspx');
            $("#GameDoorLoader").hide();
            return false;
        }
        if (data.d[0].GameChannel == 1 && data.d[0].CanPlay != true) { //For RT Game
            var strMessage = "Sorry! You have not yet registered to play this game.";
            jAlertHref(strMessage, 'QkrHome.aspx');
            $("#GameDoorLoader").hide();
            return false;
        }
        if (data.d[0].GameChannel == 2 && data.d[0].CanRegister != true) { //For MT Game
            var strMessage = "Sorry! Participation over.";
            jAlertHref(strMessage, 'QkrHome.aspx');
            $("#GameDoorLoader").hide();
            return false;
        }
        if (data.d[0].GameExpiryStatus <= 0) { //Game expired 
            var strMessage = "Sorry! Game expired";
            jAlertHref(strMessage, 'QkrHome.aspx');
            $("#GameDoorLoader").hide();
            return false;
        }
        if (data.d[0].HasReqRewardPoints == true && data.d[0].CanRegister == true && data.d[0].CanPlay == true) {
            if (data.d[0].GameChannel == 2) RegisterMemberToPlay();
            return CheckGamePlayedByMemberForPlayButtonClick();
        }
    }
    else {
        return false;
    }
    return true;
}

function CheckQkrGameIsPlayableResponse(url, postData) {
    var xmlhttp = null;
    if (window.XMLHttpRequest)
        xmlhttp = new XMLHttpRequest();
    else if (window.ActiveXObject) {
        if (new ActiveXObject("Microsoft.XMLHTTP"))
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        else
            xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    }
    // to be ensure non-cached version of response
    url = url + "?rnd=" + Math.random();

    xmlhttp.open("POST", url, false); //false means synchronous
    xmlhttp.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    xmlhttp.send(postData);
    var responseText = jQuery.parseJSON(xmlhttp.responseText);
    return responseText;
}


function CheckGamePlayedByMemberForPlayButtonClick() {
    //var qkrAtiveGameID = $("#<%=hfEncryptedGameID.ClientID %>").val();
    var qkrAtiveGameID = $("#hfEncryptedGameID").val();
    //'{"qkrGameID":"' + qkrAtiveGameID + '"}' 
    var url = webURL + 'QkrGame.aspx/CheckGamePlayedByMemberOnPlayButtonClick';
    var data = CheckGamePlayedByMemberForPlayButtonClickResponse(url, '{"qkrGameID":"' + qkrAtiveGameID + '"}');
    if (data != null && data != undefined && data.d.length > 0) {
        if (data.d[0].MemberPlayingMode == false) {
            //Member already played this game before.
            if (data.d[0].IsAlreadyPlayed == true) {
                GameAlreadyPlayed();
                $("#GameDoorLoader").hide();
                return false;
            }
            //Member never played this game before.
            else if (data.d[0].GameIsStartable == true) {
                isPlaying = true;
                return UpdateMemberGamePlayingMode(isPlaying);
            }
        }
        else if (data.d[0].MemberPlayingMode == true) {
            $("#GameStatusInfoWrapperDv").show();
            $(".StartGameWrapperDv").hide();
            $("#GameStatusInfoMsg").hide();
            $("#PlatingOtherGames").show();
            $("#PlatingOtherGames").css("height", "145px");
            if (data.d[0].GameId == '<%=GlobalSettings.QkrActiveGameID %>')
            //$("#PlatingOtherGames").html('You are not allowed to play this game at present. Please try after some time');
                $("#PlatingOtherGames").html('Sorry! You have been temporarily locked from playing this quicker game for <br/><span onclick=\'SecurityMessage();\'>security reasons</span>.<br/>Please try after some time.');
            else
                $("#PlatingOtherGames").html('Sorry! You are not allowed to play this game at present. Please try at after some time.');

            //$("#PlatingOtherGames").html('You are not allowed to play this game at present. Please try at after ' + data.d[0].LastPlayedGameEndTime.substr(7, 7));

            //GameTitle show/hide
            if (data.d[0].GameTitle != '' && data.d[0].GameTitle != null && data.d[0].GameTitle != undefined) {
                $("#GameStatusInfoGameTitle").show();
                $("#GameStatusInfoGameTitle").html(data.d[0].GameTitle);
            }
            else {
                $("#GameStatusInfoGameTitle").hide();
            }
            //GameActualDuration show/hide
            if (data.d[0].GameActualDuration != '' && data.d[0].GameActualDuration != null && data.d[0].GameActualDuration != undefined) {
                var gameActualDuration = CalculateAcutalGameDurationInHMS(data.d[0].GameActualDuration);
                var gameDurationHtml = 'Game Duration : ' + gameActualDuration;
                $("#GameStatusInfoGameDuration span").show();
                $("#GameStatusInfoGameDuration span").html(gameDurationHtml);
            }
            else {
                $("#GameStatusInfoGameDuration span").hide();
            }

            $("#GameStatusInfoMsg span").html(data.d[0].LastPlayedGameEndTime.substr(7, 7));
            $("#GameDoorLoader").hide();
            return false;
        }
    }
    else {
        return false;
    }
    return true;
}

function CheckGamePlayedByMemberForPlayButtonClickResponse(url, postData) {
    var xmlhttp = null;
    if (window.XMLHttpRequest)
        xmlhttp = new XMLHttpRequest();
    else if (window.ActiveXObject) {
        if (new ActiveXObject("Microsoft.XMLHTTP"))
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        else
            xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    }
    // to be ensure non-cached version of response
    url = url + "?rnd=" + Math.random();

    xmlhttp.open("POST", url, false); //false means synchronous
    xmlhttp.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    xmlhttp.send(postData);
    var responseText = jQuery.parseJSON(xmlhttp.responseText);
    return responseText;
}


function UpdateMemberGamePlayingMode(isPlaying) {
    //var qkrAtiveGameID = $("#<%=hfEncryptedGameID.ClientID %>").val();
    var qkrAtiveGameID = $("#hfEncryptedGameID").val();
    //'{"qkrGameID":"' + qkrAtiveGameID + '"}'
    var url = webURL + "QkrGame.aspx/UpdateMemberGamePlayingMode";
    var data = UpdateMemberGamePlayingModeResponse(url, '{"IsPlaying":"' + isPlaying + '", "qkrGameID":"' + qkrAtiveGameID + '"}');

    if (data != null && data != undefined && data.d.length > 0) {
//        indexLevel = parseInt($('#<%= hfLevelIndex.ClientID %>').val());
        indexLevel = parseInt($("#hfLevelIndex").val());
        //var arrQkrGameLevelsLength = parseInt($('#<%= hfLevelLen.ClientID %>').val());
        var arrQkrGameLevelsLength = parseInt($('#hfLevelLen').val());
        if (data.d[0].MemberPlayingMode == false) {
            if (timeOutFlag == false) {
                if (data.d[0].IsAlreadyPlayed == true) {
                    GameAlreadyPlayed();
                    return false;
                }
                else if (data.d[0].IsAlreadyPlayed == false && data.d[0].GameIsStartable == false && indexLevel < arrQkrGameLevelsLength) {
                    //Display Countdown...
                    $("#GameStatusInfoWrapperDv").show();
                    $(".StartGameWrapperDv").hide();
                    $("#GameStartsOnDateCount").show();
                    $("#GameStatusInfoGameTitle").html(data.d[0].GameTitle);
                    $("#GameStatusInfoGameDuration span").html(data.d[0].GameActualDuration);

                    //Remaining Time
                    totsec = data.d[0].GameTotalSeconds;
                    StartGameCountDown();
                    return false;
                }
                else if (data.d[0].IsAlreadyPlayed == false && data.d[0].GameIsStartable == true && indexLevel <= 0 && isGamestartByUser == false) {
                    //Display Game Start Button... [Game Start Screen]
                    isInsertedInMemberGamePlayed = true;
                    //Update DB as Member played a particular game
                    isGamestartByUser = true;
                    return InsertMemberPlayedGamesLog();
                }
                else if (data.d[0].IsAlreadyPlayed == false && data.d[0].GameIsStartable == true && indexLevel == 0 && indexLevel < arrQkrGameLevelsLength) {
                    ////Display 0 levels are completed... [Navigation to landing Screen]
                    $(".BacktoHomeBtnWrapper").show();
                    $("#CongratulationsWrapperDv").css("height", "430px");
                    return false;
                }
                else if (data.d[0].IsAlreadyPlayed == false && data.d[0].GameIsStartable == true && indexLevel > 0 && indexLevel < arrQkrGameLevelsLength) {
                    ////Display how many levels are completed... [Gratification Screen]
                    //alert(indexLevel);
                    //var gratificationPageUrl = webURL + 'Qkrgamehistory.aspx?QkrActiveGameID=' + $.trim($('#<%=hfEncryptedGameID.ClientID %>').val()) + '&IsActivated=Yes';
                    var gratificationPageUrl = webURL + 'Qkrgamehistory.aspx?QkrActiveGameID=' + $.trim($('#hfEncryptedGameID').val()) + '&IsActivated=Yes';
                    $(".dvGratification").html('You have completed ' + indexLevel.toString() + (indexLevel.toString() == "1" ? " level" : " levels") + ' . <a href=' + gratificationPageUrl + ' class="ViewResult"></a>');
                    $(".dvGratification").show();
                    return false;
                }
                else if ((data.d[0].IsAlreadyPlayed == false && data.d[0].GameIsStartable == true && indexLevel > 0 && indexLevel == arrQkrGameLevelsLength) ||
                                    (data.d[0].IsAlreadyPlayed == false && data.d[0].GameIsStartable == false && indexLevel > 0 && indexLevel == arrQkrGameLevelsLength)) {
                    ////Display all levels are completed... [Congratulation Screen]                            
                    //var gratificationPageUrl = webURL + 'Qkrgamehistory.aspx?QkrActiveGameID=' + $.trim($('#<%=hfEncryptedGameID.ClientID %>').val()) + '&IsActivated=Yes';
                    var gratificationPageUrl = webURL + 'Qkrgamehistory.aspx?QkrActiveGameID=' + $.trim($('#hfEncryptedGameID').val()) + '&IsActivated=Yes';
                    $(".dvGratification").html('<a href=' + gratificationPageUrl + ' class="ViewResult" style="margin-left:128px;"> </a>');
                    $(".dvGratification").show();
                    return false;
                }
            }
            else if (timeOutFlag == true && (data.d[0].IsAlreadyPlayed == false && data.d[0].GameIsStartable == true && indexLevel == 0 && indexLevel < arrQkrGameLevelsLength)) {
                ////Display 0 levels are completed for time out... [Navigation to landing Screen]
                $(".BacktoHomeBtnWrapper").show();
                $("#CongratulationsWrapperDv").css("height", "430px");
                return false;
            }
            else if (timeOutFlag == true && (data.d[0].IsAlreadyPlayed == false && data.d[0].GameIsStartable == true && indexLevel > 0 && indexLevel != arrQkrGameLevelsLength)) {
                ////Display how many levels are completed for time out... [Gratification Screen]
                //                var gratificationPageUrl = webURL + 'Qkrgamehistory.aspx?QkrActiveGameID=' + $.trim($('#<%=hfEncryptedGameID.ClientID %>').val()) + '&IsActivated=Yes';
                var gratificationPageUrl = webURL + 'Qkrgamehistory.aspx?QkrActiveGameID=' + $.trim($('#hfEncryptedGameID').val()) + '&IsActivated=Yes';
                $(".dvGratification").html('You have completed ' + indexLevel.toString() + (indexLevel.toString() == "1" ? " level" : " levels") + ' . <a href=' + gratificationPageUrl + ' class="ViewResult"></a>');
                $(".dvGratification").show();
                return false;
            }
        }
        else {
            $("#GameStatusInfoWrapperDv").show();
            $(".StartGameWrapperDv").hide();
            $("#GameStatusInfoMsg").hide();
            $("#PlatingOtherGames").show();
            $("#PlatingOtherGames").css("height", "145px");
            $("#PlatingOtherGames").html('Sorry! You are not allowed to play this game at present. Please try at after some time.');
            $("#GameStatusInfoGameTitle").html(data.d[0].GameTitle);
            $("#GameStatusInfoGameDuration span").html(data.d[0].GameActualDuration);
            $("#GameStatusInfoMsg span").html(data.d[0].LastPlayedGameEndTime.substr(7, 7));
            return false;
        }
    } //End of Data!=null condition
    else {
        return false;
    }
    return true;
}

function UpdateMemberGamePlayingModeResponse(url, postData) {
    var xmlhttp = null;
    if (window.XMLHttpRequest)
        xmlhttp = new XMLHttpRequest();
    else if (window.ActiveXObject) {
        if (new ActiveXObject("Microsoft.XMLHTTP"))
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        else
            xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    }
    // to be ensure non-cached version of response
    url = url + "?rnd=" + Math.random();

    xmlhttp.open("POST", url, false); //false means synchronous
    xmlhttp.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    xmlhttp.send(postData);
    var responseText = jQuery.parseJSON(xmlhttp.responseText);
    return responseText;
}


//====Write a log that a member already played a paricular game====
function InsertMemberPlayedGamesLog() {
    //var qkrAtiveGameID = $("#<%=hfEncryptedGameID.ClientID %>").val();
    var qkrAtiveGameID = $("#hfEncryptedGameID").val();
    //'{"qkrGameID":"' + qkrAtiveGameID + '"}'
    var url = webURL + 'QkrGame.aspx/InsertMemberPlayedGamesLog';
    var data = InsertMemberPlayedGamesLogResponse(url, '{"qkrGameID":"' + qkrAtiveGameID + '"}');
    if (data != null && data != undefined && data.d == true) {
        return true;
    }
    else {
        return false;
    }
}

function InsertMemberPlayedGamesLogResponse(url, postData) {
    var xmlhttp = null;
    if (window.XMLHttpRequest)
        xmlhttp = new XMLHttpRequest();
    else if (window.ActiveXObject) {
        if (new ActiveXObject("Microsoft.XMLHTTP"))
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        else
            xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    }
    // to be ensure non-cached version of response
    url = url + "?rnd=" + Math.random();

    xmlhttp.open("POST", url, false); //false means synchronous
    xmlhttp.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    xmlhttp.send(postData);
    var responseText = jQuery.parseJSON(xmlhttp.responseText);
    return responseText;
}

function PrintTest(str) {
    $("#dvTest").append("<br/>Sequence " + str);
    for (i = 0; i < arrQkrGameLevelSequences.length; i++) {
        $("#dvTest").append(arrQkrGameLevelSequences[i] + ", ");
    }
}




////Get Quicker Game Question-Answers End

////Quicker Game Question-Answers display template Start
var quesTextHtml = '<div class="GameQuiestionBgTop">&nbsp;</div><div class="GameQuiestionBgMiddel" id="GameQuiestionBgMiddel"><div class="GameQuestionOuterDV" style=" font-family:Comic Sans MS">{0}</div>';
var ansTextPrefixHtml = '<ul class="GameAnswerOuterDV">';
var ansTextHtml = '<li class="AnswerOptionRow"><table class="tblAnsOption"><tr><td valign="top" ><input type="radio" name="answer" value="{0}" class="GameAnswerOption" /></td><td><div class="AnswerText">{1}</div></td></tr></table></li>';
var ansTextSuffixHtml = '</ul></div>';
var finalQuesAnsHtml = '';
var finalQuesAnsHtmlSuffix = '<div class="GameQuiestionBgBottom"><div class="GameSubmitDvDV"><input id="btnSubmit" type="button" value="Submit" onclick="return GetQuestionAnswerDetail(this);" class="GameSubmitBtn" /></div></div>';
var firsttime = true;

function BuildQuesAnsDisplayHtml() {
    var qText, aId, aText, quesObjHtml = '', ansObjHtml = '';
    $.each(objJSONQuesAnsDtl, function (i, item) {
        $("#dvTest").append("<br/>Response (Next) - LvlIndex:" + indexLevel + ", LvlId:" + levelId + ", SeqIndex: " + indexSeq + ", SeqID:" + seqId);
        //$("#dvTest").append("<br/>indexLevel:" + indexLevel + " indexSeq:" + indexSeq + " TotalLvlLen: " + arrQkrGameLevels.length + " TotalSeqLen:" + arrQkrGameLevelSequences.length);
        indexLevel = item[0].LevelIndex;
        indexSeq = item[0].SequenceIndex;
        QuestionTime = (item[0].QuestionTime) * 1000;
        $("#hfQuestionID").val(item[0].QuestionID);
        qText = item[0].QuestionText;
        quesObjHtml += quesTextHtml.format(qText);
        $.each(item[0].Answers, function (j, ans) {
            aId = $.trim(ans.AnswerID);
            aText = $.trim(ans.AnswerText);
            ansObjHtml += ansTextHtml.format(aId, aText);
        });
    });

    finalQuesAnsHtml = quesObjHtml + ansTextPrefixHtml + ansObjHtml + ansTextSuffixHtml + finalQuesAnsHtmlSuffix;
    $("#GamePlayArea_dvQuesAns").html(finalQuesAnsHtml);
    $('#dvchatHelpContainer').hide(); //for chat

    if (firsttime) {
        ResetDigitalClock();
        LeftDvRotate(QuestionTime / 2);
        firsttime = false;
    }
    else {
        setTimeout(function () {
            ResetDigitalClock();
            LeftDvRotate(QuestionTime / 2);
        }, 1200);
    }
    $(".GameAnswerOption").click(function () {
        $(".GameSubmitBtn").focus();
    });
}

////Quicker Game Question-Answers display template End

////Build Sponsor Logo HTML Start///
//<div id="dvGameBottomAdCointainer" class="GameBottomAdCointainer" style="display: block;">
var panelHtmlPrefix = "<div class='slideshowfooter'>";
var panelHtmlSuffix = "</div>";
var brandHtml = "<img src='{0}' width='230' height='150' alt=''/>";
var rightPanelHtml = "<img src='{0}' width='250' alt=''/>";
var bottomPanelHtml = "<img src='{0}' width='707' height='178' alt=''/>";
var finalSponsorHtml = "";

var brandHtmlWithWebsiteUrl = "<a href='{1}' target='_blank'><img src='{0}' width='230' height='150' alt=''/></a>";
var rightPanelHtmlWithWebsiteUrl = "<a href='{1}' target='_blank'><img src='{0}' width='250' alt=''/></a>";
var bottomPanelHtmlWithWebsiteUrl = "<a href='{1}' target='_blank'><img src='{0}' width='707' height='178' alt=''/></a>";
var finalSponsorHtmlWithWebsiteUrl = "";

function BuildSponsorLogoHtmlFromJSON() {
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: webURL + "QkrGame.aspx/GetJSONSponsorDetails",
        async: false,
        data: "{}",
        dataType: "json",
        success: OnSuccessBuildSponsorLogoHtmlFromJSON,
        failure: function (response) {
            //alert('Failure');
        },
        error: function (response) {
            //alert('Error in BuildSponsorLogoHtmlFromJSON() function.');
        }
    });
}

function OnSuccessBuildSponsorLogoHtmlFromJSON(data) {
    if (data != null && data != undefined && $.trim(data.d) != "") {
        var strJSONSponsorDtl = data.d;
        strJSONSponsorDtl = strJSONSponsorDtl.replace(/\\/gi, '©');
        objJSONSponsorDtl = eval("(" + strJSONSponsorDtl + ")");
        if (objJSONSponsorDtl != null && objJSONSponsorDtl != '' && objJSONSponsorDtl != undefined) {

            //Retrieving Bottom Panel Sponsor Details Start
            var bottomPanelSponsors = Enumerable.From(objJSONSponsorDtl.Sponsor)
                                        .Where("$.PanelType == 'BottomPanel'")
                                        .ToArray();

            if ($(bottomPanelSponsors).length > 0) {
                var bottomPanelSponsorsFilePath = '', bottomPanelSponsorsWebsiteURL = '', bottomPanelSponsorsHtml = '';
                for (var i = 0; i < bottomPanelSponsors.length; i++) {
                    bottomPanelSponsorsFilePath = '<%=Application["siteurl"] %>' + $.trim($(bottomPanelSponsors)[i].FilePath.replace(/©/gi, '/'));
                    bottomPanelSponsorsWebsiteURL = $.trim($(bottomPanelSponsors)[i].WebsiteURL.replace(/©/gi, '/'));
                    if (bottomPanelSponsorsWebsiteURL !== null && bottomPanelSponsorsWebsiteURL != "")
                        bottomPanelSponsorsHtml += bottomPanelHtmlWithWebsiteUrl.format(bottomPanelSponsorsFilePath, bottomPanelSponsorsWebsiteURL);
                    else
                        bottomPanelSponsorsHtml += bottomPanelHtml.format(bottomPanelSponsorsFilePath);
                }

                finalSponsorHtml = panelHtmlPrefix + bottomPanelSponsorsHtml + panelHtmlSuffix;
                $('#dvGameBottomAdCointainer').html(finalSponsorHtml);
            }
            else {
                $('#dvGameBottomAdCointainer').html("");
                $('#dvGameBottomAdCointainer').hide();
            }

            var rotator = $('.slideshowfooter');
            var images = $(rotator).find("img");
            if (images.length > 1) {
                for (var i = 1; i < images.length; i++) {
                    $(images[i]).fadeOut(500);
                }
                var counter = 1;
                setInterval(function () {
                    for (var i = 0; i < images.length; i++) {
                        $(images[i]).fadeOut(500);
                    }
                    $(images[counter]).fadeIn(500);
                    counter++;
                    if (counter == images.length) {
                        counter = 0;
                    }
                }, 5000);
            }

            //Retrieving Bottom Panel Sponsor Details End

            //Retrieving Right Panel Sponsor Details Start
            var rightPanelSponsors = Enumerable.From(objJSONSponsorDtl.Sponsor)
                                        .Where("$.PanelType == 'RightPanel'")
                                        .ToArray();


            if ($(rightPanelSponsors).length > 0) {
                var rightPanelSponsorsFilePath = '', rightPanelSponsorsWebsiteURL = '', rightPanelSponsorsHtml = '';
                for (var i = 0; i < rightPanelSponsors.length; i++) {
                    rightPanelSponsorsFilePath = '<%=Application["siteurl"] %>' + $.trim($(rightPanelSponsors)[i].FilePath.replace(/©/gi, '/'));
                    rightPanelSponsorsWebsiteURL = $.trim($(rightPanelSponsors)[i].WebsiteURL.replace(/©/gi, '/'));
                    if (rightPanelSponsorsWebsiteURL !== null && rightPanelSponsorsWebsiteURL != "")
                        rightPanelSponsorsHtml += rightPanelHtmlWithWebsiteUrl.format(rightPanelSponsorsFilePath, rightPanelSponsorsWebsiteURL);
                    else
                        rightPanelSponsorsHtml += rightPanelHtml.format(rightPanelSponsorsFilePath);
                }

                finalSponsorHtml = rightPanelSponsorsHtml;
                $('#dvGameRightAdContainer').html(finalSponsorHtml);
            }
            else {
                $('#dvGameRightAdContainer').html("");
                $('#dvGameRightAdContainer').hide();
            }
            //Retrieving Right Panel Sponsor Details End

            //Retrieving Right Panel Brand Details Start
            var rightPanelBrands = Enumerable.From(objJSONSponsorDtl.Sponsor)
                                        .Where("$.PanelType == 'Brand'")
                                        .ToArray();


            if ($(rightPanelBrands).length > 0) {
                var rightPanelBrandsFilePath = '', rightPanelBrandsWebsiteURL = '', rightPanelBrandsHtml = '';
                for (var i = 0; i < rightPanelBrands.length; i++) {
                    rightPanelBrandsFilePath = '<%=Application["siteurl"] %>' + $.trim($(rightPanelBrands)[i].FilePath.replace(/©/gi, '/'));
                    rightPanelBrandsWebsiteURL = $.trim($(rightPanelBrands)[i].WebsiteURL.replace(/©/gi, '/'));
                    if (rightPanelBrandsWebsiteURL !== null && rightPanelBrandsWebsiteURL != "")
                        rightPanelBrandsHtml += brandHtmlWithWebsiteUrl.format(rightPanelBrandsFilePath, rightPanelBrandsWebsiteURL);
                    else
                        rightPanelBrandsHtml += brandHtml.format(rightPanelBrandsFilePath);
                }

                finalSponsorHtml = rightPanelBrandsHtml;
                $('#dvGameRightBrandLogoContainer').html(finalSponsorHtml);
            }
            else {
                $('#dvGameRightBrandLogoContainer').html("");
            }
            //Retrieving Right Panel Brand Details End

            setTimeout(function () { DoorOpen() }, 2200);

        }
    }
}
////Build Sponsor Logo HTML End////

function DoAnswerOptions50_50() {
    //var strJSONQuesAnsDtl = $('#<%=hfObjQuesAnsJSON.ClientID %>').val();
    var strJSONQuesAnsDtl = $('#hfObjQuesAnsJSON').val();
    if (strJSONQuesAnsDtl.length > 0) {
        var objJSONQuesAnsDtl = eval("(" + strJSONQuesAnsDtl + ")");
        var newAnsOptions = [];
        //        var qid = $.trim($('#<%=hfQuestionID.ClientID %>').val());
        var qid = $.trim($('#hfQuestionID').val());
        //To get right answer ID
        var rightAnswers = Enumerable.From(objJSONQuesAnsDtl.Question[0].Answers)
                        .Where("$.QuestionID=" + qid + " && $.XLength == '961'")
                        .ToArray();

        if ($(rightAnswers).length > 0) {
            var rightAnsID;
            for (var i = 0; i < rightAnswers.length; i++) {
                rightAnsID = $(rightAnswers)[i].AnswerID;
            }
            newAnsOptions.push(rightAnsID);
        }

        //To get wrong answer ID
        var wrongAnswers = Enumerable.From(objJSONQuesAnsDtl.Question[0].Answers)
                        .Where("$.QuestionID=" + qid + " && $.XLength != '961'")
                        .ToArray();

        if ($(wrongAnswers).length > 0) {
            var wrongAnsOptions = [];
            for (var i = 0; i < wrongAnswers.length; i++) {
                var wrongAnsID = $(wrongAnswers)[i].AnswerID;
                wrongAnsOptions.push(wrongAnsID);
            }

            //Populate new AnswerID Array after using 50-50 lifeline
            wrongAnsOptions.sort(function () { return 0.5 - Math.random() });
            for (var i = 0; i < (wrongAnsOptions.length - 1) / 2; i++) {
                randomAnsID = wrongAnsOptions[i];
                newAnsOptions.push(randomAnsID);
            }

            //New Answer options array getting randomize after clicking on 50-50 lifeline
            newAnsOptions.sort(function () { return 0.5 - Math.random() });

            $("#GamePlayArea_dvQuesAns").find("ul.GameAnswerOuterDV").empty();

            var ansTextHtml = '<li class="AnswerOptionRow"><table><tr><td valign="top"><input type="radio" name="answer" value="{0}" class="GameAnswerOption" /></td><td><div class="AnswerText">{1}</div></td></tr></table></li>';

            var qText, aId, aText, quesObjHtml = '', ansObjHtml = '';
            $.each(objJSONQuesAnsDtl, function (i, item) {
                $.each(newAnsOptions, function (j) {
                    var aId = newAnsOptions[j];

                    $.each(item[0].Answers, function (k, ans) {
                        if (aId == $.trim(ans.AnswerID)) {
                            aText = $.trim(ans.AnswerText);
                            ansObjHtml += ansTextHtml.format(aId, aText);
                        }
                    });
                });
            });

            $("#GamePlayArea_dvQuesAns").find("ul.GameAnswerOuterDV").html(ansObjHtml);
        }
    }
}

//----------------------------------
//Chat Click...
//----------------------------------
function DoChatClick() {
    minMsgId = null; //for chat
    $('#dvChatMemberWindow').empty();
    $('#QkrWallFriendListUL').empty();
    HelpingFriendsArr = []; //clear the array
    stop_GetAnswer(); //stop the GetAnswer() recursive function
    FillSelectedFriendsOnHelp();
    IsChatClicked = 1;
}

//----------------------------------
//Google Help Click...
//----------------------------------
function DoGoogleHelpClick() {
    var URL = '';
    var qText = $.trim($("div.GameQuestionOuterDV").text());
    var left = ($(window).width() / 2) - (900 / 2),
                    top = ($(window).height() / 2) - (600 / 2);

    var newWindow = null;
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");

    if (msie > 0) { //For IE browser
        URL = 'https://www.google.co.in/search?hl=en-IN&source=hp&q=' + escape(qText);
        newWindow = window.open(URL, '', 'width=900,height=600,top=' + top + ',left=' + left + ',scrollbars=yes');
        if (newWindow) newWindow.focus();
    }
    else { //For other browser
        URL = 'https://www.google.co.in/?gfe_rd=cr&ei=RAYXU72NDsHN8geP6IHIDA#q=' + escape(qText);
        newWindow = window.open(URL, '_blank', 'width=900,height=600,top=' + top + ',left=' + left + ',scrollbars=yes');
        if (newWindow) newWindow.focus();
    }
    return false;
}


////========================
////FOR SUBMIT CLICK
////========================        
function GetQuestionAnswerDetail(sender) {
    /* Control validations start */
    $("#dvTransparentGame").show();
    if ($("input[name=answer]:checked").length <= 0) {
        jAlert('Please select an answer option.');
        $("#dvTransparentGame").hide();
        return false;
    }
    /* Control validations end */
    //----------------------------------
    //To Prevent Double Click On Submit Button
    $(sender).removeAttr("onclick");

    //Reset Chat...
    isAsked = false;
    minMsgId = null; //for chat
    $('#dvChatMemberWindow').empty();
    $('#QkrWallFriendListUL').empty();
    HelpingFriendsArr = []; //clear the array
    stop_GetAnswer(); //stop the GetAnswer() recursive function
    //----------------------------------

    SubmitTime = $('#DigitalClock').last().html();
    AnswerTime = (QuestionTime / 1000) - SubmitTime;
    var qid = $.trim($('#hfQuestionID').val());
    var answers = Enumerable.From(objJSONQuesAnsDtl.Question[0].Answers)
                        .Where("$.QuestionID=" + qid + " && $.XLength == '961'")
                        .ToArray();

    if ($(answers).length > 0) { //Start of Answer Object exixts check
        for (var i = 0; i < answers.length; i++) { //Start Of For Loop
            var ansID = $(answers)[0].AnswerID;
            var chkInputAns = $("input[value='" + ansID + "']");
            if ($(chkInputAns).length > 0) { //Start of Object exixts check

                if ($(chkInputAns)[0].checked == false) { //Wrong Answer  Start
                    //                    setTimeout(function () { $("#<%=GameQuiestionBgMiddel.ClientID %>").empty(); }, 1000);
                    setTimeout(function () { $("#GameQuiestionBgMiddel").empty(); }, 1000);
                    ansStatus = false;
                    //Set Game playing mode false when Wrong answer is given by user
                    isPlaying = false;
                    UpdateMemberGamePlayingMode(isPlaying);
                    DoorClose(3); //For Wrong Answer
                    //Update current sequence data to array
                    updateQuesAnsToArray();
                    //Update current level data
                    updateDBQuesAnsFromArray();

                    //Clear arrQkrMemberAnswers array
                    arrQkrMemberAnswers.length = 0;
                    indexMemberAns = 0;
                } //Wrong Answer  End

                else { //Correct Answer Start
                    GamePlayStatus = 0;
                    ansStatus = true;

                    //Update Previous Sequence 
                    updateQuesAnsToArray();
                    flipQuestionId = 0;

                    if (indexSeq >= arrQkrGameLevelSequences.length) { //Outer Level Up
                        //alert('Game Level Changed');
                        GamePlayStatus = 1;
                        //Update Previous Level
                        updateDBQuesAnsFromArray();

                        //Clear arrQkrMemberAnswers array
                        arrQkrMemberAnswers.length = 0;
                        indexMemberAns = 0;

                        if (indexLevel >= arrQkrGameLevels.length) { //All Level Complete
                            //Set Game playing mode false when all game levels are completed by user
                            isPlaying = false;
                            GamePlayStatus = 2;
                            UpdateMemberGamePlayingMode(isPlaying);
                            //DoorClose(2);
                        }
                        else { //Inner Level Up
                            //DBOperation for Level Change and Clear array
                            GamePlayStatus = 1;
                            setTimeout(function () {
                                levelId = arrQkrGameLevels[indexLevel];
                                GetQkrGameLevelSequences(levelId);
                            }, 3000);
                            //DoorClose(1);
                        }

                    }
                    else { //Sequence Change
                        seqId = arrQkrGameLevelSequences[indexSeq];
                        innerRank = 1;
                        GamePlayStatus = 0;
                        //DoorClose(GamePlayStatus);
                        setTimeout(function () { GetQuesAnsJSON(levelId, seqId, innerRank); }, 2200);
                    }
                    DoorClose(GamePlayStatus);

                } //Correct Answer End
            } //End of Object exixts check
        } //End Of For Loop
    } //End of Answer Object exixts check
    return true;
}

function updateQuesAnsToArray() {
    var mid = 0; //MemberID
    var gid = 0; //QkrActiveGameID
    var lid = levelId;
    var sid = seqId;
    //var qid = $("#<%=hfQuestionID.ClientID%>").val();
    var qid = $("#hfQuestionID").val();
    var fqid = (isFlipped == false) ? 0 : flipQuestionId;
    var isQFlip = isFlipped;
    var isQFifty = isFifty;
    var aid = 0;
    if ($('input[name=answer]:radio:checked').length > 0) {
        var aid = $('input[name=answer]:radio:checked').val();
    }

    var atext = null;  //$($('input[name=answer]:radio:checked').parent()[0].nextSibling).text();
    //var ansStatus = ansStatus;
    var playedOn = getDateTime();

    var qkrQuesAnsDtl = new Object();
    qkrQuesAnsDtl.MemberID = mid;
    qkrQuesAnsDtl.GameID = gid;
    qkrQuesAnsDtl.LevelID = lid;
    qkrQuesAnsDtl.SequenceID = sid;
    qkrQuesAnsDtl.QuestionID = qid;
    qkrQuesAnsDtl.FlipQuestionID = fqid;
    qkrQuesAnsDtl.IsFlip = isQFlip;
    qkrQuesAnsDtl.IsFifty = isQFifty;
    qkrQuesAnsDtl.AnswerID = aid;
    qkrQuesAnsDtl.AnswerText = atext;
    qkrQuesAnsDtl.AnswerStatus = ansStatus;

    if (indexSeq >= arrQkrGameLevelSequences.length)
        qkrQuesAnsDtl.IsLastSequence = true;
    else
        qkrQuesAnsDtl.IsLastSequence = false;

    if (ansStatus == true) {
        qkrQuesAnsDtl.ActionOnGame = "Right";
    }
    else if (ansStatus == false && timeOutFlag == false) {
        qkrQuesAnsDtl.ActionOnGame = "Wrong";
    }
    else if (ansStatus == false && timeOutFlag == true) {
        qkrQuesAnsDtl.AnswerID = 0;
        qkrQuesAnsDtl.ActionOnGame = "Timeout";
    }

    qkrQuesAnsDtl.PlayedOn = playedOn;
    arrQkrMemberAnswers[indexMemberAns++] = qkrQuesAnsDtl;
    ansStatus = false;
    clearInterval(dctmr);
}

function updateDBQuesAnsFromArray() {
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: "QkrGame.aspx/InsertQkrMemberAnswer",
        async: false,
        data: JSON.stringify({ QkrMemberAnswers: arrQkrMemberAnswers }),
        dataType: "json",
        success: OnSuccessInsertQkrMemberAnswer,
        failure: function (response) {
            //alert('Failure on updateDBQuesAnsFromArray');
        },
        error: function (response) {
            //alert('Error in updateDBQuesAnsFromArray() function.');
        }
    });
}

function OnSuccessInsertQkrMemberAnswer(data) {
    if (data != null && data != undefined && $.trim(data.d) != "") {

    }
}


//Call the function while timeout
function DBOperationAtTimeOut() {
    timeOutFlag = true;
    //Update current sequence data to array
    updateQuesAnsToArray();
    //Update current level data
    updateDBQuesAnsFromArray();
    //Set IsPlaying state to false;
    isPlaying = false;
    UpdateMemberGamePlayingMode(isPlaying); //To play the game
}

function RegisterMemberToPlay() {
    //var qkrAtiveGameID = $("#<%=hfEncryptedGameID.ClientID %>").val();
    var qkrAtiveGameID = $("#hfEncryptedGameID").val();
    //'{"qkrGameID":"' + qkrAtiveGameID + '"}'
    $.ajax({
        type: "POST",
        url: webURL + 'QkrGame.aspx/RegisterMT',
        async: false,
        data: '{"qkrGameID":"' + qkrAtiveGameID + '"}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            RegisterMemberToPlay_SuccessCallBack(msg);
        },
        failure: function (response) {
            //alert('RegisterMemberToPlay_Error' + response);
        },
        error: function (response) {
            //alert('RegisterMemberToPlay_Faliure' + response);
        }
    });
}

function RegisterMemberToPlay_SuccessCallBack(msg) {
    CheckChatHelpers();
}


function CheckChatHelpers() {
    //var qkrAtiveGameID = $("#<%=hfEncryptedGameID.ClientID %>").val();
    var qkrAtiveGameID = $("#hfEncryptedGameID").val();
    //'{"qkrGameID":"' + qkrAtiveGameID + '"}'
    $.ajax({
        type: "POST",
        url: webURL + 'QkrGame.aspx/CheckFriendSelected',
        data: '{"qkrGameID":"' + qkrAtiveGameID + '"}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            CheckChatHelpers_SuccessCallBack(msg);
        },
        failure: function (response) {
            //alert('CheckChatHelpers_Error' + response);
        },
        error: function (response) {
            //alert('CheckChatHelpers_Faliure' + response);
        }
    });
}

function CheckChatHelpers_SuccessCallBack(msg) {
    //$("#dvTest").append("<br/>ChatHlprCnt:" + $.trim(msg.d));
    if (msg.d == 0) {
        $('#Chat').unbind('click');
        $('#Chat').removeClass('LifeLineDV').addClass('LifeLineDVDsbl');
        $("#Chat_Shadow").removeClass('LifeLineShadow').addClass('LifeLineShadowDsbl');
        $("#Chat").removeClass('ChatBg').addClass('ChatBgDsbl');
    }
    else {
        $('#Chat').bind('click');
        $('#Chat').removeClass('LifeLineDVDsbl'); //.addClass('LifeLineDV');
        $("#Chat_Shadow").removeClass('LifeLineShadowDsbl').addClass('LifeLineShadow');
        $("#Chat").removeClass('ChatBgDsbl').addClass('ChatBg');
    }
}


function CalculateAcutalGameDurationInHMS(gameDurationTotalSeconds) {
    var durationInHour = 0, durationInMinute = 0, durationInSeconds = 0;
    durationInHour = Math.floor(gameDurationTotalSeconds / 3600);
    durationInMinute = Math.floor(gameDurationTotalSeconds / 60);
    durationInSeconds = Math.floor(gameDurationTotalSeconds % 60);
    var gmeActualDuration = (durationInHour == 0 ? "" : (durationInHour != 1 ? durationInHour + " Hours " : durationInHour + " Hour ")) + (durationInMinute == 0 ? "" : (durationInMinute != 1 ? durationInMinute + " Minutes " : durationInMinute + " Minute ")) + (durationInSeconds == 0 ? "" : (durationInSeconds != 1 ? durationInSeconds + " Seconds" : durationInSeconds + " Second"));
    return gmeActualDuration;
}


function getDateTime() {
    var now = new Date();
    var year = now.getFullYear();
    var month = now.getMonth() + 1;
    var day = now.getDate();
    var hour = now.getHours();
    var minute = now.getMinutes();
    var second = now.getSeconds();
    if (month.toString().length == 1) {
        var month = '0' + month;
    }
    if (day.toString().length == 1) {
        var day = '0' + day;
    }
    if (hour.toString().length == 1) {
        var hour = '0' + hour;
    }
    if (minute.toString().length == 1) {
        var minute = '0' + minute;
    }
    if (second.toString().length == 1) {
        var second = '0' + second;
    }
    var dateTime = year + '/' + month + '/' + day + ' ' + hour + ':' + minute + ':' + second;
    return dateTime;
}

//#region GameRemainingTime
var totsec = 0, tmrtotsec = null, day = 0, hour = 0, minute = 0, sec = 0;
function StartGameCountDown() {
    day = Math.floor(totsec / 86400);
    hour = Math.floor((totsec - (day * 86400)) / 3600);
    minute = Math.floor((totsec - (day * 86400) - (hour * 3600)) / 60);
    sec = totsec - (day * 86400) - (hour * 3600) - (minute * 60);
    //$('#divTime').html(day + 'days ' + hour + 'hours ' + minute + 'minutes ' + sec + 'seconds');
    tmrtotsec = setInterval(function () { SetCountDown(); }, 1000);
}

function SetCountDown() {

    if (sec == 0) {
        sec = 59;
        if (minute > 0) {
            minute = minute - 1;
        }
    }
    else {
        sec = sec - 1;
    }

    if (minute == 0) {
        if (hour > 0) {
            hour = hour - 1;
            minute = 59;
        }
    }

    if (hour == 0) {
        if (day > 0) {
            day = day - 1;
            hour = 23;
        }
    }

    $('#divDay').html(day);
    $('#divHour').html(hour);
    $('#divMinute').html(minute);
    $('#divSecond').html(sec);

    if (day == 0 && hour == 0 && minute == 0 && sec == 0) {
        clearInterval(tmrtotsec);
        location.reload();
    }
}

//#endregion GameRemainingTime

function IsAnswerOptionSelected() { 

//    if ($("#<%= hfTF.ClientID %>").val() == "1") {
//        return true;
    //    }

    if ($("#hfTF").val() == "1") {
        return true;
    }

    /* Control validations start */
    if ($("input[name=answer]:checked").length <= 0) {
        jAlert('Please select an answer option.');
        $("#dvTransparentGame").hide();
        return false;
    }
    else {
        //clearInterval(dctmr);
        //dctmr = null;
        //        QuestionTime = $("#<%=hfQuestionTime.ClientID %>").val();
        QuestionTime = $("#hfQuestionTime").val();
        SubmitTime = $('#DigitalClock').last().html();
        AnswerTime = (QuestionTime / 1000) - SubmitTime;
        //$("#<%=hfSelectedAnsID.ClientID %>").val($("input[name=answer]:checked").val());
        $("#hfSelectedAnsID").val($("input[name=answer]:checked").val());
        //DoorCloseAnimation();
        return true;
    }
    /* Control validations end */
}