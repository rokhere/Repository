﻿var listingFilterObj;
var _categories;
var strTree = '';
var _leftCatClicked = 0;
var _pageno = 1;
var siteUrl = '';
var webUrl = '';

/* Reset Listing */
function ReSetFilter() {
    listingFilterObj =
    {
        CategoryId : 0,
        DiscountPerc: 0,
        DiscountFlat: 0,
        OfferType: 0,
        Stores: [],
        SortByMaxFSGCash: 0,
        SortByPopularity: 0,
        SortByExpiry: 0,
        PageSize : 20,
        StartRow: 0,
        EndRow: 0,
        ListingType:0,
        IsMore: false,
        topCat:0,
       
    };
    listingFilterObj.StartRow = 1;
    listingFilterObj.EndRow = listingFilterObj.PageSize;
    resetShortBy();
}

function RemoveActiveClass() {
    $('a.oz').removeClass('active');
    $('a.qs').removeClass('active');
    $('a.hd').removeClass('active');
}
///////////////////// Load All Data //////////////////////
/* Page Load */
function Page_Onload() {
    RemoveActiveClass();
    ReSetFilter();
    siteUrl = $("#ContentPlaceHolder1_hidSiteUrl").val();
    webUrl = $("#ContentPlaceHolder1_hidWebUrl").val();
    $('#dvLoad').hide();
    $('.topMainHeadingArea').hide();

    //Populate PopularCategories
    var allCategory = JSON.parse($('#ContentPlaceHolder1_hidPopularCategories').val());
        PopulateCategories(allCategory);
 
    //Populate Online Stores
        var allStores = JSON.parse($('#ContentPlaceHolder1_hidOnlineStores').val());
    if (allStores.length > 12) {
        PopulateOnlineStore(allStores, 12, 1);
    }
    else {
        PopulateOnlineStore(allStores, allStores.length, 0);
    }

   
    var sName = $('#ContentPlaceHolder1_hidStoreHeaderName').val() || '';
   // var sName = getUrlQueryStrin()["sn"] || ''
    var catId = getUrlQueryStrin()["cId"] || '';
    var sId = getUrlQueryStrin()["sId"] || '';

    if (sName.length > 0 && sId.length > 0) {
        listingFilterObj.Stores.push(sId);
        listingFilterObj.ListingType = 1;
        HeaderDisplay(sName, 1);

    }
    else if (catId.length > 0) {
        listingFilterObj.CategoryId = catId;
        listingFilterObj.ListingType = 0;
        HeaderDisplay(sName, 2);
    }
    LoadFilterData('treeView');
    LoadFilterData('stores');
    LoadFilterData('discountType');
    LoadFilterData('offerType');
    LoadFilterData('offers');
    LoadFilterData('topStores');
    loadTabLink();
    
}
/* Load Tab Link */
function loadTabLink() {
    $(document).click(function (event) {
        var $tabcontent = $('.tabcontent');
        if ($tabcontent.is(':visible')) {
            $tabcontent.hide();
        }
    });
}
function openMenu(evt, menuName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(menuName).style.display = "block";
    evt.currentTarget.className += " active";

    evt.cancelBubble = true;
}
/* load filter Data */
function LoadFilterData(mode) {
    switch (mode) {
        case 'treeView':
            //TreeView
            var treeView = JSON.parse($('#ContentPlaceHolder1_hidCatTree').val());
            PopulateTreeView(treeView);
           // console.log('treeView');
            break;
        case 'stores':
            //Store & Counts  
            var stores = JSON.parse($('#ContentPlaceHolder1_hidStores').val());
            PopulateStores(stores);
           // console.log('stores');
            break;
        case 'discountType':
            // Populate Discount Type
            var discountType = JSON.parse($('#ContentPlaceHolder1_hidDiscountType').val());
            PopulateDiscountType(discountType);
           // console.log('discountType');
            break;
        case 'offerType':
            // Populate Offer Type
            var offerType = JSON.parse($('#ContentPlaceHolder1_hidOfferType').val());
            PopulateOfferType(offerType);
           // console.log('offerType');
            break;
        case 'offers':
            // Populate OfferDetails
            var allOfferDetails = JSON.parse($('#ContentPlaceHolder1_hidOfferDetails').val());
          //  var memberId = $("#ContentPlaceHolder1_hidMemberId").val();
            PopulateOfferDetails(allOfferDetails, webUrl);
            DescriptionReadMore();
           // console.log('offer');
            break;
        case 'topStores':
             //Populate OfferDetails
            var topStores = JSON.parse($('#ContentPlaceHolder1_hidTopStores').val());
            PopulateTopStores(topStores);
            break;
            
    }
}

/////////////////////// Top Menus ////////////////////////
/* Start PopulateCategories*/
function PopulateCategories(category) {
    var siteUrls = siteUrl + "/Upload/CPSCategoryImage/CouponIconImage/";
    var $ulPopularCategory = $('#dvCatMenu');
    var categoryHtml = '';
    var k = 1;
    if (category.length > 0) {
        for (var i = 0; i < category.length; i++) {
            var catName = category[i].CategoryName;
            catName = '"' + catName + '"';
            categoryHtml += ("<a href='javascript:void(0)' onclick='fn_GetTopCategory(" + category[i].CategoryId + "," + catName + ")' value=" + category[i].CategoryId + "><span class='text-center'><p style='width: 100%; position: absolute; bottom: 4px;'>" + category[i].CategoryName + "</p><img src='" + siteUrls + category[i].IconImage + "' style='margin-top: 25px'/></span></a>");
        }
    }
    categoryHtml+=("<p class='text-center loadMoreLink'></p>");
    $ulPopularCategory.html(categoryHtml);
}

/* Start Populate Online Stores*/
function PopulateOnlineStore(stores, displayCount, showmore) {
    var $ulOnlineStores = $('#dvStoreMenu');
    var storeHtml = '';
    var html = "<a href='javascript:void(0)' onclick='fn_GetOnlineStore({strId},{strName})' value='{strId}' title='{strName}'><span class='text-center'><img src='" + siteUrl + "{strImgUrl}' class='img-responsive  center-block' style='margin-top: 30px'/></span></a>";
    var p = 1;
    if (stores.length > 0) {
        for (var i = 0; i < displayCount; i++) {
            storeHtml += html.format({ strId: stores[i].StoreId, strName: '"' + stores[i].StoreName + '"', strImgUrl: stores[i].StoreImageURL });
        }
    }
    if (showmore == 1) {
        storeHtml += ("<p class='text-center loadMoreLink'><a href='" + webUrl + "/m-coupons-discounts-cashback/hot-deals-offers.aspx'>More</a></p>");
    }
    $ulOnlineStores.html(storeHtml);
}

////////////////////// Side Panel ///////////////////////
/* Start PopulateTopStores*/
function PopulateTopStores(topStores) {
    var $dvStores = $('.dvRelStore');
    var storesHtml = '';
   
    $('.dvRelStore').show();
    $('#ContentPlaceHolder1_dvSlider').show();
    $('#storeHeader').removeClass('displayNone');
    $('#ContentPlaceHolder1_navSlider').removeClass('displayNone');
    if (topStores.length > 0) {
        $('.topSliderArea_listing').removeClass('displayNone');;
        if (topStores.length < 4) {
            $('#ContentPlaceHolder1_navSlider').addClass(' displayNone');
        }
        for (var i = 0; i < topStores.length; i++) {
            var strName = '"' + topStores[i].StoreName + '"';
            storesHtml += "<div class='foresee-item-coupon' title='" + topStores[i].StoreName + "'><a style='cursor:pointer;' id='" + topStores[i].StoreId + "' onclick='fn_GetOnlineStore(" + topStores[i].StoreId + "," + strName + ")'>";
            if (checkImagePath(topStores[i].StoreImageURL)) {
                storesHtml += "<img src='" + siteUrl + topStores[i].StoreImageURL + "' alt='" + topStores[i].StoreName + "' class='img-responsive imgborder center-block'/>";
            }
            else {
                var parts = topStores[i].StoreName.split('.');
                storesHtml += "<div class='breakImage' title= '" + topStores[i].StoreName + "'>" + parts[0] + "</div>";
            }
            storesHtml += "</a></div>";
        }
        $dvStores.html(storesHtml);
        fn_PrepareCarousel();
    }
    else {
        $('#ContentPlaceHolder1_dvSlider').hide();
        $('.topSliderArea_listing').addClass('displayNone');
        $('.storeHeader').addClass('displayNone');
        $('#ContentPlaceHolder1_navSlider').addClass('displayNone');
        $('.dvRelStore').hide();
    }

}
/* Show Percentage type */
function fnShowPercentageType(sender) {
    $sender = $(sender);
    $dvPercent = $('#dvPercentage');
    $('.lnkDisc').prop('checked', false);
    if ($sender.is(":checked")) {
        $('#dvPercentage input[value="1"]').prop('checked', true);
        $dvPercent.show();
        fn_SetListingFilter({ 'DiscTypePerc': 1 });
    }
    else {
        fn_SetListingFilter({ 'DiscTypePerc': 0 });
        $dvPercent.hide();
        
    }
}
/* Strat PopulateDiscountType */
function PopulateDiscountType(discountType) {
    var html = "<div class='radio' style='margin-left:15px;'><label id='lblPercentage'><input type='radio' name='optradio' {checkedStatus} class='lnkDisc' onclick='fn_SetListingFilter({ DiscTypePerc:{discTypeId} })'  value='{discTypeId}' />{discSubType} ({discOfferCnt})</label></div>";
    var $dvPercentage = $('#dvPercentage');
    var $lnkPercentage = $('#lnkPercentage');
    var $dvchkFlat = $('#lnkFlatCount');
    var percentageHtml = '';
    var flatHtml = '';
    $('.dvrDiscountType').show();
    if (discountType.length > 0) {
        for (var i = 0; i < discountType.length; i++) {
            var dType = discountType[i];
            var checkedStatus = '';
            if (listingFilterObj.DiscountPerc === dType.DiscountTypeID) {
                checkedStatus = 'checked';
            }
            if (dType.DiscountSubType.trim() != '') {
                $lnkPercentage.text("(" + discountType[0].OfferCount + ")");
                percentageHtml += html.format({ discTypeId: dType.DiscountTypeID, discSubType: dType.DiscountSubType, discOfferCnt: dType.OfferCount, checkedStatus: checkedStatus });
            }
            else {
                $('#ContentPlaceHolder1_chkFlat').val(dType.DiscountTypeID);
                flatHtml += ("Flat (" + dType.OfferCount + ")");
            }
        }

        if (percentageHtml.length == 0) {
            listingFilterObj.DiscountPerc = 0;
            $('.lnkDisc').prop('checked', false);
            $('.lnkDiscType').prop('checked', false);
            $('.chkPerce').hide();
        }
        else {
            $('.chkPerce').show();
            $('#dvPercentage input[value="1"]').prop('checked', true);
        }
        $dvPercentage.html(percentageHtml);
        if (listingFilterObj.DiscountPerc == 0) {
            $('.lnkDiscType').prop('checked', false);
              $('#dvPercentage').hide();
        }
        else {
             $('#dvPercentage').show();
        }

        if (flatHtml == '') {
            $('#dvFlatHtml').hide();
        }
        else {
            $('#dvFlatHtml').show();
        }
        $dvchkFlat.html(flatHtml);

        if (listingFilterObj.DiscountFlat == 0) {
            $('.lnkFlatType').prop('checked', false);
        }
        
    }
    else {
        $('.dvrDiscountType').hide();
    }
}
/* Start PopulateOfferType */
function PopulateOfferType(offerType) {
    var html = "<div class='radio'><label><input type='radio' name='ofrTypRadio' value='{OfrId}' class='lnkOfferType' {chkStatus}  onclick='fn_SetListingFilter({ofrType :{OfrId}})' />{OfrType}</label></div>";
    var $dvOfferType = $('#dvOfferType');
    var offerTypeHtml = '';
    $('.dvrOfferType').show();
    if (offerType.length > 0) {
        for (var i = 0; i < offerType.length; i++) {
            var ofr = offerType[i];
            var chkStatus = '';
            if (listingFilterObj.OfferType === ofr.OfferId) {
                chkStatus = 'checked'; 
            }
            offerTypeHtml += html.format({ OfrId: ofr.OfferId, OfrType: ofr.OfferType, chkStatus: chkStatus });
        }
        $dvOfferType.html(offerTypeHtml);
    }
    else {
        $('.dvrOfferType').hide();
    }
} 
/* Strat PopulateStores & Search Stores */
function PopulateStores(stores) {
    if (!listingFilterObj.ListingType) {
        $('.dvrStores').show();
        var html = "<div class='checkbox elStores'><label><input type='checkbox' class='lnkStores' {checkedStatus} onclick='fn_SetListingFilter({strId :{strId}})' value='{strId}'/>{strName} ({strCount})</label></div>";
        var $dvStores = $('#dvStores');
        var storesHtml = '';
        if (stores.length > 0) {
            var listingFilterStores = [];
            for (var i = 0; i < stores.length; i++) {
                var store = stores[i];
                var checkedStatus = '';
                if (listingFilterObj.Stores.indexOf(store.StoreId) > -1) {
                    listingFilterStores.push(store.StoreId);
                    checkedStatus = 'checked';
                }
                storesHtml += html.format({ strId: store.StoreId, strName: store.StoreName, strCount: store.OfferCount, checkedStatus: checkedStatus });
            }
            $dvStores.html(storesHtml);
            //Rebind Filter Stores - remove non existing stores.
            listingFilterObj.Stores = listingFilterStores;
        }
        else {
            $('.dvrStores').hide();
        }
    }
    else {
        $('.dvrStores').hide();
    }
}
function searchStores(txt) {
    var searchTerm = $(txt).val().toLowerCase();
    $('.elStores label').each(function () {
        var $sender = $(this);
        if ($sender.text().toLowerCase().indexOf(searchTerm) > -1) {
            $sender.parent().show();
        }
        else {
            $sender.parent().hide();
        }
    });
}

///////////////////// Filter Offer Data /////////////////
/* Start Offer Detals */
function PopulateOfferDetails(offerDetails, webUrl) {
    var memberId = $("#ContentPlaceHolder1_hidMemberId").val();
    var $divOfferDetails = $('#divOfferDetails');
    var offerHtml = '';
   // debugger;
    if (offerDetails.length > 0) {
        var offersLength = offerDetails.length > listingFilterObj.PageSize ? offerDetails.length - 1 : offerDetails.length;
        for (var i = 0; i < offersLength; i++) {
            var ofrDtl = offerDetails[i];
            if (ofrDtl.CouponCode == "") {
                ofrGetDeal = "Get Deal";
            }
            else {
                ofrGetDeal = "Get Coupon";
            }
            var html = "<div class='eachDealBoxInner'><input type='hidden' id='hidOfferDetail{ofrDtlId}' value='{jsonOfferDetails}'></input>" +
                "<i style='float:right; color: #337ac6; font-size:12px; cursor:pointer;' data-tnc='{TnC}' onclick='openTermAndCondition(this)'><u>T&C</u></i>" +
              "<div class='row'><div class='col-lg-3 col-md-3 col-sm-4 col-xs-12 padingOferDetails' title='{Title}'>";

            if (checkImagePath(ofrDtl.StoreImageURL)) {
                html += "<img src='{siteUrl}{imgSrcUrl}' alt='{Title}' class='img-responsive imgborder pull-left'/>"
            }
            else {
                var parts = ofrDtl.StoreName.split('.');
                html += "<div class='breakImage' title='{Title}'>" + parts[0] + "</div>";
            }
            html += "</div><div class='col-lg-9 col-md-9 col-sm-8 col-xs-12 padingTRB30'><h3>"
            html += "<a style='cursor:pointer;' data-toggle='modal' data-target='#myModal' onclick='SetUrl({ofrDtlId}); OnPopularityCount_Click({ofrDtlId});'>"
            // Conditional Model Popup Open End
            html += " {oftDtlTitle} </a></h3><h4> <span style='color:#cd3232; margin-left:0px;'>{ofrDtlUpTo}</span></h4></div></div>" +
            "<div class='row'><div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'><h3 class='item'> {ofrDesc} </h3></div></div> <div class='row'><div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'><div class='singleline'></div></div>" +
            "</div>  <div class='row'> <div class='col-lg-8 col-md-8 col-sm-8 col-xs-12 padingTBL40'><span style='font-size:13px; line-height:20px; color:#858588'>Expires on : {ofrExp} </span></div>";

            // Conditional Model Popup Open Start
            html += "<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12 padingTBL40 text-right' style='margin-top:8px;'><a class='btn btn-success' data-toggle='modal' data-target='#myModal' onclick='SetUrl({ofrDtlId}); OnPopularityCount_Click({ofrDtlId});'>{getDeal}</a></div>";
            // Conditional Model Popup Open End
            html += "</div></div>";

            var tnc = ofrDtl.TermCondition;
            ofrDtl.TermCondition = '';
            offerHtml += html.format({ ofrDtlId: ofrDtl.OfferDetailsID, Title: ofrDtl.StoreName, siteUrl: siteUrl, imgSrcUrl: ofrDtl.StoreImageURL, oftDtlTitle: ofrDtl.Title, ofrDtlUpTo: ofrDtl.ExistingCustomerWeb, ofrDesc: ofrDtl.Description, ofrExp: ofrDtl.ExpiryDate, TnC: escape(tnc), getDeal: ofrGetDeal, jsonOfferDetails: escape(JSON.stringify(ofrDtl)) });
        }

        //Show More
        $('#pageDiv, #aOfferShowMore, #loadimg').remove();
        if (offerDetails.length > listingFilterObj.PageSize) {
            offerHtml += "<div class='eachDealBoxInner' id ='pageDiv'><div class='row'><div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'><div class='text-center viewMorelnk' style='margin-bottom:0px;'><a id='aOfferShowMore' style='cursor: pointer; line-height:25px; text-decoration:none; display:block; padding:0;' onclick='OffersShowMore();' class='loadMoreLink'>More</a><div id='loadimg' class='displayNone'><i class='fa fa-spinner fa-spin fa-lg'  style='color: #337ab7;'></i></div></div></div></div></div>";
        }
        $('#RecNotFound').addClass('displayNone');

    }
    else {
        $('#RecNotFound').removeClass('displayNone');
    }

    if (listingFilterObj.IsMore) {
        $divOfferDetails.append(offerHtml);
        listingFilterObj.IsMore = false;
    } else {
        $divOfferDetails.html(offerHtml);
    }
}
function openTermAndCondition(sender) {
    var $sender = $(sender)
    var tnc = unescape($sender.data('tnc'));
    var $dvTermAndCon = $('#dvTermAndCon');
    var $p =$dvTermAndCon.find('div.modal-body div');
    $p.html(tnc);
    $('.tncPopup li').first().append('<li>Cashback/Rewards can only be earned from foreseegame to web or mobile web store. It is not for foreseegame to other mobile apps.</li>');
    $dvTermAndCon.modal('show');
}
function SetUrl(id) {
    var memberId = $("#ContentPlaceHolder1_hidMemberId").val();
    var $hid = $('#hidOfferDetail' + id);
    var jsonOffrDtl = JSON.parse(unescape($hid.val()));
    $('#popImgUrl').attr('src', siteUrl + jsonOffrDtl.StoreImageURL);
    $('#popImgUrl').attr('alt', jsonOffrDtl.StoreName);

    if (jsonOffrDtl.StoreImageURL != "") {
        localStorage.setItem("Frwdurl", (siteUrl + jsonOffrDtl.StoreImageURL));
    } else {
        localStorage.setItem("Frwdurl", null);
    }
    localStorage.setItem('Frwdalt', jsonOffrDtl.StoreName);

    $('#h4Offer').text(jsonOffrDtl.Title);
    $('#h3Cashback').text(jsonOffrDtl.ExistingCustomerWeb);
    $('.couponCodeArea').removeClass('displayNone');
    var $dvCode = $('#dvWithoutLogIn');
    var codeHtml = '';
    if (jsonOffrDtl.CouponCode != "") {

        codeHtml = "<div class='row'><div class='col-lg-4 col-md-4 col-sm-12 col-xs-12' style='margin-bottom:5px;'><strong>Your Coupon Code :</strong></div>" +
           "<div class='col-lg-8 col-md-8 col-sm-12 col-xs-12'><div class='input-group'><input type='text' id='txtCode' readonly='true' class='form-control' value='" + jsonOffrDtl.CouponCode + "'/>" +
           "<span class='input-group-btn'><button class='btn btn-primary' id='copyBlock' onclick='CopyCouponCode()' type='button'>Copy</button></span></div></div></div>" +
           "<div class='row'><div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>" +
           "<p>Visit <span style='color:#337ab7;'><b>" + jsonOffrDtl.StoreName + "</b></span> & paste the above code at checkout</p></div></div>" +
           "<hr />";
    }
    else {
        codeHtml += "";

    }
    if (jsonOffrDtl.StoreName.toLowerCase().trim() != 'amazon.in') {
        if (memberId == 0) {
            codeHtml += "<div class='row'>" +
            "<div class='col-lg-5 col-md-5 col-sm-12 col-xs-12' id='dvWithLogin'><a id='hrefLogin' onclick='hideContent(2);' Target='_blank'>" +
            "<div class='skipLoginBtn btn btn-success btn-block' style='line-height:39px; text-align:center;'>Log In & Go to Store<br/></div></a></div>" +
            "<div class='col-lg-7 col-md-7 col-sm-12 col-xs-12'>" +
            "<div class='skipLoginBtn btn btn-info btn-block' id='dvWithoutLogin'><a id='hrefWithoutlogin' onclick='hideContent(1);' Target='_blank'>" +
            "Skip Login & Go to Store<span>(No cashback)</span></a></div></div></div>";
        }
        else {
            codeHtml += "<div class='row'><div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'><div class='goToStoreBtnAlign'>" +
            "<a class='skipLoginBtn btn btn-success' id='hrefGetCashBack' style='line-height:39px; text-align:center;' Target='_blank'>Go to Store</a></div></div>";
        }
    }
    else {
        codeHtml = "";
        $('#h3Cashback').text('');
        codeHtml += "<div class='row'><div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'><div class='goToStoreBtnAlign'>" +
           "<a class='skipLoginBtn btn btn-success' id='hrefGetCashBack' style='line-height:39px; text-align:center;' Target='_blank'>Go to Store</a></div></div>";
    }

    $dvCode.html(codeHtml);

    $("#hrefLogin").attr("href", webUrl + "/Muser/MemberLogin.aspx?Rpage=CASHBACK&At=" + jsonOffrDtl.AffiliationId + "&ACI=" + jsonOffrDtl.AffiliateChannelID + "&Oid=" + jsonOffrDtl.OfferDetailsID + "&Purl=" + jsonOffrDtl.OfferPageURL);
    $("#hrefWithoutlogin").attr("href", "get-deals-offeres.aspx?At=" + jsonOffrDtl.AffiliationId + "&ACI=" + jsonOffrDtl.AffiliateChannelID + "&Oid=" + jsonOffrDtl.OfferDetailsID + "&Purl=" + jsonOffrDtl.OfferPageURL);
    $("#hrefGetCashBack").attr("href", "get-deals-offeres.aspx?At=" + jsonOffrDtl.AffiliationId + "&ACI=" + jsonOffrDtl.AffiliateChannelID + "&Oid=" + jsonOffrDtl.OfferDetailsID + "&Purl=" + jsonOffrDtl.OfferPageURL);
}
function CopyCouponCode() {
    var txt = $('#txtCode').val();
    $('#txtCode').select();
    document.execCommand('copy');
    $("#copyBlock").html('Copied');
    $('#copyBlock').removeClass('btn-primary');
    $('#copyBlock').addClass('btn-success');
    $('#txtCode').addClass('form-controlCopied');
    
}
function checkImagePath(imageURL) {
    var valid_extensions = /(\.jpg|\.jpeg|\.gif|\.png)$/i; 
    if (valid_extensions.test(imageURL)) {
        return true;
    }
    else {
        return false;
    }
}

//////////////////// Miscellaneous  /////////////////////
/* Start Description Show more */
function DescriptionReadMore() {
    $('.item').each(function (event) {
        var $sender = $(this);
        if (!$sender.hasClass('item-done')) {
            /* select all divs with the item class */
            var max_length = 100; /* set the max content length before a read more link will be added */
            if ($(this).html().length > max_length) { /* check for content length */
                var short_content = $(this).html().substr(0, max_length); /* split the content in two parts */
                var long_content = $(this).html().substr(max_length);
                $(this).html(short_content + '<a href="javascript:void(0)" class="read_more" style="color:#062c4d;">..&nbsp; more</a>' + '<span class="more_text" style="display:none;">' + long_content + '<a href="javascript:void(0)" class="compress" style="color:#062c4d;">&nbsp; less</a></span>'); /* Alter the html to allow the read more functionality */
                $(this).find('a.read_more').click(function (event) { /* find the a.read_more element within the new html and bind the following code to it */
                    event.preventDefault(); /* prevent the a from changing the url */
                    $(this).hide(); /* hide the read more button */
                    $(this).parents('.item').find('.more_text').show(); /* show the .more_text span */
                });
                $(this).find('a.compress').click(function (event) { /* find the a.read_more element within the new html and bind the following code to it */
                    event.preventDefault(); /* prevent the a from changing the url */
                    $('.read_more').show(); /* hide the read more button */
                    $(this).parents('.item').find('.more_text').hide(); /* .slideUp show the .more_text span */
                });
                $sender.addClass('item-done');
            }
        }
    });
}
/* Login Panel Update*/
function PopulateLoginPanel(loginstate) {
   
    var userName = $('#ContentPlaceHolder1_hidMemberName').val();
    SetLoginPanel(loginstate, siteUrl, webUrl, userName);
}
function hideContent(ctrlId) {
    if (ctrlId == 1) {
        $('.couponCodeArea').addClass('displayNone');
    }
    else if (ctrlId == 2) {
        $('#dvWithLogin').addClass('displayNone');
    }
}

/////////////////// Clear Data //////////////////////////
/* Start Clear Link Butoon */
function clearDicountType() {
    $('.lnkDisc').prop('checked', false);
    $('.lnkDiscType').prop('checked', false);
    $('.lnkFlatType').prop('checked', false);
    $('#dvPercentage').hide();
    fn_SetListingFilter({ 'DiscTypeFlat': 0 });
    fn_SetListingFilter({ 'DiscTypePerc': 0 });
}
function clearOfferType() {
    $('.lnkOfferType').prop('checked', false);
    fn_SetListingFilter({ ofrType: 0 })
}
function clearStores() {
    $('.lnkStores').prop('checked', false);
    $('#txtStoreSearch').val('');
    $('#txtStoreSearch').keyup()
    listingFilterObj.Stores = [];
}
function resetPageIndex() {
    listingFilterObj.PageSize = 20;
    listingFilterObj.StartRow = 1;
    listingFilterObj.EndRow = 20;
}

////////////////// Start Common Function Call ///////////
function fn_GetTopCategory(CategoryId, CategoryName) {
    ReSetFilter();
    HeaderDisplay(CategoryName, 2);
    $('#dvStoreHeader').addClass('displayNone');
    $('.dvrStores').show();
    listingFilterObj.topCat = 1;
    listingFilterObj.ListingType = 0;
    filterSettings = { 'catId': CategoryId }
    fn_SetListingFilter(filterSettings)
    GetFilterData();
}
function fn_GetCategory(CategoryId) {
    if (listingFilterObj.ListingType == 1) {
        $('.dvrStores').hide();
    }
    else {
        $('.dvrStores').show();
    }
   
    filterSettings = { 'catId': CategoryId }
    fn_SetListingFilter(filterSettings)
}
function fn_GetOnlineStore(storeId, storeName) {
    ReSetFilter();
    HeaderDisplay(storeName, 1);
    $('.lnkDiscType').prop('checked', false);
    $('.lnkFlatType').prop('checked', false);
    $('#dvPercentage').hide();
    listingFilterObj.ListingType = 1;
    $('.dvrStores').hide();
    filterSettings = { 'strOnlineId': storeId }
    fn_SetListingFilter(filterSettings)
    GetFilterData();

}
function fn_GetTopBrand(brandId) {
    ReSetFilter();
    $("#ContentPlaceHolder1_storeText").html('Brand');
    $('.dvrStores').show();
    listingFilterObj.CategoryId = 0;
    filterSettings = { 'strId': brandId }
    fn_SetListingFilter(filterSettings);
}
function HeaderDisplay(storeName, id) {
    var storeName = storeName.replace(/%20/g, " ");
    $('#spnStoreName').html(storeName);
    $
    if (id == 1) {
        $("#ContentPlaceHolder1_storeText").html('Related Stores');
        $('#dvStoreHeader').removeClass('displayNone');
    }
    else if (id == 2) {
        $("#ContentPlaceHolder1_storeText").html(storeName);
        $('#dvStoreHeader').addClass('displayNone');
    }
}

///////////////// Start Short By/////////////////////////

function ShortBy(val) {
    var val = val.value;
    if (val == '0' || val == undefined) {
        listingFilterObj.SortByMaxFSGCash = 0,
        listingFilterObj.SortByPopularity = 0,
        listingFilterObj.SortByExpiry = 0;
        resetShortBy();
    }

    if (val == '1') {
        listingFilterObj.SortByMaxFSGCash = 1,
        listingFilterObj.SortByPopularity = 0,
        listingFilterObj.SortByExpiry = 0;
        fn_ApplyFiler();
    }
    if (val == '2') {
        listingFilterObj.SortByMaxFSGCash = 0,
       listingFilterObj.SortByPopularity = 1,
       listingFilterObj.SortByExpiry = 0;
        fn_ApplyFiler();
    }
    if (val == '3') {
        listingFilterObj.SortByMaxFSGCash = 0,
       listingFilterObj.SortByPopularity = 0,
       listingFilterObj.SortByExpiry = 1;
        fn_ApplyFiler();
    }    
}
function resetShortBy() {
    $("#ddlShort")[0].selectedIndex = 0;
}
///////////////// Start Filter //////////////////////////
function fn_SetListingFilter(filterSettings) {
    //Discount Type
    if (filterSettings.DiscTypeFlat != undefined) {
        listingFilterObj.DiscountFlat = filterSettings.DiscTypeFlat;
    }
    if (filterSettings.DiscTypePerc != undefined) {
        listingFilterObj.DiscountPerc = filterSettings.DiscTypePerc;
    }

    //Offer Type
    if (filterSettings.ofrType != undefined) {
        listingFilterObj.OfferType = filterSettings.ofrType;
       
    }
    //Stores
    if (filterSettings.strId != undefined) {
        var list = listingFilterObj.Stores;
        if (list.indexOf(filterSettings.strId) > -1) {
            var stores = [];
            for (var i = 0; i < list.length; i++) {
                if (list[i] != filterSettings.strId) {
                    stores.push(list[i]);
                }
            }
            listingFilterObj.Stores = stores;
        }
        else {
            listingFilterObj.Stores.push(filterSettings.strId);
        }

        listingFilterObj.ListingType = 0;
    }
    //Top menu Category Id
    if (filterSettings.catId != undefined) {
        listingFilterObj.CategoryId = filterSettings.catId;
    }
    //Top menu Store Id
    if (filterSettings.strOnlineId != undefined) {
        listingFilterObj.Stores.push(filterSettings.strOnlineId);
    }
   // GetFilterData();
}
function fn_ApplyFiler() {
    $('.icon-close').click();
    GetFilterData();
}

///////////////// Start Server side Calling /////////////
function GetFilterData() {
    listingFilterObj;
    resetPageIndex();
    _pageno = 1;
    $.ajax({
        url: "best-deals.aspx/GetFilterData",
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        data: '{listingFilter :' + JSON.stringify(listingFilterObj) + '}',
        beforeSend: function () {
            $('#dvLoad').show();
            // console.log('Show Loading');
        },
        success: function (response) {
            //Prepare Objects
            var jDiscountType = (response.d.JDidcountType);
            var jOfferType = (response.d.JOfferType);
            var jStores = (response.d.JStores);
            var jOffers = (response.d.JOffers);
            var jCategories = (response.d.htmlCategories);
            var jTopStore = (response.d.JTopStore);
           // debugger;
            if (JSON.parse(jOffers).length > 0) {
                //Set to hid ctrls
                $('#ContentPlaceHolder1_hidDiscountType').val(jDiscountType);
                $('#ContentPlaceHolder1_hidOfferType').val(jOfferType);
                $('#ContentPlaceHolder1_hidStores').val(jStores);
                $('#ContentPlaceHolder1_hidOfferDetails').val(jOffers);
                $('#ContentPlaceHolder1_hidCatTree').val(jCategories);
                $('#ContentPlaceHolder1_hidTopStores').val(jTopStore);
                LoadFilterData('stores');
                LoadFilterData('discountType');
                LoadFilterData('offerType');
                LoadFilterData('offers');
                LoadFilterData('treeView');
                LoadFilterData('topStores');
            }
            else {
                
                $('#ContentPlaceHolder1_hidOfferDetails').val(jOffers);
                LoadFilterData('offers');
               
            }
        },
        complete: function () {
            $('#dvLoad').hide();
            _leftCatClicked = 0;
        },
        error: function (response) {
            //alert('Error');
            console.log('Error: Some thing is wrong');
        }
    });
}
function OffersShowMore() {
    _pageno += 1;
    listingFilterObj.IsMore = true;
    listingFilterObj.StartRow += listingFilterObj.PageSize;
    listingFilterObj.EndRow += listingFilterObj.PageSize;
    //console.log(listingFilterObj);
    listingFilterObj;
    $.ajax({
        url: "best-deals.aspx/GetFilterDataShowMore",
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        data: '{listingFilter :' + JSON.stringify(listingFilterObj) + '}',
        beforeSend: function () {
            $('#aOfferShowMore').hide();
            $('#loadimg').removeClass('displayNone');
        },
        success: function (response) {
            //Prepare Objects
            var jOffers = (response.d.JOffers);

            //Set to hid ctrls
            $('#ContentPlaceHolder1_hidOfferDetails').val(jOffers);

            $('#divOfferDetails').append("<div class='eachDealBoxInner'><div class='row'><div class='col-lg-12 col-md-12 col-sm-12 col-xs-12 text-right'><div style='width:100%; float:right; background:#d9edf7; color: #337ab7; line-height:24px; padding-right:10px; font-weight:600;'>Page " + (_pageno - 1) + "</div></div></div></div>");

            LoadFilterData('offers');


        },
        complete: function () {
            $('#loadimg').addClass('displayNone');
            $('#aOfferShowMore').show();
        },
        error: function (response) {
            // alert('Error');
            console.log('Error: Some thing is wrong');
        }
    });
}
function OnPopularityCount_Click(ofrDtlId) {
    window.localStorage.removeItem('isredirected');
    $.ajax({
        url: "best-deals.aspx/CPS_PopularityCount",
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        data: '{ofrDtlId :' + ofrDtlId + '}',
        beforeSend: function () {
            $('#dvLoad').show();
        },
        success: function (response) {
        },
        complete: function () {
            $('#dvLoad').hide();
        },
        error: function (response) {
            console.log('Error: Some thing is wrong');
        }
    });
}
function OnPopupClose() {
    $.ajax({
        url: "best-deals.aspx/OnPopupClose",
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        data: {},
        beforeSend: function () {
        },
        success: function (response) {
            var JMemberId = (response.d.JMemberId);
            var JMemberName = (response.d.JMemberName);
            var loginstate = JMemberId > 0 ? "True" : "False";
            $('#ContentPlaceHolder1_hidMemberId').val(JMemberId);
            $('#ContentPlaceHolder1_hidMemberName').val(JMemberName);
            PopulateLoginPanel(loginstate);
        },
        complete: function () {
        },
        error: function (response) {
            console.log('Error: Some thing is wrong');
        }
    });
}

///////////////// Start Tree View Population ////////////

function PopulateTreeView(categories) {
    var $dvTree = $('#ulTreeView');
    _categories = categories;
    var catPid = 0;
    if (categories.length > 0) {
        catPid = categories[0].ParentId;
    }

    strTree = '';
    fn_PrepareTree(catPid);

    if (catPid > 0) {
        $dvTree.html(strTree);
    }
    else {
        $dvTree.html("<li>Category<ul>" + strTree + "</ul></li>");
    }
    $dvTree.html(strTree);
    $("#ulTreeView").treeview({
        collapsed: true,
        unique: true,
        persist: "location"
    });
        var $span = $('#ulTreeView').find('li[id="' + listingFilterObj.CategoryId + '"] span:eq(0)');
        if ($span != undefined) {
            $span.addClass('treeSelected');
             $span.closest('ul').parentsUntil().find('div:eq(0)').click();
        }
}
function leftCat_OnClick(sender, catId) {
    //remove all selected
    $('#ulTreeView span.treeSelected').each(function () {
        var $this = $(this);
        $this.removeClass('treeSelected');
    });

    //add selected
    var $sender = $(sender);
    $sender.addClass('treeSelected');
    _leftCatClicked = 1;
    fn_GetCategory(catId);
}
function fn_PrepareTree(ParentId) {
    var catChilds = fn_GetChildren(ParentId);
    var cat;

    if (catChilds.length > 0) {

        if (ParentId > 0) {
            cat = fn_GetTreeCategory(ParentId);
           
            //strTree += "<li id=" + cat.CategoryId + "><span onclick='leftCat_OnClick(this," + cat.CategoryId + ");'>" + cat.CategoryName + "</span>";
            if (cat.CategoryName.trim() != "") {
               strTree += "<li id=" + cat.CategoryId + "><span onclick='leftCat_OnClick(this," + cat.CategoryId + ");'>" + cat.CategoryName + "</span>";
            }
            strTree += "<ul>";
        }

        for (var i = 0; i < catChilds.length; i++) {
            fn_PrepareTree(catChilds[i].CategoryId);
        }
        strTree += "</ul>";
        strTree += "</li>";
    }
    else {
        cat = fn_GetTreeCategory(ParentId);
        //strTree += "<li id=" + cat.CategoryId + " data-pid='" + ParentId + "'><span onclick='leftCat_OnClick(this, " + cat.CategoryId + ");'>" + cat.CategoryName + "</span></li>";
        if (cat.CategoryName.trim() != "") {
            strTree += "<li id=" + cat.CategoryId + " data-pid='" + ParentId + "'><span onclick='leftCat_OnClick(this, " + cat.CategoryId + ");'>" + cat.CategoryName + "</span></li>";
        }
    }
}
function fn_GetChildren(ParentId) {
    var children = [];
    for (var i = 0; i < _categories.length; i++) {
        var cat = _categories[i];
        if (cat.ParentId == ParentId) {
            children.push(cat);
        }
    }
    return children;
}
function fn_GetTreeCategory(cid) {
    var cat;
    for (var i = 0; i < _categories.length; i++) {
        cat = _categories[i];
        if (cat.CategoryId == cid) {
            break;
        }
    }
    return cat;
}
