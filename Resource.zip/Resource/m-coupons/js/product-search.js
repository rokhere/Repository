﻿var membername = '';
var siteUrl = '';
var webUrl = '';
var loginstate = '';

$(document).ready(function () {
    DescriptionReadMore();
});

function SetUrl(sender) {

    window.localStorage.removeItem('isredirected');

    var $sender = $(sender);
    var jdata = JSON.parse($sender.attr('data-jdata'));

    At = jdata.At;
    ACI = jdata.ACI;
    Oid = jdata.Oid;
    Purl = jdata.Purl;
    Src = jdata.Src;
    Alt = jdata.Alt;
    Title = jdata.Title;
    OfferDetails = jdata.OfferDetails;
    CouponCode = jdata.CouponCode

    webUrl = $("#hidWebUrl").val();
    siteUrl = $("#hidSiteUrl").val();
    loginstate = $("#hidLoginState").val();

    var codeHtml = '';
    if (CouponCode != "" && OfferDetails != "FLIPKART") {

        $("#dvcCode").show();

        codeHtml = "<div class='row'><div class='col-lg-4 col-md-4 col-sm-12 col-xs-12'><strong>Your Coupon Code :</strong></div>" +
           "<div class='col-lg-8 col-md-8 col-sm-12 col-xs-12'><div class='input-group'><input type='text' id='txtCode' readonly='true' class='form-control' value='" + CouponCode + "'/>" +
           "<span class='input-group-btn'><button class='btn btn-primary' id='copyBlock' onclick='CopyCouponCode()' type='button'>Copy</button></span></div></div></div>" +
           "<div class='row'><div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>" +
           "<p>Visit <span style='color:#337ab7;'><b>" + Alt + "</b></span> & paste the above code at checkout</p></div></div>" +
           "<hr />";
    }
    else {
        $("#dvcCode").hide();
        codeHtml += "";
    }
    $("#dvcCode").html(codeHtml);


    $('.couponCodeArea').show();

    if (loginstate == 'False') {
        $("#divGoToStore").hide();
        $('#divhrefWithoutlogin').attr("style", "");
        $('#divhrefLogin').attr("style", "");
        $("#divRedBtn").show();
    } else {
        $('#divGoToStore').attr("style", "");
        $("#divGoToStore").show();
        $("#divRedBtn").hide();
    }

    if (OfferDetails != "") {

        if (OfferDetails == "FLIPKART") {

            $("#spnOfferDetails").show();

            $("#spnOfferDetails").html(Alt);

        }
        else if (OfferDetails != "FLIPKART") {

            $("#spnOfferDetails").show();

            $("#spnOfferDetails").html("<h4><strong>" + Title + "</strong></h4>" + "<h5><span style='color:#cd3232; margin-left:25px;'>" + OfferDetails + "</span></h5>");
        }
    }
    else {

        $("#spnOfferDetails").hide();
    }

    $("#hrefLogin").attr("href", webUrl + "/Muser/MemberLogin.aspx?Rpage=CASHBACK&At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);
    $("#hrefWithoutlogin").attr("href", "get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);
    $("#hrefGoToStore").attr("href", "get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);

    if (Src != '' && Src != 'No') {
        $("#myModalLabel").show();
        var srcLocal = '';
        if (OfferDetails != "FLIPKART") {
            srcLocal = siteUrl + Src;
            //Src = siteUrl + Src;
        }
        $("#myModalLabel").html("<img id='brndImg' class='center-block' src='" + (srcLocal) + "' alt='" + Alt + "' />");
    } else if (Src == 'No') {
        $("#myModalLabel").hide();
    } else {
        $("#myModalLabel").show();
        $("#myModalLabel").html("<div class='breakImage' title='" + Alt + "'>" + Alt + "</div>");
    }


    //// store brand image in local storage 
    if (OfferDetails == "FLIPKART") {
        localStorage.setItem("Frwdurl", (siteUrl + "/Resource/coupons/images/flipkart.png"));
        localStorage.setItem('Frwdalt', "Flipkart");
    } else {
        if (Src != "") {
            localStorage.setItem("Frwdurl", (siteUrl + Src));
        } else {
            localStorage.setItem("Frwdurl", "");
        }
        localStorage.setItem("Frwdalt", Alt);
    }

}

function OnPopupClose() {
    webUrl = $("#hidWebUrl").val();

    $.ajax({
        url: webUrl + "/m-coupons-discounts-cashback/best-deals.aspx/OnPopupClose",
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        data: {},
        beforeSend: function () {
        },
        success: function (response) {
            // debugger;
            var JMemberId = (response.d.JMemberId);
            var JMemberName = (response.d.JMemberName);

            loginstate = JMemberId > 0 ? "True" : "False";
            membername = JMemberName;
            $('#hidMemberName').val(JMemberName);
            $("#hidLoginState").val(JMemberId > 0 ? "True" : "False");
            //$('#ContentPlaceHolder1_hidMemberId').val(JMemberId);
            //$('#ContentPlaceHolder1_hidMemberName').val(JMemberName);

            PopulateLoginPanel1(loginstate);
        },
        complete: function () {
        },
        error: function (response) {
            console.log('Error: Some thing is wrong');
        }
    });
}

function PopulateLoginPanel1(loginstate) {
    siteUrl = $("#hidSiteUrl").val();
    webUrl = $("#hidWebUrl").val();
    var userName = $('#hidMemberName').val();

    SetLoginPanel(loginstate, siteUrl, webUrl, userName);
}
function hideContent(ctrlId) {
    if (ctrlId == 1) {
        $('#divhrefWithoutlogin').attr("style", "display:none");
    }
    if (ctrlId == 2) {
        $('#divhrefLogin').attr("style", "display:none");
    }
    else if (ctrlId == 3) {
        $('#divGoToStore').attr("style", "display:none");
    }
    if ($('#divhrefWithoutlogin').is(':hidden') == true && $('#divGoToStore').is(':hidden') == true) {
        $('.couponCodeArea').hide();
    }
}
function goTo(sender) {

    window.localStorage.removeItem('isredirected');

    var $sender = $(sender);
    var jdata = JSON.parse($sender.attr('data-jdata'));

    At = jdata.At;
    ACI = jdata.ACI;
    Oid = jdata.Oid;
    Purl = jdata.Purl;
    Src = jdata.Src;
    Alt = jdata.Alt;
    Title = jdata.Title;
    OfferDetails = jdata.OfferDetails;
    CouponCode = jdata.CouponCode

    siteUrl = $("#hidSiteUrl").val();

    //// store brand image in local storage  
    if (OfferDetails == "FLIPKART") {
        localStorage.setItem("Frwdurl", (siteUrl + "/Resource/coupons/images/flipkart.png"));
        localStorage.setItem('Frwdalt', Alt);
    } else {
        if (Src != "") {
            localStorage.setItem("Frwdurl", (siteUrl + Src));
        } else {
            localStorage.setItem("Frwdurl", "");
        }
        localStorage.setItem("Frwdalt", Alt);
    }

    var Url = "get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl;
    window.open(Url, '_blank');
}
function CopyCouponCode() {
    var txt = $('#txtCode').val();
    $('#txtCode').select();
    document.execCommand('copy');
    $("#copyBlock").html('Copied');
    $('#copyBlock').removeClass('btn-primary');
    $('#copyBlock').addClass('btn-success');
    $('#txtCode').addClass('form-controlCopied');

}

function openTermAndCondition(sender) {
    var $sender = $(sender)
    var tnc = unescape($sender.data('tnc'));
    var $dvTermAndCon = $('#dvTermAndCon');
    var $p = $dvTermAndCon.find('div.modal-body div');
    $p.html(tnc);
    $('.tncPopup li').first().append('<li>Cashback/Rewards can only be earned from foreseegame to web or mobile web store. It is not for foreseegame to other mobile apps.</li>');
    $dvTermAndCon.modal('show');
}
function DescriptionReadMore() {
    $('.item').each(function (event) {
        var $sender = $(this);
        if (!$sender.hasClass('item-done')) {
            /* select all divs with the item class */
            var max_length = 100; /* set the max content length before a read more link will be added */
            if ($(this).html().length > max_length) { /* check for content length */
                var short_content = $(this).html().substr(0, max_length); /* split the content in two parts */
                var long_content = $(this).html().substr(max_length);
                $(this).html(short_content + '<a href="javascript:void(0)" class="read_more" style="color:#062c4d;">..&nbsp; more</a>' + '<span class="more_text" style="display:none;">' + long_content + '<a href="javascript:void(0)" class="compress" style="color:#062c4d;">&nbsp; less</a></span>'); /* Alter the html to allow the read more functionality */
                $(this).find('a.read_more').click(function (event) { /* find the a.read_more element within the new html and bind the following code to it */
                    event.preventDefault(); /* prevent the a from changing the url */
                    $(this).hide(); /* hide the read more button */
                    $(this).parents('.item').find('.more_text').show(); /* show the .more_text span */
                });
                $(this).find('a.compress').click(function (event) { /* find the a.read_more element within the new html and bind the following code to it */
                    event.preventDefault(); /* prevent the a from changing the url */
                    $('.read_more').show(); /* hide the read more button */
                    $(this).parents('.item').find('.more_text').hide(); /* .slideUp show the .more_text span */
                });
                $sender.addClass('item-done');
            }
        }
    });
}
