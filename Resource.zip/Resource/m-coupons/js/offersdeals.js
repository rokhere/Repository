﻿var membername = '';
var siteUrl = '';
var webUrl = '';
var loginstate = '';
var toggle = true;

function Page_Onload() {
    $('a.oz').addClass('active');
    scrollfix();
    fn_PrepareCarouselNew();

    $(document).on('click', 'ul#CouponSubcategoryLinkArea>li>a', function () {
        $(this).siblings(".subCategoryMobile").stop().slideToggle();
        $(this).closest("li").siblings("li").find(".subCategoryMobile").stop().slideUp();
        $(this).find(".plusMinusIcons").html("-");
        $(this).closest("li").siblings("li").find(".plusMinusIcons").html("+");
    });

    $(".sidebar-icon").click(function () {
        if (toggle) {
            $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
            $("#menu span").css({ "position": "absolute" });
        }
        else {
            $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
            setTimeout(function () {
                $("#menu span").css({ "position": "relative" });
            }, 400);
        }

        toggle = !toggle;

    });

    // BS tabs hover (instead - hover write - click)
    $('.tbQS').hover(function (e) {
        $(".tab-content").addClass('displayNone');
        e.preventDefault()
    });// PatchUp Code

    $('.tab-menu li a').hover(function (e) {
        $(".tab-content").removeClass('displayNone');
        e.preventDefault()
        $(this).tab('show')
    })

    $('#leftTabFunction').mouseleave(function (e) {
        $(".tab-content").addClass('displayNone');
        e.preventDefault()
        $("#leftTabFunction .tab-pane").removeClass('active in');
        $(".tab-menu li").removeClass('active');
    });

    $(window).scroll(function () {
        scrollfix();
    });
}

function SetUrl(sender) {

    window.localStorage.removeItem('isredirected');
    //debugger;
    var $sender = $(sender);
    var jdata = JSON.parse($sender.attr('data-jdata'));

    Section = jdata.Section;
    At = jdata.At;
    ACI = jdata.ACI;
    Oid = jdata.Oid;
    Purl = jdata.Purl;
    Src = jdata.Src;
    Alt = jdata.Alt;
    OfferDetails = jdata.OfferDetails;

    webUrl = $("#hidWebUrl").val();
    siteUrl = $("#hidSiteUrl").val();
    loginstate = $("#hidLoginState").val();

    if (Alt != '') {
        $("#spnBrndName").html(Alt);
    } else {
        $("#spnBrndName").hide();
    }

    $('.couponCodeArea').show();

    if (loginstate == 'False') {
        $("#divGoToStore").hide();
        $('#divhrefWithoutlogin').attr("style", "");
        $('#divhrefLogin').attr("style", "");
        $("#divRedBtn").show();
    } else {
        $('#divGoToStore').attr("style", "");
        $("#divGoToStore").show();
        $("#divRedBtn").hide();
    }

    if (OfferDetails != '') {

        $("#spnOfferDetails").show();

        if (Section == 'QS') {
            OfferDetails = 'Store Offers <span style="color:red;"> + ' + OfferDetails + ' from Foreseegame </span>';
        }

        $("#spnOfferDetails").html(OfferDetails);

    } else {
        $("#spnOfferDetails").hide();
    }

    $("#hrefLogin").attr("href", webUrl + "/Muser/MemberLogin.aspx?Rpage=CASHBACK&At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);
    $("#hrefWithoutlogin").attr("href", "get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);
    $("#hrefGoToStore").attr("href", "get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl);

    if (Src != '' && Src != 'No') {
        $("#myModalLabel").show();
        $("#myModalLabel").html("<img id='brndImg' class='center-block' src='" + (siteUrl + Src) + "' alt='" + Alt + "' />");
    } else if (Src == 'No') {
        $("#myModalLabel").hide();
    } else {
        $("#myModalLabel").show();
        $("#myModalLabel").html("<div class='breakImage' title='" + Alt + "'>" + Alt + "</div>");
    }

    //// store brand image in local storage  
    if (Section == 'QS' || Src != 'No') {
        localStorage.setItem("Frwdurl", (siteUrl + Src));
    } else {
        localStorage.setItem("Frwdurl", "");
    }
    localStorage.setItem('Frwdalt', Alt);

}

function OnPopupClose() {
    webUrl = $("#hidWebUrl").val();

    $.ajax({
        url: webUrl + "/m-coupons-discounts-cashback/best-deals.aspx/OnPopupClose",
        type: "POST",
        dataType: "json",
        contentType: "application/json",
        data: {},
        beforeSend: function () {
        },
        success: function (response) {
            var JMemberId = (response.d.JMemberId);
            var JMemberName = (response.d.JMemberName);

            loginstate = JMemberId > 0 ? "True" : "False";
            membername = JMemberName;
            $('#hidMemberName').val(JMemberName);
            $("#hidLoginState").val(JMemberId > 0 ? "True" : "False");
            //$('#ContentPlaceHolder1_hidMemberId').val(JMemberId);
            //$('#ContentPlaceHolder1_hidMemberName').val(JMemberName);

            PopulateLoginPanel1(loginstate);
        },
        complete: function () {
        },
        error: function (response) {
            console.log('Error: Some thing is wrong');
        }
    });
}

function PopulateLoginPanel1(loginstate) {
    // debugger;   
    siteUrl = $("#hidSiteUrl").val();
    webUrl = $("#hidWebUrl").val();
    var userName = $('#hidMemberName').val();

    SetLoginPanel(loginstate, siteUrl, webUrl, userName);
}

function hideContent(ctrlId) {
    if (ctrlId == 1) {
        $('#divhrefWithoutlogin').attr("style", "display:none");
    }
    if (ctrlId == 2) {
        $('#divhrefLogin').attr("style", "display:none");
    }
    else if (ctrlId == 3) {
        $('#divGoToStore').attr("style", "display:none");
    }
    if ($('#divhrefWithoutlogin').is(':hidden') == true && $('#divGoToStore').is(':hidden') == true) {
        $('.couponCodeArea').hide();
    }
}

function SetPosition() {

    var winHeight = $(window).height();
    var winSTop = $(window).scrollTop();
    var HeaderHeight = 0;
    var position = $('#hidPosition').val();
    var id = "";
    $("#hidIsClick").val("1");
    if (position == '0') {
        id = "ContentPlaceHolder1_divQuickStores";
        HeaderHeight = $('#divQuickStoreHeader').height() * 4;
        //$("#spnText").text("Hot Deals");
        $("#divSetPosition").show();
        $('#hidPosition').val("1");
    }
    else if (position == '1') {
        id = "ContentPlaceHolder1_divTopStores";
        HeaderHeight =  $('#divTopStoreHeader').height();
        $("#spnText").text("");
        $("#divSetPosition").hide();
        $('#hidPosition').val("0");
    }
    $('html,body').animate({ scrollTop: $("#" + id).offset().top - HeaderHeight }, 'slow');
}

function scrollfix() {


    var winHeight = $(window).height();
    var winSTop = $(window).scrollTop();
    var qsHeaderHeight = $('#divQuickStoreHeader').height() * 2;
    var tsHeaderHeight = $('#divTopStoreHeader').height() * 2;

    if (winHeight + winSTop < $('#ContentPlaceHolder1_divQuickStores').offset().top) {
        $('#hidPosition').val("0");
        $("#spnText").text("Quick Stores");
        $("#divSetPosition").show();
    }

    if ((winHeight + winSTop - qsHeaderHeight) > $('#ContentPlaceHolder1_divQuickStores').offset().top) {
        $('#hidPosition').val("1");
        $("#spnText").text("Hot Deals");
    }

    if ((winHeight + winSTop - tsHeaderHeight) > $('#ContentPlaceHolder1_divTopStores').offset().top) {
        $('#hidPosition').val("0");
        $("#divSetPosition").hide();
    }


}

function goTo(sender) {

    window.localStorage.removeItem('isredirected');

    var $sender = $(sender);
    var jdata = JSON.parse($sender.attr('data-jdata'));

    Section = jdata.Section;
    At = jdata.At;
    ACI = jdata.ACI;
    Oid = jdata.Oid;
    Purl = jdata.Purl;
    Src = jdata.Src;
    Alt = jdata.Alt;
    OfferDetails = jdata.OfferDetails;

    siteUrl = $("#hidSiteUrl").val();

    //// store brand image in local storage  

    if (Section == 'QS' || Src != 'No') {
        localStorage.setItem("Frwdurl", (siteUrl + Src));      
    } else {
        localStorage.setItem("Frwdurl", "");
    }

    localStorage.setItem('Frwdalt', Alt);

    var Url = "get-deals-offeres.aspx?At=" + At + "&ACI=" + ACI + "&Oid=" + Oid + "&Purl=" + Purl;
    window.open(Url, '_blank');
}

function catShowMore() {

    var catShowMore = $('#lnkShowMore').text();
    if (catShowMore == "More") {
        $('#lnkShowMore').text('Less');
        $('.ebrand_default').removeClass('displayNone');
    }
    else {
        $('#lnkShowMore').text('More');
        var catList = $('.ebrand_default');
        catList.slice(+6).addClass('displayNone');
        $(window).scrollTop(0);
    }
}