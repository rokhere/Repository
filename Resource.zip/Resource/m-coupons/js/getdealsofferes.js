﻿var siteUrl = '';
var webUrl = '';

var i = 0;
$(document).ready(function () {
    var isredirected = window.localStorage.getItem('isredirected') || '0';
    var FRWDSRC = localStorage.getItem("Frwdurl");
    var FRWDALT = localStorage.getItem("Frwdalt");
    siteUrl = $("#hidSiteUrl").val();

    //Manage back click
    if (window.localStorage.getItem('isredirected') === '1') {
        window.history.go(-1);
    }

    if (FRWDSRC == "") {
        $("#FrwArea").html("<img src='" + siteUrl + "/Resource/coupons/images/shopping-cart.png' id='frwIMG' style='max-width: 100%;' class='img-responsive' alt='" + FRWDALT + "' />");
        //$("#FrwArea").html("<div class='breakImage'>" + FRWDALT + "</div>");
    } else {
        $("#FrwArea").html("<img src='" + FRWDSRC + "' id='frwIMG' alt='" + FRWDALT + "' />");
    }

    //$("#frwIMG").attr("src", FRWDSRC);
    //$("#frwIMG").attr("alt", FRWDALT);

    //localStorage.removeItem('alt');
    //localStorage.removeItem('url');

    ShowCurrentTime();
})
function ShowCurrentTime() {
    var rurl = $('#hdnRedUrl').val();
    siteUrl = $("#hidSiteUrl").val();
    webUrl = $("#hidWebUrl").val();

    if (rurl != null) {

        var dt = new Date();

        if (i == 2) {
            window.localStorage.setItem('isredirected', '1');
            document.getElementById("lblTime").innerHTML = 2 - i + " Second(s)";
            window.location.href = rurl
            //setTimeout("location.href='" + rurl + "'", 0);    
        } else if (i < 2) {
            document.getElementById("lblTime").innerHTML = 2 - i + " Second(s)";
        }

        i++;

        window.setTimeout("ShowCurrentTime()", 1000);

    } else {
        setTimeout("location.href= '" + webUrl + "/m-coupons-discounts-cashback/offers-deals.aspx'", 0);
    }


    //window.setTimeout(window.location.href = rurl, 1000);

    //window.setTimeout(function () {

    //    // Move to a new location or you can do something else       
    //    window.location.href = rurl;
    //}, 5000);
}