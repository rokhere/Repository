﻿var membername = '';
var siteUrl = '';
var webUrl = '';
var loginstate = '';
var dbStores = [];

function searchStoresXXX(txt, attr) {

    siteUrl = $("#hidSiteUrl").val();
    attr = attr || 'storetype';

    if (attr == 'cashbacktype' || attr == 'storetype') {
        $('#txtSearchStore').val("");
        //if (attr == 'storetype') {
        //    $('#ddlCashbackType').val("");
        //}
    }
    else {
        $('#ddlStoreType').val("");
        $('#ddlCashbackType').val("");
    }

    var re = txt.split(' ').join('');
    var searchTerm = re.toLowerCase();
    var isfound = false;
    var count = 0;

    if (attr == 'stores') {
        //fn_SortDescendingByAttribute('data-offersCount');
        if (txt.length == 1) {
            $('#dvRowTopStores').html(dbStores);
        }
        $('.storedata[data-' + attr + ']').each(function () {
            var $sender = $(this);

            var datastore = $sender.attr("data-" + attr);

            if (datastore.toLowerCase().indexOf(searchTerm) > -1) {
                $sender.stop(true, true).fadeIn(500);
                isfound = true;
                count = count + 1;
            }
            else {
                $sender.stop(true, true).fadeOut(500);
            }
        });
    }
    else {
        if ($('#ddlCashbackType').val().length > 0) {
            fn_SortDescendingByAttribute('data-cashbackValue');
        }
        else {
            $('#dvRowTopStores').html(dbStores);
            //fn_SortDescendingByAttribute('data-offersCount');
        }

        $('.storedata[data-cashbacktype],.storedata[data-storetype]').each(function () {
            var $sender = $(this);

            var dataCashbacktype = $sender.attr("data-cashbacktype");
            var dataStoretype = $sender.attr("data-storetype");

            if (dataCashbacktype.toLowerCase().indexOf($('#ddlCashbackType').val().toLowerCase()) > -1 && dataStoretype.toLowerCase().indexOf($('#ddlStoreType').val().toLowerCase()) > -1) {
                $sender.stop(true, true).fadeIn(500);
                isfound = true;
                count = count + 1;
            }
            else {
                $sender.stop(true, true).fadeOut(500);
            }
        });

    }

    if (isfound) {
        $('#searchCount').show();
        $('#noSearchFound').hide();
        $('#searchCount').text(count + ' Record(s) found.');
    } else {
        $('#searchCount').hide();
        $('#noSearchFound').show();
        $('#noSearchFound').html("<b>We will provide you the requested Stores with exciting Deals shortly.</b>");
    }
}
function searchStores(txt, attr) {
    siteUrl = $("#hidSiteUrl").val();
    attr = attr || 'storetype';

    if (attr == 'cashbacktype' || attr == 'storetype') {
        $('#txtSearchStore').val("");
        //if (attr == 'storetype') {
        //    $('#ddlCashbackType').val("");
        //}
    }
    else {
        $('#ddlStoreType').val("");
        $('#ddlCashbackType').val("");
    }

    var re = txt.split(' ').join('');
    var searchTerm = re.toLowerCase();
    var isfound = false;
    var count = 0;

    if (attr == 'stores') {
        //fn_SortDescendingByAttribute('data-offersCount');
        if (txt.length == 1) {
            $('#dvRowTopStores').html(dbStores);
        }
        $('.storedata[data-' + attr + ']').each(function () {
            var $sender = $(this);

            var datastore = $sender.attr("data-" + attr);

            if (datastore.toLowerCase().indexOf(searchTerm) > -1) {
                $sender.stop(true, true).fadeIn(500);
                isfound = true;
                count = count + 1;
            }
            else {
                $sender.stop(true, true).fadeOut(500);
            }
        });
    }
    else {
        if ($('#ddlCashbackType').val().length > 0) {
            fn_SortDescendingByAttribute('data-cashbackValue');
        }
        else {
            $('#dvRowTopStores').html(dbStores);
            //fn_SortDescendingByAttribute('data-offersCount');
        }

        $('.storedata[data-cashbacktype],.storedata[data-storetype]').each(function () {
            var $sender = $(this);

            var dataCashbacktype = $sender.attr("data-cashbacktype");
            var dataStoretype = $sender.attr("data-storetype");

            if (dataCashbacktype.toLowerCase().indexOf($('#ddlCashbackType').val().toLowerCase()) > -1 && dataStoretype.toLowerCase().indexOf($('#ddlStoreType').val().toLowerCase()) > -1) {
                $sender.stop(true, true).fadeIn(500);
                isfound = true;
                count = count + 1;
            }
            else {
                $sender.stop(true, true).fadeOut(500);
            }
        });

    }

    if (isfound) {
        $('#searchCount').show();
        $('#noSearchFound').hide();
        $('#searchCount').text(count + ' Record(s) found.');
    } else {
        $('#searchCount').hide();
        $('#noSearchFound').show();

        if (attr == 'stores') {
            $('#noSearchFound').html("<img src='" + siteUrl + "/Resource/coupons/images/whyPeoplePreferUsHeadingIcon.png' /> <br/> <b>No matching Stores! Search other Stores.</b>");
        }
        else {
            $('#noSearchFound').html("<img src='" + siteUrl + "/Resource/coupons/images/whyPeoplePreferUsHeadingIcon.png' /> <br/> <b>We will provide you the requested Stores with exciting Deals shortly.</b>");
        }
    }
}

function fn_SortDescendingByAttribute(attribute) {
    var $dvRowTopStores = $('#dvRowTopStores div.brandsLogo');
    //Prepare Array
    var items = $dvRowTopStores.children();
    var arry = [];
    for (var i = 0; i < items.length; i++) {
        arry.push({ value: $(items[i]).attr(attribute), item: items[i] });
    }

    //Sort Array
    arry.sort(sortDescendingNumber);

    //Render Sorted Array
    $dvRowTopStores.html('');
    for (var i = 0; i < arry.length; i++) {
        $dvRowTopStores.append(arry[i].item);
    }
}

function sortDescendingNumber(a, b) {
    return b.value - a.value;
}

window.addEventListener('load', function () {
    dbStores = $('#dvRowTopStores').children();
}, false);

function Page_Onload() {
    $('a.hd').addClass('active');
    $('#txtSearchStore').val('');
    $('#ddlCashbackType').val('');
    $('#ddlStoreType').val('');
}
